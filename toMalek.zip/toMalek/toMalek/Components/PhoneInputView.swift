import SwiftUI

// Telefon numarası giriş bileşeni
// Desteklenen ülkeler:
// - Türkçe konuşan: TR
// - Arapça konuşan: AE, SA, EG, QA, BH, KW, OM
// - İngilizce konuşan: US, GB, CA, AU, NZ, IE
// - İspanyolca konuşan: ES, MX, AR, CO, CL
// - Fransızca konuşan: FR, BE, CH, CA
// - Almanca konuşan: DE, AT, CH
// - AB Ülkeleri: NL, IT, PT, GR, SE, DK, FI, PL
struct PhoneInputView: View {
    @Binding var text: String
    let label: LocalizedStringKey
    let placeholder: LocalizedStringKey
    var error: String? = nil
    
    @State private var isValid: Bool = true
    @State private var selectedRegion: String = "TR"
    @State private var localNumber: String = ""
    
    // Desteklenen ülke kodları
    private let regions = [
        // Türkçe
        "TR",
        // Arapça
        "AE", "SA", "EG", "QA", "BH", "KW", "OM",
        // İngilizce
        "US", "GB", "CA", "AU", "NZ", "IE",
        // İspanyolca
        "ES", "MX", "AR", "CO", "CL",
        // Fransızca
        "FR", "BE", "CH",
        // Almanca
        "DE", "AT",
        // AB Ülkeleri
        "NL", "IT", "PT", "GR", "SE", "DK", "FI", "PL"
    ]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .foregroundColor(.primary)
                .font(.subheadline)
            
            HStack {
                // Ülke kodu seçici
                Menu {
                    ForEach(regions.sorted(), id: \.self) { region in
                        Button(action: {
                            selectedRegion = region
                            formatNumber()
                        }) {
                            Text("\(countryName(for: region))")
                        }
                    }
                } label: {
                    Text("+\(getCountryCode(for: selectedRegion))")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                }
                
                TextField(placeholder, text: $localNumber)
                    .keyboardType(.numberPad)
                    .onChange(of: localNumber) { oldValue, newValue in
                        let filtered = newValue.filter { $0.isNumber }
                        if filtered != newValue {
                            localNumber = filtered
                        }
                        formatNumber()
                    }
            }
            .padding(8)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
            
            if let error = error, !isValid {
                Text(LocalizedStringKey(error))
                    .foregroundColor(.red)
                    .font(.caption)
            }
        }
        .onAppear {
            // İlk yüklemede mevcut numarayı parse et
            if !text.isEmpty {
                parseStoredNumber()
            }
        }
    }
    
    private func formatNumber() {
        let numbers = localNumber.filter { $0.isNumber }
        
        // Ülkeye göre minimum uzunluk kontrolü
        let minLength = getMinLength(for: selectedRegion)
        isValid = numbers.count >= minLength
        
        // Formatlı gösterim için
        localNumber = formatLocal(numbers, for: selectedRegion)
        
        // Kaydetmek için E164 formatı
        text = "+\(getCountryCode(for: selectedRegion))\(numbers)"
    }
    
    private func parseStoredNumber() {
        // E164 formatındaki numarayı parse et (+901234567890)
        if text.hasPrefix("+"), let firstDigit = text.dropFirst().first {
            // Ülke kodunu bul
            let countryCode = String(firstDigit)
            for region in regions {
                if getCountryCode(for: region).hasPrefix(countryCode) {
                    selectedRegion = region
                    localNumber = String(text.dropFirst(getCountryCode(for: region).count + 1))
                    formatNumber()
                    return
                }
            }
        }
        // Parse edilemezse direkt göster
        localNumber = text
    }
    
    private func formatLocal(_ numbers: String, for region: String) -> String {
        switch region {
        case "TR": // (5XX) XXX XX XX
            guard numbers.count >= 10 else { return numbers }
            return String(format: "(%@) %@ %@ %@",
                         String(numbers.prefix(3)),
                         String(numbers.dropFirst(3).prefix(3)),
                         String(numbers.dropFirst(6).prefix(2)),
                         String(numbers.dropFirst(8).prefix(2)))
            
        case "US", "CA": // (XXX) XXX-XXXX
            guard numbers.count >= 10 else { return numbers }
            return String(format: "(%@) %@-%@",
                         String(numbers.prefix(3)),
                         String(numbers.dropFirst(3).prefix(3)),
                         String(numbers.dropFirst(6).prefix(4)))
            
        case "GB": // XXXX XXXXXX
            guard numbers.count >= 10 else { return numbers }
            return String(format: "%@ %@",
                         String(numbers.prefix(4)),
                         String(numbers.dropFirst(4)))
            
        default: // Diğer ülkeler için basit format
            var formatted = numbers
            if numbers.count > 3 {
                formatted.insert(" ", at: formatted.index(formatted.startIndex, offsetBy: 3))
            }
            if numbers.count > 6 {
                formatted.insert(" ", at: formatted.index(formatted.startIndex, offsetBy: 7))
            }
            return formatted
        }
    }
    
    private func countryName(for countryCode: String) -> String {
        let current = Locale(identifier: "tr_TR")
        return current.localizedString(forRegionCode: countryCode) ?? countryCode
    }
    
    private func getCountryCode(for region: String) -> String {
        // Ülke kodları
        let codes = [
            "TR": "90",
            "US": "1", "GB": "44", "CA": "1", "AU": "61", "NZ": "64", "IE": "353",
            "AE": "971", "SA": "966", "EG": "20", "QA": "974", "BH": "973", "KW": "965", "OM": "968",
            "ES": "34", "MX": "52", "AR": "54", "CO": "57", "CL": "56",
            "FR": "33", "BE": "32", "CH": "41",
            "DE": "49", "AT": "43",
            "NL": "31", "IT": "39", "PT": "351", "GR": "30", "SE": "46", "DK": "45", "FI": "358", "PL": "48"
        ]
        return codes[region] ?? "90"
    }
    
    private func getMinLength(for region: String) -> Int {
        switch region {
        case "TR": return 10 // 5XX XXX XXXX
        case "US", "CA": return 10 // XXX XXX XXXX
        case "GB": return 10 // XXXX XXXXXX
        case "AE", "SA", "QA", "BH", "KW", "OM": return 8 // Körfez ülkeleri
        default: return 9 // Diğer ülkeler için
        }
    }
}

#Preview {
    struct PreviewWrapper: View {
        @State private var phoneNumber = ""
        
        var body: some View {
            PhoneInputView(
                text: $phoneNumber,
                label: "phone_number_label",
                placeholder: "phone_number_placeholder",
                error: "phone_number_invalid"
            )
            .padding()
        }
    }
    
    return PreviewWrapper()
}
