import Foundation
import SwiftUI
import PhoneNumberKit

// MARK: - Currency Format (CurrencyType enum'unuzla birlikte)
@propertyWrapper
struct CurrencyFormat: Codable {
    var wrappedValue: String
    let currency: CurrencyType
    
    init(wrappedValue: String = "0,00", currency: CurrencyType) {
        self.wrappedValue = Self.format(wrappedValue, currency: currency)
        self.currency = currency
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.wrappedValue = try container.decode(String.self, forKey: .wrappedValue)
        self.currency = try container.decode(CurrencyType.self, forKey: .currency)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(wrappedValue, forKey: .wrappedValue)
        try container.encode(currency, forKey: .currency)
    }
    
    private enum CodingKeys: String, CodingKey {
        case wrappedValue
        case currency
    }
    
    private static func format(_ value: String, currency: CurrencyType) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = currency.rawValue
        formatter.locale = Locale.current
        
        // Türkçe ve İngilizce format için özel ayar
        switch currency {
        case .try:
            formatter.currencyDecimalSeparator = ","
            formatter.currencyGroupingSeparator = "."
        default:
            break
        }
        
        if let number = Double(value),
           let formatted = formatter.string(from: NSNumber(value: number)) {
            return formatted
        }
        return "\(currency.symbol)\(value)"
    }
}

// MARK: - Phone Format
@propertyWrapper
struct PhoneFormat: Codable {
    var wrappedValue: String
    
    init(wrappedValue: String) {
        self.wrappedValue = Self.format(wrappedValue)
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let value = try container.decode(String.self)
        self.wrappedValue = Self.format(value)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(wrappedValue)
    }
    
    public static func format(_ value: String) -> String {
        let cleanedValue = value.filter { $0.isNumber }
        guard cleanedValue.count >= 10 else { return value }
        
        var numberWithoutCode = cleanedValue
        if numberWithoutCode.hasPrefix("90") {
            numberWithoutCode = String(numberWithoutCode.dropFirst(2))
        }
        
        let last10 = String(numberWithoutCode.suffix(10))
        let parts = [
            String(last10.prefix(3)),
            String(last10.dropFirst(3).prefix(3)),
            String(last10.dropFirst(6).prefix(2)),
            String(last10.dropFirst(8))
        ]
        
        return String(
            format: NSLocalizedString("phone_number_format", comment: ""),
            parts[0], parts[1], parts[2], parts[3]
        )
    }
}

@propertyWrapper
struct UppercaseFormat: Codable {
    var wrappedValue: String
    
    init(wrappedValue: String) {
        self.wrappedValue = wrappedValue.uppercased()
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let value = try container.decode(String.self)
        self.wrappedValue = value.uppercased()
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(wrappedValue)
    }
}

extension String {
    func formatPhoneNumber() -> String {
        // Sadece rakamları al
        let numbers = self.filter { $0.isNumber }
        guard !numbers.isEmpty else { return self }
        
        // E164 formatında mı kontrol et (+901234567890)
        var numberWithoutCode = numbers
        if numbers.hasPrefix("90") {
            numberWithoutCode = String(numbers.dropFirst(2))
        } else if self.hasPrefix("+90") {
            numberWithoutCode = String(numbers.dropFirst(2))
        }
        
        // Son 10 haneyi al
        let last10 = String(numberWithoutCode.suffix(10))
        guard last10.count == 10 else { return self }
        
        // +90 (532) 123 45 67 formatında göster
        return String(format: "+90 (%@) %@ %@ %@",
                     String(last10.prefix(3)),
                     String(last10.dropFirst(3).prefix(3)),
                     String(last10.dropFirst(6).prefix(2)),
                     String(last10.dropFirst(8)))
    }
}
