//
//  Rows.swift
//  toMalek
//

import SwiftUI
import FirebaseFirestore

// Mark: PortfolioView
struct PortfolioRow: View {
    let portfolio: PortfolioModel
    let onEdit: () -> Void
    let onCall: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(portfolio.fullName)
                        .font(.headline)
                    
                    if !portfolio.companyName.isEmpty {
                        Text(portfolio.companyName)
                            .font(.subheadline)
                            .foregroundColor(.areapolSecondary)
                    }
                }
                
                Spacer()
                
                HStack(spacing: 12) {
                    Button(action: onCall) {
                        Image(systemName: "phone.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                    
                    Button(action: onEdit) {
                        Image(systemName: "pencil.circle.fill")
                            .font(.title2)
                            .foregroundColor(.orange)
                    }
                }
            }
            
            HStack(spacing: 8) {
                ForEach(portfolio.interests, id: \.self) { interest in
                    Label(interest.displayName, systemImage: interest.icon)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.blue.opacity(0.1))
                        .foregroundColor(.blue)
                        .clipShape(Capsule())
                }
            }
            .lineLimit(1)
            .mask(
                HStack(spacing: 0) {
                    LinearGradient(
                        gradient: Gradient(colors: [.black, .black, .clear]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                }
            )
        }
        .padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

// Mark: Document Row
struct DocumentRow: View {
    let document: PortfolioDocument
    @State private var showingOptions = false
    let onPreview: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        Button(action: onPreview) {
            HStack {
                Image(systemName: document.type.icon)
                    .foregroundColor(.blue)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(document.name)
                        .font(.subheadline)
                        .foregroundColor(.areapolPrimary)
                    
                    Text(document.createdAt.formatted(date: .numeric, time: .shortened))
                        .font(.caption)
                        .foregroundColor(.areapolSecondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.areapolSecondary)
            }
            .contentShape(Rectangle())
        }
        .contextMenu {
            Button {
                onEdit()
            } label: {
                Label(String(localized: "edit"), systemImage: "pencil")
            }
            
            Button(role: .destructive) {
                onDelete()
            } label: {
                Label(String(localized: "delete"), systemImage: "trash")
            }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) {
                onDelete()
            } label: {
                Label(String(localized: "delete"), systemImage: "trash")
            }
            
            Button {
                onEdit()
            } label: {
                Label(String(localized: "edit"), systemImage: "pencil")
            }
            .tint(.blue)
        }
        .padding(.vertical, 4)
    }
}

// Yeni Status Row komponenti
   
// Rows.swift içindeki StatusRow'u güncelle
struct StatusRow: View {
    let icon: String
    let title: LocalizedStringKey
    let status: String
    let backgroundColor: Color
    let textColor: Color
    let isEditable: Bool
    let menuContent: (() -> AnyView)?
    
    init(
        icon: String,
        title: LocalizedStringKey,
        status: String,
        backgroundColor: Color,
        textColor: Color,
        isEditable: Bool = false,
        menuContent: (() -> AnyView)? = nil
    ) {
        self.icon = icon
        self.title = title
        self.status = status
        self.backgroundColor = backgroundColor
        self.textColor = textColor
        self.isEditable = isEditable
        self.menuContent = menuContent
    }
    
    var body: some View {
        HStack {
            // Sol taraf - başlık ve ikon
            HStack(spacing: TLayout.spacingXS) {
                Image(systemName: icon)
                    .foregroundColor(textColor)
                Text(title)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
            }
            
            Spacer()
            
            // Sağ taraf - status
            if isEditable, let menuContent = menuContent {
                menuContent()
                    .font(TFont.bodyBold)
                    .foregroundColor(textColor)
                    .padding(.horizontal, TLayout.spacingS)
                    .padding(.vertical, TLayout.spacingXS)
                    .background(backgroundColor)
                    .cornerRadius(TLayout.cornerRadius)
            } else {
                Text(status)
                    .font(TFont.bodyBold)
                    .foregroundColor(textColor)
                    .padding(.horizontal, TLayout.spacingS)
                    .padding(.vertical, TLayout.spacingXS)
                    .background(backgroundColor)
                    .cornerRadius(TLayout.cornerRadius)
            }
        }
    }
}


struct FormTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .font(TFont.body)
            .padding(TLayout.spacingXS)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(TColor.areapolPrimary.opacity(0.2), lineWidth: 1)
            )
    }
}
