//
//  PhotosPickers.swift
//  toMalek
//
//  Created by Selman Erbay on 30.01.2025.
//

import SwiftUI
import PhotosUI

// MARK: Portfolio İçin Photo Picker
struct PortfolioPhotosPickerItem: Identifiable, Hashable {
    let id = UUID()
    let pickerItem: PhotosPickerItem
    
    static func == (lhs: PortfolioPhotosPickerItem, rhs: PortfolioPhotosPickerItem) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

// MARK: - Portfolio İçin Image Picker
struct PortfolioImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.dismiss) var dismiss
    var sourceType: UIImagePickerController.SourceType
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: PortfolioImagePicker
        
        init(_ parent: PortfolioImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            parent.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}

struct PortfolioPhotosPicker: View {
    @Binding var selectedItems: [PortfolioPhotosPickerItem]
    let onCompletion: ([PortfolioPhotosPickerItem]) -> Void
    @State private var photosPickerItem: PhotosPickerItem?
    
    var body: some View {
        PhotosPicker(
            selection: $photosPickerItem,
            matching: .images,
            photoLibrary: .shared()
        ) {
            Label(String(localized: "choose_photo"), systemImage: "photo")
        }
        .onChange(of: photosPickerItem) { _, newItem in
            if let item = newItem {
                let portfolioItem = PortfolioPhotosPickerItem(pickerItem: item)
                selectedItems = [portfolioItem]
                onCompletion(selectedItems)
                photosPickerItem = nil
            }
        }
    }
}
