//
//  FilterChip.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import SwiftUI

struct FilterChip: View {
    let title: LocalizedStringKey
    @Binding var isSelected: Bool
    var icon: String? = nil
    
    @Namespace private var animation
    
    var body: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                isSelected.toggle()
            }
        }) {
            HStack(spacing: TLayout.spacingXS) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(TFont.footnote)
                }
                
                Text(title)
                    .font(TFont.footnote)
                
                if isSelected {
                    Image(systemName: "checkmark")
                        .font(TFont.caption)
                        .matchedGeometryEffect(id: "check", in: animation)
                }
            }
            .padding(.horizontal, TLayout.paddingXS)
            .padding(.vertical, TLayout.spacingXS)
            .foregroundColor(isSelected ? TColor.onPrimary : TColor.textSecondary)
            .background(
                Capsule()
                    .fill(isSelected ? TColor.areapolPrimary : TColor.surface)
            )
            .overlay(
                Capsule()
                    .strokeBorder(
                        isSelected ? TColor.areapolPrimary : TColor.border,
                        lineWidth: 1
                    )
            )
            .contentShape(Capsule())
        }
        .buttonStyle(ScaleButtonStyle())
    }
}

// Basılma animasyonu için özel button style
struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

/// Özel filtre seçici bileşeni
/// - İkon ve başlık içerir
/// - Seçili durumda özel renk
/// - Açılır menü şeklinde
struct SpecialFilterChip<T: Hashable>: View {
    let icon: String
    let title: String
    let selectedTitle: String?
    let isSelected: Bool
    let items: [T]
    let itemTitle: (T) -> String
    let onSelect: (T?) -> Void
    let iconColor: Color
    
    init(
        icon: String,
        title: String,
        selectedTitle: String?,
        isSelected: Bool,
        items: [T],
        itemTitle: @escaping (T) -> String,
        onSelect: @escaping (T?) -> Void,
        iconColor: Color = TColor.areapolPrimary
    ) {
        self.icon = icon
        self.title = title
        self.selectedTitle = selectedTitle
        self.isSelected = isSelected
        self.items = items
        self.itemTitle = itemTitle
        self.onSelect = onSelect
        self.iconColor = iconColor
    }
    
    var body: some View {
        Menu {
            Button("Tümü") {
                onSelect(nil)
            }
            ForEach(items, id: \.self) { item in
                Button(itemTitle(item)) {
                    onSelect(item)
                }
            }
        } label: {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(isSelected ? iconColor : iconColor.opacity(0.6))
                Text(selectedTitle ?? title)
                    .foregroundColor(isSelected ? TColor.areapolPrimary : TColor.textSecondary)
                Image(systemName: "chevron.down")
                    .foregroundColor(isSelected ? TColor.areapolPrimary : TColor.textSecondary)
            }
            .font(TFont.body)
            .padding(.horizontal, TLayout.paddingXS)
            .padding(.vertical, TLayout.spacingXS)
            .background(
                Capsule()
                    .fill(isSelected ? TColor.areapolPrimary.opacity(0.1) : TColor.surface)
            )
            .overlay(
                Capsule()
                    .strokeBorder(
                        isSelected ? TColor.areapolPrimary : TColor.border,
                        lineWidth: 1
                    )
            )
        }
    }
}
