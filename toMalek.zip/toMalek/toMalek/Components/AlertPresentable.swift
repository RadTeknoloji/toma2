//
//  AlertPresentable.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

protocol AlertPresentable: View {
    func presentError(_ message: String?, onDismiss: @escaping () -> Void) -> Alert
}

extension AlertPresentable {
    func presentError(_ message: String?, onDismiss: @escaping () -> Void) -> Alert {
        Alert(
            title: Text(String(localized: "error")),
            message: message.map { Text($0).font(TFont.body) },
            dismissButton: .cancel(Text(String(localized: "ok"))) {
                onDismiss()
            }
        )
    }
}
