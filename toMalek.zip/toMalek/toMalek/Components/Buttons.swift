//
//  Buttons.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import SwiftUI

// MARK: - Button Styles
struct PrimaryButtonStyle: ButtonStyle {
    var isLoading: Bool = false
    var isDisabled: Bool = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isDisabled ? Color.border.opacity(0.3) : Color.blue)
            )
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .overlay(
                Group {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    }
                }
            )
            .disabled(isDisabled || isLoading)
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    var isDisabled: Bool = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .foregroundColor(isDisabled ? .border : .blue)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isDisabled ? Color.border.opacity(0.3) : Color.blue, lineWidth: 2)
            )
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .disabled(isDisabled)
    }
}

struct IconButtonStyle: ButtonStyle {
    var backgroundColor: Color = .blue
    var size: CGFloat = 44
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 20))
            .foregroundColor(.white)
            .frame(width: size, height: size)
            .background(
                Circle()
                    .fill(backgroundColor)
            )
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .shadow(color: backgroundColor.opacity(0.3), radius: 8, x: 0, y: 4)
    }
}

// MARK: - Custom Button Views
struct PrimaryButton: View {
    let title: LocalizedStringKey
    let action: () -> Void
    var isLoading: Bool = false
    var isDisabled: Bool = false
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .opacity(isLoading ? 0 : 1)
        }
        .buttonStyle(PrimaryButtonStyle(isLoading: isLoading, isDisabled: isDisabled))
    }
}

struct SecondaryButton: View {
    let title: LocalizedStringKey
    let action: () -> Void
    var isDisabled: Bool = false
    
    var body: some View {
        Button(action: action) {
            Text(title)
        }
        .buttonStyle(SecondaryButtonStyle(isDisabled: isDisabled))
    }
}

struct IconButton: View {
    let icon: String
    let action: () -> Void
    var backgroundColor: Color = .blue
    var size: CGFloat = 44
    
    var body: some View {
        Button(action: action) {
            Image(systemName: icon)
        }
        .buttonStyle(IconButtonStyle(backgroundColor: backgroundColor, size: size))
    }
}

// MARK: - Preview
struct Buttons_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            PrimaryButton(title: LocalizedStringKey("button_save"), action: {})
            PrimaryButton(title: LocalizedStringKey("button_loading"), action: {}, isLoading: true)
            PrimaryButton(title: LocalizedStringKey("button_disabled"), action: {}, isDisabled: true)
            
            SecondaryButton(title: LocalizedStringKey("button_cancel"), action: {})
            SecondaryButton(title: LocalizedStringKey("button_disabled"), action: {}, isDisabled: true)
            
            HStack(spacing: 20) {
                IconButton(icon: "plus", action: {})
                IconButton(icon: "trash", action: {}, backgroundColor: .red)
                IconButton(icon: "pencil", action: {}, backgroundColor: .orange, size: 36)
            }
        }
        .padding()
        .previewLayout(.sizeThatFits)
    }
}
