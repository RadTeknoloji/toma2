//
//  PortfolioViewModel.swift
//  toMalek
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import FirebaseStorage
import SwiftUI
import PhotosUI

@MainActor
@preconcurrency protocol PortfolioViewModelProtocol: ObservableObject {
    var portfolios: [PortfolioModel] { get set }
    var selectedPortfolio: PortfolioModel? { get set }
    var showDeleteConfirmation: Bool { get set }
    var portfolioToDelete: PortfolioModel? { get set }
    var isLoading: Bool { get set }
    var errorMessage: String? { get set }
    
    func fetchPortfolios() async
    func clearForm() async
    func createPortfolio() async -> Bool
    func updatePortfolio(_ portfolio: PortfolioModel) async -> Bool
    func deletePortfolio(_ portfolio: PortfolioModel) async
    func uploadDocument(data: Data, fileName: String, type: PortfolioDocument.DocumentType, for portfolio: PortfolioModel) async
    func updateDocumentName(_ document: PortfolioDocument, newName: String, in portfolio: PortfolioModel) async
    func deleteDocument(_ document: PortfolioDocument, from portfolio: PortfolioModel) async
}

@MainActor
final class PortfolioViewModel: PortfolioViewModelProtocol {
    private let db = Firestore.firestore()
    private let storage = Storage.storage()
    private let authState = ServiceContainer.shared.authenticationState
    
    @Published var portfolios: [PortfolioModel] = []
    @Published var selectedPortfolio: PortfolioModel?
    @Published var showDeleteConfirmation = false
    @Published var portfolioToDelete: PortfolioModel?
    @Published var isLoading = false
    @Published var errorMessage: String?

    
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // Form fields
    @Published var fullName = ""
    @Published var companyName = ""
    @Published var phoneNumber = ""
    @Published var city = ""
    @Published var selectedInterests: Set<PropertyTypeForPortfolio> = []
    
    // Document handling
    @Published var selectedItems: [PortfolioPhotosPickerItem] = []
    @Published var selectedImage: UIImage?
    @Published var showingDocumentPicker = false
    @Published var showingDocumentOptions = false
    @Published var showingScanner = false
    @Published var showingPhotoPicker = false
    
    // Document editing
    @Published var editingDocumentId: UUID?
    @Published var showingDocumentNameEdit = false
    @Published var newDocumentName = ""
    

    
    init() {
        fetchPortfolios()
    }
    
    var isValidForm: Bool {
        isValidFullName && isValidPhoneNumber
    }
    
    var isValidFullName: Bool {
        !fullName.isEmpty && fullName.count >= 3
    }
    
    var isValidPhoneNumber: Bool {
        let digitsOnly = phoneNumber.filter { $0.isNumber }
        return digitsOnly.count >= 10
    }
    
    func loadPortfolioData(_ portfolio: PortfolioModel) {
        fullName = portfolio.fullName
        companyName = portfolio.companyName
        phoneNumber = portfolio.phoneNumber
        city = portfolio.city
        selectedInterests = Set(portfolio.interests)
    }
    
        func clearForm() {
        fullName = ""
        companyName = ""
        phoneNumber = ""
        city = ""
        selectedInterests = []
        selectedPortfolio = nil
    }
    
    func updatePortfolio(_ portfolio: PortfolioModel) -> Bool {
        guard isValidForm else {
            errorMessage = String(localized: "fill_required_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        let updatedPortfolio = PortfolioModel(
            id: portfolio.id,
            fullName: fullName,
            companyName: companyName,
            phoneNumber: phoneNumber,
            city: city,
            interests: Array(selectedInterests),
            status: portfolio.status,
            createdBy: portfolio.createdBy,
            documents: portfolio.documents
        )
        
        do {
            let ref = db.collection("portfolios").document(portfolio.id.uuidString)
            try ref.setData(from: updatedPortfolio)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_updating"), error.localizedDescription)
            return false
        }
    }
    
    func fetchPortfolios() {
        guard let userId = currentUserId else {
            errorMessage = String(localized: "user_not_logged_in")
            return
        }
        
        isLoading = true
        
        db.collection("portfolios")
            .whereField("createdBy", isEqualTo: userId)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("Portfolios fetch error: \(error.localizedDescription)")
                    self.errorMessage = String(format: String(localized: "error_fetching_data"), error.localizedDescription)
                    self.isLoading = false
                    return
                }
                
                self.portfolios = querySnapshot?.documents.compactMap { doc in
                    try? doc.data(as: PortfolioModel.self)
                } ?? []
                
                print("Fetched \(self.portfolios.count) portfolios")
                self.isLoading = false
            }
    }
    
    func createPortfolio() async -> Bool {
        guard let userId = currentUserId, isValidForm else {
            errorMessage = String(localized: "fill_required_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        let newPortfolio = PortfolioModel(
            id: UUID(),
            fullName: fullName,
            companyName: companyName,
            phoneNumber: phoneNumber,
            city: city,
            interests: Array(selectedInterests),
            status: .potential,
            createdBy: userId,  // Kullanıcı ID'sini kaydediyoruz
            documents: []
        )
        
        do {
            print("Creating portfolio for user: \(userId)")
            let ref = db.collection("portfolios").document(newPortfolio.id.uuidString)
            try ref.setData(from: newPortfolio)
            clearForm()
            return true
        } catch {
            print("Portfolio creation error: \(error.localizedDescription)")
            errorMessage = String(format: String(localized: "error_adding_portfolio"), error.localizedDescription)
            return false
        }
    }
    
    /// Belgeyi Firebase Storage'a yükler ve Firestore'u günceller
    /// - Parameters:
    ///   - data: Yüklenecek belge verisi
    ///   - fileName: Dosya adı
    ///   - type: Belge tipi (fotoğraf veya PDF)
    ///   - portfolio: Belgenin ekleneceği portföy
    func uploadDocument(data: Data, fileName: String, type: PortfolioDocument.DocumentType, for portfolio: PortfolioModel) async {
        // Eşzamanlı yüklemeleri engelle
        guard !isLoading, let userId = currentUserId else {
            print("Hata: Zaten yükleme yapılıyor veya kullanıcı girişi yok")
            return
        }
        
        // Portföy ID'sini kontrol et
        let portfolioId = portfolio.id.uuidString
        guard !portfolioId.isEmpty else {
            print("Hata: Geçersiz portföy ID")
            errorMessage = "Geçersiz portföy"
            return
        }
        
        // Portföyün yerel listede olup olmadığını kontrol et
        guard portfolios.contains(where: { $0.id == portfolio.id }) else {
            print("Hata: Portföy yerel listede bulunamadı. ID: \(portfolioId)")
            errorMessage = "Portföy bulunamadı"
            return
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            // 1. Firebase Storage'a yükleme
            let storagePath = "portfolios/\(userId)/\(portfolioId)/\(UUID().uuidString)_\(fileName)"
            let storageRef = storage.reference().child(storagePath)
            
            print("Yükleme yolu: \(storagePath)")
            
            let metadata = StorageMetadata()
            metadata.contentType = type == .photo ? "image/jpeg" : "application/pdf"
            
            // Veriyi Storage'a yükle
            print("Veri Storage'a yükleniyor...")
            _ = try await storageRef.putDataAsync(data, metadata: metadata)
            
            // İndirme URL'sini al
            print("İndirme URL'si alınıyor...")
            let downloadURL = try await storageRef.downloadURL()
            print("İndirme URL'si alındı: \(downloadURL.absoluteString)")
            
            // 2. Firestore'u güncelle
            let portfolioRef = db.collection("portfolios").document(portfolioId)
            
            // Portföyün var olup olmadığını kontrol et
            print("Portföy kontrol ediliyor: \(portfolioId)")
            let document = try await portfolioRef.getDocument()
            
            guard document.exists else {
                print("Hata: Portföy dokümanı bulunamadı. ID: \(portfolioId)")
                errorMessage = "Portföy bulunamadı"
                
                // Firestore'da portföyü yeniden oluştur
                print("Portföy dokümanı yeniden oluşturuluyor...")
                try await portfolioRef.setData([
                    "id": portfolioId,
                    "createdBy": userId,
                    "createdAt": Date(),
                    "documents": []
                ])
                
                // İşlemi tekrar dene
                return await uploadDocument(data: data, fileName: fileName, type: type, for: portfolio)
            }
            
            // Dokümanı decode et
            do {
                var currentPortfolio = try document.data(as: PortfolioModel.self)
                
                // Yeni belge oluştur
                let newDocument = PortfolioDocument(
                    id: UUID(),
                    name: fileName,
                    url: downloadURL.absoluteString,
                    type: type,
                    createdAt: Date()
                )
                
                // Belgeyi portföye ekle
                print("Yeni belge portföye ekleniyor...")
                currentPortfolio.documents.append(newDocument)
                
                // Firestore'u güncelle
                print("Firestore güncelleniyor...")
                try portfolioRef.setData(from: currentPortfolio)
                print("Belge yükleme başarıyla tamamlandı")
                
                // Yerel veriyi güncelle
                if let index = portfolios.firstIndex(where: { $0.id == portfolio.id }) {
                    portfolios[index] = currentPortfolio
                }
                
            } catch let decodeError {
                print("Portföy decode hatası: \(decodeError.localizedDescription)")
                errorMessage = "Portföy verileri okunamadı"
                return
            }
            
        } catch {
            // Hataları yönet
            print("Belge yükleme hatası: \(error.localizedDescription)")
            errorMessage = String(format: String(localized: "error_uploading_document"), error.localizedDescription)
        }
    }
    
    func updateDocumentName(_ document: PortfolioDocument, newName: String, in portfolio: PortfolioModel) async {
        guard !newName.isEmpty, let _ = currentUserId else { return }
        isLoading = true
        defer { isLoading = false }
        
        do {
            let portfolioRef = db.collection("portfolios").document(portfolio.id.uuidString)
            let documentSnapshot = try await portfolioRef.getDocument()
            
            guard var currentPortfolio = try? documentSnapshot.data(as: PortfolioModel.self) else {
                print("Error: Could not decode portfolio")
                return
            }
            
            if let index = currentPortfolio.documents.firstIndex(where: { $0.id == document.id }) {
                let updatedDocument = PortfolioDocument(
                    id: document.id,
                    name: newName,
                    url: document.url,
                    type: document.type,
                    createdAt: document.createdAt
                )
                currentPortfolio.documents[index] = updatedDocument
                
                try portfolioRef.setData(from: currentPortfolio)
                
                // Yerel veriyi güncelle
                if let portfolioIndex = portfolios.firstIndex(where: { $0.id == portfolio.id }) {
                    portfolios[portfolioIndex] = currentPortfolio
                }
            }
        } catch {
            print("Document name update error: \(error.localizedDescription)")
            errorMessage = String(format: String(localized: "error_updating_document"), error.localizedDescription)
        }
    }
    
    func deleteDocument(_ document: PortfolioDocument, from portfolio: PortfolioModel) async {
        guard currentUserId != nil else { return }
        isLoading = true
        defer { isLoading = false }
        
        do {
            // Storage'dan sil
            try await storage.reference(forURL: document.url).delete()
            
            // Firestore'u güncelle
            let portfolioRef = db.collection("portfolios").document(portfolio.id.uuidString)
            let documentSnapshot = try await portfolioRef.getDocument()
            
            guard var currentPortfolio = try? documentSnapshot.data(as: PortfolioModel.self) else {
                print("Error: Could not decode portfolio")
                return
            }
            
            currentPortfolio.documents.removeAll { $0.id == document.id }
            try portfolioRef.setData(from: currentPortfolio)
            
            // Yerel veriyi güncelle
            if let index = portfolios.firstIndex(where: { $0.id == portfolio.id }) {
                portfolios[index] = currentPortfolio
            }
            
        } catch {
            print("Document deletion error: \(error.localizedDescription)")
            errorMessage = String(format: String(localized: "error_deleting_document"), error.localizedDescription)
        }
    }
    
    
    nonisolated func performDatabaseOperation<T>(_ operation: @escaping () async throws -> T) async throws -> T {
        do {
            return try await operation()
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
            }
            throw error
        }
    }
    
    func deletePortfolio(_ portfolio: PortfolioModel) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            try await performDatabaseOperation {
                // Delete documents from storage
                for document in portfolio.documents {
                    try await self.storage.reference(forURL: document.url).delete()
                }
                
                // Delete portfolio document
                try await self.db.collection("portfolios").document(portfolio.id.uuidString).delete()
                
                await MainActor.run {
                    self.portfolios.removeAll { $0.id == portfolio.id }
                    self.portfolioToDelete = nil
                }
            }
        } catch {
            errorMessage = String(format: String(localized: "error_deleting"), error.localizedDescription)
        }
    }
}
