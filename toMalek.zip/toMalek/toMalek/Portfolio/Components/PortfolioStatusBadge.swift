//
//  PortfolioStatusBadge.swift
//  toMalek
//
//  Created by Selman Erbay on 14.02.2025.
//

import SwiftUI

/// Portföy durumunu gösteren rozet bileşeni
/// - Durum rengine göre arka plan
/// - Durum adı
struct PortfolioStatusBadge: View {
    let status: PortfolioStatus
    
    var body: some View {
        Text(status.displayName)
            .font(TFont.caption)
            .foregroundColor(.white)
            .padding(.horizontal, TLayout.paddingXS)
            .padding(.vertical, 4)
            .background(statusBackground)
            .cornerRadius(TLayout.cornerRadiusS)
    }
    
    private var statusBackground: Color {
        switch status {
        case .active:
            return TColor.success
        case .potential:
            return TColor.warning
        }
    }
}
