//
//  PortfolioRowView.swift
//  toMalek
//
//  Created by Selman Erbay on 14.02.2025.
//

import SwiftUI

/// Portföy listesi için satır görünümü
/// - Portföy sahibinin avatarı/ikonu
/// - İsim ve durum
/// - Şirket adı
/// - Alt bilgiler (şehir, ilgi alanları, belgeler)
///
struct PortfolioRowView: View {
    let portfolio: PortfolioModel
    
    var body: some View {
        HStack(spacing: TLayout.spacingM) {
            // Avatar/İkon
            ZStack {
                Circle()
                    .fill(TColor.areapolPrimary.opacity(0.1))
                    .frame(width: 48, height: 48)
                
                Text(portfolio.fullName.prefix(1).uppercased())
                    .font(TFont.h2)
                    .foregroundColor(TColor.areapolPrimary)
            }
            
            // Bilgi Alanı
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                // İsim ve Durum
                HStack {
                    Text(portfolio.fullName)
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                    
                    Spacer()
                    
                    PortfolioStatusBadge(status: portfolio.status)
                }
                
                // Şirket Adı
                if !portfolio.companyName.isEmpty {
                    Text(portfolio.companyName)
                        .font(TFont.body)
                        .foregroundColor(TColor.textSecondary)
                }
                
                // Alt Bilgiler
                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                    // Şehir
                    if !portfolio.city.isEmpty {
                        HStack(spacing: TLayout.spacingXS) {
                            Image(systemName: "mappin.circle.fill")
                                .foregroundColor(TColor.areapolPrimary)
                            Text(portfolio.city)
                                .font(TFont.caption)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                    
                    // İlgi Alanları
                    if !portfolio.interests.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: TLayout.spacingXS) {
                                ForEach(portfolio.interests, id: \.self) { interest in
                                    Text(interest.displayName)
                                        .font(TFont.caption)
                                        .foregroundColor(TColor.textSecondary)
                                        .padding(.horizontal, TLayout.paddingXS)
                                        .padding(.vertical, 4)
                                        .background(TColor.border.opacity(0.1))
                                        .cornerRadius(TLayout.cornerRadiusS)
                                }
                            }
                        }
                    }
                    
                    // Belgeler
                    if !portfolio.documents.isEmpty {
                        HStack(spacing: TLayout.spacingXS) {
                            Image(systemName: "doc.fill")
                                .foregroundColor(TColor.areapolPrimary)
                            Text("\(portfolio.documents.count) belge")
                                .font(TFont.caption)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                }
            }
        }
        .padding(TLayout.paddingS)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}
