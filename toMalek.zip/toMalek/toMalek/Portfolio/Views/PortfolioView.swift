//
//  PortfolioView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI

struct PortfolioView<ViewModel: PortfolioViewModelProtocol>: View {
    @ObservedObject var viewModel: ViewModel
    @State private var showingForm = false
    @State private var selectedCity: String?
    @State private var selectedInterest: PropertyTypeForPortfolio?
    @State private var selectedStatus: PortfolioStatus?
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filtreler
                filterSection
                    .padding(.horizontal, TLayout.paddingS)
                
                // Liste
                portfolioList
            }
            .navigationTitle(String(localized: "my_portfolio"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { toolbarItems }
            .overlay { loadingOverlay }
            .sheet(isPresented: $showingForm) {
                NavigationStack {
                    PortfolioFormSheet(
                        viewModel: viewModel,
                        showingForm: $showingForm
                    )
                }
            }
            .errorAlert(errorMessage: viewModel.errorMessage) {
                viewModel.errorMessage = nil
            }
            .deleteConfirmation(
                isPresented: $viewModel.showDeleteConfirmation,
                portfolio: viewModel.portfolioToDelete
            ) { portfolio in
                Task {
                    await viewModel.deletePortfolio(portfolio)
                }
            }
        }
    }
    
    // MARK: - Liste Görünümü
    private var portfolioList: some View {
        ScrollView {
            LazyVStack(spacing: TLayout.spacingS) {
                ForEach(filteredPortfolios) { portfolio in
                    portfolioLink(for: portfolio)
                }
            }
            .padding(.horizontal, TLayout.paddingS)
        }
    }
    
    private func portfolioLink(for portfolio: PortfolioModel) -> some View {
        NavigationLink {
            if let portfolioViewModel = viewModel as? PortfolioViewModel {
                PortfolioDetailView(viewModel: portfolioViewModel, portfolio: portfolio)
            }
        } label: {
            PortfolioRowView(portfolio: portfolio)
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button(role: .destructive) {
                handleDelete(portfolio: portfolio)
            } label: {
                Label(String(localized: "delete"), systemImage: "trash")
            }
        }
    }
    
    // MARK: - Filtreleme
    private var filterSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: TLayout.spacingS) {
                // Şehir Filtresi
                cityFilterMenu
                
                // İlgi Alanı Filtresi
                interestFilterMenu
                
                // Durum Filtresi
                statusFilterMenu
            }
            .padding(.vertical, TLayout.paddingXS)
        }
    }
    
    private var cityFilterMenu: some View {
        SpecialFilterChip(
            icon: "mappin.circle.fill",
            title: "Şehir",
            selectedTitle: selectedCity,
            isSelected: selectedCity != nil,
            items: Array(Set(viewModel.portfolios.map(\.city))).sorted(),
            itemTitle: { $0 },
            onSelect: { selectedCity = $0 },
            iconColor: .blue
        )
    }
    
    private var interestFilterMenu: some View {
        SpecialFilterChip(
            icon: "tag.fill",
            title: "İlgi Alanı",
            selectedTitle: selectedInterest?.displayName,
            isSelected: selectedInterest != nil,
            items: PropertyTypeForPortfolio.allCases,
            itemTitle: { $0.displayName },
            onSelect: { selectedInterest = $0 },
            iconColor: .orange
        )
    }
    
    private var statusFilterMenu: some View {
        SpecialFilterChip(
            icon: "circle.fill",
            title: "Durum",
            selectedTitle: selectedStatus?.displayName,
            isSelected: selectedStatus != nil,
            items: PortfolioStatus.allCases,
            itemTitle: { $0.displayName },
            onSelect: { selectedStatus = $0 },
            iconColor: .green
        )
    }
    
    private var filteredPortfolios: [PortfolioModel] {
        viewModel.portfolios.filter { portfolio in
            (selectedCity == nil || portfolio.city == selectedCity) &&
            (selectedInterest == nil || portfolio.interests.contains(selectedInterest!)) &&
            (selectedStatus == nil || portfolio.status == selectedStatus)
        }
    }
    
    // MARK: - Components
    private var toolbarItems: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            AddButton(viewModel: viewModel, showingForm: $showingForm)
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                LoadingView(text: String(localized: "loading_portfolio"))
            }
        }
    }
    
    private func handleDelete(portfolio: PortfolioModel) {
        viewModel.portfolioToDelete = portfolio
        viewModel.showDeleteConfirmation = true
    }
}

// MARK: - Helper Views
private struct AddButton: View {
    let viewModel: any PortfolioViewModelProtocol
    @Binding var showingForm: Bool
    
    var body: some View {
        Button {
            showingForm = true
        } label: {
            Image(systemName: "plus.circle.fill")
                .font(.title2)
                .foregroundColor(TColor.areapolPrimary)
        }
    }
}

private struct PortfolioFormSheet<ViewModel: PortfolioViewModelProtocol>: View {
    @ObservedObject var viewModel: ViewModel
    @Binding var showingForm: Bool
    
    var body: some View {
        Group {
            if let portfolioViewModel = viewModel as? PortfolioViewModel {
                PortfolioFormView(
                    viewModel: portfolioViewModel,
                    portfolio: viewModel.selectedPortfolio
                ) { success in
                    if success {
                        showingForm = false
                    }
                }
                .navigationTitle(viewModel.selectedPortfolio == nil ?
                    String(localized: "new_portfolio") :
                    String(localized: "edit_portfolio"))
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button(String(localized: "cancel")) {
                            showingForm = false
                        }
                        .foregroundColor(TColor.areapolPrimary)
                    }
                }
                .background(TColor.background)
            }
        }
    }
}

// MARK: - View Modifiers
private extension View {
    func errorAlert(errorMessage: String?, action: @escaping () -> Void) -> some View {
        alert(String(localized: "error"), isPresented: .constant(errorMessage != nil)) {
            Button(String(localized: "ok"), role: .cancel) { action() }
        } message: {
            if let error = errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
    }
    
    func deleteConfirmation(
        isPresented: Binding<Bool>,
        portfolio: PortfolioModel?,
        onDelete: @escaping (PortfolioModel) -> Void
    ) -> some View {
        modifier(DeleteConfirmationModifier(
            isPresented: isPresented,
            portfolio: portfolio,
            onDelete: onDelete
        ))
    }
}

private struct DeleteConfirmationModifier: ViewModifier {
    let isPresented: Binding<Bool>
    let portfolio: PortfolioModel?
    let onDelete: (PortfolioModel) -> Void
    
    func body(content: Content) -> some View {
        content.confirmationDialog(
            String(localized: "delete_portfolio"),
            isPresented: isPresented
        ) {
            if let portfolio = portfolio {
                Button(String(localized: "delete"), role: .destructive) {
                    onDelete(portfolio)
                }
                Button(String(localized: "cancel_action"), role: .cancel) {}
            }
        } message: {
            if let portfolio = portfolio {
                Text(String(format: String(localized: "confirm_delete_portfolio"), portfolio.fullName))
                    .font(TFont.body)
            }
        }
    }
}

// MARK: - Preview Provider
#Preview {
    NavigationView {
        PortfolioView(viewModel: PortfolioViewModel())
            .background(TColor.background)
    }
}
