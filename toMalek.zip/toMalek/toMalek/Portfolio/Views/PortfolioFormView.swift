//
//  PortfolioFormView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI

struct PortfolioFormView: View {
    @ObservedObject var viewModel: PortfolioViewModel
    let portfolio: PortfolioModel?
    let onSave: (Bool) -> Void
    
    var body: some View {
        Form {
            personalInfoSection
            interestsSection
            saveButtonSection
        }
        .scrollDismissesKeyboard(.immediately)
        .background(TColor.background)
        .scrollContentBackground(.hidden)
    }
    
    // MARK: - Form Sections
    private var personalInfoSection: some View {
        Section(String(localized: "personal_info")) {
            fullNameField
            companyNameField
            phoneField
            cityField
        }
        .listRowBackground(TColor.border.opacity(0.1))
    }
    
    private var interestsSection: some View {
        Section(String(localized: "interests")) {
            ForEach(PropertyTypeForPortfolio.allCases, id: \.self) { type in
                Toggle(type.displayName, isOn: Binding(
                    get: { viewModel.selectedInterests.contains(type) },
                    set: { isSelected in
                        if isSelected {
                            viewModel.selectedInterests.insert(type)
                        } else {
                            viewModel.selectedInterests.remove(type)
                        }
                    }
                ))
                .toggleStyle(SwitchToggleStyle(tint: TColor.areapolPrimary))
                .font(TFont.body)
                .foregroundColor(TColor.surfaceDark)
            }
        }
        .listRowBackground(TColor.border.opacity(0.1))
    }
    
    private var saveButtonSection: some View {
        Section {
            Button {
                handleSave()
            } label: {
                Text(String(localized: "save"))
                    .frame(maxWidth: .infinity)
                    .font(TFont.bodyBold)
            }
            .buttonStyle(TButton.Primary())
            .disabled(!viewModel.isValidForm)
        }
    }
    
    // MARK: - Form Fields
    private var fullNameField: some View {
        TextField(String(localized: "full_name"), text: $viewModel.fullName)
            .textContentType(.name)
            .autocapitalization(.words)
            .disableAutocorrection(true)
            .overlay(alignment: .trailing) {
                if !viewModel.fullName.isEmpty && !viewModel.isValidFullName {
                    Image(systemName: "exclamationmark.circle")
                        .foregroundColor(TColor.error)
                        .help(String(localized: "error_fullname"))
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
    }
    
    private var companyNameField: some View {
        TextField(String(localized: "company_name"), text: $viewModel.companyName)
            .textContentType(.organizationName)
            .autocapitalization(.words)
            .disableAutocorrection(true)
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
    }
    
    private var phoneField: some View {
        PhoneInputView(
            text: $viewModel.phoneNumber,
            label: "phone",
            placeholder: "phone_placeholder",
            error: !viewModel.isValidPhoneNumber ? "error_phone" : nil
        )
    }
    
    private var cityField: some View {
        TextField(String(localized: "city"), text: $viewModel.city)
            .textContentType(.addressCity)
            .autocapitalization(.words)
            .disableAutocorrection(true)
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
    }
    
    // MARK: - Actions
    private func handleSave() {
        if let existingPortfolio = portfolio {
            let success = viewModel.updatePortfolio(existingPortfolio)
            onSave(success)
        } else {
            Task {
                let success = await viewModel.createPortfolio()
                onSave(success)
            }
        }
    }
}

#Preview {
    PortfolioFormView(
        viewModel: PortfolioViewModel(),
        portfolio: nil
    ) { _ in }
    .background(TColor.background)
}
