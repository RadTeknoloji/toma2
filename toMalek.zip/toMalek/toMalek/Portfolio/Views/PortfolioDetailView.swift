//
//  PortfolioDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI
import PhotosUI

// MARK: - Active Sheet Enum
enum PortfolioActiveSheet: Identifiable {
    case scanner
    case documentList
    case documentViewer(PortfolioDocument)
    
    var id: String {
        switch self {
        case .scanner: return "scanner"
        case .documentList: return "documentList"
        case .documentViewer(let document): return "viewer_\(document.id)"
        }
    }
}

struct PortfolioDetailView: View {
    @ObservedObject var viewModel: PortfolioViewModel
    let portfolio: PortfolioModel
    @Environment(\.dismiss) private var dismiss
    
    // Sheet ve action sheet durum yönetimi
    @State private var showingEditSheet = false
    @State private var showingDocumentOptions = false
    @State private var showingCamera = false
    @State private var showingImagePicker = false
    @State private var activeSheet: PortfolioActiveSheet?
    @State private var processingDocument = false
    
    // Document handling
    @State private var selectedImage: UIImage?
    
    var body: some View {
        List {
            // Durum Bölümü
            StatusSection(status: portfolio.status)
            
            // Kişisel Bilgiler Bölümü
            PersonalInfoSection(portfolio: portfolio)
            
            // İlgi Alanları Bölümü
            InterestsSection(interests: portfolio.interests)
            
            // Belgeler Bölümü
            DocumentsSection(
                viewModel: viewModel,
                portfolio: portfolio,
                activeSheet: $activeSheet
            )
        }
        .background(TColor.background)
        .navigationTitle(portfolio.fullName)
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack(spacing: TLayout.spacing) {
                    documentOptionsButton
                    contextMenuButton
                }
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            editPortfolioSheet
        }
        .sheet(isPresented: $showingCamera) {
            PortfolioImagePicker(image: $selectedImage, sourceType: .camera)
                .ignoresSafeArea()
                .background(TColor.background)
        }
        .sheet(isPresented: $showingImagePicker) {
            PortfolioImagePicker(image: $selectedImage, sourceType: .photoLibrary)
                .ignoresSafeArea()
                .background(TColor.background)
        }
        .onChange(of: selectedImage) { _, newImage in
            handleImageChange(newImage)
        }
        .sheet(item: $activeSheet) { sheet in
            Group {
                switch sheet {
                case .scanner: scannerSheet
                case .documentList: documentListView
                case .documentViewer(let document): documentViewerView(document)
                }
            }
            .background(TColor.background)
        }
        .alert(String(localized: "edit_document_name"), isPresented: $viewModel.showingDocumentNameEdit) {
            documentNameAlertContent
        }
        .confirmationDialog(
            String(localized: "add_document"),
            isPresented: $showingDocumentOptions,
            titleVisibility: .visible
        ) {
            documentOptionsContent
        }
    }
    
    // MARK: - Private Components
    private var documentOptionsButton: some View {
        Button {
            showingDocumentOptions = true
        } label: {
            Image(systemName: "doc.badge.plus")
                .font(.system(size: TLayout.iconSize))
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    private var contextMenuButton: some View {
        Menu {
            Button {
                viewModel.loadPortfolioData(portfolio)
                showingEditSheet = true
            } label: {
                Label(String(localized: "edit"), systemImage: "pencil")
            }
            
            Button(role: .destructive) {
                viewModel.portfolioToDelete = portfolio
                viewModel.showDeleteConfirmation = true
            } label: {
                Label(String(localized: "delete"), systemImage: "trash")
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.system(size: TLayout.iconSize))
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    private var editPortfolioSheet: some View {
        NavigationStack {
            PortfolioFormView(
                viewModel: viewModel,
                portfolio: portfolio
            ) { success in
                if success {
                    showingEditSheet = false
                    dismiss()
                }
            }
            .navigationTitle(String(localized: "edit_portfolio"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(String(localized: "cancel")) {
                        showingEditSheet = false
                    }
                    .foregroundColor(TColor.areapolPrimary)
                }
            }
            .background(TColor.background)
        }
    }
    
    private var scannerSheet: some View {
        DocumentScannerView { result in
            switch result {
            case .success(let scan):
                guard let pdfData = scan.createPDF() else {
                    viewModel.errorMessage = String(localized: "error_creating_pdf")
                    return
                }
                handleDocumentScan(pdfData)
                
            case .failure(let error):
                viewModel.errorMessage = error.localizedDescription
                activeSheet = nil
            }
        }
    }
    
    private var documentListView: some View {
        NavigationStack {
            PortfolioDocumentsView(viewModel: viewModel, portfolio: portfolio)
        }
    }
    
    private func documentViewerView(_ document: PortfolioDocument) -> some View {
        DocumentViewer(document: document)
    }
    
    private var documentNameAlertContent: some View {
        Group {
            TextField(String(localized: "document_name"), text: $viewModel.newDocumentName)
            Button(String(localized: "cancel"), role: .cancel) {
                viewModel.editingDocumentId = nil
            }
            Button(String(localized: "save")) {
                if let documentId = viewModel.editingDocumentId,
                   let document = portfolio.documents.first(where: { $0.id == documentId }) {
                    Task {
                        await viewModel.updateDocumentName(document, newName: viewModel.newDocumentName, in: portfolio)
                    }
                }
                viewModel.editingDocumentId = nil
            }
        }
    }
    
    private var documentOptionsContent: some View {
        Group {
            Button {
                activeSheet = .scanner
            } label: {
                Label(String(localized: "scan_document"), systemImage: "doc.text.viewfinder")
            }
            
            Button {
                showingCamera = true
            } label: {
                Label(String(localized: "take_photo"), systemImage: "camera")
            }
            
            Button {
                showingImagePicker = true
            } label: {
                Label(String(localized: "choose_photo"), systemImage: "photo.on.rectangle")
            }
            
            Button(String(localized: "cancel"), role: .cancel) {
                showingDocumentOptions = false
            }
        }
    }
    
    // MARK: - Handlers
    private func handleImageChange(_ newImage: UIImage?) {
        if let image = newImage {
            handleImageSelection(image)
        }
        showingCamera = false
        showingImagePicker = false
    }
    
    private func handleImageSelection(_ image: UIImage) {
        Task {
            let fileName = "\(String(localized: "photo_filename"))_\(Date().formatted(date: .numeric, time: .shortened)).jpg"
            if let imageData = image.jpegData(compressionQuality: 0.7) {
                await viewModel.uploadDocument(
                    data: imageData,
                    fileName: fileName,
                    type: .photo,
                    for: portfolio
                )
            }
            selectedImage = nil
        }
    }
    
    private func handleDocumentScan(_ pdfData: Data) {
        Task {
            await viewModel.uploadDocument(
                data: pdfData,
                fileName: "\(String(localized: "scan_filename"))_\(Date().formatted(date: .numeric, time: .shortened)).pdf",
                type: .scan,
                for: portfolio
            )
            activeSheet = nil
        }
    }
}

// MARK: - Bölüm Görünümleri
private struct StatusSection: View {
    let status: PortfolioStatus
    
    var body: some View {
        Section {
            HStack {
                Text(status.displayName)
                    .font(TFont.caption)
                    .padding(.horizontal, TLayout.padding)
                    .padding(.vertical, TLayout.spacing)
                    .background(
                        RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                            .fill(statusBackgroundColor)
                    )
                    .foregroundColor(statusTextColor)
            }
        }
    }
    
    private var statusBackgroundColor: Color {
        status == .active ? TColor.success.opacity(0.2) : TColor.warning.opacity(0.2)
    }
    
    private var statusTextColor: Color {
        status == .active ? TColor.success : TColor.warning
    }
}

private struct PersonalInfoSection: View {
    let portfolio: PortfolioModel
    
    var body: some View {
        Section(String(localized: "personal_info")) {
            PortfolioDetailRow(
                title: String(localized: "full_name"),
                value: portfolio.fullName,
                icon: "person.fill"
            )
            
            if !portfolio.companyName.isEmpty {
                PortfolioDetailRow(
                    title: String(localized: "company_name"),
                    value: portfolio.companyName,
                    icon: "building.2"
                )
            }
            
            phoneNumberRow
                .foregroundColor(TColor.areapolPrimary)
            
            if !portfolio.city.isEmpty {
                PortfolioDetailRow(
                    title: String(localized: "city"),
                    value: portfolio.city,
                    icon: "mappin.circle.fill"
                )
            }
        }
    }
    
    private var phoneNumberRow: some View {
        Button {
            let formattedNumber = portfolio.phoneNumber.formatPhoneNumber()
                .replacingOccurrences(of: " ", with: "")
                .replacingOccurrences(of: "(", with: "")
                .replacingOccurrences(of: ")", with: "")
            guard let url = URL(string: "tel:\(formattedNumber)") else { return }
            UIApplication.shared.open(url)
        } label: {
            PortfolioDetailRow(
                title: String(localized: "phone"),
                value: portfolio.formattedPhoneNumber,
                icon: "phone.fill",
                showChevron: true
            )
        }
        .foregroundColor(TColor.textPrimary)
    }
}

private struct InterestsSection: View {
    let interests: [PropertyTypeForPortfolio]
    
    var body: some View {
        Section(String(localized: "interests")) {
            ForEach(interests, id: \.self) { interest in
                HStack(spacing: TLayout.spacing) {
                    Image(systemName: interest.icon)
                        .foregroundColor(TColor.areapolPrimary)
                    Text(interest.displayName)
                        .font(TFont.body)
                }
            }
        }
    }
}

private struct DocumentsSection: View {
    @ObservedObject var viewModel: PortfolioViewModel
    let portfolio: PortfolioModel
    @Binding var activeSheet: PortfolioActiveSheet?
    
    var body: some View {
        Section(String(localized: "documents")) {
            if portfolio.documents.isEmpty {
                emptyStateView
            } else {
                documentsList
            }
        }
        .headerProminence(.increased)
    }
    
    private var emptyStateView: some View {
        Text(String(localized: "no_documents"))
            .font(TFont.body)
            .foregroundColor(TColor.border)
    }
    
    private var documentsList: some View {
        ForEach(portfolio.documents.sorted(by: { $0.createdAt < $1.createdAt })) { document in
            DocumentRow(
                document: document,
                onPreview: { activeSheet = .documentViewer(document) },
                onEdit: {
                    viewModel.editingDocumentId = document.id
                    viewModel.newDocumentName = document.name
                    viewModel.showingDocumentNameEdit = true
                },
                onDelete: {
                    Task {
                        await viewModel.deleteDocument(document, from: portfolio)
                    }
                }
            )
        }
    }
}

// MARK: - Yardımcı Görünümler
struct PortfolioDetailRow: View {
    let title: String
    let value: String
    var icon: String? = nil
    var showChevron: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacing/2) {
            Text(title)
                .font(TFont.caption)
                .foregroundColor(TColor.border)
            
            HStack(spacing: TLayout.spacing) {
                iconView
                Text(value)
                    .font(TFont.body)
                chevronView
            }
        }
        .padding(.vertical, TLayout.spacing/2)
    }
    
    @ViewBuilder
    private var iconView: some View {
        if let icon = icon {
            Image(systemName: icon)
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    @ViewBuilder
    private var chevronView: some View {
        if showChevron {
            Spacer()
            Image(systemName: "chevron.right")
                .font(TFont.caption)
                .foregroundColor(TColor.border)
        }
    }
}

#Preview {
    PortfolioDetailView(
        viewModel: PortfolioViewModel(),
        portfolio: PortfolioModel(
            id: UUID(),
            fullName: "John Doe",
            companyName: "Doe Real Estate",
            phoneNumber: "5555555555",
            city: "Istanbul",
            interests: [.apartment, .villa],
            status: .active,
            createdBy: "user123",
            documents: []
        )
    )
}
