//
//  PortfolioDocumentsView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI
import PhotosUI
import VisionKit

struct PortfolioDocumentsView: View {
    @ObservedObject var viewModel: PortfolioViewModel
    let portfolio: PortfolioModel
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDocument: PortfolioDocument?
    @State private var activeSheet: ActiveSheet? // Tek sheet yönetimi
    
    enum ActiveSheet: Identifiable {
        case documentViewer(document: PortfolioDocument)
        case scanner
        case photoPicker
        
        var id: String {
            switch self {
            case .documentViewer(let document): return "document_\(document.id)"
            case .scanner: return "scanner"
            case .photoPicker: return "photoPicker"
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            DocumentsList(
                documents: portfolio.documents,
                onDocumentSelect: { document in
                    activeSheet = .documentViewer(document: document)
                },
                onDelete: { document in
                    Task {
                        await viewModel.deleteDocument(document, from: portfolio)
                    }
                }
            )
            .navigationTitle(String(localized: "documents"))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        activeSheet = .scanner // Direkt scanner'ı aç
                    } label: {
                        Image(systemName: "plus")
                    }
                }
                
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Text(String(localized: "close"))
                    }
                }
            }
            .sheet(item: $activeSheet) { sheet in
                switch sheet {
                case .documentViewer(let document):
                    DocumentViewer(document: document)
                case .scanner:
                    DocumentScannerView { result in
                        switch result {
                        case .success(let scan):
                            guard let pdfData = scan.createPDF() else {
                                viewModel.errorMessage = String(localized: "error_creating_pdf")
                                return
                            }
                            
                            Task {
                                await viewModel.uploadDocument(
                                    data: pdfData,
                                    fileName: "Scan_\(Date().formatted(date: .numeric, time: .shortened)).pdf",
                                    type: .scan,
                                    for: portfolio
                                )
                            }
                        case .failure(let error):
                            viewModel.errorMessage = error.localizedDescription
                        }
                        activeSheet = nil
                    }
                case .photoPicker:
                    PortfolioPhotosPicker(selectedItems: $viewModel.selectedItems) { items in
                        Task {
                            for item in items {
                                if let data = try? await item.pickerItem.loadTransferable(type: Data.self) {
                                    await viewModel.uploadDocument(
                                        data: data,
                                        fileName: "Photo_\(Date().formatted(date: .numeric, time: .shortened)).jpg",
                                        type: .photo,
                                        for: portfolio
                                    )
                                }
                            }
                            viewModel.selectedItems = []
                            activeSheet = nil
                        }
                    }
                }
            }
            .alert(
                String(localized: "error"),
                isPresented: .constant(viewModel.errorMessage != nil),
                actions: {
                    Button(String(localized: "ok")) {
                        viewModel.errorMessage = nil
                    }
                },
                message: {
                    if let error = viewModel.errorMessage {
                        Text(error)
                    }
                }
            )
        }
    }
}

// MARK: - Subviews
private struct DocumentsList: View {
    let documents: [PortfolioDocument]
    let onDocumentSelect: (PortfolioDocument) -> Void
    let onDelete: (PortfolioDocument) -> Void
    
    var body: some View {
        List {
            ForEach(documents.sorted(by: { $0.createdAt > $1.createdAt })) { document in
                Button {
                    onDocumentSelect(document)
                } label: {
                    HStack {
                        Image(systemName: document.type.icon)
                            .font(.title2)
                            .foregroundColor(.blue)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(document.name)
                                .font(.subheadline)
                                .foregroundColor(.areapolPrimary)
                            
                            Text(document.createdAt.formatted())
                                .font(.caption)
                                .foregroundColor(.areapolSecondary)
                        }
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right")
                            .foregroundColor(.areapolSecondary)
                            .font(.caption)
                    }
                    .contentShape(Rectangle())
                }
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) {
                        onDelete(document)
                    } label: {
                        Label(String(localized: "delete"), systemImage: "trash")
                    }
                }
            }
        }
    }
}
