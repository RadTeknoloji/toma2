//
//  PortfolioModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseFirestore

struct PortfolioModel: Identifiable, Codable, Hashable {
    let id: UUID
    var fullName: String
    var companyName: String
    var phoneNumber: String
    var city: String
    var interests: [PropertyTypeForPortfolio]
    var status: PortfolioStatus
    var createdBy: String
    var documents: [PortfolioDocument]
    
    var isValidFullName: Bool {
        !fullName.isEmpty && fullName.count >= 3
    }
    
    var isValidPhoneNumber: Bool {
        let numbers = phoneNumber.filter { $0.isNumber }
        return numbers.count >= 10
    }
    
    var formattedPhoneNumber: String {
        phoneNumber.formatPhoneNumber()
    }
}

struct PortfolioDocument: Identifiable, Codable, Hashable {
    let id: UUID
    let name: String
    let url: String
    let type: DocumentType
    let createdAt: Date
    
    enum DocumentType: String, Codable {
        case photo
        case scan
        case file
        
        var icon: String {
            switch self {
            case .photo: return "photo"
            case .scan: return "doc.text.viewfinder"
            case .file: return "doc"
            }
        }
    }
}

enum PortfolioStatus: String, Codable, CaseIterable {
    case potential = "potential"
    case active = "active"
    
    var displayName: String {
        switch self {
        case .potential: return String(localized: "potential")
        case .active: return String(localized: "active")
        }
    }
}

enum PropertyTypeForPortfolio: String, Codable, CaseIterable {
    case apartment = "apartment"
    case villa = "villa"
    case land = "land"
    case field = "field"
    case commercial = "commercial"
    case tourism = "tourism"
    
    var displayName: String {
        switch self {
        case .apartment: return String(localized: "apartment")
        case .villa: return String(localized: "villa")
        case .land: return String(localized: "land")
        case .field: return String(localized: "field")
        case .commercial: return String(localized: "commercial")
        case .tourism: return String(localized: "tourism")
        }
    }
    
    var icon: String {
        switch self {
        case .apartment: return "building.2"
        case .villa: return "house"
        case .land: return "leaf"
        case .field: return "mountain.2"
        case .commercial: return "building.columns"
        case .tourism: return "beach.umbrella"
        }
    }
}
