import Foundation
import FirebaseFirestore
import FirebaseAuth

@MainActor
final class TokenViewModel: ObservableObject {
    private let db = Firestore.firestore()
    
    @Published var totalBalance = 0
    @Published var transactions: [TokenTransactionModel] = []
    @Published var packages: [TokenPackageModel] = []
    @Published var errorMessage: String?
    @Published var isLoading = false
    
    /// Kullanıcının token bakiyesini getirir
    func fetchUserTokens() async {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let snapshot = try await db.collection("tokens")
                .document(userId)
                .getDocument()
            
            totalBalance = snapshot.data()?["totalBalance"] as? Int ?? 0
            
        } catch {
            errorMessage = String(format: NSLocalizedString("token_fetch_error", comment: ""))
        }
    }
    
    /// Kullanıcının token işlem geçmişini getirir
    func fetchTransactionHistory() async {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let transactionDocs = try await db.collection("tokenTransactions")
                .whereField("userId", isEqualTo: userId)
                .order(by: "transactionCreatedAt", descending: true)
                .getDocuments()
            
            transactions = transactionDocs.documents.compactMap { TokenTransactionModel(document: $0) }
            
        } catch {
            errorMessage = String(format: NSLocalizedString("token_transaction_history_error", comment: ""))
        }
    }
    
    /// Token paketlerini getirir
    func fetchTokenPackages() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let packageDocs = try await db.collection("tokenPackages")
                .whereField("tokenPackageIsActive", isEqualTo: true)
                .getDocuments()
            
            print("Token paketleri: \(packageDocs.documents.count)")
            
            packages = packageDocs.documents.compactMap { doc in
                print("Paket verisi: \(doc.data())")
                return TokenPackageModel(document: doc)
            }
            
            print("İşlenen paket sayısı: \(packages.count)")
            
        } catch {
            print("Token paketleri hatası: \(error)")
            errorMessage = String(format: NSLocalizedString("token_packages_fetch_error", comment: ""))
        }
    }
    
    /// Token paketi satın alma işlemi
    func purchaseTokenPackage(_ package: TokenPackageModel, paymentMethod: TokenPaymentMethod) async -> Bool {
        guard let userId = Auth.auth().currentUser?.uid else { return false }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let transactionData: [String: Any] = [
                "userId": userId,
                "tokenAmount": package.tokenAmount,
                "transactionType": TransactionType.purchase.rawValue,
                "transactionStatus": TransactionStatus.pending.rawValue,
                "transactionCreatedAt": Timestamp(date: Date()),
                "transactionPaymentMethod": paymentMethod.rawValue,
                "transactionPrice": package.tokenPackagePrice,
                "transactionCurrency": package.tokenPackageCurrency.rawValue
            ] as [String: Any]
            
            let transactionRef = db.collection("tokenTransactions").document()
            try await transactionRef.setData(transactionData)
            
            let tokenData: [String: Any] = [
                "userId": userId,
                "tokenAmount": package.tokenAmount,
                "tokenType": TokenType.purchased.rawValue,
                "tokenStatus": TokenStatus.active.rawValue,
                "tokenCreatedAt": Timestamp(date: Date()),
                "tokenTransactionId": transactionRef.documentID
            ] as [String: Any]
            
            let tokenRef = db.collection("tokens").document()
            try await tokenRef.setData(tokenData)
            
            try await db.collection("tokens")
                .document(userId)
                .setData(["totalBalance": FieldValue.increment(Int64(package.tokenAmount))] as [String: Any], merge: true)
            
            try await transactionRef.updateData([
                "transactionStatus": TransactionStatus.completed.rawValue
            ] as [String: Any])
            
            await fetchUserTokens()
            await fetchTransactionHistory()
            
            return true
            
        } catch {
            errorMessage = String(format: NSLocalizedString("token_purchase_error", comment: ""))
            return false
        }
    }
    
    /// Token kullanma işlemi
    func useTokens(amount: Int) async -> Bool {
        guard let userId = Auth.auth().currentUser?.uid else { return false }
        guard amount > 0, amount <= totalBalance else { return false }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let transactionData: [String: Any] = [
                "userId": userId,
                "tokenAmount": amount,
                "transactionType": TransactionType.usage.rawValue,
                "transactionStatus": TransactionStatus.completed.rawValue,
                "transactionCreatedAt": Timestamp(date: Date()),
                "transactionCurrency": TokenCurrency.turkishLira.rawValue,
                "transactionPaymentMethod": NSNull(),
                "transactionPrice": NSNull()
            ] as [String: Any]
            
            let transactionRef = db.collection("tokenTransactions").document()
            try await transactionRef.setData(transactionData)
            
            try await db.collection("tokens")
                .document(userId)
                .setData(["totalBalance": FieldValue.increment(Int64(-amount))] as [String: Any], merge: true)
            
            await fetchUserTokens()
            await fetchTransactionHistory()
            
            return true
            
        } catch {
            errorMessage = String(format: NSLocalizedString("token_usage_error", comment: ""))
            return false
        }
    }
}
