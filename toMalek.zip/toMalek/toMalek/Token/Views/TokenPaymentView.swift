import SwiftUI
import FirebaseFirestore

/// Token paketi satın alma sayfası
struct TokenPaymentView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var viewModel: TokenViewModel
    let package: TokenPackageModel
    
    @State private var selectedPaymentMethod: TokenPaymentMethod = .creditCard
    @State private var isProcessing = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: Theme.Layout.padding) {
                    // Paket Detayları
                    VStack(spacing: Theme.Layout.padding) {
                        Text(package.tokenPackageName)
                            .font(Theme.Typography.h2)
                            .foregroundColor(Theme.ColorPalette.textPrimary)
                        
                        HStack(spacing: Theme.Layout.padding) {
                            // Token Miktarı
                            VStack(spacing: Theme.Layout.paddingXXS) {
                                Text("\(package.tokenAmount)")
                                    .font(Theme.Typography.h1)
                                    .foregroundColor(Theme.ColorPalette.areapolPrimary)
                                
                                Text(NSLocalizedString("tokens", comment: ""))
                                    .font(Theme.Typography.footnote)
                                    .foregroundColor(Theme.ColorPalette.textSecondary)
                            }
                            
                            if let bonus = package.tokenBonusAmount, bonus > 0 {
                                // Bonus Miktarı
                                VStack(spacing: Theme.Layout.paddingXXS) {
                                    Text("+\(bonus)")
                                        .font(Theme.Typography.h2)
                                        .foregroundColor(Theme.ColorPalette.success)
                                    
                                    Text(NSLocalizedString("bonus", comment: ""))
                                        .font(Theme.Typography.footnote)
                                        .foregroundColor(Theme.ColorPalette.textSecondary)
                                }
                            }
                        }
                        
                        Text(package.tokenPackageDescription)
                            .font(Theme.Typography.body)
                            .foregroundColor(Theme.ColorPalette.textSecondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(Theme.Layout.padding)
                    .background(Theme.ColorPalette.surface)
                    .cornerRadius(Theme.Layout.cornerRadius)
                    
                    // Ödeme Yöntemi Seçimi
                    VStack(alignment: .leading, spacing: Theme.Layout.padding) {
                        Text(NSLocalizedString("payment_method", comment: ""))
                            .font(Theme.Typography.h3)
                            .foregroundColor(Theme.ColorPalette.textPrimary)
                        
                        ForEach(TokenPaymentMethod.allCases, id: \.self) { method in
                            PaymentMethodButton(
                                method: method,
                                isSelected: selectedPaymentMethod == method
                            ) {
                                selectedPaymentMethod = method
                            }
                        }
                    }
                    .padding(Theme.Layout.padding)
                    .background(Theme.ColorPalette.surface)
                    .cornerRadius(Theme.Layout.cornerRadius)
                    
                    // Toplam Tutar
                    VStack(spacing: Theme.Layout.paddingXS) {
                        HStack {
                            Text(NSLocalizedString("total_amount", comment: ""))
                                .font(Theme.Typography.body)
                                .foregroundColor(Theme.ColorPalette.textSecondary)
                            
                            Spacer()
                            
                            Text("\(package.tokenPackagePrice.formatted()) \(package.tokenPackageCurrency.symbol)")
                                .font(Theme.Typography.h2)
                                .foregroundColor(Theme.ColorPalette.textPrimary)
                        }
                    }
                    .padding(Theme.Layout.padding)
                    .background(Theme.ColorPalette.surface)
                    .cornerRadius(Theme.Layout.cornerRadius)
                }
                .padding(Theme.Layout.padding)
            }
            .background(Theme.ColorPalette.background)
            .navigationTitle(NSLocalizedString("payment", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(NSLocalizedString("cancel", comment: "")) {
                        dismiss()
                    }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    Task {
                        isProcessing = true
                        if await viewModel.purchaseTokenPackage(package, paymentMethod: selectedPaymentMethod) {
                            dismiss()
                        }
                        isProcessing = false
                    }
                } label: {
                    if isProcessing {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .tint(Theme.ColorPalette.onPrimary)
                    } else {
                        Text(NSLocalizedString("confirm_payment", comment: ""))
                    }
                }
                .buttonStyle(Theme.ButtonStyles.Primary())
                .disabled(isProcessing)
                .padding(Theme.Layout.padding)
                .background(Theme.ColorPalette.background)
            }
        }
    }
}

/// Ödeme yöntemi seçim butonu
private struct PaymentMethodButton: View {
    let method: TokenPaymentMethod
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: method.iconName)
                    .font(.system(size: 24))
                    .foregroundColor(isSelected ? Theme.ColorPalette.areapolPrimary : Theme.ColorPalette.textSecondary)
                
                Text(method.displayName)
                    .font(Theme.Typography.body)
                    .foregroundColor(isSelected ? Theme.ColorPalette.textPrimary : Theme.ColorPalette.textSecondary)
                
                Spacer()
                
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(isSelected ? Theme.ColorPalette.areapolPrimary : Theme.ColorPalette.textSecondary)
            }
            .padding(Theme.Layout.padding)
            .background(isSelected ? Theme.ColorPalette.areapolPrimary.opacity(0.1) : Theme.ColorPalette.surface)
            .cornerRadius(Theme.Layout.cornerRadius)
        }
    }
}

// MARK: - TokenPaymentMethod Extensions
extension TokenPaymentMethod {
    var iconName: String {
        switch self {
        case .creditCard: return "creditcard.fill"
        case .bankTransfer: return "building.columns.fill"
        case .applePay: return "apple.logo"
        }
    }
    
    var displayName: String {
        switch self {
        case .creditCard: return NSLocalizedString("credit_card", comment: "")
        case .bankTransfer: return NSLocalizedString("bank_transfer", comment: "")
        case .applePay: return "Apple Pay"
        }
    }
    
    static var allCases: [TokenPaymentMethod] {
        [.creditCard, .bankTransfer, .applePay]
    }
}
