import SwiftUI
import StoreKit

/// Token ana sayfası - Token paketlerini listeler ve bakiyeyi gösterir
struct TokenView: View {
    @StateObject private var viewModel = TokenViewModel()
    @StateObject private var storeKit = StoreKitService.shared
    @State private var selectedProduct: Product?
    @State private var showingPaymentSheet = false
    @State private var showingError = false
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationView {
            tokenContent
        }
    }
    
    private var tokenContent: some View {
        ScrollView {
            VStack(spacing: Theme.Layout.padding) {
                balanceCard
                packagesList
            }
            .padding(Theme.Layout.padding)
        }
        .background(Theme.ColorPalette.background)
        .navigationTitle(NSLocalizedString("tokens", comment: ""))
        .refreshable {
            await viewModel.fetchUserTokens()
            await storeKit.loadProducts()
        }
        .task {
            await viewModel.fetchUserTokens()
            await storeKit.loadProducts()
        }
        .alert(NSLocalizedString("error", comment: ""), isPresented: $showingError) {
            Button(NSLocalizedString("ok", comment: ""), role: .cancel) {}
        } message: {
            if let error = errorMessage {
                Text(error)
            }
        }
    }
    
    private var balanceCard: some View {
        VStack(spacing: Theme.Layout.paddingXS) {
            Text("\(viewModel.totalBalance)")
                .font(Theme.Typography.h1)
                .foregroundColor(Theme.ColorPalette.areapolPrimary)
            
            Text(NSLocalizedString("tokens", comment: ""))
                .font(Theme.Typography.body)
                .foregroundColor(Theme.ColorPalette.textSecondary)
        }
        .padding(Theme.Layout.padding)
        .frame(maxWidth: .infinity)
        .background(Theme.ColorPalette.surface)
        .cornerRadius(Theme.Layout.cornerRadius)
    }
    
    private var packagesList: some View {
        LazyVStack(spacing: Theme.Layout.padding) {
            if storeKit.products.isEmpty {
                Text(NSLocalizedString("no_token_packages", comment: ""))
                    .font(Theme.Typography.body)
                    .foregroundColor(Theme.ColorPalette.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(Theme.Layout.padding)
            } else {
                ForEach(storeKit.products) { product in
                    TokenPackageCard(product: product) {
                        Task {
                            do {
                                if let transaction = try await storeKit.purchase(product) {
                                    print("Satın alma başarılı: \(transaction.productID)")
                                }
                            } catch {
                                errorMessage = error.localizedDescription
                                showingError = true
                            }
                        }
                    }
                }
            }
        }
    }
}

/// Token paketi kartı
private struct TokenPackageCard: View {
    let product: Product
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: Theme.Layout.paddingS) {
                HStack {
                    tokenAmountView
                    Spacer()
                    priceView
                }
                packageDescription
            }
            .padding(Theme.Layout.padding)
            .background(Theme.ColorPalette.surface)
            .cornerRadius(Theme.Layout.cornerRadius)
        }
    }
    
    private var tokenAmountView: some View {
        VStack(alignment: .leading, spacing: Theme.Layout.paddingXXS) {
            Text(getTokenAmount())
                .font(Theme.Typography.h2)
                .foregroundColor(Theme.ColorPalette.areapolPrimary)
            
            Text(NSLocalizedString("tokens", comment: ""))
                .font(Theme.Typography.caption)
                .foregroundColor(Theme.ColorPalette.textSecondary)
        }
    }
    
    private var priceView: some View {
        VStack(alignment: .trailing, spacing: Theme.Layout.paddingXXS) {
            Text(product.displayPrice)
                .font(Theme.Typography.h3)
                .foregroundColor(Theme.ColorPalette.textPrimary)
            
            if let bonus = getBonusAmount() {
                Text(String(format: NSLocalizedString("bonus_tokens", comment: ""), "\(bonus)"))
                    .font(Theme.Typography.caption)
                    .foregroundColor(Theme.ColorPalette.success)
            }
        }
    }
    
    private var packageDescription: some View {
        Text(product.description)
            .font(Theme.Typography.footnote)
            .foregroundColor(Theme.ColorPalette.textSecondary)
            .multilineTextAlignment(.leading)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private func getTokenAmount() -> String {
        switch product.id {
        case "com.tomalek.tokens.5000": return "5.000"
        case "com.tomalek.tokens.10000": return "10.000"
        case "com.tomalek.tokens.20000": return "20.000"
        case "com.tomalek.tokens.100000": return "100.000"
        default: return "0"
        }
    }
    
    private func getBonusAmount() -> Int? {
        switch product.id {
        case "com.tomalek.tokens.5000": return 500
        case "com.tomalek.tokens.10000": return 1500
        case "com.tomalek.tokens.20000": return 4000
        case "com.tomalek.tokens.100000": return 25000
        default: return nil
        }
    }
}

struct TokenView_Previews: PreviewProvider {
    static var previews: some View {
        TokenView()
    }
}
