import SwiftUI

/// Token işlem geçmişi sayfası
struct TokenHistoryView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var viewModel: TokenViewModel
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: TLayout.spacingM) {
                if viewModel.transactions.isEmpty {
                    VStack(spacing: TLayout.spacingM) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 48))
                            .foregroundColor(TColor.textSecondary)
                        
                        Text(String(localized: "no_transactions"))
                            .font(TFont.body)
                            .foregroundColor(TColor.textSecondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, TLayout.spacingXL)
                } else {
                    ForEach(viewModel.transactions) { transaction in
                        TransactionCard(transaction: transaction)
                    }
                }
            }
            .padding(TLayout.spacingM)
        }
        .background(TColor.background)
        .navigationTitle(String(localized: "transaction_history"))
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await viewModel.fetchTransactionHistory()
        }
        .refreshable {
            await viewModel.fetchTransactionHistory()
        }
    }
}

/// İşlem kartı
private struct TransactionCard: View {
    let transaction: TokenTransactionModel
    
    var body: some View {
        VStack(spacing: TLayout.spacingS) {
            HStack {
                // İşlem İkonu
                Image(systemName: transaction.transactionType.iconName)
                    .font(.system(size: 24))
                    .foregroundColor(transaction.transactionType.iconColor)
                    .frame(width: 48, height: 48)
                    .background(transaction.transactionType.iconColor.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadiusL)
                
                VStack(alignment: .leading, spacing: 4) {
                    // İşlem Tipi
                    Text(transaction.transactionType.displayName)
                        .font(TFont.body)
                        .foregroundColor(TColor.textPrimary)
                    
                    // İşlem Tarihi
                    Text(transaction.transactionCreatedAt.formatted())
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                }
                
                Spacer()
                
                // Token Miktarı
                VStack(alignment: .trailing, spacing: 4) {
                    Text(transaction.transactionType.amountPrefix + "\(transaction.tokenAmount)")
                        .font(TFont.body)
                        .foregroundColor(transaction.transactionType.amountColor)
                    
                    // İşlem Durumu
                    Text(transaction.transactionStatus.displayName)
                        .font(TFont.caption)
                        .foregroundColor(transaction.transactionStatus.statusColor)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(transaction.transactionStatus.statusColor.opacity(0.1))
                        .cornerRadius(TLayout.cornerRadiusS)
                }
            }
            
            // Ödeme Detayları
            if let price = transaction.transactionPrice {
                Divider()
                    .padding(.vertical, TLayout.spacingXS)
                
                HStack {
                    if let method = transaction.transactionPaymentMethod {
                        Text(method.displayName)
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                    }
                    
                    Spacer()
                    
                    Text("\(price.formatted()) \(transaction.transactionCurrency.symbol)")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
            }
        }
        .padding(TLayout.spacingM)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}

// MARK: - TransactionType Extensions
extension TransactionType {
    var iconName: String {
        switch self {
        case .purchase: return "cart.fill"
        case .usage: return "arrow.up.circle.fill"
        case .refund: return "arrow.uturn.backward.circle.fill"
        case .reward: return "gift.fill"
        }
    }
    
    var iconColor: Color {
        switch self {
        case .purchase: return TColor.areapolPrimary
        case .usage: return TColor.warning
        case .refund: return TColor.error
        case .reward: return TColor.success
        }
    }
    
    var displayName: String {
        switch self {
        case .purchase: return String(localized: "token_purchase")
        case .usage: return String(localized: "token_usage")
        case .refund: return String(localized: "token_refund")
        case .reward: return String(localized: "token_reward")
        }
    }
    
    var amountPrefix: String {
        switch self {
        case .purchase, .reward: return "+"
        case .usage, .refund: return "-"
        }
    }
    
    var amountColor: Color {
        switch self {
        case .purchase, .reward: return TColor.success
        case .usage, .refund: return TColor.error
        }
    }
}

// MARK: - TransactionStatus Extensions
extension TransactionStatus {
    var displayName: String {
        switch self {
        case .pending: return String(localized: "status_pending")
        case .completed: return String(localized: "status_completed")
        case .failed: return String(localized: "status_failed")
        case .refunded: return String(localized: "status_refunded")
        }
    }
    
    var statusColor: Color {
        switch self {
        case .pending: return TColor.warning
        case .completed: return TColor.success
        case .failed: return TColor.error
        case .refunded: return TColor.info
        }
    }
}

#Preview {
    NavigationView {
        TokenHistoryView(viewModel: TokenViewModel())
    }
}
