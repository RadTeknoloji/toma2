import StoreKit
import FirebaseFirestore
import FirebaseAuth

/// StoreKit ile token satın alma işlemlerini yöneten servis
@MainActor
final class StoreKitService: ObservableObject {
    static let shared = StoreKitService()
    private let db = Firestore.firestore()
    
    @Published private(set) var products: [Product] = []
    @Published private(set) var purchasedProducts: [Product] = []
    
    private var productIDs: [String] = [
        "com.tomalek.tokens.5000",
        "com.tomalek.tokens.10000",
        "com.tomalek.tokens.20000",
        "com.tomalek.tokens.100000"
    ]
    
    private init() {
        Task {
            await loadProducts()
        }
        
        // Transaction listener'ı başlat
        Task {
            await listenForTransactions()
        }
    }
    
    /// Ürünleri StoreKit'ten yükler
    func loadProducts() async {
        do {
            products = try await Product.products(for: productIDs)
        } catch {
            print("Ürünler yüklenemedi: \(error)")
        }
    }
    
    /// Satın alma işlemlerini dinler
    func listenForTransactions() async {
        for await result in StoreKit.Transaction.updates {
            await handle(transactionResult: result)
        }
    }
    
    /// Satın alma işlemini gerçekleştirir
    func purchase(_ product: Product) async throws -> StoreKit.Transaction? {
        let result = try await product.purchase()
        
        switch result {
        case .success(let verification):
            let transaction = try checkVerified(verification)
            await transaction.finish()
            await addTokensToUser(for: product)
            return transaction
            
        case .userCancelled:
            return nil
            
        case .pending:
            return nil
            
        @unknown default:
            return nil
        }
    }
    
    /// Transaction'ı doğrular
    func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .unverified:
            throw StoreError.failedVerification
        case .verified(let safe):
            return safe
        }
    }
    
    /// Satın alma işlemini işler
    private func handle(transactionResult: VerificationResult<StoreKit.Transaction>) async {
        guard let transaction = try? checkVerified(transactionResult) else { return }
        
        // Ürünü satın alınmışlar listesine ekle
        if let product = products.first(where: { $0.id == transaction.productID }) {
            purchasedProducts.append(product)
        }
        
        // Token'ları kullanıcıya ekle
        if let product = products.first(where: { $0.id == transaction.productID }) {
            await addTokensToUser(for: product)
        }
        
        // Transaction'ı tamamla
        await transaction.finish()
    }
    
    /// Kullanıcıya token ekler
    private func addTokensToUser(for product: Product) async {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        // Ürün ID'sine göre token miktarını belirle
        let tokenAmount: Int
        switch product.id {
        case "com.tomalek.tokens.5000":
            tokenAmount = 5000
        case "com.tomalek.tokens.10000":
            tokenAmount = 10000
        case "com.tomalek.tokens.20000":
            tokenAmount = 20000
        case "com.tomalek.tokens.100000":
            tokenAmount = 100000
        default:
            return
        }
        
        do {
            // Transaction oluştur
            let transactionData: [String: Any] = [
                "userId": userId,
                "tokenAmount": tokenAmount,
                "transactionType": TransactionType.purchase.rawValue,
                "transactionStatus": TransactionStatus.completed.rawValue,
                "transactionCreatedAt": Timestamp(date: Date()),
                "transactionPaymentMethod": "apple_pay",
                "transactionPrice": product.price,
                "transactionCurrency": "TRY"
            ] as [String: Any]
            
            let transactionRef = db.collection("tokenTransactions").document()
            try await transactionRef.setData(transactionData)
            
            // Token bakiyesini güncelle
            try await db.collection("tokens")
                .document(userId)
                .setData(["totalBalance": FieldValue.increment(Int64(tokenAmount))] as [String: Any], merge: true)
            
        } catch {
            print("Token ekleme hatası: \(error)")
        }
    }
}

enum StoreError: Error {
    case failedVerification
}
