import Foundation
import FirebaseCore
import FirebaseFirestore

/// Token paketlerini oluşturan script
struct TokenPackageCreator {
    static let packages: [[String: Any]] = [
        [
            "tokenPackageName": "Başlangıç Paketi",
            "tokenPackageDescription": "5.000 token ile toMalek'e başlayın",
            "tokenAmount": 5000,
            "tokenBonusAmount": 500,  // %10 bonus
            "tokenPackagePrice": 499.99,
            "tokenPackageCurrency": "TRY",
            "tokenPackageIsActive": true
        ],
        [
            "tokenPackageName": "Standart Paket",
            "tokenPackageDescription": "10.000 token ile daha fazla kiralama yapın",
            "tokenAmount": 10000,
            "tokenBonusAmount": 1500,  // %15 bonus
            "tokenPackagePrice": 899.99,
            "tokenPackageCurrency": "TRY",
            "tokenPackageIsActive": true
        ],
        [
            "tokenPackageName": "Premium Paket",
            "tokenPackageDescription": "20.000 token ile premium kiralama deneyimi",
            "tokenAmount": 20000,
            "tokenBonusAmount": 4000,  // %20 bonus
            "tokenPackagePrice": 1599.99,
            "tokenPackageCurrency": "TRY",
            "tokenPackageIsActive": true
        ],
        [
            "tokenPackageName": "VIP Paket",
            "tokenPackageDescription": "100.000 token ile sınırsız kiralama özgürlüğü",
            "tokenAmount": 100000,
            "tokenBonusAmount": 25000,  // %25 bonus
            "tokenPackagePrice": 6999.99,
            "tokenPackageCurrency": "TRY",
            "tokenPackageIsActive": true
        ]
    ]
    
    static func createPackages() async throws {
        let db = Firestore.firestore()
        
        for package in packages {
            let _ = try await db.collection("tokenPackages").addDocument(data: package)
        }
        
        print("Token paketleri başarıyla oluşturuldu!")
    }
}

// Script'i çalıştırmak için:
// Task {
//     do {
//         try await TokenPackageCreator.createPackages()
//     } catch {
//         print("Hata: \(error)")
//     }
// }
