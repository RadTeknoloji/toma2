import Foundation
import FirebaseFirestore


/// Token işlemlerini temsil eden yapı
struct TokenTransactionModel: Identifiable, Codable {
    let id: String
    let userId: String
    let tokenAmount: Int
    let transactionType: TransactionType
    let transactionStatus: TransactionStatus
    let transactionCreatedAt: Date
    let transactionPaymentMethod: TokenPaymentMethod?
    let transactionPrice: Double?
    let transactionCurrency: TokenCurrency
    
    /// Firebase dökümanından TokenTransactionModel oluşturur
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let userId = data["userId"] as? String,
              let tokenAmount = data["tokenAmount"] as? Int,
              let transactionTypeRaw = data["transactionType"] as? String,
              let transactionStatusRaw = data["transactionStatus"] as? String,
              let transactionCreatedAt = (data["transactionCreatedAt"] as? Timestamp)?.dateValue(),
              let transactionCurrencyRaw = data["transactionCurrency"] as? String
        else { return nil }
        
        self.id = document.documentID
        self.userId = userId
        self.tokenAmount = tokenAmount
        self.transactionType = TransactionType(rawValue: transactionTypeRaw) ?? .purchase
        self.transactionStatus = TransactionStatus(rawValue: transactionStatusRaw) ?? .pending
        self.transactionCreatedAt = transactionCreatedAt
        self.transactionPaymentMethod = (data["transactionPaymentMethod"] as? String).flatMap { TokenPaymentMethod(rawValue: $0) }
        self.transactionPrice = data["transactionPrice"] as? Double
        self.transactionCurrency = TokenCurrency(rawValue: transactionCurrencyRaw) ?? .turkishLira
    }
}

/// İşlem tiplerini temsil eden enum
enum TransactionType: String, Codable {
    case purchase = "PURCHASE"   // Token satın alma
    case usage = "USAGE"        // Token kullanma
    case refund = "REFUND"      // İade
    case reward = "REWARD"      // Ödül/Promosyon
}

/// İşlem durumlarını temsil eden enum
enum TransactionStatus: String, Codable {
    case pending = "PENDING"      // Beklemede
    case completed = "COMPLETED"  // Tamamlandı
    case failed = "FAILED"       // Başarısız
    case refunded = "REFUNDED"   // İade edildi
}

/// Token ödemelerinde kullanılacak ödeme yöntemleri
enum TokenPaymentMethod: String, Codable, CaseIterable {
    case creditCard = "CREDIT_CARD"
    case bankTransfer = "BANK_TRANSFER"
    case applePay = "APPLE_PAY"
}
