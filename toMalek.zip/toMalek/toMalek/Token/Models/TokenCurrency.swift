import Foundation

/// Token işlemlerinde kullanılacak para birimleri
enum TokenCurrency: String, Codable {
    case turkishLira = "TRY"
    case usDollar = "USD"
    case euro = "EUR"
    
    var symbol: String {
        switch self {
        case .turkishLira: return "₺"
        case .usDollar: return "$"
        case .euro: return "€"
        }
    }
}
