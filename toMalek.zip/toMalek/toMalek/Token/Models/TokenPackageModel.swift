import Foundation
import FirebaseFirestore

/// Token paketlerini temsil eden yapı
struct TokenPackageModel: Identifiable, Codable {
    let id: String
    let tokenPackageName: String
    let tokenPackageDescription: String
    let tokenAmount: Int
    let tokenPackagePrice: Double
    let tokenPackageCurrency: TokenCurrency
    let tokenPackageIsActive: Bool
    let tokenBonusAmount: Int?
    
    /// Firebase dökümanından TokenPackageModel oluşturur
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let tokenPackageName = data["tokenPackageName"] as? String,
              let tokenPackageDescription = data["tokenPackageDescription"] as? String,
              let tokenAmount = data["tokenAmount"] as? Int,
              let tokenPackagePrice = data["tokenPackagePrice"] as? Double,
              let tokenPackageCurrencyRaw = data["tokenPackageCurrency"] as? String,
              let tokenPackageIsActive = data["tokenPackageIsActive"] as? Bool
        else { return nil }
        
        self.id = document.documentID
        self.tokenPackageName = tokenPackageName
        self.tokenPackageDescription = tokenPackageDescription
        self.tokenAmount = tokenAmount
        self.tokenPackagePrice = tokenPackagePrice
        self.tokenPackageCurrency = TokenCurrency(rawValue: tokenPackageCurrencyRaw) ?? .turkishLira
        self.tokenPackageIsActive = tokenPackageIsActive
        self.tokenBonusAmount = data["tokenBonusAmount"] as? Int
    }
}
