import Foundation
import FirebaseFirestore

/// Token modelini temsil eden yapı
struct TokenModel: Identifiable, Codable {
    let id: String
    let userId: String
    let tokenAmount: Int
    let tokenType: TokenType
    let tokenStatus: TokenStatus
    let tokenCreatedAt: Date
    let tokenExpiresAt: Date?
    let tokenTransactionId: String?
    
    /// Firebase dökümanından TokenModel oluşturur
    init?(document: QueryDocumentSnapshot) {
        let data = document.data()
        
        guard let userId = data["userId"] as? String,
              let tokenAmount = data["tokenAmount"] as? Int,
              let tokenTypeRaw = data["tokenType"] as? String,
              let tokenStatusRaw = data["tokenStatus"] as? String,
              let tokenCreatedAt = (data["tokenCreatedAt"] as? Timestamp)?.dateValue()
        else { return nil }
        
        self.id = document.documentID
        self.userId = userId
        self.tokenAmount = tokenAmount
        self.tokenType = TokenType(rawValue: tokenTypeRaw) ?? .purchased
        self.tokenStatus = TokenStatus(rawValue: tokenStatusRaw) ?? .active
        self.tokenCreatedAt = tokenCreatedAt
        self.tokenExpiresAt = (data["tokenExpiresAt"] as? Timestamp)?.dateValue()
        self.tokenTransactionId = data["tokenTransactionId"] as? String
    }
}

/// Token tiplerini temsil eden enum
enum TokenType: String, Codable {
    case purchased = "PURCHASED"      // Satın alınan
    case earned = "EARNED"           // Kazanılan (örn: referans)
    case promotional = "PROMOTIONAL"  // Promosyon
}

/// Token durumlarını temsil eden enum
enum TokenStatus: String, Codable {
    case active = "ACTIVE"      // Kullanılabilir
    case used = "USED"         // Kullanılmış
    case expired = "EXPIRED"   // Süresi dolmuş
    case reserved = "RESERVED" // Rezerve edilmiş
}
