//
//  ModulMediaPickerViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import Foundation
import SwiftUI
import PhotosUI

@MainActor
public final class ModulMediaPickerViewModel: ObservableObject {
    // MARK: - Services
    private let mediaService: ModulMediaServiceProtocol
    
    // MARK: - Properties
    private let propertyId: UUID
    
    // MARK: - Published Properties
    @Published var imageSelections: [PhotosPickerItem] = []
    @Published var selectedMedias: [ModulMediaModel] = []
    @Published var selectedImagesData: [UUID: Data] = [:]
    @Published var isLoading = false
    @Published var showError = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    @Published var mediaUrls: [String] = []
    
    // Camera & Scanner Properties
    @Published var showCamera = false
    @Published var showDocumentScanner = false
    
    // MARK: - Initialization
    public init(
        propertyId: UUID,
        mediaService: ModulMediaServiceProtocol
    ) {
        self.propertyId = propertyId
        self.mediaService = mediaService
    }
    
    // MARK: - Methods - Image Loading
    func loadImages(from selections: [PhotosPickerItem]) async {
        do {
            for selection in selections {
                guard let data = try await selection.loadTransferable(type: Data.self) else { continue }
                
                let mediaId = UUID()
                let media = ModulMediaModel(
                    id: mediaId,
                    propertyId: propertyId,
                    modulMediaType: .image,
                    fileExtension: "jpg"
                )
                
                selectedImagesData[mediaId] = data
                selectedMedias.append(media)
            }
        } catch {
            showError = true
            errorMessage = String(localized: "error_loading_images")
        }
    }
    
    // MARK: - Methods - Media Management
    func removeMedia(at index: Int) {
        guard selectedMedias.indices.contains(index) else { return }
        let media = selectedMedias[index]
        selectedImagesData.removeValue(forKey: media.id)
        selectedMedias.remove(at: index)
    }
    
    func renameMedia(at index: Int, newTitle: String) {
        guard selectedMedias.indices.contains(index) else { return }
        selectedMedias[index].title = newTitle
    }
    
    // MARK: - Methods - Camera & Scanner
    func handleCameraResult(_ image: UIImage?) {
        guard let image = image,
              let imageData = image.jpegData(compressionQuality: 0.7) else { return }
        
        let mediaId = UUID()
        let media = ModulMediaModel(
            id: mediaId,
            propertyId: propertyId,
            modulMediaType: .image,
            fileExtension: "jpg"
        )
        
        selectedImagesData[mediaId] = imageData
        selectedMedias.append(media)
    }

    func handleDocumentScanResult(_ document: Data?) {
        guard let document = document else { return }
        
        let mediaId = UUID()
        let media = ModulMediaModel(
            id: mediaId,
            propertyId: propertyId,
            modulMediaType: .pdf,
            fileExtension: "pdf"
        )
        
        selectedImagesData[mediaId] = document
        selectedMedias.append(media)
    }
    
    // MARK: - Methods - Upload
    func uploadMedias() async {
        guard !selectedMedias.isEmpty else { return }
        
        isLoading = true
        showError = false
        errorMessage = nil
        mediaUrls = []
        
        do {
            for media in selectedMedias {
                guard let data = selectedImagesData[media.id] else { continue }
                try await uploadSingleMedia(media, data: data)
            }
            
            isSuccessful = true
        } catch {
            showError = true
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    private func uploadSingleMedia(_ media: ModulMediaModel, data: Data) async throws {
        try await mediaService.uploadMedia(media, data: data)
        
        if let uploadedMedia = try await mediaService.fetchMedia(id: media.id.uuidString) {
            mediaUrls.append(uploadedMedia.url)
        } else {
            throw ModulMediaError.uploadFailed
        }
    }
}
