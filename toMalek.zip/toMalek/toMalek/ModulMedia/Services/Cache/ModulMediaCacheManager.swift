//
//  ModulMediaCacheManager.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import Foundation
import UIKit

/// Medya önbellekleme yöneticisi
public final class ModulMediaCacheManager: ModulMediaCacheProtocol {
    // MARK: - Singleton
    public static let shared = ModulMediaCacheManager()
    
    // MARK: - Private Properties
    private let memoryCache = NSCache<NSString, NSData>()
    private let fileManager = FileManager.default
    private let diskCacheURL: URL
    private let maxDiskCacheSize: Int = 100 * 1024 * 1024  // 100 MB
    private let queue = DispatchQueue(label: "com.tomalek.mediacache")
    
    // MARK: - Initialization
    private init() {
        let cacheDirectory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        diskCacheURL = cacheDirectory.appendingPathComponent("ModulMediaCache")
        
        try? fileManager.createDirectory(at: diskCacheURL, withIntermediateDirectories: true)
        
        memoryCache.countLimit = 100
        memoryCache.totalCostLimit = 50 * 1024 * 1024  // 50 MB
        
        // Düzenli cache temizliği için timer
        Timer.scheduledTimer(withTimeInterval: 3600, repeats: true) { [weak self] _ in
            self?.cleanExpiredCache()
        }
    }
    
    // MARK: - Public Methods
    public func store(_ data: Data, for key: String, options: ModulMediaCacheOptions) throws {
        queue.async {
            // Memory cache
            self.memoryCache.setObject(data as NSData, forKey: key as NSString)
            
            // Disk cache
            let fileURL = self.diskCacheURL.appendingPathComponent(key)
            let metadata = [
                "timestamp": Date().timeIntervalSince1970,
                "expiration": options.expirationDuration
            ]
            
            do {
                try data.write(to: fileURL)
                try JSONSerialization.data(withJSONObject: metadata)
                    .write(to: fileURL.appendingPathExtension("metadata"))
            } catch {
                print("ModulMediaCache error: \(error.localizedDescription)")
            }
        }
    }
    
    public func retrieve(_ key: String) throws -> Data? {
        // Önce memory cache'e bak
        if let cachedData = memoryCache.object(forKey: key as NSString) {
            return cachedData as Data
        }
        
        // Disk cache'e bak
        let fileURL = diskCacheURL.appendingPathComponent(key)
        let metadataURL = fileURL.appendingPathExtension("metadata")
        
        guard let metadata = try? Data(contentsOf: metadataURL),
              let info = try? JSONSerialization.jsonObject(with: metadata) as? [String: Double],
              let timestamp = info["timestamp"],
              let expiration = info["expiration"] else {
            return nil
        }
        
        // Süre kontrolü
        if Date().timeIntervalSince1970 - timestamp > expiration {
            remove(key)  // try? kaldırıldı çünkü fonksiyon throwing değil
            return nil
        }
        
        // Disk'ten oku ve memory'ye ekle
        if let data = try? Data(contentsOf: fileURL) {
            memoryCache.setObject(data as NSData, forKey: key as NSString)
            return data
        }
        
        return nil
    }
    
    public func remove(_ key: String) {
        queue.async {
            self.memoryCache.removeObject(forKey: key as NSString)
            
            let fileURL = self.diskCacheURL.appendingPathComponent(key)
            let metadataURL = fileURL.appendingPathExtension("metadata")
            
            try? self.fileManager.removeItem(at: fileURL)
            try? self.fileManager.removeItem(at: metadataURL)
        }
    }
    
    public func clear() {
        queue.async {
            self.memoryCache.removeAllObjects()
            try? self.fileManager.removeItem(at: self.diskCacheURL)
            try? self.fileManager.createDirectory(at: self.diskCacheURL, withIntermediateDirectories: true)
        }
    }
    
    public func currentCacheSize() -> Int {
        var size = 0
        let urls = try? fileManager.contentsOfDirectory(at: diskCacheURL, includingPropertiesForKeys: [.fileSizeKey])
        urls?.forEach { url in
            size += (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        }
        return size
    }
    
    public func checkCacheStatus() -> ModulMediaCacheStatus {
        let currentSize = currentCacheSize()
        
        if currentSize >= maxDiskCacheSize {
            return .full
        } else if currentSize >= (maxDiskCacheSize * 8 / 10) {
            return .nearCapacity
        }
        return .healthy
    }
    
    // MARK: - Private Methods
    private func cleanExpiredCache() {
        queue.async {
            let urls = try? self.fileManager.contentsOfDirectory(
                at: self.diskCacheURL,
                includingPropertiesForKeys: [.contentModificationDateKey]
            )
            
            urls?.forEach { url in
                guard url.pathExtension != "metadata" else { return }
                
                let metadataURL = url.appendingPathExtension("metadata")
                guard let metadata = try? Data(contentsOf: metadataURL),
                      let info = try? JSONSerialization.jsonObject(with: metadata) as? [String: Double],
                      let timestamp = info["timestamp"],
                      let expiration = info["expiration"] else {
                    return
                }
                
                if Date().timeIntervalSince1970 - timestamp > expiration {
                    try? self.fileManager.removeItem(at: url)
                    try? self.fileManager.removeItem(at: metadataURL)
                }
            }
        }
    }
}
