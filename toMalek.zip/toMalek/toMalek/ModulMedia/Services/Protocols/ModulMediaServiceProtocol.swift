//
//  ModulMediaServiceProtocol.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//


import Foundation
import UIKit

/// Medya servisi için temel protokol
public protocol ModulMediaServiceProtocol {
    /// Medya yükleme işlemleri
    func uploadMedia(_ media: ModulMediaModel, data: Data) async throws
    func uploadImages(_ images: [UIImage]) async throws -> [String]
    
    /// Medya okuma işlemleri
    func fetchMedias(propertyId: String) async throws -> [ModulMediaModel]
    func fetchMedia(id: String) async throws -> ModulMediaModel?
    func downloadMedia(url: String) async throws -> Data
    
    /// Medya silme işlemi
    func deleteMedia(_ media: ModulMediaModel) async throws
    
    /// Medya yeniden adlandırma işlemi
    func renameMedia(_ media: ModulMediaModel, newTitle: String) async throws
    
    /// Medya paylaşım işlemi
    func shareMedia(_ media: ModulMediaModel) async throws -> URL
}

/// Medya önbellekleme işlemleri için protokol
public protocol ModulMediaCacheProtocol {
    /// Veriyi önbelleğe kaydetme
    func store(_ data: Data, for key: String, options: ModulMediaCacheOptions) throws
    
    /// Veriyi önbellekten getirme
    func retrieve(_ key: String) throws -> Data?
    
    /// Veriyi önbellekten silme
    func remove(_ key: String)
    
    /// Önbelleği temizleme
    func clear()
    
    /// Önbellek boyutunu kontrol etme
    func currentCacheSize() -> Int
    
    /// Önbellek durumunu kontrol etme
    func checkCacheStatus() -> ModulMediaCacheStatus
}

/// Medya yönetimi için protokol
public protocol ModulMediaManageable {
    /// Medya seçme işlemi
    func pickMedia(from source: ModulMediaSourceType) async throws -> ModulMediaModel
    
    /// Medya önizleme işlemi
    func previewMedia(_ media: ModulMediaModel) async throws
    
    /// Medya paylaşım işlemi
    func shareMedia(_ media: ModulMediaModel) async throws
}

/// Önbellek durumu için enum
public enum ModulMediaCacheStatus {
    case healthy
    case nearCapacity
    case full
    case error(ModulMediaError)
}
