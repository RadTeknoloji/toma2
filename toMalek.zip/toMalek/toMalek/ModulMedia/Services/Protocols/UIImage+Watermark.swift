//
//  UIImage+Watermark.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import UIKit

extension UIImage {
    func addWatermark() -> UIImage? {
        let watermarkImage = UIImage(named: "tomalek_watermark")?.withRenderingMode(.alwaysTemplate)
        
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        draw(in: CGRect(origin: .zero, size: size))
        
        if let watermark = watermarkImage {
            // Filigran boyutunu hesapla - orijinal görüntünün %30'u
            let watermarkSize = CGSize(
                width: size.width * 0.3,
                height: size.width * 0.3 * (watermark.size.height / watermark.size.width)
            )
            
            // Filigranı merkeze yerleştir
            let point = CGPoint(
                x: (size.width - watermarkSize.width) / 2,
                y: (size.height - watermarkSize.height) / 2
            )
            
            // Filigranı yarı saydam olarak çiz
            watermark.draw(
                in: CGRect(origin: point, size: watermarkSize),
                blendMode: .normal,
                alpha: 0.2
            )
        }
        
        let watermarkedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return watermarkedImage
    }
}
