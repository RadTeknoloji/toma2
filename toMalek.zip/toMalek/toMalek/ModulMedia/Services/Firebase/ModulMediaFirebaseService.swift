//
//  ModulMediaFirebaseService.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore
import UIKit

public final class ModulMediaFirebaseService: ModulMediaServiceProtocol {
    // MARK: - Properties
    private let storage = Storage.storage()
    private let db = Firestore.firestore()
    private let cacheManager = ModulMediaCacheManager.shared
    private let collection = "module_medias"
    
    // MARK: - Helper Properties
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // MARK: - Public Methods - Upload
    public func uploadMedia(_ media: ModulMediaModel, data: Data) async throws {
        guard let userId = currentUserId else {
            throw ModulMediaError.unauthorized
        }
        
        // Optimize data based on media type
        let optimizedData = try await optimizeData(data, for: media.modulMediaType)
        
        // Create storage reference
        let storageRef = createStorageReference(
            userId: userId,
            propertyId: media.propertyId.uuidString,
            mediaId: media.id.uuidString,
            fileExtension: media.fileExtension ?? "jpg"
        )
        
        // Upload metadata
        let metadata = StorageMetadata()
        metadata.contentType = getContentType(for: media.modulMediaType)
        
        // Upload to Firebase Storage
        try await storageRef.putDataAsync(optimizedData, metadata: metadata)
        let url = try await storageRef.downloadURL()
        
        // Prepare Firestore data
        let mediaData: [String: Any] = [
            "id": media.id.uuidString,
            "propertyId": media.propertyId.uuidString,
            "title": media.title as Any,
            "modulMediaType": media.modulMediaType.rawValue,
            "url": url.absoluteString,
            "createdDate": FieldValue.serverTimestamp(),
            "fileSize": optimizedData.count,
            "fileExtension": media.fileExtension ?? "jpg",
            "userId": userId
        ]
        
        // Save to Firestore
        try await db.collection(collection)
            .document(media.id.uuidString)
            .setData(mediaData)
        
        // Cache the media
        try cacheManager.store(optimizedData, for: media.id.uuidString, options: ModulMediaCacheOptions())
    }
    
    public func uploadImages(_ images: [UIImage]) async throws -> [String] {
        var uploadedUrls: [String] = []
        
        for image in images {
            guard let imageData = image.jpegData(compressionQuality: 0.7) else { continue }
            
            let media = ModulMediaModel(
                propertyId: UUID(),
                modulMediaType: .image,
                fileExtension: "jpg"
            )
            
            try await uploadMedia(media, data: imageData)
            
            if let uploadedMedia = try await fetchMedia(id: media.id.uuidString) {
                uploadedUrls.append(uploadedMedia.url)
            }
        }
        
        return uploadedUrls
    }
    
    // MARK: - Public Methods - Fetch
    public func fetchMedias(propertyId: String) async throws -> [ModulMediaModel] {
        guard let userId = currentUserId else {
            throw ModulMediaError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("propertyId", isEqualTo: propertyId)
            .order(by: "createdDate", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeMedia(from: document)
        }
    }
    
    public func fetchMedia(id: String) async throws -> ModulMediaModel? {
        let document = try await db.collection(collection)
            .document(id)
            .getDocument()
        
        guard document.exists else { return nil }
        return try decodeMedia(from: document)
    }
    
    public func downloadMedia(url: String) async throws -> Data {
        guard let url = URL(string: url) else {
            throw ModulMediaError.invalidData
        }
        
        let storageRef = storage.reference(forURL: url.absoluteString)
        let maxSize: Int64 = 100 * 1024 * 1024 // 100MB
        return try await storageRef.data(maxSize: maxSize)
    }
    
    // MARK: - Public Methods - Delete
    public func deleteMedia(_ media: ModulMediaModel) async throws {
        guard let userId = currentUserId else {
            throw ModulMediaError.unauthorized
        }
        
        // Check ownership
        let document = try await db.collection(collection)
            .document(media.id.uuidString)
            .getDocument()
        
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw ModulMediaError.unauthorized
        }
        
        // Delete from Storage
        let storageRef = storage.reference(forURL: media.url)
        try await storageRef.delete()
        
        // Delete from Firestore
        try await db.collection(collection)
            .document(media.id.uuidString)
            .delete()
        
        // Remove from cache
        cacheManager.remove(media.id.uuidString)
    }
    
    // MARK: - Public Methods - Rename
    public func renameMedia(_ media: ModulMediaModel, newTitle: String) async throws {
        guard currentUserId != nil else {  // userId değişkeni kullanılmadığı için doğrudan boolean kontrolü yapıyoruz
            throw ModulMediaError.unauthorized
        }
        
        try await db.collection(collection)
            .document(media.id.uuidString)
            .updateData(["title": newTitle])
    }
    
    // MARK: - Public Methods - Share
    public func shareMedia(_ media: ModulMediaModel) async throws -> URL {
        let storageRef = storage.reference(forURL: media.url)
        // 24 saat geçerli paylaşım linki
        return try await storageRef.downloadURL()
    }
    
    // MARK: - Private Methods - Helpers
    private func optimizeData(_ data: Data, for modulMediaType: ModulMediaType) async throws -> Data {
        switch modulMediaType {
        case .image:
            return try await optimizeImage(data)
        case .pdf:
            return try await optimizePDF(data)
        case .document:
            return data // No optimization for other documents
        }
    }
    
    private func optimizeImage(_ data: Data) async throws -> Data {
        guard let image = UIImage(data: data) else {
            throw ModulMediaError.invalidData
        }
        
        let maxDimension: CGFloat = 1920
        let scale: CGFloat
        
        if image.size.width > image.size.height {
            scale = maxDimension / image.size.width
        } else {
            scale = maxDimension / image.size.height
        }
        
        let newSize = CGSize(
            width: image.size.width * min(scale, 1.0),
            height: image.size.height * min(scale, 1.0)
        )
        
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1.0
        
        let renderer = UIGraphicsImageRenderer(size: newSize, format: format)
        
        let optimizedData = renderer.jpegData(withCompressionQuality: 0.7) { context in
            image.draw(in: CGRect(origin: .zero, size: newSize))
        }
        
        return optimizedData
    }
    
    private func optimizePDF(_ data: Data) async throws -> Data {
        // PDF optimization logic if needed
        return data
    }
    
    private func getContentType(for modulMediaType: ModulMediaType) -> String {
        switch modulMediaType {
        case .image:
            return "image/jpeg"
        case .pdf:
            return "application/pdf"
        case .document:
            return "application/octet-stream"
        }
    }
    
    private func createStorageReference(
        userId: String,
        propertyId: String,
        mediaId: String,
        fileExtension: String
    ) -> StorageReference {
        storage.reference()
            .child("users")
            .child(userId)
            .child("properties")
            .child(propertyId)
            .child("media")
            .child("\(mediaId).\(fileExtension)")
    }
    
    private func decodeMedia(from document: DocumentSnapshot) throws -> ModulMediaModel {
        guard let data = document.data() else {
            throw ModulMediaError.invalidData
        }
        
        return ModulMediaModel(
            id: UUID(uuidString: data["id"] as? String ?? "") ?? UUID(),
            propertyId: UUID(uuidString: data["propertyId"] as? String ?? "") ?? UUID(),
            title: data["title"] as? String,
            modulMediaType: ModulMediaType(rawValue: data["modulMediaType"] as? String ?? "") ?? .image,
            url: data["url"] as? String ?? "",
            createdDate: (data["createdDate"] as? Timestamp)?.dateValue() ?? Date(),
            fileSize: data["fileSize"] as? Int,
            fileExtension: data["fileExtension"] as? String
        )
    }
}

// MARK: - StorageReference Extension
extension StorageReference {
    func putDataAsync(_ data: Data, metadata: StorageMetadata? = nil) async throws -> Void {
        return try await withCheckedThrowingContinuation { continuation in
            self.putData(data, metadata: metadata) { metadata, error in
                if let error = error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume(returning: ())
                }
            }
        }
    }
}
