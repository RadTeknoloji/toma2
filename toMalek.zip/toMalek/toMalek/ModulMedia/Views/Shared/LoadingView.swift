//
//  LoadingView.swift
//  toMalek
//
//  Created by Selman Erbay on 12.02.2025.
//

// Components/LoadingView.swift

import SwiftUI
import Foundation

struct LoadingView: View {
    // MARK: - Properties
    let text: String
    var backgroundColor: Color = Color.black.opacity(0.3)
    var textColor: Color = TColor.textSecondary
    var showProgressIndicator: Bool = true
    
    // MARK: - Body
    var body: some View {
        VStack(spacing: TLayout.spacing) {
            if showProgressIndicator {
                ProgressView()
                    .tint(textColor)
            }
            
            Text(text)
                .font(TFont.footnote)
                .foregroundColor(textColor)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(backgroundColor)
    }
}

// Örnek kullanım:
//.overlay {
  //  if isLoading {
    //    LoadingView(text: String(localized: "loading_message"))
   // }
//}
