//
//  ModulMediaPDFPreviewViewController.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//


import UIKit
import PDFKit

public final class ModulMediaPDFPreviewViewController: UIViewController {
    // MARK: - Properties
    private let pdfURL: URL
    public var completion: ((Bool) -> Void)?
    
    // MARK: - UI Components
    private lazy var pdfView: PDFView = {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePage
        view.displayDirection = .vertical
        view.usePageViewController(true)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var closeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal)
        button.tintColor = .systemGray
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        return button
    }()
    
    private lazy var loadingIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.hidesWhenStopped = true
        indicator.translatesAutoresizingMaskIntoConstraints = false
        return indicator
    }()
    
    private lazy var toolBar: UIToolbar = {
        let toolbar = UIToolbar()
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        
        let shareButton = UIBarButtonItem(
            image: UIImage(systemName: "square.and.arrow.up"),
            style: .plain,
            target: self,
            action: #selector(shareButtonTapped)
        )
        
        let searchButton = UIBarButtonItem(
            image: UIImage(systemName: "magnifyingglass"),
            style: .plain,
            target: self,
            action: #selector(searchButtonTapped)
        )
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        toolbar.items = [flexSpace, shareButton, searchButton]
        return toolbar
    }()
    
    // MARK: - Initialization
    public init(pdfURL: URL) {
        self.pdfURL = pdfURL
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Lifecycle
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadPDF()
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        
        view.addSubview(pdfView)
        view.addSubview(closeButton)
        view.addSubview(loadingIndicator)
        view.addSubview(toolBar)
        
        NSLayoutConstraint.activate([
            pdfView.topAnchor.constraint(equalTo: view.topAnchor),
            pdfView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pdfView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pdfView.bottomAnchor.constraint(equalTo: toolBar.topAnchor),
            
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            closeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            closeButton.widthAnchor.constraint(equalToConstant: 32),
            closeButton.heightAnchor.constraint(equalToConstant: 32),
            
            loadingIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loadingIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
            toolBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    // MARK: - PDF Loading
    private func loadPDF() {
        loadingIndicator.startAnimating()
        
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: pdfURL)
                if let document = PDFDocument(data: data) {
                    await MainActor.run {
                        self.pdfView.document = document
                        self.loadingIndicator.stopAnimating()
                    }
                }
            } catch {
                print("Error loading PDF: \(error)")
                await MainActor.run {
                    self.loadingIndicator.stopAnimating()
                    // Show error alert
                }
            }
        }
    }
    
    // MARK: - Actions
    @objc private func closeButtonTapped() {
        dismiss(animated: true) {
            self.completion?(true)
        }
    }
    
    @objc private func shareButtonTapped() {
        guard let document = pdfView.document,
              let documentData = document.dataRepresentation() else { return }
        
        let activityVC = UIActivityViewController(
            activityItems: [documentData],
            applicationActivities: nil
        )
        
        if let popoverController = activityVC.popoverPresentationController {
            popoverController.sourceView = toolBar
            popoverController.sourceRect = toolBar.bounds
        }
        
        present(activityVC, animated: true)
    }
    
    @objc private func searchButtonTapped() {
        pdfView.document?.beginFindString("", withOptions: .caseInsensitive)
    }
}
