//
//  ModulMediaPreviewManager.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//


import Foundation
import UIKit
import QuickLook
import PhotosUI
import PDFKit
import VisionKit

/// Medya önizleme yöneticisi
public final class ModulMediaPreviewManager: NSObject {
    // MARK: - Singleton
    public static let shared = ModulMediaPreviewManager()
    
    // MARK: - Private Properties
    private var previewController: UIViewController?
    private var previewCompletion: ((Bool) -> Void)?
    
    // MARK: - Public Methods
    
    /// Medya önizlemesini gösterir
    /// - Parameters:
    ///   - media: Gösterilecek medya modeli
    ///   - from: Gösterimin yapılacağı view controller
    ///   - completion: İşlem tamamlandığında çağrılacak closure
    public func showPreview(
        for media: ModulMediaModel,
        from viewController: UIViewController,
        completion: ((Bool) -> Void)? = nil
    ) {
        self.previewCompletion = completion
        
        switch media.modulMediaType {
        case .image:
            showImagePreview(for: media, from: viewController)
        case .pdf:
            showPDFPreview(for: media, from: viewController)
        case .document:
            showDocumentPreview(for: media, from: viewController)
        }
    }
    
    // MARK: - Private Methods - Image Preview
    
    private func showImagePreview(
            for media: ModulMediaModel,
            from viewController: UIViewController
        ) {
            guard let url = URL(string: media.url) else {
                print("Invalid URL for media: \(media.id)")
                return
            }
            
            let previewVC = ModulMediaImagePreviewViewController(mediaURL: url)
            previewVC.modalPresentationStyle = .fullScreen
            previewVC.completion = { [weak self] success in
                self?.previewCompletion?(success)
            }
            
            viewController.present(previewVC, animated: true)
            self.previewController = previewVC
        }
    
    // MARK: - Private Methods - PDF Preview
    
    private func showPDFPreview(
        for media: ModulMediaModel,
        from viewController: UIViewController
    ) {
        guard let url = URL(string: media.url) else { return }
        
        let previewVC = ModulMediaPDFPreviewViewController(pdfURL: url)
        previewVC.modalPresentationStyle = .fullScreen
        previewVC.completion = { [weak self] success in
            self?.previewCompletion?(success)
        }
        
        viewController.present(previewVC, animated: true)
        self.previewController = previewVC
    }
    
    // MARK: - Private Methods - Document Preview
    
    private func showDocumentPreview(
        for media: ModulMediaModel,
        from viewController: UIViewController
    ) {
        guard let url = URL(string: media.url) else { return }
        
        let previewVC = QLPreviewController()
        previewVC.dataSource = self
        previewVC.delegate = self
        previewVC.currentPreviewItemIndex = 0
        
        viewController.present(previewVC, animated: true)
        self.previewController = previewVC
    }
}

// MARK: - QLPreviewControllerDataSource
extension ModulMediaPreviewManager: QLPreviewControllerDataSource {
    public func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }
    
    public func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        // URL'i güvenli bir şekilde oluştur
        guard let url = URL(string: "your_document_url") else {
            fatalError("Invalid URL")
        }
        return url as QLPreviewItem
    }
}

// MARK: - QLPreviewControllerDelegate
extension ModulMediaPreviewManager: QLPreviewControllerDelegate {
    public func previewControllerDidDismiss(_ controller: QLPreviewController) {
        previewCompletion?(true)
        previewController = nil
    }
}
