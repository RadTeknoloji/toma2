//
//  ModulMediaGridItemView.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import SwiftUI

/// Medya grid öğelerinin görüntüleme modları
public enum ModulMediaGridMode {
    case edit       // Düzenleme modu (silme ve yeniden adlandırma izinli)
    case readonly   // Salt okunur mod (sadece görüntüleme)
}

/// Grid içinde kullanılan medya önizleme bileşeni
public struct ModulMediaGridItemView: View {
    // MARK: - Properties
    private let media: ModulMediaModel
    private let mode: ModulMediaGridMode
    private let onDelete: (() -> Void)?
    private let onRename: ((String) -> Void)?
    private let onTap: (() -> Void)?
    
    @State private var showRenameAlert = false
    @State private var newTitle = ""
    @State private var showDeleteAlert = false
    
    // MARK: - Initialization
    public init(
        media: ModulMediaModel,
        mode: ModulMediaGridMode = .readonly,
        onDelete: (() -> Void)? = nil,
        onRename: ((String) -> Void)? = nil,
        onTap: (() -> Void)? = nil
    ) {
        self.media = media
        self.mode = mode
        self.onDelete = onDelete
        self.onRename = onRename
        self.onTap = onTap
    }
    
    // MARK: - Body
    public var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topTrailing) {
                // Medya Önizleme
                mediaPreview
                    .frame(width: geo.size.width, height: geo.size.width)
                    .clipped()
                    .contentShape(Rectangle())
                    .onTapGesture {
                        onTap?()
                    }
                
                // Silme Butonu - Sadece edit modunda göster
                if mode == .edit {
                    deleteButton
                }
            }
        }
        .aspectRatio(1, contentMode: .fit)
        .contextMenu {
            contextMenuContent
        }
        .alert(String(localized: "rename_media"), isPresented: $showRenameAlert) {
            renameAlert
        }
        .alert(String(localized: "delete_media"), isPresented: $showDeleteAlert) {
            deleteAlert
        }
    }
    
    // MARK: - Subviews
    
    @ViewBuilder
    private var mediaPreview: some View {
        Group {
            switch media.modulMediaType {
            case .image:
                imagePreview
            case .pdf:
                pdfPreview
            case .document:
                documentPreview
            }
        }
    }
    
    private var imagePreview: some View {
        Group {
            if let url = URL(string: media.url) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    case .failure:
                        errorPlaceholder
                    @unknown default:
                        EmptyView()
                    }
                }
            } else {
                errorPlaceholder
            }
        }
    }
    
    private var errorPlaceholder: some View {
        Image(systemName: "photo")
            .font(.title)
            .foregroundColor(.gray)
    }
    
    private var pdfPreview: some View {
        VStack {
            Image(systemName: "doc.text.fill")
                .font(.title)
                .foregroundColor(.red)
            Text(media.title ?? String(localized: "pdf_document"))
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(TColor.surface)
    }
    
    private var documentPreview: some View {
        VStack {
            Image(systemName: "doc.fill")
                .font(.title)
                .foregroundColor(.blue)
            Text(media.title ?? String(localized: "document"))
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(TColor.surface)
    }
    
    @ViewBuilder
        private var deleteButton: some View {
            Button {
                showDeleteAlert = true
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.white)
                    .padding(4)
                    .shadow(radius: 2)
            }
        }
        
        @ViewBuilder
        private var contextMenuContent: some View {
            if mode == .edit {
                if onRename != nil {
                    Button {
                        showRenameAlert = true
                    } label: {
                        Label(String(localized: "rename"), systemImage: "pencil")
                    }
                }
                
                if onDelete != nil {
                    Button(role: .destructive) {
                        showDeleteAlert = true
                    } label: {
                        Label(String(localized: "delete"), systemImage: "trash")
                    }
                }
            } else {
                readonlyContextMenu
            }
        }
    
    private var editModeContextMenu: some View {
        Group {
            if onRename != nil {  // değişken tanımlamadan doğrudan kontrol
                Button {
                    showRenameAlert = true
                } label: {
                    Label(String(localized: "rename"), systemImage: "pencil")
                }
            }
            
            if onDelete != nil {  // değişken tanımlamadan doğrudan kontrol
                Button(role: .destructive) {
                    showDeleteAlert = true
                } label: {
                    Label(String(localized: "delete"), systemImage: "trash")
                }
            }
        }
    }
    
    private var readonlyContextMenu: some View {
        Group {
            Button {
                // Paylaşım aksiyonu buraya gelecek
            } label: {
                Label(String(localized: "share"), systemImage: "square.and.arrow.up")
            }
            
            Button {
                // Kaydetme aksiyonu buraya gelecek
            } label: {
                Label(String(localized: "save"), systemImage: "square.and.arrow.down")
            }
        }
    }
    
    private var renameAlert: some View {
        Group {
            TextField(String(localized: "enter_new_name"), text: $newTitle)
            Button(String(localized: "cancel"), role: .cancel) { }
            Button(String(localized: "rename")) {
                if let onRename = onRename {
                    onRename(newTitle)
                }
                newTitle = ""
            }
        }
    }
    
    private var deleteAlert: some View {
        Group {
            Button(String(localized: "cancel"), role: .cancel) { }
            Button(String(localized: "delete"), role: .destructive) {
                if let onDelete = onDelete {
                    onDelete()
                }
            }
        }
    }
}

// MARK: - Preview
#Preview {
    Grid {
        GridRow {
            // Edit modu örneği
            ModulMediaGridItemView(
                media: ModulMediaModel(
                    propertyId: UUID(),
                    title: "Test Media",
                    modulMediaType: .image,
                    url: "https://example.com/image.jpg"
                ),
                mode: .edit,
                onDelete: {},
                onRename: { _ in }
            )
            .frame(width: 150, height: 150)
            
            // Readonly modu örneği
            ModulMediaGridItemView(
                media: ModulMediaModel(
                    propertyId: UUID(),
                    title: "View Only Media",
                    modulMediaType: .pdf,
                    url: "https://example.com/document.pdf"
                ),
                mode: .readonly
            )
            .frame(width: 150, height: 150)
        }
    }
    .padding()
}
