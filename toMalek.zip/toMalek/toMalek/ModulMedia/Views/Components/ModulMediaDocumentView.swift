//
//  ModulMediaDocumentView.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import SwiftUI
import PDFKit

/// PDF ve belge görüntüleme bileşeni
public struct ModulMediaDocumentView: View {
    // MARK: - Properties
    let url: URL
    
    // MARK: - State
    @State private var isLoading = true
    @State private var showError = false
    @State private var errorMessage: String?
    @State private var document: PDFDocument?
    
    // MARK: - Body
    public var body: some View {
        ZStack {
            if isLoading {
                LoadingView(
                    text: String(localized: "loading_document"),
                    backgroundColor: Color.clear
                )
            } else if showError {
                errorView
            } else if let doc = document {
                PDFKitView(document: doc)
                    .edgesIgnoringSafeArea(.all)
            }
        }
        .task {
            await loadDocument()
        }
    }
    
    // MARK: - Components
    private var errorView: some View {
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundColor(.red)
            Text(errorMessage ?? String(localized: "error_loading_document"))
                .multilineTextAlignment(.center)
                .padding()
        }
    }
    
    // MARK: - Methods
    private func loadDocument() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }
            
            if let pdfDocument = PDFDocument(data: data) {
                await MainActor.run {
                    self.document = pdfDocument
                }
            } else {
                throw NSError(
                    domain: "ModulMediaDocumentView",
                    code: -1,
                    userInfo: [NSLocalizedDescriptionKey: String(localized: "invalid_document_format")]
                )
            }
        } catch {
            await MainActor.run {
                showError = true
                errorMessage = error.localizedDescription
            }
        }
    }
}

/// PDFKit wrapper view
public struct PDFKitView: UIViewRepresentable {
    // MARK: - Properties
    let document: PDFDocument
    
    // MARK: - UIViewRepresentable
    public func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.document = document
        pdfView.autoScales = true
        pdfView.displayMode = .singlePage
        pdfView.displayDirection = .horizontal
        pdfView.usePageViewController(true)
        return pdfView
    }
    
    public func updateUIView(_ uiView: PDFView, context: Context) {
        uiView.document = document
    }
}

// MARK: - Preview Provider
struct ModulMediaDocumentView_Previews: PreviewProvider {
    static var previews: some View {
        ModulMediaDocumentView(
            url: URL(string: "https://example.com/document.pdf")!
        )
    }
}
