//
//  ModulMediaPreviewView.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import SwiftUI
import PDFKit

/// Tam ekran medya önizleme görünümü
public struct ModulMediaPreviewView: View {
    // MARK: - Environment
    @Environment(\.dismiss) var dismiss
    
    // MARK: - Properties
    let media: ModulMediaModel
    let mediaService: ModulMediaServiceProtocol
    
    // MARK: - State
    @State private var showShareSheet = false
    @State private var shareUrl: URL?
    @State private var showError = false
    @State private var errorMessage: String?
    @State private var isLoading = false
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    
    // MARK: - Initialization
    public init(
        media: ModulMediaModel,
        mediaService: ModulMediaServiceProtocol
    ) {
        self.media = media
        self.mediaService = mediaService
    }
    
    // MARK: - Body
    public var body: some View {
        NavigationView {
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                Group {
                    switch media.modulMediaType {
                    case .image:
                        imagePreview
                            .scaleEffect(scale)
                            .offset(offset)
                            .gesture(
                                MagnificationGesture()
                                    .onChanged { value in
                                        let delta = value / lastScale
                                        lastScale = value
                                        scale = min(max(scale * delta, 1), 4)
                                    }
                                    .onEnded { _ in
                                        lastScale = 1.0
                                    }
                            )
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        if scale > 1 {
                                            offset = CGSize(
                                                width: lastOffset.width + value.translation.width,
                                                height: lastOffset.height + value.translation.height
                                            )
                                        }
                                    }
                                    .onEnded { _ in
                                        lastOffset = offset
                                        if scale <= 1 {
                                            withAnimation {
                                                offset = .zero
                                                lastOffset = .zero
                                            }
                                        }
                                    }
                            )
                            .onTapGesture(count: 2) {
                                withAnimation {
                                    if scale > 1 {
                                        scale = 1
                                        offset = .zero
                                        lastOffset = .zero
                                    } else {
                                        scale = 2
                                    }
                                }
                            }
                    case .pdf, .document:
                        documentPreview
                    }
                }
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    toolbarItems
                }
                .alert(String(localized: "error"), isPresented: $showError) {
                    Button(String(localized: "ok"), role: .cancel) { }
                } message: {
                    if let error = errorMessage {
                        Text(error)
                    }
                }
                
                if isLoading {
                    LoadingView(
                        text: String(localized: "loading_media"),
                        backgroundColor: .black.opacity(0.7)
                    )
                }
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let url = shareUrl {
                ShareSheet(items: [url])
            }
        }
    }
    
    // MARK: - Views
    @ViewBuilder
        private var imagePreview: some View {
            if let url = URL(string: media.url) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        // UIImage'i filigran eklenmiş haliyle kullan
                        if let uiImage = image.asUIImage()?.addWatermark() {
                            Image(uiImage: uiImage)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                        } else {
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .edgesIgnoringSafeArea(.all)
                        }
                    case .failure:
                        errorView
                    @unknown default:
                        EmptyView()
                    }
                }
            }
        }
    
    private var documentPreview: some View {
        Group {
            if let url = URL(string: media.url) {
                ModulMediaDocumentView(url: url)
            } else {
                errorView
            }
        }
    }
    
    private var errorView: some View {
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .font(.largeTitle)
                .foregroundColor(.red)
            Text(String(localized: "error_loading_media"))
                .multilineTextAlignment(.center)
                .padding()
        }
    }
    
    private var toolbarItems: some ToolbarContent {
        Group {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.white)
                }
            }
            
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    Task {
                        await shareMedia()
                    }
                } label: {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundColor(.white)
                }
            }
        }
    }
    
    // MARK: - Methods
    private func shareMedia() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let url = try await mediaService.shareMedia(media)
            await MainActor.run {
                self.shareUrl = url
                self.showShareSheet = true
            }
        } catch {
            await MainActor.run {
                self.showError = true
                self.errorMessage = error.localizedDescription
            }
        }
    }
}

// MARK: - ShareSheet
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(
            activityItems: items,
            applicationActivities: nil
        )
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
