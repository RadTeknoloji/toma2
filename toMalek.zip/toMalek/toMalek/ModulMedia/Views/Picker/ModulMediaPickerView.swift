//
//  ModulMediaPickerView.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import SwiftUI
import PhotosUI

public struct ModulMediaPickerView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: ModulMediaPickerViewModel
    var onComplete: (([String]) -> Void)?
    
    @State private var internalShowCamera = false
    @State private var internalShowDocumentScanner = false
    @State private var cameraImage: UIImage?
    
    public init(
        propertyId: UUID,
        onComplete: (([String]) -> Void)? = nil
    ) {
        _viewModel = StateObject(wrappedValue: ModulMediaPickerViewModel(
            propertyId: propertyId,
            mediaService: ModulMediaFirebaseService()
        ))
        self.onComplete = onComplete
    }
    
    public var body: some View {
        NavigationView {
            VStack(spacing: TLayout.spacing) {
                HStack(spacing: TLayout.spacingM) {
                    PhotosPicker(
                        selection: $viewModel.imageSelections,
                        maxSelectionCount: 5,
                        matching: .images
                    ) {
                        mediaPickerButton(
                            title: String(localized: "gallery"),
                            icon: "photo.on.rectangle.angled"
                        )
                    }
                    .onChange(of: viewModel.imageSelections) { _, newValue in
                        Task {
                            await viewModel.loadImages(from: newValue)
                        }
                    }
                    
                    Button {
                        internalShowCamera = true
                    } label: {
                        mediaPickerButton(
                            title: String(localized: "camera"),
                            icon: "camera"
                        )
                    }
                    
                    Button {
                        internalShowDocumentScanner = true
                    } label: {
                        mediaPickerButton(
                            title: String(localized: "scan"),
                            icon: "doc.text.viewfinder"
                        )
                    }
                }
                .padding(.horizontal)
                
                if !viewModel.selectedMedias.isEmpty {
                    selectedMediaGrid
                }
                
                Spacer()
                
                uploadButton
            }
            .navigationTitle(String(localized: "select_media"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "cancel")) {
                        dismiss()
                    }
                    .foregroundColor(TColor.textPrimary)
                }
            }
            .alert(String(localized: "error"), isPresented: $viewModel.showError) {
                Button(String(localized: "ok"), role: .cancel) { }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
            .overlay {
                if viewModel.isLoading {
                    LoadingView(
                        text: String(localized: "uploading_media"),
                        backgroundColor: Color.black.opacity(0.7)
                    )
                }
            }
            .sheet(isPresented: $internalShowCamera) {
                ModulCameraView(
                    image: Binding<UIImage?>(
                        get: { cameraImage },
                        set: { image in
                            if let image = image {
                                viewModel.handleCameraResult(image)
                            }
                            cameraImage = nil
                            internalShowCamera = false
                        }
                    ),
                    isPresented: $internalShowCamera
                )
            }
            .sheet(isPresented: $internalShowDocumentScanner) {
                Text("Document Scanner Placeholder")
            }
        }
    }
    
    private var selectedMediaGrid: some View {
            ScrollView {
                LazyVGrid(
                    columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ],
                    spacing: TLayout.spacingM
                ) {
                    ForEach(viewModel.selectedMedias.indices, id: \.self) { index in
                        let media = viewModel.selectedMedias[index]
                        if let imageData = viewModel.selectedImagesData[media.id],
                           let uiImage = UIImage(data: imageData) {
                            MediaGridCell(
                                image: uiImage,
                                onDelete: {
                                    viewModel.removeMedia(at: index)
                                }
                            )
                        }
                    }
                }
                .padding()
            }
        }

    private struct MediaGridCell: View {
        let image: UIImage
        let onDelete: () -> Void
        
        var body: some View {
            GeometryReader { geo in
                ZStack(alignment: .topTrailing) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.width)
                        .clipped()
                    
                    Button(action: onDelete) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.white)
                            .padding(4)
                            .shadow(radius: 2)
                    }
                }
            }
            .aspectRatio(1, contentMode: .fit)
        }
    }
    
    private var uploadButton: some View {
        Button {
            Task {
                await viewModel.uploadMedias()
                if viewModel.isSuccessful {
                    onComplete?(viewModel.mediaUrls)
                    dismiss()
                }
            }
        } label: {
            Text(String(localized: "upload"))
                .frame(maxWidth: .infinity)
                .padding()
                .background(TColor.areapolPrimary)
                .foregroundColor(TColor.onPrimary)
                .cornerRadius(TLayout.cornerRadius)
        }
        .disabled(viewModel.selectedMedias.isEmpty || viewModel.isLoading)
        .padding()
    }
    
    private func mediaPickerButton(title: String, icon: String) -> some View {
        VStack {
            Image(systemName: icon)
                .font(.title2)
            Text(title)
                .font(TFont.footnote)
        }
        .foregroundColor(TColor.areapolPrimary)
        .frame(maxWidth: .infinity)
        .padding()
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}

#Preview {
    ModulMediaPickerView(
        propertyId: UUID(),
        onComplete: { _ in }
    )
}
