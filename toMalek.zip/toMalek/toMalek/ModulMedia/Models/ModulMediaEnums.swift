//
//  ModulMediaEnums.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import Foundation

/// Medya kaynak tiplerini tanımlar (kamera, galeri, belge tarayıcı, dosya seçici)
public enum ModulMediaSourceType {
    case camera
    case photoLibrary
    case documentScanner
    case filePicker
}

/// Medya tiplerini tanımlar (resim, pdf, belge)
public enum ModulMediaType: String, Codable {
    case image
    case pdf
    case document
}

/// Medya işlemleri sırasında oluşabilecek hataları tanımlar
public enum ModulMediaError: LocalizedError {
    case invalidData
    case uploadFailed
    case downloadFailed
    case deleteFailed
    case renameFailed
    case unauthorized
    case invalidFileFormat
    case fileSizeLimitExceeded
    case cacheError
    case shareError
    
    public var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "media_error_invalid_data")
        case .uploadFailed:
            return String(localized: "media_error_upload_failed")
        case .downloadFailed:
            return String(localized: "media_error_download_failed")
        case .deleteFailed:
            return String(localized: "media_error_delete_failed")
        case .renameFailed:
            return String(localized: "media_error_rename_failed")
        case .unauthorized:
            return String(localized: "media_error_unauthorized")
        case .invalidFileFormat:
            return String(localized: "media_error_invalid_format")
        case .fileSizeLimitExceeded:
            return String(localized: "media_error_size_exceeded")
        case .cacheError:
            return String(localized: "media_error_cache")
        case .shareError:
            return String(localized: "media_error_share")
        }
    }
}

/// Önbellekleme seçeneklerini tanımlar
public struct ModulMediaCacheOptions {
    let expirationDuration: TimeInterval
    let maxFileSize: Int
    let compressionQuality: CGFloat
    
    public init(
        expirationDuration: TimeInterval = 7 * 24 * 60 * 60, // 1 hafta
        maxFileSize: Int = 10 * 1024 * 1024, // 10 MB
        compressionQuality: CGFloat = 0.7
    ) {
        self.expirationDuration = expirationDuration
        self.maxFileSize = maxFileSize
        self.compressionQuality = compressionQuality
    }
}
