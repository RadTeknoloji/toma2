//
//  ModulMediaModel.swift
//  toMalek
//
//  Created by Selman Erbay on 16.02.2025.
//

import Foundation

/// Medya verilerini temsil eden model
public struct ModulMediaModel: Codable, Identifiable, Equatable {
    /// Medyanın benzersiz tanımlayıcısı
    public let id: UUID
    
    /// Medyanın bağlı olduğu mülkün ID'si
    public let propertyId: UUID
    
    /// Medyanın başlığı (yeniden adlandırılabilir)
    public var title: String?
    
    /// Medyanın tipi (resim, pdf, belge)
    public var modulMediaType: ModulMediaType
    
    /// Medyanın depolamadaki URL'i
    public var url: String
    
    /// Medyanın oluşturulma tarihi
    public var createdDate: Date
    
    /// Medyanın dosya boyutu (byte)
    public var fileSize: Int?
    
    /// Medyanın dosya uzantısı (.jpg, .pdf vb.)
    public var fileExtension: String?
    
    /// Medyanın local önbellekteki yolu
    public var localCachePath: String?
    
    /// Medyanın paylaşım URL'i
    public var shareUrl: String?
    
    public init(
        id: UUID = UUID(),
        propertyId: UUID,
        title: String? = nil,
        modulMediaType: ModulMediaType,
        url: String = "",
        createdDate: Date = Date(),
        fileSize: Int? = nil,
        fileExtension: String? = nil,
        localCachePath: String? = nil,
        shareUrl: String? = nil
    ) {
        self.id = id
        self.propertyId = propertyId
        self.title = title
        self.modulMediaType = modulMediaType
        self.url = url
        self.createdDate = createdDate
        self.fileSize = fileSize
        self.fileExtension = fileExtension
        self.localCachePath = localCachePath
        self.shareUrl = shareUrl
    }
    
    public static func == (lhs: ModulMediaModel, rhs: ModulMediaModel) -> Bool {
        lhs.id == rhs.id
    }
}
