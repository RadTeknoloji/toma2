# ModulMedia Integration Guide

## Genel Bakış
ModulMedia, iOS uygulamaları için geliştirilmiş kapsamlı bir medya yönetim modülüdür. Bu modül, resim ve belge yükleme, önizleme, paylaşma ve yönetme işlevlerini sağlar.

## Sistem Gereksinimleri
- iOS 17.6 veya üzeri
- Xcode 15.0 veya üzeri
- Swift 5.9 veya üzeri
- Firebase SDK

## Kurulum

### 1. Modülün Projeye Eklenmesi
1. ModulMedia klasörünü projenize ekleyin
2. Target settings'de "Copy items if needed" seçeneğini işaretleyin
3. ModulMedia klasörünü hedef projenizin target membership'ine ekleyin

### 2. Firebase Kurulumu
1. Firebase Console'dan yeni bir proje oluşturun (veya mevcut projenizi kullanın)
2. iOS uygulamanızı Firebase'e ekleyin
3. GoogleService-Info.plist dosyasını projenize ekleyin
4. Firebase SDK'yı CocoaPods veya SPM ile projenize ekleyin:

```ruby
# Podfile
pod 'FirebaseCore'
pod 'FirebaseAuth'
pod 'FirebaseStorage'
pod 'FirebaseFirestore'
```

### 3. Firebase Inicializasyonu
AppDelegate veya ana Swift dosyanızda Firebase'i başlatın:

```swift
import FirebaseCore

class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        return true
    }
}
```

## Kullanım

### 1. Medya Seçici Ekranı
ModulMediaPickerView'ı kullanarak medya seçici ekranını gösterin:

```swift
struct ContentView: View {
    @State private var showMediaPicker = false
    
    var body: some View {
        Button("Medya Seç") {
            showMediaPicker = true
        }
        .sheet(isPresented: $showMediaPicker) {
            ModulMediaPickerView(
                propertyId: yourPropertyId
            ) { mediaUrls in
                // mediaUrls: Yüklenen medyaların URL'leri
                print("Yüklenen medyalar:", mediaUrls)
            }
        }
    }
}
```

### 2. Medya Önizleme
Medyaları önizlemek için ModulMediaPreviewView'ı kullanın:

```swift
ModulMediaPreviewView(media: yourMediaModel)
```

### 3. Custom Media Service Oluşturma
Kendi medya servisinizi oluşturmak için ModulMediaServiceProtocol'ü implemente edin:

```swift
class YourCustomMediaService: ModulMediaServiceProtocol {
    // Protocol metodlarını implemente edin
}
```

## Localization

Modülün desteklediği diller için Localizable.strings dosyalarınıza şu anahtarları ekleyin:

```
// English (en)
"select_media" = "Select Media";
"gallery" = "Gallery";
"camera" = "Camera";
"scan" = "Scan";
"upload" = "Upload";
"cancel" = "Cancel";
"rename" = "Rename";
"delete" = "Delete";
"error" = "Error";
"loading_media" = "Loading Media...";
"uploading_media" = "Uploading Media...";

// Turkish (tr)
"select_media" = "Medya Seç";
"gallery" = "Galeri";
"camera" = "Kamera";
"scan" = "Tara";
"upload" = "Yükle";
"cancel" = "İptal";
"rename" = "Yeniden Adlandır";
"delete" = "Sil";
"error" = "Hata";
"loading_media" = "Medya Yükleniyor...";
"uploading_media" = "Medya Yükleniyor...";
```

## Tema Özelleştirme

Modülün görünümünü özelleştirmek için TColor ve TFont yapılarını kullanın:

```swift
extension TColor {
    static var areapolPrimary: Color { ... }
    static var surface: Color { ... }
    static var onPrimary: Color { ... }
    static var textPrimary: Color { ... }
    static var textSecondary: Color { ... }
}

extension TFont {
    static var headline: Font { ... }
    static var footnote: Font { ... }
    static var caption: Font { ... }
}
```

## Güvenlik Notları

1. Firebase Rules'larınızı doğru yapılandırın:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

2. Medya boyutu limitlerini ayarlayın:
```swift
let options = ModulMediaCacheOptions(
    maxFileSize: 10 * 1024 * 1024 // 10 MB
)
```

## Performans Optimizasyonu

1. Önbellek yapılandırması:
```swift
ModulMediaCacheManager.shared.clear() // Önbelleği temizleme
let cacheStatus = ModulMediaCacheManager.shared.checkCacheStatus()
```

2. Görsel optimizasyonu otomatik olarak yapılır:
- Maksimum boyut: 1920x1920 piksel
- JPEG kalitesi: %70
- Metadata temizleme

## Hata Yönetimi

Modül şu hata türlerini handle eder:
- ModulMediaError.invalidData
- ModulMediaError.uploadFailed
- ModulMediaError.downloadFailed
- ModulMediaError.unauthorized
- ModulMediaError.fileSizeLimitExceeded

## Best Practices

1. Medya yükleme işlemlerini async/await ile yapın
2. Büyük medya koleksiyonları için pagination kullanın
3. Önbellek durumunu düzenli kontrol edin
4. Kullanıcı yetkilendirmesini doğru yapılandırın
5. Hata mesajlarını localize edin

## Örnek Kullanım Senaryoları

1. Profil Fotoğrafı Yükleme:
```swift
let picker = ModulMediaPickerView(propertyId: userId) { urls in
    if let profilePhotoUrl = urls.first {
        // Profil fotoğrafını güncelle
    }
}
```

2. Çoklu Belge Tarama:
```swift
let picker = ModulMediaPickerView(propertyId: documentGroupId) { urls in
    // Taranan belgeleri kaydet
}
```

## Sorun Giderme

1. Yükleme Hataları:
- Firebase yapılandırmasını kontrol edin
- Kullanıcı yetkilerini doğrulayın
- Internet bağlantısını kontrol edin

2. Önbellek Sorunları:
- Önbellek boyutunu kontrol edin
- Gereksiz önbelleği temizleyin
- Disk alanını kontrol edin

3. Performans Sorunları:
- Görsel optimizasyon ayarlarını kontrol edin
- Önbellek yapılandırmasını gözden geçirin
- Ağ bağlantı kalitesini kontrol edin