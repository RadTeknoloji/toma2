//
//  AuthenticationService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

/// Protocol defining the authentication service interface
protocol AuthenticationService {
    /// Signs in a user with email and password
    func signIn(email: String, password: String) async throws
    
    /// Creates a new user account
    func signUp(email: String, password: String) async throws -> User
    
    /// Sends a password reset email
    func resetPassword(email: String) async throws
    
    /// Signs out the current user
    func signOut() throws
    
    /// The currently signed-in user, if any
    var currentUser: User? { get }
}

// MARK: - Auth Errors
enum AuthError: LocalizedError {
    case invalidEmail
    case weakPassword
    case emailAlreadyInUse
    case userNotFound
    case wrongPassword
    case signInRequired
    case networkError
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .invalidEmail:
            return String(localized: "auth_error_invalid_email")
        case .weakPassword:
            return String(localized: "auth_error_weak_password")
        case .emailAlreadyInUse:
            return String(localized: "auth_error_email_in_use")
        case .userNotFound:
            return String(localized: "auth_error_user_not_found")
        case .wrongPassword:
            return String(localized: "auth_error_wrong_password")
        case .signInRequired:
            return String(localized: "auth_error_sign_in_required")
        case .networkError:
            return String(localized: "auth_error_network")
        case .unknown:
            return String(localized: "auth_error_unknown")
        }
    }
}
