import Foundation
import FirebaseFirestore

/// Firestore veritabanı işlemleri için protokol
protocol FirestoreService {
    /// Belge oluşturma
    func createDocument(collection: String, data: [String: Any]) async throws -> DocumentReference
    
    /// Belge güncelleme
    func updateDocument(collection: String, documentId: String, data: [String: Any]) async throws
    
    /// Belge silme
    func deleteDocument(collection: String, documentId: String) async throws
    
    /// Belge getirme
    func getDocument(collection: String, documentId: String) async throws -> DocumentSnapshot
    
    /// Koleksiyon getirme
    func getCollection(collection: String) async throws -> QuerySnapshot
    
    /// Filtrelenmiş koleksiyon getirme
    func getFilteredCollection(collection: String, field: String, isEqualTo value: Any) async throws -> QuerySnapshot
}

/// Firebase Firestore implementasyonu
@MainActor
final class FirebaseFirestoreService: FirestoreService {
    private let db = Firestore.firestore()
    
    func createDocument(collection: String, data: [String: Any]) async throws -> DocumentReference {
        let ref = db.collection(collection).document()
        try await ref.setData(data)
        return ref
    }
    
    func updateDocument(collection: String, documentId: String, data: [String: Any]) async throws {
        try await db.collection(collection).document(documentId).setData(data, merge: true)
    }
    
    func deleteDocument(collection: String, documentId: String) async throws {
        try await db.collection(collection).document(documentId).delete()
    }
    
    func getDocument(collection: String, documentId: String) async throws -> DocumentSnapshot {
        try await db.collection(collection).document(documentId).getDocument()
    }
    
    func getCollection(collection: String) async throws -> QuerySnapshot {
        try await db.collection(collection).getDocuments()
    }
    
    func getFilteredCollection(collection: String, field: String, isEqualTo value: Any) async throws -> QuerySnapshot {
        try await db.collection(collection)
            .whereField(field, isEqualTo: value)
            .getDocuments()
    }
}

#if DEBUG
/// Test için mock servis
final class MockFirestoreService: FirestoreService {
    func createDocument(collection: String, data: [String: Any]) async throws -> DocumentReference {
        fatalError("Not implemented")
    }
    
    func updateDocument(collection: String, documentId: String, data: [String: Any]) async throws {
        fatalError("Not implemented")
    }
    
    func deleteDocument(collection: String, documentId: String) async throws {
        fatalError("Not implemented")
    }
    
    func getDocument(collection: String, documentId: String) async throws -> DocumentSnapshot {
        fatalError("Not implemented")
    }
    
    func getCollection(collection: String) async throws -> QuerySnapshot {
        fatalError("Not implemented")
    }
    
    func getFilteredCollection(collection: String, field: String, isEqualTo value: Any) async throws -> QuerySnapshot {
        fatalError("Not implemented")
    }
}
#endif
