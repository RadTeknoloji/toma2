//
//  ServiceContainer.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

// MARK: - Navigation Protocol
protocol NavigationCoordinator {
    func navigateToCreateRequest(withPropertyId propertyId: String, propertyTitle: String)
    func navigateToRenewContract(withPropertyId propertyId: String, propertyTitle: String)
    func navigateToRaiseRent(withPropertyId propertyId: String, propertyTitle: String)
    func navigateToMatch(withPropertyId propertyId: String, propertyTitle: String)
    func navigateToRentTracking(withPropertyId propertyId: String)
    func navigateToExpenseTracking(withPropertyId propertyId: String)
    func navigateToCreateListing(withPropertyId propertyId: String, propertyTitle: String)
}

// MARK: - Navigation Implementation
class AppNavigationCoordinator: NavigationCoordinator {
    func navigateToCreateRequest(withPropertyId propertyId: String, propertyTitle: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToRenewContract(withPropertyId propertyId: String, propertyTitle: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToRaiseRent(withPropertyId propertyId: String, propertyTitle: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToMatch(withPropertyId propertyId: String, propertyTitle: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToRentTracking(withPropertyId propertyId: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToExpenseTracking(withPropertyId propertyId: String) {
        // Implementation will be added based on navigation requirements
    }
    
    func navigateToCreateListing(withPropertyId propertyId: String, propertyTitle: String) {
        // Implementation will be added based on navigation requirements
    }
}

/// A container that manages all services in the application
final class ServiceContainer {
    /// Shared instance of the ServiceContainer
    static let shared = ServiceContainer()
    
    private init() {}
    
    // MARK: - Services
    
    /// Service for handling authentication operations
    lazy var authService: AuthenticationService = FirebaseAuthService()
    
    /// Authentication state management
    private var _authenticationState: AuthenticationState?
    var authenticationState: AuthenticationState {
        if let state = _authenticationState {
            return state
        }
        
        let state = MainActor.assumeIsolated {
            AuthenticationState()
        }
        _authenticationState = state
        return state
    }
    
    /// Service for managing property-related operations
    lazy var propertyService: PropertyService = FirestorePropertyService()
    
    /// Service for managing expense-related operations
    lazy var expenseService: ExpenseService = FirestoreExpenseService()
    
    /// Service for managing rent payment operations
    lazy var rentPaymentService: RentPaymentService = FirestoreRentPaymentService()
    
    /// Service for handling media operations (upload, download, etc.)
    lazy var mediaService: MediaService = FirebaseMediaService()
    
    /// Service for handling request operations
    lazy var requestService: RequestService = FirestoreRequestService()
    
    /// Service for handling navigation operations
    lazy var navigationCoordinator: NavigationCoordinator = AppNavigationCoordinator()
}
