//
//  FirebaseAuthService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

/// Firebase implementation of the AuthenticationService protocol
final class FirebaseAuthService: AuthenticationService {
    // MARK: - Properties
    
    /// The currently signed-in user, if any
    var currentUser: User? {
        Auth.auth().currentUser
    }
    
    // MARK: - Sign In
    
    /// Signs in a user with email and password
    /// - Parameters:
    ///   - email: User's email address
    ///   - password: User's password
    /// - Throws: AuthError if sign in fails
    func signIn(email: String, password: String) async throws {
        do {
            try await Auth.auth().signIn(withEmail: email, password: password)
        } catch {
            throw mapFirebaseError(error)
        }
    }
    
    // MARK: - Sign Up
    
    /// Creates a new user account with email and password
    /// - Parameters:
    ///   - email: New user's email address
    ///   - password: New user's password
    /// - Returns: The newly created User object
    /// - Throws: AuthError if account creation fails
    func signUp(email: String, password: String) async throws -> User {
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            return result.user
        } catch {
            throw mapFirebaseError(error)
        }
    }
    
    // MARK: - Reset Password
    
    /// Sends a password reset email to the specified email address
    /// - Parameter email: The email address to send the reset link to
    /// - Throws: AuthError if the password reset request fails
    func resetPassword(email: String) async throws {
        do {
            try await Auth.auth().sendPasswordReset(withEmail: email)
        } catch {
            throw mapFirebaseError(error)
        }
    }
    
    // MARK: - Sign Out
    
    /// Signs out the currently signed-in user
    /// - Throws: AuthError.unknown if sign out fails
    func signOut() throws {
        do {
            try Auth.auth().signOut()
        } catch {
            throw AuthError.unknown
        }
    }
    
    // MARK: - Helper Methods
    
    /// Maps Firebase authentication errors to our custom AuthError type
    /// - Parameter error: The original Firebase error
    /// - Returns: A corresponding AuthError
    private func mapFirebaseError(_ error: Error) -> AuthError {
        let authError = error as NSError
        
        switch authError.code {
        case AuthErrorCode.invalidEmail.rawValue:
            return .invalidEmail
        case AuthErrorCode.weakPassword.rawValue:
            return .weakPassword
        case AuthErrorCode.emailAlreadyInUse.rawValue:
            return .emailAlreadyInUse
        case AuthErrorCode.userNotFound.rawValue:
            return .userNotFound
        case AuthErrorCode.wrongPassword.rawValue:
            return .wrongPassword
        case AuthErrorCode.networkError.rawValue:
            return .networkError
        default:
            print("Firebase Auth Error: \(authError.localizedDescription)")
            return .unknown
        }
    }
}
