//
//  FindAgencyViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

@MainActor
final class FindAgencyViewModel: ObservableObject {
    @Published var agencies: [FindAgencyModel] = []
    @Published var searchText = "" {
        didSet {
            Task {
                await searchAgencies()
            }
        }
    }
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var selectedAgency: FindAgencyModel?
    
    private let db = Firestore.firestore()
    private let pageSize = 10
    private var lastDocument: DocumentSnapshot?
    private var hasMoreData = true
    
    // Arama fonksiyonu
    private func searchAgencies() async {
        guard !searchText.isEmpty else {
            agencies = []
            lastDocument = nil
            hasMoreData = true
            await fetchAgencies(isInitialLoad: true)
            return
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let searchTextLower = searchText.lowercased()
            let query = db.collection("profiles")
                .whereField("userTypes", arrayContains: "agency")
            
            let snapshot = try await query.getDocuments()
            let fetchedAgencies = snapshot.documents.compactMap { doc -> FindAgencyModel? in
                guard let agencyInfo = doc.data()["agencyInfo"] as? [String: Any],
                      let email = doc.data()["email"] as? String,
                      let phoneNumber = doc.data()["phoneNumber"] as? String else {
                    return nil
                }
                
                let agency = FindAgencyModel(
                    id: UUID(),
                    officialName: agencyInfo["officialName"] as? String ?? "",
                    brandName: agencyInfo["brandName"] as? String ?? "",
                    taxNumber: agencyInfo["taxNumber"] as? String ?? "",
                    phoneNumber: phoneNumber,
                    email: email,
                    rating: agencyInfo["rating"] as? Double,
                    userID: doc.documentID,
                    district: agencyInfo["district"] as? String,
                    city: agencyInfo["city"] as? String,
                    country: agencyInfo["country"] as? String
                )
                
                // Client-side filtering
                let searchableFields = [
                    agency.officialName.lowercased(),
                    agency.brandName.lowercased(),
                    agency.taxNumber.lowercased(),
                    agency.phoneNumber.lowercased(),
                    agency.district?.lowercased() ?? "",
                    agency.city?.lowercased() ?? "",
                    agency.country?.lowercased() ?? ""
                ]
                
                return searchableFields.contains(where: { $0.contains(searchTextLower) }) ? agency : nil
            }
            
            self.agencies = fetchedAgencies
            
        } catch {
            errorMessage = String(format: String(localized: "find_agency_error_loading"), error.localizedDescription)
        }
    }
    
    // Normal sayfalı yükleme
    func fetchAgencies(isInitialLoad: Bool = false) async {
        guard !isLoading && (hasMoreData || isInitialLoad) else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            var query = db.collection("profiles")
                .whereField("userTypes", arrayContains: "agency")
                .limit(to: pageSize)
            
            if let lastDoc = lastDocument, !isInitialLoad {
                query = query.start(afterDocument: lastDoc)
            }
            
            let snapshot = try await query.getDocuments()
            lastDocument = snapshot.documents.last
            hasMoreData = !snapshot.documents.isEmpty && snapshot.documents.count == pageSize
            
            let fetchedAgencies = snapshot.documents.compactMap { doc -> FindAgencyModel? in
                guard let agencyInfo = doc.data()["agencyInfo"] as? [String: Any],
                      let email = doc.data()["email"] as? String,
                      let phoneNumber = doc.data()["phoneNumber"] as? String else {
                    return nil
                }
                
                return FindAgencyModel(
                    id: UUID(),
                    officialName: agencyInfo["officialName"] as? String ?? "",
                    brandName: agencyInfo["brandName"] as? String ?? "",
                    taxNumber: agencyInfo["taxNumber"] as? String ?? "",
                    phoneNumber: phoneNumber,
                    email: email,
                    rating: agencyInfo["rating"] as? Double ?? 0.0,
                    userID: doc.documentID,
                    district: agencyInfo["district"] as? String,
                    city: agencyInfo["city"] as? String,
                    country: agencyInfo["country"] as? String
                )
            }
            
            if isInitialLoad {
                self.agencies = fetchedAgencies
            } else {
                self.agencies.append(contentsOf: fetchedAgencies)
            }
            
        } catch {
            errorMessage = String(format: String(localized: "find_agency_error_loading"), error.localizedDescription)
        }
    }
    
    // Test için tüm kayıtları getir
    func fetchAllAgencies() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let snapshot = try await db.collection("profiles")
                .whereField("userTypes", arrayContains: "agency")
                .getDocuments()
            
            let fetchedAgencies = snapshot.documents.compactMap { doc -> FindAgencyModel? in
                guard let agencyInfo = doc.data()["agencyInfo"] as? [String: Any],
                      let email = doc.data()["email"] as? String,
                      let phoneNumber = doc.data()["phoneNumber"] as? String else {
                    return nil
                }
                
                return FindAgencyModel(
                    id: UUID(),
                    officialName: agencyInfo["officialName"] as? String ?? "",
                    brandName: agencyInfo["brandName"] as? String ?? "",
                    taxNumber: agencyInfo["taxNumber"] as? String ?? "",
                    phoneNumber: phoneNumber,
                    email: email,
                    rating: agencyInfo["rating"] as? Double ?? 0.0,
                    userID: doc.documentID,
                    district: agencyInfo["district"] as? String,
                    city: agencyInfo["city"] as? String,
                    country: agencyInfo["country"] as? String
                )
            }
            
            await MainActor.run {
                self.agencies = fetchedAgencies
            }
            
        } catch {
            await MainActor.run {
                self.errorMessage = String(format: String(localized: "find_agency_error_loading"), error.localizedDescription)
            }
        }
    }
    
    // Yeni veri yükleme kontrolü
    func loadMoreIfNeeded(currentAgency agency: FindAgencyModel) async {
        let thresholdIndex = agencies.index(agencies.endIndex, offsetBy: -3)
        if let currentIndex = agencies.firstIndex(where: { $0.id == agency.id }),
           currentIndex >= thresholdIndex {
            await fetchAgencies()
        }
    }
}
