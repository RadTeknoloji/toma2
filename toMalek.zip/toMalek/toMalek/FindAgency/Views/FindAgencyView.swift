//
//  FindAgencyView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct FindAgencyView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = FindAgencyViewModel()
    @State private var selectedCountry: String?
    @State private var selectedCity: String?
    @State private var selectedDistrict: String?
    @State private var selectedSortOption: AgencySortOption?
    var onAgencySelected: ((FindAgencyModel) -> Void)?
    
    init(onAgencySelected: ((FindAgencyModel) -> Void)? = nil) {
        self.onAgencySelected = onAgencySelected
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Filtreler
                filterSection
                    .padding(.horizontal, TLayout.paddingS)
                
                if viewModel.agencies.isEmpty {
                    if viewModel.searchText.isEmpty {
                        ContentUnavailableView(
                            String(localized: "find_agency_start_search"),
                            systemImage: "magnifyingglass",
                            description: Text(String(localized: "find_agency_search_description"))
                        )
                    } else {
                        ContentUnavailableView.search(text: viewModel.searchText)
                    }
                } else {
                    // Liste
                    ScrollView {
                        LazyVStack(spacing: TLayout.spacingS) {
                            ForEach(sortedAgencies) { agency in
                                NavigationLink {
                                    AgencyDetailView(agency: agency) { selectedAgency in
                                        onAgencySelected?(selectedAgency)
                                        dismiss()
                                    }
                                } label: {
                                    AgencyRowView(agency: agency)
                                        .modifier(TViewStyle.ListRow())
                                }
                                .task {
                                    await viewModel.loadMoreIfNeeded(currentAgency: agency)
                                }
                            }
                            
                            if viewModel.isLoading {
                                ProgressView()
                                    .frame(maxWidth: .infinity)
                                    .padding()
                            }
                        }
                        .padding()
                    }
                }
            }
            .searchable(
                text: $viewModel.searchText,
                prompt: String(localized: "find_agency_search_prompt")
            )
            .navigationTitle(String(localized: "find_agency_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "find_agency_cancel")) {
                        dismiss()
                    }
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.areapolPrimary)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(String(localized: "show_all")) {
                        Task {
                            await viewModel.fetchAllAgencies()
                        }
                    }
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.areapolPrimary)
                }
            }
        }
        .task {
            await viewModel.fetchAgencies(isInitialLoad: true)
        }
        .alert(String(localized: "find_agency_error_title"), isPresented: .constant(viewModel.errorMessage != nil)) {
            Button(String(localized: "find_agency_ok"), role: .cancel) {
                viewModel.errorMessage = nil
            }
        } message: {
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
    }
    
    // MARK: - Filtreleme
    private var filterSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: TLayout.spacingS) {
                // Ülke Filtresi
                SpecialFilterChip(
                    icon: "globe",
                    title: String(localized: "filter_country"),
                    selectedTitle: selectedCountry,
                    isSelected: selectedCountry != nil,
                    items: Array(Set(viewModel.agencies.compactMap(\.country))).sorted(),
                    itemTitle: { $0 },
                    onSelect: { selectedCountry = $0 },
                    iconColor: .blue
                )
                
                // Şehir Filtresi
                SpecialFilterChip(
                    icon: "building.2",
                    title: String(localized: "filter_city"),
                    selectedTitle: selectedCity,
                    isSelected: selectedCity != nil,
                    items: Array(Set(viewModel.agencies.compactMap(\.city))).sorted(),
                    itemTitle: { $0 },
                    onSelect: { selectedCity = $0 },
                    iconColor: .orange
                )
                
                // İlçe Filtresi
                SpecialFilterChip(
                    icon: "mappin.circle.fill",
                    title: String(localized: "filter_district"),
                    selectedTitle: selectedDistrict,
                    isSelected: selectedDistrict != nil,
                    items: Array(Set(viewModel.agencies.compactMap(\.district))).sorted(),
                    itemTitle: { $0 },
                    onSelect: { selectedDistrict = $0 },
                    iconColor: .green
                )
                
                // Sıralama
                SpecialFilterChip(
                    icon: "arrow.up.arrow.down",
                    title: String(localized: "sort_by"),
                    selectedTitle: selectedSortOption?.displayName,
                    isSelected: selectedSortOption != nil,
                    items: AgencySortOption.allCases,
                    itemTitle: { $0.displayName },
                    onSelect: { selectedSortOption = $0 },
                    iconColor: .purple
                )
            }
            .padding(.vertical, TLayout.paddingXS)
        }
    }
    
    private var sortedAgencies: [FindAgencyModel] {
        let filteredAgencies = viewModel.agencies.filter { agency in
            (selectedCountry == nil || agency.country == selectedCountry) &&
            (selectedCity == nil || agency.city == selectedCity) &&
            (selectedDistrict == nil || agency.district == selectedDistrict)
        }
        
        switch selectedSortOption {
        case .name:
            return filteredAgencies.sorted { $0.brandName < $1.brandName }
        case .rating:
            return filteredAgencies.sorted { ($0.rating ?? 0) > ($1.rating ?? 0) }
        case .none:
            return filteredAgencies
        }
    }
}

private struct AgencyRowView: View {
    let agency: FindAgencyModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            // Üst Kısım: Başlık ve Rating
            HStack {
                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                    Text(agency.brandName)
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                    
                    Text(agency.officialName)
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
                
                Spacer()
                
                HStack(spacing: TLayout.spacingXXS) {
                    Image(systemName: "star.fill")
                        .foregroundColor(TColor.warning)
                    Text(String(format: "%.1f", agency.rating ?? 0.0))
                        .font(TFont.footnoteBold)
                }
                .padding(.horizontal, TLayout.spacingXS)
                .padding(.vertical, 4)
                .background(TColor.warning.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            }
            
            // Alt Kısım: İletişim ve Konum
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                // Telefon
                Label(agency.phoneNumber.formatPhoneNumber(), systemImage: "phone.fill")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textPrimary)
                
                // Konum
                if let location = formatLocation(agency) {
                    Label(location, systemImage: "location.fill")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
            }
        }
        .padding(TLayout.spacingM)
        .background(TColor.card)
        .cornerRadius(TLayout.cornerRadiusL)
        .shadow(
            color: TColor.areapolPrimary.opacity(0.08),
            radius: 8,
            x: 0,
            y: 2
        )
    }
    
    private func formatLocation(_ agency: FindAgencyModel) -> String? {
        var components: [String] = []
        
        if let district = agency.district, !district.isEmpty {
            components.append(district)
        }
        if let city = agency.city, !city.isEmpty {
            components.append(city)
        }
        if let country = agency.country, !country.isEmpty {
            components.append(country)
        }
        
        return components.isEmpty ? nil : components.joined(separator: ", ")
    }
}

#Preview {
    FindAgencyView()
}
