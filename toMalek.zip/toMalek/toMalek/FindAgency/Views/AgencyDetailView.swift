//
//  AgencyDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct AgencyDetailView: View {
    let agency: FindAgencyModel
    let onAssign: ((FindAgencyModel) -> Void)? // Atama için callback

    
    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: TLayout.spacing) {
                    // Firma Bilgileri
                    Text(agency.brandName)
                        .font(TFont.title2)
                    
                    Text(agency.officialName)
                        .font(TFont.body)
                        .foregroundColor(TColor.border)
                    
                    HStack {
                        Image(systemName: "star.fill")
                            .foregroundColor(TColor.warning)
                        if let rating = agency.rating {
                            Text(String(format: "%.1f", rating))
                                .font(TFont.bodyBold)
                        } else {
                            Text(String(localized: "agency_not_rated"))
                                .font(TFont.bodyBold)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                    .padding(.horizontal, TLayout.spacingXS)
                    .padding(.vertical, 4)
                    .background(TColor.warning.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
            
            Section {
                // İletişim Bilgileri
                // Ofis telefonu
                LabeledContent(String(localized: "agency_detail_phone")) {
                    Button {
                        let formattedNumber = agency.phoneNumber.formatPhoneNumber()
                            .replacingOccurrences(of: " ", with: "")
                            .replacingOccurrences(of: "(", with: "")
                            .replacingOccurrences(of: ")", with: "")
                        guard let url = URL(string: "tel:\(formattedNumber)") else { return }
                        UIApplication.shared.open(url)
                    } label: {
                        HStack {
                            Text(agency.phoneNumber.formatPhoneNumber())
                            Image(systemName: "phone.fill")
                                .foregroundColor(TColor.areapolPrimary)
                        }
                    }
                }
                
                LabeledContent(String(localized: "agency_detail_email")) {
                    Text(agency.email)
                }
            }
            
            if let district = agency.district,
               let city = agency.city,
               let country = agency.country {
                Section {
                    // Konum Bilgileri
                    LabeledContent(String(localized: "agency_detail_district")) {
                        Text(district)
                    }
                    
                    LabeledContent(String(localized: "agency_detail_city")) {
                        Text(city)
                    }
                    
                    LabeledContent(String(localized: "agency_detail_country")) {
                        Text(country)
                    }
                }
            }
            
            Section {
                Button {
                    onAssign?(agency)
                } label: {
                    HStack {
                        Spacer()
                        Text("assign_to_property")
                            .font(TFont.bodyBold)
                        Spacer()
                    }
                }
                .buttonStyle(TButton.Primary())
            }
        }
        .navigationTitle(String(localized: "agency_detail_title"))
        .navigationBarTitleDisplayMode(.inline)
    }
}
