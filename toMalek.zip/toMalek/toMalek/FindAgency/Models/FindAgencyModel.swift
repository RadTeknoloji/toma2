//
//  FindAgencyModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation

struct FindAgencyModel: Identifiable, Codable {
    let id: UUID
    let officialName: String
    let brandName: String
    let taxNumber: String
    let phoneNumber: String
    let email: String
    let rating: Double?
    let userID: String
    
    // Adres bilgileri
    let district: String?    // İlçe
    let city: String?        // Şehir
    let country: String?     // Ülke
    
    func matchesSearchQuery(_ query: String) -> Bool {
        let lowercasedQuery = query.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Arama kriterleri
        let matches = [
            officialName,           // Resmi ünvan
            brandName,              // Tabela adı
            taxNumber,              // Vergi no
            phoneNumber,            // Telefon
            district,              // İlçe
            city,                  // Şehir
            country               // Ülke
        ]
        
        return matches.compactMap { $0?.lowercased() }
            .contains { $0.contains(lowercasedQuery) }
    }
    
    var formattedLocation: String {
        var components: [String] = []
        if let district = district { components.append(district) }
        if let city = city { components.append(city) }
        if let country = country { components.append(country) }
        return components.joined(separator: ", ")
    }
}
