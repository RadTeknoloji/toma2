import Foundation

enum AgencySortOption: String, CaseIterable {
    case name = "name"
    case rating = "rating"
    
    var displayName: String {
        switch self {
        case .name:
            String(localized: "sort_by_name")
        case .rating:
            String(localized: "sort_by_rating")
        }
    }
}
