//
//  AddPropertyView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI
import Combine

struct AddPropertyView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel = AddPropertyViewModel()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                makeProgressView()
                makeContentView()
                makeNavigationButtons()
            }
            .navigationTitle(viewModel.currentStep.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    makeCancelButton()
                }
            }
            .alert("error_alert_title", isPresented: .constant(viewModel.errorMessage != nil)) {
                makeErrorAlert()
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                        .font(TFont.body)
                        .foregroundColor(TColor.textPrimary)
                }
            }
            .onChange(of: viewModel.isSuccessful) { _, newValue in
                if newValue {
                    dismiss()
                }
            }
            .background(TColor.background)
        }
    }
    
    // MARK: - Subviews
    private func makeProgressView() -> some View {
        HStack(spacing: TLayout.spacingXS) {
            ForEach(PropertyFormStep.allCases, id: \.self) { step in
                Circle()
                    .fill(step == viewModel.currentStep ? TColor.areapolPrimary : TColor.textSecondary.opacity(0.3))
                    .frame(width: 8, height: 8)
            }
        }
        .padding(TLayout.padding)
    }
    
    private func makeContentView() -> some View {
        ScrollView {
            VStack(spacing: TLayout.spacingL) {
                switch viewModel.currentStep {
                case .basicInfo:
                    BasicInfoStepView(viewModel: viewModel)
                case .buildingDetails:
                    BuildingDetailsStepView(viewModel: viewModel)
                case .propertyAdvantages:
                                PropertyAdvantagesStepView(viewModel: viewModel)
                case .locationInfo:
                    LocationStepView(viewModel: viewModel)
                case .ownerInfo:
                    OwnerInfoStepView(viewModel: viewModel)
                case .tenantInfo:
                    TenantInfoStepView(viewModel: viewModel)
                case .agencyInfo:
                    AgencyInfoStepView(viewModel: viewModel)
                case .financialInfo:
                    FinancialInfoStepView(viewModel: viewModel)
                case .contractInfo:
                    ContractInfoStepView(viewModel: viewModel)
                case .mediaUpload:
                    MediaUploadStepView(viewModel: viewModel)
                }
            }
            .padding(TLayout.padding)
        }
    }
    
    private func makeNavigationButtons() -> some View {
        VStack(spacing: TLayout.spacingM) {
            if viewModel.currentStep == .mediaUpload {
                makeSaveButton()
            } else {
                makeNextButton()
            }
            
            if viewModel.currentStep != .basicInfo {
                makeBackButton()
            }
        }
        .padding(TLayout.padding)
    }
    
    private func makeCancelButton() -> some View {
        Button("cancel_button") {
            dismiss()
        }
        .foregroundColor(TColor.textPrimary)
    }
    
    private func makeSaveButton() -> some View {
        Button("save_button") {
            Task {
                await viewModel.save()
            }
        }
        .buttonStyle(TButton.Primary())
        .disabled(!viewModel.canMoveToNextStep || viewModel.isLoading)
    }
    
    private func makeNextButton() -> some View {
        Button("continue_button") {
            withAnimation {
                viewModel.moveToNextStep()
            }
        }
        .buttonStyle(TButton.Primary())
        .disabled(!viewModel.canMoveToNextStep)
    }
    
    private func makeBackButton() -> some View {
        Button("back_button") {
            withAnimation {
                viewModel.moveToPreviousStep()
            }
        }
        .buttonStyle(TButton.Bordered())
    }
    
    private func makeErrorAlert() -> some View {
        Button("ok_button", role: .cancel) {
            viewModel.errorMessage = nil
        }
    }
}

#Preview {
    AddPropertyView()
}
