//
//  TenantInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct TenantInfoStepView: View {
    @ObservedObject private var viewModel: AddPropertyViewModel
    
    init(viewModel: AddPropertyViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            // Header Section
            Text(PropertyFormStep.tenantInfo.description)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
            
            // Content Section
            Group {
                switch viewModel.activeUserType {
                case .tenant:
                    tenantInfoDisplay
                case .owner, .agency:
                    tenantInfoInput
                }
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .shadow(color: TElevation.low.color, radius: TElevation.low.radius, x: TElevation.low.x, y: TElevation.low.y)
        }
        .padding(.horizontal, TLayout.padding)
    }
    
    // MARK: - Subviews
    private var tenantInfoDisplay: some View {
        VStack(spacing: TLayout.spacingM) {
            VStack(spacing: TLayout.spacingS) {
                InfoRowView(label: "tenant_name_label", value: viewModel.tenantName ?? "")
                InfoRowView(label: "tenant_phone_label", value: PhoneFormat.format(viewModel.tenantPhone ?? ""))
                InfoRowView(label: "tenant_email_label", value: viewModel.tenantEmail ?? "")
            }
            
            Text("tenant_info_readonly_note")
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
                .padding(.top, TLayout.spacingXS)
        }
    }
    
    private var tenantInfoInput: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            // Name Input
            inputField(
                label: "tenant_name_label",
                placeholder: "tenant_name_placeholder",
                text: Binding(
                    get: { viewModel.tenantName ?? "" },
                    set: { viewModel.tenantName = $0.isEmpty ? nil : $0 }
                )
            )
            
            // Phone Input
            inputField(
                label: "tenant_phone_label",
                placeholder: "tenant_phone_placeholder",
                text: Binding(
                    get: { viewModel.tenantPhone ?? "" },
                    set: {
                        let filtered = $0.filter { $0.isNumber }
                        viewModel.tenantPhone = filtered.isEmpty ? nil : filtered
                    }
                ),
                error: viewModel.tenantPhone.flatMap { !isValidPhone($0) ? "tenant_phone_invalid" : nil },
                keyboardType: .phonePad
            )
            
            // Email Input
            inputField(
                label: "tenant_email_label",
                placeholder: "tenant_email_placeholder",
                text: Binding(
                    get: { viewModel.tenantEmail ?? "" },
                    set: { viewModel.tenantEmail = $0.isEmpty ? nil : $0 }
                ),
                keyboardType: .emailAddress
            )
        }
    }
    
    // MARK: - Helper Methods
    private func inputField(
        label: LocalizedStringKey,
        placeholder: LocalizedStringKey,
        text: Binding<String>,
        error: String? = nil,
        keyboardType: UIKeyboardType = .default
    ) -> some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(label)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            TextField(placeholder, text: text)
                .customTextFieldStyle()
                .keyboardType(keyboardType)
                .textInputAutocapitalization(keyboardType == .emailAddress ? .never : .words)
                .disableAutocorrection(keyboardType == .emailAddress)
            
            if let error {
                Text(error)
                    .font(TFont.caption)
                    .foregroundColor(TColor.error)
            }
        }
    }
    
    private func isValidPhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{10,13}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let cleanPhone = phone.filter { $0.isNumber }
        return phonePredicate.evaluate(with: cleanPhone)
    }
}

// MARK: - Preview Provider
struct TenantInfoStepView_Previews: PreviewProvider {
    static var previews: some View {
        TenantInfoStepView(viewModel: AddPropertyViewModel())
            .padding()
            .background(TColor.background)
    }
}
