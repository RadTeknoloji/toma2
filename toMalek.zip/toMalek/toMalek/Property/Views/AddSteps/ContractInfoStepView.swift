//
//  ContractInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct ContractInfoStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            Text(PropertyFormStep.contractInfo.description)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            // Contract Start Date
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("contract_start_date_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                DatePicker(
                    "contract_start_date_label",
                    selection: Binding(
                        get: { viewModel.rentStartDate ?? Date() },
                        set: { viewModel.rentStartDate = $0 }
                    ),
                    displayedComponents: [.date]
                )
                .datePickerStyle(.graphical)
                .tint(TColor.areapolPrimary)
            }
            
            // Contract Duration
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("contract_duration_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: TLayout.spacingXS) {
                        ForEach(ContractTime.allCases, id: \.self) { time in
                            Button {
                                viewModel.contractTime = time
                            } label: {
                                Text(contractTimeText(time))
                                    .font(TFont.footnote)
                                    .padding(.horizontal, TLayout.spacingS)
                                    .padding(.vertical, TLayout.spacingXS)
                                    .background(viewModel.contractTime == time ? TColor.areapolPrimary : TColor.surface)
                                    .foregroundColor(viewModel.contractTime == time ? TColor.onPrimary : TColor.textPrimary)
                                    .cornerRadius(TLayout.cornerRadius)
                            }
                        }
                    }
                    .padding(.vertical, TLayout.spacingXS)
                }
            }

            // Payment Day
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("payment_day_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: TLayout.spacingXS) {
                        ForEach(PaymentDay.allCases, id: \.self) { day in
                            Button {
                                viewModel.paymentDay = day
                            } label: {
                                Text(day.displayName)
                                    .font(TFont.footnote)
                                    .padding(.horizontal, TLayout.spacingS)
                                    .padding(.vertical, TLayout.spacingXS)
                                    .background(viewModel.paymentDay == day ? TColor.areapolPrimary : TColor.surface)
                                    .foregroundColor(viewModel.paymentDay == day ? TColor.onPrimary : TColor.textPrimary)
                                    .cornerRadius(TLayout.cornerRadius)
                            }
                        }
                    }
                    .padding(.vertical, TLayout.spacingXS)
                }
            }
            
            // Contract Type
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("contract_type_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                Picker("contract_type_label", selection: $viewModel.contractType) {
                    ForEach(ContractType.allCases, id: \.self) { type in
                        Text(type.localizedText) // ✅ contractTypeText yerine localizedText kullan
                            .tag(type)
                    }
                }
                .pickerStyle(.segmented)
                .colorMultiply(TColor.areapolPrimary)
            }
            
            

            
            // Contract Info Summary
            VStack(alignment: .leading, spacing: TLayout.spacingS) {
                Text("summary_label")
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                VStack(spacing: TLayout.spacingXS) {
                    HStack {
                        Text("start_date_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        Spacer()
                        Text(viewModel.rentStartDate?.formatted(date: .long, time: .omitted) ?? String(localized: "not_specified"))
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                    
                    HStack {
                        Text("end_date_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        Spacer()
                        Text(calculateEndDate().formatted(date: .long, time: .omitted))
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                    
                    HStack {
                        Text("duration_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        Spacer()
                        Text(contractTimeText(viewModel.contractTime))
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                    
                    HStack {
                        Text("type_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        Spacer()
                        Text(viewModel.contractType.localizedText) // ✅ contractTypeText yerine localizedText kullan
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                    
                    HStack {
                        Text("payment_day_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        Spacer()
                        Text(viewModel.paymentDay.displayName)
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                }
                .padding(TLayout.spacingS)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
            }
        }
        .padding(TLayout.spacingS)
        .background(TColor.background)
    }
    
    private func contractTimeText(_ time: ContractTime) -> String {
        let months = time.rawValue
        if months < 12 {
            return String(format: String(localized: "months_format"), months)
        } else if months == 12 {
            return String(localized: "one_year")
        } else if months % 12 == 0 {
            return String(format: String(localized: "years_format"), months / 12)
        } else {
            return String(format: String(localized: "months_format"), months)
        }
    }
    
    
    private func calculateEndDate() -> Date {
        let months = viewModel.contractTime.rawValue
        return Calendar.current.date(byAdding: .month, value: months, to: viewModel.rentStartDate ?? Date()) ?? Date()
    }
}
