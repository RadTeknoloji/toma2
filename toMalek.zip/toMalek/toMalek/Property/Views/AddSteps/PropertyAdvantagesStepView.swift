//
//  PropertyAdvantagesStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

import SwiftUI

struct PropertyAdvantagesStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Text(PropertyFormStep.propertyAdvantages.description)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            switch viewModel.propertyType {
            case .residential:
                PropertyMultipleSelectionView(
                    title: "residential_advantages_title",
                    selectedItems: $viewModel.residentialAdvantages
                )
            case .commercial:
                PropertyMultipleSelectionView(
                    title: "commercial_advantages_title",
                    selectedItems: $viewModel.commercialAdvantages
                )
            case .land:
                PropertyMultipleSelectionView(
                    title: "land_advantages_title",
                    selectedItems: $viewModel.landAdvantages
                )
            case .machine:
                PropertyMultipleSelectionView(
                    title: "machine_advantages_title",
                    selectedItems: $viewModel.machineAdvantages
                )
            case .timeshareProperty:
                PropertyMultipleSelectionView(
                    title: "timeshare_advantages_title",
                    selectedItems: $viewModel.timeshareAdvantages
                )
            }
            
            if selectedAdvantagesCount == 0 {
                Text("select_at_least_one_advantage")
                    .font(TFont.caption)
                    .foregroundColor(TColor.error)
            }
        }
        .padding()
        .background(TColor.background)
    }
    
    private var selectedAdvantagesCount: Int {
        switch viewModel.propertyType {
        case .residential:
            return viewModel.residentialAdvantages.count
        case .commercial:
            return viewModel.commercialAdvantages.count
        case .land:
            return viewModel.landAdvantages.count
        case .machine:
            return viewModel.machineAdvantages.count
        case .timeshareProperty:
            return viewModel.timeshareAdvantages.count
        }
    }
}
