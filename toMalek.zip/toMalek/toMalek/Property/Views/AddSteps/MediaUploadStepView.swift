//
//  MediaUploadStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct MediaUploadStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            headerSection
            photoPickerSection
            photosContentSection
        }
        .padding(.horizontal, TLayout.padding)
        .frame(maxHeight: .infinity, alignment: .top)
    }
    
    // MARK: - Subviews
    private var headerSection: some View {
        Text(PropertyFormStep.mediaUpload.description)
            .font(TFont.subheadline)
            .foregroundColor(TColor.textSecondary)
    }
    
    private var photoPickerSection: some View {
        PhotosPicker(
            selection: $viewModel.selectedPhotosPickerItems,
            maxSelectionCount: 5,
            matching: .images
        ) {
            PhotoPickerButton()
        }
        .onChange(of: viewModel.selectedPhotosPickerItems) { _, newValue in
            Task { await viewModel.loadSelectedImages() }
        }
    }
    
    @ViewBuilder
    private var photosContentSection: some View {
        if viewModel.selectedImageData.isEmpty {
            EmptyPhotoStateView()
                .transition(.opacity)
        } else {
            SelectedPhotosGridView(
                images: viewModel.selectedImageData,
                removeAction: { index in
                    viewModel.removePhoto(at: index) // Doğrudan viewModel üzerinden çağır
                }
            )
        }
    }
    
    
    // MARK: - Components
    struct PhotoPickerButton: View {
        var body: some View {
            VStack(spacing: TLayout.spacingM) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 32))
                    .foregroundColor(TColor.areapolPrimary)
                
                Text("select_photos_button")
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.areapolPrimary)
                
                Text("photo_format_info")
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
            }
            .frame(maxWidth: .infinity)
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .shadow(
                color: TElevation.medium.color,
                radius: TElevation.medium.radius,
                x: TElevation.medium.x,
                y: TElevation.medium.y
            )
        }
    }
    
    struct EmptyPhotoStateView: View {
        var body: some View {
            VStack(spacing: TLayout.spacingM) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 48))
                    .foregroundColor(TColor.textSecondary)
                
                Text("no_photos_selected")
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                Text("photo_upload_instruction")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                    .multilineTextAlignment(.center)
            }
            .padding(TLayout.padding)
            .frame(maxWidth: .infinity)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    struct SelectedPhotosGridView: View {
        let images: [UIImage]
        let removeAction: (Int) -> Void // Parametre alan closure
        
        var body: some View {
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text("selected_photos_label")
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                LazyVGrid(
                    columns: [GridItem(.adaptive(minimum: 100), spacing: TLayout.spacing)],
                    spacing: TLayout.spacing
                ) {
                    ForEach(images.indices, id: \.self) { index in
                        PhotoItemView(
                            image: images[index],
                            removeAction: {
                                removeAction(index) // Index parametresini iletiyoruz
                            }
                        )
                    }
                }
            }
            .animation(.easeInOut, value: images.count)
        }
    }
    
    struct PhotoItemView: View {
        let image: UIImage
        let removeAction: () -> Void
        
        var body: some View {
            ZStack(alignment: .topTrailing) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                    .shadow(
                        color: TElevation.low.color,
                        radius: TElevation.low.radius,
                        x: TElevation.low.x,
                        y: TElevation.low.y
                    )
                
                RemovePhotoButton(action: removeAction)
            }
        }
    }
    
    struct RemovePhotoButton: View {
        let action: () -> Void
        
        var body: some View {
            Button(action: action) {
                Image(systemName: "xmark.circle.fill")
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(TColor.onPrimary, TColor.error)
                    .font(.system(size: 20))
            }
            .padding(4)
        }
    }
}
// MARK: - Preview
struct MediaUploadStepView_Previews: PreviewProvider {
    static var previews: some View {
        MediaUploadStepView(viewModel: AddPropertyViewModel())
            .padding()
            .background(TColor.background)
    }
}
