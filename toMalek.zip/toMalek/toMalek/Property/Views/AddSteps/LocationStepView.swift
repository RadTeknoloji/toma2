//
//  LocationStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import MapKit

struct LocationPin: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
}

struct LocationStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    @StateObject private var locationManager = LocationManager()
    @State private var searchText = ""
    @State private var selectedCoordinate: LocationPin?
    @State private var mapPosition: MapCameraPosition = .automatic
    
    var body: some View {
        mainContent
            .padding(TLayout.spacingS)
            .background(TColor.background)
            .onAppear(perform: setupInitialLocation)
            .onChange(of: locationManager.formattedAddress) { _, newValue in  // _, eklendi
                handleAddressChange(newValue)
            }
    }
    
    // MARK: - Main Components
    private var mainContent: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            stepHeader
            searchSection
            mapSection
            locationDetailsSection
            errorSection
            Spacer()
        }
    }
    
    private var stepHeader: some View {
        Text(PropertyFormStep.locationInfo.description)
            .font(TFont.footnote)
            .foregroundColor(TColor.textSecondary)
    }
    
    // MARK: - Search Section
    private var searchSection: some View {
        Group {
            searchBar
            searchResultsList
        }
    }
    
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(TColor.textSecondary)
            
            TextField("search_address_placeholder", text: $searchText)
                .foregroundColor(TColor.textPrimary)
                .background(TColor.background)
                .onChange(of: searchText) { _, newValue in
                    locationManager.searchAddress(newValue)
                }
            
            clearSearchButton
        }
        .textFieldStyle()
    }
    
    private var clearSearchButton: some View {
        Group {
            if !searchText.isEmpty {
                Button(action: clearSearch) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(TColor.textSecondary)
                }
            }
        }
    }
    
    private var searchResultsList: some View {
        Group {
            if !searchText.isEmpty && !locationManager.searchResults.isEmpty {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        ForEach(locationManager.searchResults, id: \.self) { result in
                            searchResultItem(for: result)
                            Divider()
                        }
                    }
                    .padding(TLayout.spacingS)
                }
                .searchResultsStyle()
            }
        }
    }
    
    private func searchResultItem(for result: MKLocalSearchCompletion) -> some View {
        Button {
            selectSearchResult(result)
            // Adres seçildiğinde haritayı taşı
            Task {
                if let coordinate = await locationManager.getCoordinateFromResult(result) {
                    mapPosition = .region(MKCoordinateRegion(
                        center: coordinate,
                        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                    ))
                }
            }
        } label: {
            VStack(alignment: .leading) {
                Text(result.title)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textPrimary)
                Text(result.subtitle)
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
            }
        }
        .buttonStyle(.plain)
    }
    
    // MARK: - Map Section
    private var mapSection: some View {
        ZStack(alignment: .bottomTrailing) {
            mapReader
            locationButtons
            
            if selectedCoordinate == nil {
                VStack(spacing: TLayout.spacingXS) {
                    Text("map_guidance_line1")
                        .font(TFont.caption)
                    Text("map_guidance_line2")
                        .font(TFont.caption)
                }
                .foregroundColor(TColor.textSecondary)
                .padding(TLayout.spacingS)
                .background(TColor.background)
                .cornerRadius(TLayout.cornerRadius)
                .shadow(radius: 1)
                .padding(TLayout.spacingS)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
        }
        .frame(height: 300)
    }
    
    private var mapReader: some View {
        MapReader { proxy in
            Map(position: $mapPosition) {
                UserAnnotation()
                annotationLayer
            }
            .mapStyle(.standard(elevation: .realistic))
            .gesture(longPressGesture(proxy: proxy))
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    
    private var annotationLayer: some MapContent {
        Group {
            if let selectedCoordinate = selectedCoordinate {
                Annotation("", coordinate: selectedCoordinate.coordinate) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.title)
                        .foregroundColor(TColor.error)
                        .shadow(radius: 2)
                }
            }
        }
    }
    
    private var locationButtons: some View {
        VStack(spacing: TLayout.spacingS) {
            Button(action: focusOnUserLocation) {
                Image(systemName: "location")
                    .padding(TLayout.spacingS)
                    .background(TColor.background)
                    .cornerRadius(TLayout.cornerRadius)
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
        .padding(.trailing, TLayout.spacingS)
    }
    
    // MARK: - Location Details
    private var locationDetailsSection: some View {
        Group {
            if locationManager.isLoading {
                loadingIndicator
            } else if let details = locationManager.addressDetails {
                VStack(alignment: .leading, spacing: TLayout.spacingM) {
                    Text("selected_location_label")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                    
                    VStack(alignment: .leading, spacing: TLayout.spacingS) {
                        addressDetailRow("address_label", details.streetAddress)
                        addressDetailRow("neighborhood_label", details.neighborhood)
                        addressDetailRow("district_label", details.district)
                        addressDetailRow("city_label", details.city)
                        addressDetailRow("province_label", details.province)
                        addressDetailRow("state_label", details.state)
                        addressDetailRow("country_label", details.country)
                        addressDetailRow("postal_code_label", details.postalCode)
                    }
                    .padding(TLayout.spacingS)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
        }
    }

    private func addressDetailRow(_ label: LocalizedStringKey, _ value: String?) -> some View {
        Group {
            if let value = value {
                HStack {
                    Text(label)
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                    Spacer()
                    Text(value)
                        .font(TFont.footnote)
                }
            } else {
                EmptyView()
            }
        }
    }
    
    private var loadingIndicator: some View {
        HStack {
            Spacer()
            ProgressView()
                .tint(TColor.areapolPrimary)
            Spacer()
        }
    }
    
    private var errorSection: some View {
        Group {
            if let error = locationManager.errorMessage {
                Text(error)
                    .font(TFont.caption)
                    .foregroundColor(TColor.error)
                    .padding(.top)
            }
        }
    }
    
    // MARK: - Gesture Handlers
    private func longPressGesture(proxy: MapProxy) -> some Gesture {
        LongPressGesture(minimumDuration: 0.3)
            .sequenced(before: DragGesture(minimumDistance: 0))
            .onEnded { value in
                handleLongPress(value: value, proxy: proxy)
            }
    }
    
    private func handleLongPress(value: SequenceGesture<LongPressGesture, DragGesture>.Value, proxy: MapProxy) {
        guard case .second(_, let drag) = value,
              let dragLocation = drag?.location,
              let coordinate = proxy.convert(dragLocation, from: .local) else {
            return
        }
        
        viewModel.latitude = coordinate.latitude
        viewModel.longitude = coordinate.longitude
        selectedCoordinate = LocationPin(coordinate: coordinate)
        
        Task {
            await locationManager.getAddressFromLocation(coordinate)
        }
    }
    
    // MARK: - Action Handlers
    private func clearSearch() {
        searchText = ""
    }
    
    private func selectSearchResult(_ result: MKLocalSearchCompletion) {
        locationManager.selectSearchResult(result)
        searchText = ""
    }
    
    private func focusOnUserLocation() {
        locationManager.requestLocation { location in
            guard let coordinate = location?.coordinate else { return }
            
            DispatchQueue.main.async {
                self.mapPosition = .region(MKCoordinateRegion(
                    center: coordinate,
                    span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                ))
            }
        }
    }
    // MARK: - Lifecycle Handlers
    private func setupInitialLocation() {
        guard let lat = viewModel.latitude,
              let lon = viewModel.longitude else { return }
        
        selectedCoordinate = LocationPin(coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon))
        mapPosition = .region(MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: lat, longitude: lon),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        ))
        
        if viewModel.formattedAddress == nil {
            Task {
                await locationManager.getAddressFromLocation(CLLocationCoordinate2D(latitude: lat, longitude: lon))
            }
        } else {
            locationManager.formattedAddress = viewModel.formattedAddress
        }
    }
    
    private func handleAddressChange(_ newAddress: String?) {
        guard let newAddress = newAddress else { return }
        viewModel.formattedAddress = newAddress
        
        // Adres detaylarını viewModel'e aktar
        if let details = locationManager.addressDetails {
            viewModel.streetAddress = details.streetAddress
            viewModel.neighborhood = details.neighborhood
            viewModel.district = details.district
            viewModel.city = details.city
            viewModel.province = details.province
            viewModel.state = details.state
            viewModel.country = details.country
            viewModel.postalCode = details.postalCode
        }
    }
}

// MARK: - View Modifiers
extension View {
    fileprivate func textFieldStyle() -> some View {
        self
            .padding(TLayout.spacingS)
            .background(TColor.background)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(TColor.border, lineWidth: 1)
            )
    }
    
    fileprivate func searchResultsStyle() -> some View {
        self
            .background(TColor.background)
            .cornerRadius(TLayout.cornerRadius)
            .frame(maxHeight: 200)
    }
    
    fileprivate func userLocationButtonStyle() -> some View {
        self
            .buttonBorderShape(.circle)
            .tint(TColor.areapolPrimary)
    }
}

#Preview {
    LocationStepView(viewModel: AddPropertyViewModel())
}
