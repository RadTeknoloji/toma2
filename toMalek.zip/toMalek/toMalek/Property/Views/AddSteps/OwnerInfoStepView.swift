//
//  OwnerInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct OwnerInfoStepView: View {
    @ObservedObject private var viewModel: AddPropertyViewModel
    
    init(viewModel: AddPropertyViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            // Header Section
            Text(PropertyFormStep.ownerInfo.description)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
            
            // Content Section
            Group {
                switch viewModel.activeUserType {
                case .owner:
                    ownerInfoDisplay
                case .tenant, .agency:
                    ownerInfoInput
                }
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .shadow(color: TElevation.low.color, radius: TElevation.low.radius, x: TElevation.low.x, y: TElevation.low.y)
        }
        .padding(.horizontal, TLayout.padding)
    }
    
    // MARK: - Subviews
    private var ownerInfoDisplay: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            InfoRowView(label: "owner_name_label", value: viewModel.ownerName)
            InfoRowView(label: "owner_phone_label", value: PhoneFormat.format(viewModel.ownerPhone))
            
            Text("owner_info_readonly_note")
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
                .padding(.top, TLayout.spacingS)
        }
    }
    
    private var ownerInfoInput: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            // Name Input
            inputField(
                label: "owner_name_label",
                placeholder: "owner_name_placeholder",
                text: $viewModel.ownerName,
                error: viewModel.ownerName.isEmpty ? "owner_name_required" : nil
            )
            
            // Phone Input
            inputField(
                label: "owner_phone_label",
                placeholder: "owner_phone_placeholder",
                text: $viewModel.ownerPhone,
                error: !viewModel.ownerPhone.isEmpty && !isValidPhone(viewModel.ownerPhone) ? "owner_phone_invalid" : nil,
                keyboardType: .phonePad
            )
        }
    }
    
    // MARK: - Helper Methods
    private func inputField(
        label: LocalizedStringKey,
        placeholder: LocalizedStringKey,
        text: Binding<String>,
        error: String?,
        keyboardType: UIKeyboardType = .default
    ) -> some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(label)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            TextField(placeholder, text: text)
                .customTextFieldStyle()
                .keyboardType(keyboardType)
                .textInputAutocapitalization(.words)
                .onChange(of: text.wrappedValue) { _, newValue in
                    if keyboardType == .phonePad {
                        let filtered = newValue.filter { $0.isNumber }
                        if filtered != newValue {
                            text.wrappedValue = filtered
                        }
                    }
                }
            
            if let error {
                Text(error)
                    .font(TFont.caption)
                    .foregroundColor(TColor.error)
            }
        }
    }
    
    private func isValidPhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{10,13}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let cleanPhone = phone.filter { $0.isNumber }
        return phonePredicate.evaluate(with: cleanPhone)
    }
}

// MARK: - Helper Views
struct InfoRowView: View {
    let label: LocalizedStringKey
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
            
            Spacer()
            
            Text(value)
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
        }
    }
}

extension View {
    func customTextFieldStyle() -> some View {
        self
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            .padding(.horizontal, TLayout.spacingS)
            .frame(height: 44)
            .background(TColor.background)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(TColor.border.opacity(0.3), lineWidth: 1)
            )
    }
}

// Preview Provider
struct OwnerInfoStepView_Previews: PreviewProvider {
    static var previews: some View {
        OwnerInfoStepView(viewModel: AddPropertyViewModel())
            .padding()
            .background(TColor.background)
    }
}
