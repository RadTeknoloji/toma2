//
//  BuildingDetailsStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct BuildingDetailsStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(PropertyFormStep.buildingDetails.description)
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView {
                VStack(spacing: 20) {
                    // Property Type Specific Content
                    Group {
                        switch viewModel.propertyType {
                        case .residential:
                            residentialContent
                        case .commercial:
                            commercialContent
                        case .land:
                            landContent
                        case .machine:
                            machineContent
                        case .timeshareProperty:
                            timeshareContent
                        }
                    }
                    
                    // Common Content
                    if viewModel.propertyType != .land && viewModel.propertyType != .machine {
                        heatingTypeSection
                    }
                }
                .padding(.bottom, 30)
            }
        }
    }
    
    // MARK: - Residential Content
    private var residentialContent: some View {
        Group {
            netSquareMetersSection
            buildingAgeSection
            buildingFloorsSection
            floorLocationSection
            roomCountSection
            bathroomCountSection
            kitchenCountSection
            constructionMaterialSection
            directionFacadeSection
        }
    }
    
    // MARK: - Commercial Content
    private var commercialContent: some View {
        Group {
            netSquareMetersSection
            buildingAgeSection
            buildingFloorsSection
            floorLocationSection
            commercialRoomCountSection
            kitchenCountSection
            constructionMaterialSection
        }
    }
    
    // MARK: - Land Content
    private var landContent: some View {
        Group {
            netSquareMetersSection
            adaNoSection
            parselNoSection
        }
    }
    
    // MARK: - Machine Content
    private var machineContent: some View {
        Group {
            machineAgeSection
            warrantyStatusSection
            serviceSupportSection
        }
    }
    
    // MARK: - Timeshare Content
    private var timeshareContent: some View {
        Group {
            netSquareMetersSection
            buildingFloorsSection
            floorLocationSection
            roomCountSection
            bathroomCountSection
            kitchenCountSection
            constructionMaterialSection
            periodDateSection
        }
    }
}

// MARK: - Section Components
extension BuildingDetailsStepView {
    // MARK: Building Age
    private var buildingAgeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("building_age_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(BuildingAge.allCases, id: \.self) { age in
                        selectionRow(
                            systemImage: "calendar",
                            text: Text(String(format: String(localized: "building_age_format"), age.rawValue)),
                            isSelected: viewModel.buildingAge == age
                        ) {
                            viewModel.buildingAge = age
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Building Floors
    private var buildingFloorsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("floor_count_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(BuildingFloorCount.allCases, id: \.self) { count in
                        selectionRow(
                            systemImage: "building.2",
                            text: Text(String(format: String(localized: "floor_count_format"), count.rawValue)),
                            isSelected: viewModel.buildingFloorCount == count
                        ) {
                            viewModel.buildingFloorCount = count
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Floor Location
    private var floorLocationSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("floor_location_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(FloorLocation.allCases, id: \.self) { location in
                        selectionRow(
                            systemImage: "level",
                            text: Text(location.localizedText),
                            isSelected: viewModel.floorLocation == location
                        ) {
                            viewModel.floorLocation = location
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Residential Room Count
    private var roomCountSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("room_count_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(RoomCount.allCases.filter { $0 != .openOffice }, id: \.self) { count in
                        selectionRow(
                            systemImage: "bed.double",
                            text: Text(roomCountText(count)),
                            isSelected: viewModel.roomCount == count
                        ) {
                            viewModel.roomCount = count
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Commercial Room Count
    private var commercialRoomCountSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("room_count_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(RoomCount.allCases, id: \.self) { count in
                        selectionRow(
                            systemImage: count == .openOffice ? "officebuilding" : "bed.double",
                            text: Text(count == .openOffice ? String(localized: "room_count_open_office") : roomCountText(count)),
                            isSelected: viewModel.roomCount == count
                        ) {
                            viewModel.roomCount = count
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Bathroom Count
    private var bathroomCountSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("bathroom_count_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(BathroomCount.allCases, id: \.self) { count in
                        selectionRow(
                            systemImage: "shower",
                            text: Text(String(format: String(localized: "bathroom_count_format"), count.rawValue)),
                            isSelected: viewModel.bathroomCount == count
                        ) {
                            viewModel.bathroomCount = count
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Kitchen Count
    private var kitchenCountSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("kitchen_count_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(KitchenCount.allCases, id: \.self) { count in
                        selectionRow(
                            systemImage: "cooktop",
                            text: Text(count == .none ? String(localized: "kitchen_none") : String(format: String(localized: "kitchen_count_format"), count.rawValue)),
                            isSelected: viewModel.kitchenCount == count
                        ) {
                            viewModel.kitchenCount = count
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Heating Type
    private var heatingTypeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("heating_type_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(HeatingType.allCases, id: \.self) { type in
                        selectionRow(
                            systemImage: heatingTypeIcon(type),
                            text: Text(heatingTypeText(type)),
                            isSelected: viewModel.heatingType == type
                        ) {
                            viewModel.heatingType = type
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Construction Material
    private var constructionMaterialSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("construction_material_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(ConstructionMaterial.allCases, id: \.self) { material in
                        selectionRow(
                            systemImage: "hammer",
                            text: Text(material.localizedKey),
                            isSelected: viewModel.constructionMaterial == material
                        ) {
                            viewModel.constructionMaterial = material
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Direction Facade
    private var directionFacadeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("direction_facade_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(DirectionFacade.allCases, id: \.self) { direction in
                        selectionRow(
                            systemImage: "location.north",
                            text: Text(direction.localizedKey),
                            isSelected: viewModel.directionFacade == direction
                        ) {
                            viewModel.directionFacade = direction
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Net Square Meters
    private var netSquareMetersSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("net_square_meters_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            TextField("m²", text: $viewModel.netSquareMeters)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
    
    // MARK: Land Details
    private var adaNoSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("ada_number_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            TextField(String(localized: "ada_number_placeholder"), text: $viewModel.adaNo)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
    
    private var parselNoSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("parcel_number_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            TextField(String(localized: "parcel_number_placeholder"), text: $viewModel.parselNo)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
    
    // MARK: Machine Details
    private var machineAgeSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("machine_age_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(BuildingAge.allCases, id: \.self) { age in
                        selectionRow(
                            systemImage: "calendar",
                            text: Text(String(format: String(localized: "building_age_format"), age.rawValue)),
                            isSelected: viewModel.machineAge == age
                        ) {
                            viewModel.machineAge = age
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    private var warrantyStatusSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("warranty_status_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(WarrantyStatus.allCases, id: \.self) { status in
                        selectionRow(
                            systemImage: "checkmark.shield",
                            text: Text(status.localizedKey),
                            isSelected: viewModel.warrantyStatus == status
                        ) {
                            viewModel.warrantyStatus = status
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    private var serviceSupportSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("service_support_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(spacing: 8) {
                    ForEach(ServiceSupport.allCases, id: \.self) { support in
                        selectionRow(
                            systemImage: "wrench.and.screwdriver",
                            text: Text(support.localizedKey),
                            isSelected: viewModel.serviceSupport == support
                        ) {
                            viewModel.serviceSupport = support
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
    }
    
    // MARK: Timeshare Period
    private var periodDateSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("period_dates_label")
                .font(.subheadline)
                .foregroundColor(.border)
            
            DatePicker(
                "start_date",
                selection: Binding<Date>(
                    get: { viewModel.periodStartDate ?? Date() },
                    set: { viewModel.periodStartDate = $0 }
                ),
                displayedComponents: .date
            )
            
            DatePicker(
                "end_date",
                selection: Binding<Date>(
                    get: { viewModel.periodEndDate ?? Date() },
                    set: { viewModel.periodEndDate = $0 }
                ),
                in: (viewModel.periodStartDate ?? Date())...,
                displayedComponents: .date
            )
        }
    }
}

// MARK: - Helper Methods
extension BuildingDetailsStepView {
    private func selectionRow(
        systemImage: String,
        text: Text,
        isSelected: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: systemImage)
                text
                    .foregroundColor(.areapolPrimary)
                Spacer()
                if isSelected {
                    Image(systemName: "checkmark")
                        .foregroundColor(.blue)
                }
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isSelected ? Color.blue.opacity(0.1) : Color(.systemGray6))
            )
        }
    }
    
    private func roomCountText(_ count: RoomCount) -> String {
        switch count {
        case .openOffice: return String(localized: "room_count_open_office")
        case .studio: return String(localized: "room_count_studio")
        case .room1_0: return "1+0"
        case .room1_1: return "1+1"
        case .room2_0: return "2+0"
        case .room2_1: return "2+1"
        case .room3_1: return "3+1"
        case .room4_1: return "4+1"
        case .room5_1: return "5+1"
        case .room6_1: return "6+1"
        case .room7_1: return "7+1"
        case .room8_1: return "8+1"
        case .other: return String(localized: "room_count_other")
        }
    }
    
    private func heatingTypeText(_ type: HeatingType) -> String {
        switch type {
        case .none: return String(localized: "heating_type_none")
        case .combi: return String(localized: "heating_type_combi")
        case .underfloor: return String(localized: "heating_type_underfloor")
        case .central: return String(localized: "heating_type_central")
        case .stove: return String(localized: "heating_type_stove")
        case .fullSolar: return String(localized: "heating_type_full_solar")
        case .partialSolar: return String(localized: "heating_type_partial_solar")
        case .airCondition: return String(localized: "heating_type_air_condition")
        case .other: return String(localized: "heating_type_other")
        }
    }
    
    private func heatingTypeIcon(_ type: HeatingType) -> String {
        switch type {
        case .none: return "questionmark.circle"
        case .combi: return "flame"
        case .underfloor: return "arrow.down.forward.and.arrow.up.backward"
        case .central: return "building"
        case .stove: return "flame.fill"
        case .fullSolar: return "sun.max.fill"
        case .partialSolar: return "sun.min"
        case .airCondition: return "snowflake"
        case .other: return "questionmark.circle.fill" // Eksik kısım tamamlandı
        }
    }
}
