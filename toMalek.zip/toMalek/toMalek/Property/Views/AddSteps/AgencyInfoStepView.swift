//
//  AgencyInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct AgencyInfoStepView: View {
    @ObservedObject private var viewModel: AddPropertyViewModel
    
    // Sayfaya özel bileşenler
    private struct AgencyTextFieldStyle: TextFieldStyle {
        func _body(configuration: TextField<Self._Label>) -> some View {
            configuration
                .font(TFont.body)
                .padding(TLayout.spacingS)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(TColor.areapolPrimary.opacity(0.2), lineWidth: 1)
                )
        }
    }
    
    init(viewModel: AddPropertyViewModel) {
        self._viewModel = ObservedObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Text(PropertyFormStep.agencyInfo.description)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            switch viewModel.activeUserType {
            case .agency:
                agencyInfoSection
                
                Text("agency_info_readonly_note")
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
                    .padding(.top, TLayout.spacingXS)
                
            case .owner, .tenant:
                inputFieldsSection
            }
        }
        .padding(TLayout.spacingM)
        .background(TColor.background)
    }
    
    // MARK: - Components
    private var agencyInfoSection: some View {
        VStack(spacing: TLayout.spacingM) {
            VStack(spacing: TLayout.spacingS) {
                InfoRowView(
                    label: LocalizedStringKey("agency_name_label"),
                    value: viewModel.agencyName ?? ""
                )
                
                InfoRowView(
                    label: LocalizedStringKey("agent_name_label"),
                    value: viewModel.agentName ?? ""
                )
                
                InfoRowView(
                    label: LocalizedStringKey("agent_phone_label"),
                    value: PhoneFormat.format(viewModel.agentPhone ?? "")
                )
            }
            .padding(TLayout.spacingM)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    private var inputFieldsSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(LocalizedStringKey("agency_name_label"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                TextField(
                    LocalizedStringKey("agency_name_placeholder"),
                    text: Binding(
                        get: { viewModel.agencyName ?? "" },
                        set: { viewModel.agencyName = $0.isEmpty ? nil : $0 }
                    )
                )
                .textFieldStyle(AgencyTextFieldStyle())
            }
            
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(LocalizedStringKey("agent_name_label"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                TextField(
                    LocalizedStringKey("agent_name_placeholder"),
                    text: Binding(
                        get: { viewModel.agentName ?? "" },
                        set: { viewModel.agentName = $0.isEmpty ? nil : $0 }
                    )
                )
                .textFieldStyle(AgencyTextFieldStyle())
            }
            
            phoneInputField
        }
    }
    
    private var phoneInputField: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(LocalizedStringKey("agent_phone_label"))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            TextField(
                LocalizedStringKey("agent_phone_placeholder"),
                text: Binding(
                    get: { viewModel.agentPhone ?? "" },
                    set: {
                        let filtered = $0.filter { $0.isNumber }
                        viewModel.agentPhone = filtered.isEmpty ? nil : filtered
                    }
                )
            )
            .textFieldStyle(AgencyTextFieldStyle())
            .keyboardType(.phonePad)
            
            if let phone = viewModel.agentPhone, !phone.isEmpty && !isValidPhone(phone) {
                Text(LocalizedStringKey("agent_phone_invalid"))
                    .font(TFont.caption)
                    .foregroundColor(TColor.error)
                    .padding(.leading, TLayout.spacingXS)
            }
        }
    }
    
    // MARK: - Validation
    private func isValidPhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{10,13}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let cleanPhone = phone.filter { $0.isNumber }
        return phonePredicate.evaluate(with: cleanPhone)
    }
}
