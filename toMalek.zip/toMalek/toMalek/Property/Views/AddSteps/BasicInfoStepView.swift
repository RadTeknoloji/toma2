//
//  BasicInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct BasicInfoStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    @EnvironmentObject var authState: AuthenticationState
    @FocusState private var isTitleFocused: Bool
    
    private var canShowSaleStatus: Bool {
        authState.userType != "tenant"
    }
    
    // Sayfaya özel stil bileşenleri
    private struct TypeSelectionButtonStyle: ButtonStyle {
        let isSelected: Bool
        
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .contentShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                .background(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .fill(isSelected ? TColor.areapolPrimary.opacity(0.1) : TColor.surface)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(isSelected ? TColor.areapolPrimary : TColor.surface, lineWidth: 1)
                )
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Text(PropertyFormStep.basicInfo.description)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            // Title Input
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(LocalizedStringKey("title_label"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                TextField(LocalizedStringKey("title_placeholder"), text: $viewModel.title)
                    .font(TFont.body)
                    .padding(TLayout.spacingS)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                    .textInputAutocapitalization(.characters)
                    .focused($isTitleFocused)
                    .overlay(
                        RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                            .stroke(TColor.areapolPrimary.opacity(0.2), lineWidth: 1)
                    )
            }
            .padding(.bottom, TLayout.spacingS)
            
            // Property Type and Sub Type Selection
            HStack(alignment: .top, spacing: TLayout.spacingM) {
                propertyTypeColumn
                subTypeColumn
            }
            
            // Status Selection
            PropertyStatusSelectionView(
                rentalStatus: $viewModel.rentalStatus,
                saleStatus: $viewModel.saleStatus,
                canShowSaleStatus: canShowSaleStatus
            )
        }
        .padding(TLayout.spacingM)
        .background(TColor.background)
    }

    
    // MARK: - Property Type Column
    private var propertyTypeColumn: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(LocalizedStringKey("property_type_label"))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            ScrollView {
                VStack(spacing: TLayout.spacingXS) {
                    ForEach(PropertyType.allCases, id: \.self) { type in
                        Button {
                            isTitleFocused = false
                            viewModel.propertyType = type
                        } label: {
                            HStack {
                                Image(systemName: propertyTypeIcon(type))
                                    .foregroundColor(TColor.areapolPrimary)
                                Text(propertyTypeText(type))
                                    .font(TFont.body)
                                    .foregroundColor(TColor.textPrimary)
                                Spacer()
                                if viewModel.propertyType == type {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(TColor.areapolPrimary)
                                }
                            }
                            .padding(TLayout.spacingS)
                        }
                        .buttonStyle(TypeSelectionButtonStyle(isSelected: viewModel.propertyType == type))
                    }
                }
            }
            .frame(maxHeight: 200)
        }
        .frame(maxWidth: .infinity)
    }
    
    // MARK: - Sub Type Column
    private var subTypeColumn: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(subTypeTitle)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            ScrollView {
                VStack(spacing: TLayout.spacingXS) {
                    switch viewModel.propertyType {
                    case .residential:
                        ForEach(ResidentialType.allCases, id: \.self) { type in
                            subTypeButton(
                                title: residentialTypeText(type),
                                icon: residentialTypeIcon(type),
                                isSelected: viewModel.residentialType == type
                            ) {
                                viewModel.residentialType = type
                            }
                        }
                    case .commercial:
                        ForEach(CommercialType.allCases, id: \.self) { type in
                            subTypeButton(
                                title: commercialTypeText(type),
                                icon: commercialTypeIcon(type),
                                isSelected: viewModel.commercialType == type
                            ) {
                                viewModel.commercialType = type
                            }
                        }
                    case .land:
                        ForEach(LandType.allCases, id: \.self) { type in
                            subTypeButton(
                                title: landTypeText(type),
                                icon: landTypeIcon(type),
                                isSelected: viewModel.landType == type
                            ) {
                                viewModel.landType = type
                            }
                        }
                    case .machine:
                        ForEach(MachineType.allCases, id: \.self) { type in
                            subTypeButton(
                                title: machineTypeText(type),
                                icon: machineTypeIcon(type),
                                isSelected: viewModel.machineType == type
                            ) {
                                viewModel.machineType = type
                            }
                        }
                    case .timeshareProperty:
                        ForEach(TimeshareType.allCases, id: \.self) { type in
                            subTypeButton(
                                title: timeshareTypeText(type),
                                icon: timeshareTypeIcon(type),
                                isSelected: viewModel.timeshareType == type
                            ) {
                                viewModel.timeshareType = type
                            }
                        }
                    }
                }
            }
            .frame(maxHeight: 200)
        }
        .frame(maxWidth: .infinity)
    }
    
    // MARK: - Sub Type Button Builder
    private func subTypeButton(title: String, icon: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(TColor.areapolPrimary)
                Text(title)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
                Spacer()
                if isSelected {
                    Image(systemName: "checkmark")
                        .foregroundColor(TColor.areapolPrimary)
                }
            }
            .padding(TLayout.spacingS)
        }
        .buttonStyle(TypeSelectionButtonStyle(isSelected: isSelected))
    }
    
    
    // MARK: - Status Button
    private func statusButton(title: String, isSelected: Bool, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(TFont.footnote)
                .padding(.horizontal, TLayout.spacingM)
                .padding(.vertical, TLayout.spacingS)
                .background(isSelected ? color.opacity(0.1) : TColor.surface)
                .foregroundColor(isSelected ? color : TColor.textPrimary)
                .cornerRadius(TLayout.cornerRadius)
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(isSelected ? color : TColor.surface, lineWidth: 1)
                )
        }
    }

    // MARK: - Helper Functions
    private func getRentalStatusColor(_ status: RentalStatus) -> Color {
        switch status {
        case .rented: return TColor.error
        case .reserved: return TColor.warning
        case .available: return TColor.success
        case .notRent: return TColor.success

        }
    }

    private func getSaleStatusColor(_ status: SaleStatus) -> Color {
        switch status {
        case .forSale, .available: return TColor.success
        case .sold: return TColor.error
        case .reserved: return TColor.warning
        }
    }
    // MARK: - Helper Properties
    private var subTypeTitle: String {
        switch viewModel.propertyType {
        case .residential: return String(localized: "residential_type_label")
        case .commercial: return String(localized: "commercial_type_label")
        case .land: return String(localized: "land_type_label")
        case .machine: return String(localized: "machine_type_label")
        case .timeshareProperty: return String(localized: "timeshare_type_label")
        }
    }
    
    // MARK: - Property Type Icons
    private func propertyTypeIcon(_ type: PropertyType) -> String {
        switch type {
        case .residential: return "house.fill"
        case .commercial: return "building.2.fill"
        case .land: return "mountain.2.fill"
        case .machine: return "wrench.and.screwdriver.fill"
        case .timeshareProperty: return "clock.badge.checkmark"
        }
    }
    
    // MARK: - Sub Type Icons
    private func residentialTypeIcon(_ type: ResidentialType) -> String {
        switch type {
        case .apartment: return "building.2"
        case .residence: return "building.columns"
        case .villa: return "house"
        case .detachedHouse: return "house.lodge"
        case .building: return "building"
        case .waterfrontMansion: return "water.waves"
        case .mansion: return "building.columns.fill"
        case .farmhouse: return "leaf"
        }
    }
    
    private func commercialTypeIcon(_ type: CommercialType) -> String {
        switch type {
        case .office: return "briefcase"
        case .store: return "cart"
        case .factory: return "building.2.crop.circle"
        case .school: return "graduationcap"
        case .gasStation: return "fuelpump"
        case .workshop: return "hammer"
        case .kiosk: return "takeoutbag.and.cup.and.straw"
        case .cafeBar: return "cup.and.saucer"
        case .animalFarm: return "pawprint"
        case .warehouse: return "shippingbox"
        case .weddingVenue: return "heart"
        case .garage: return "car.rear"
        case .parkingLot: return "parkingsign"
        case .canteen: return "fork.knife"
        case .garden: return "tree"
        case .carWash: return "car.front.waves.up"
        case .bakery: return "oven"
        case .dessertShop: return "birthday.cake"
        case .restaurant: return "fork.knife"
        case .marketplace: return "cart.badge.plus"
        case .sportsFacility: return "sportscourt"
        case .dormitory: return "bed.double"
        case .other: return "building"
        }
    }
    
    private func landTypeIcon(_ type: LandType) -> String {
        switch type {
        case .zoned: return "map"
        case .unzoned: return "map.fill"
        case .floorEquivalent: return "building.2"
        case .field: return "tractor"
        case .other: return "mountain.2"
        }
    }
    
    private func machineTypeIcon(_ type: MachineType) -> String {
        switch type {
        case .workVehicle: return "car"
        case .industrialMachine: return "gearshape.2"
        case .other: return "wrench.and.screwdriver"
        }
    }
    
    private func timeshareTypeIcon(_ type: TimeshareType) -> String {
        switch type {
        case .hotel: return "building"
        case .thermalResort: return "thermal"
        case .summerHouse: return "beach.umbrella"
        case .villa: return "house"
        case .apartment: return "building.2"
        case .residence: return "building.columns"
        }
    }
    
    // MARK: - Type Texts
    private func propertyTypeText(_ type: PropertyType) -> String {
        switch type {
        case .residential: return String(localized: "property_type_residential")
        case .commercial: return String(localized: "property_type_commercial")
        case .land: return String(localized: "property_type_land")
        case .machine: return String(localized: "property_type_machine")
        case .timeshareProperty: return String(localized: "property_type_timeshare")
        }
    }
    
    private func residentialTypeText(_ type: ResidentialType) -> String {
        switch type {
        case .apartment: return String(localized: "residential_type_apartment")
        case .residence: return String(localized: "residential_type_residence")
        case .villa: return String(localized: "residential_type_villa")
        case .detachedHouse: return String(localized: "residential_type_detached_house")
        case .building: return String(localized: "residential_type_building")
        case .waterfrontMansion: return String(localized: "residential_type_waterfront_mansion")
        case .mansion: return String(localized: "residential_type_mansion")
        case .farmhouse: return String(localized: "residential_type_farmhouse")
        }
    }
    
    private func commercialTypeText(_ type: CommercialType) -> String {
        switch type {
        case .office: return String(localized: "commercial_type_office")
        case .store: return String(localized: "commercial_type_store")
        case .factory: return String(localized: "commercial_type_factory")
        case .school: return String(localized: "commercial_type_school")
        case .gasStation: return String(localized: "commercial_type_gas_station")
        case .workshop: return String(localized: "commercial_type_workshop")
        case .kiosk: return String(localized: "commercial_type_kiosk")
        case .cafeBar: return String(localized: "commercial_type_cafe_bar")
        case .animalFarm: return String(localized: "commercial_type_animal_farm")
        case .warehouse: return String(localized: "commercial_type_warehouse")
        case .weddingVenue: return String(localized: "commercial_type_wedding_venue")
        case .garage: return String(localized: "commercial_type_garage")
        case .parkingLot: return String(localized: "commercial_type_parking_lot")
        case .canteen: return String(localized: "commercial_type_canteen")
        case .garden: return String(localized: "commercial_type_garden")
        case .carWash: return String(localized: "commercial_type_car_wash")
        case .bakery: return String(localized: "commercial_type_bakery")
        case .dessertShop: return String(localized: "commercial_type_dessert_shop")
        case .restaurant: return String(localized: "commercial_type_restaurant")
        case .marketplace: return String(localized: "commercial_type_marketplace")
        case .sportsFacility: return String(localized: "commercial_type_sports_facility")
        case .dormitory: return String(localized: "commercial_type_dormitory")
        case .other: return String(localized: "commercial_type_other")
        }
    }
    
    private func landTypeText(_ type: LandType) -> String {
        switch type {
        case .zoned: return String(localized: "land_type_zoned")
        case .unzoned: return String(localized: "land_type_unzoned")
        case .floorEquivalent: return String(localized: "land_type_floor_equivalent")
        case .field: return String(localized: "land_type_field")
        case .other: return String(localized: "land_type_other")
        }
    }
    
    private func machineTypeText(_ type: MachineType) -> String {
        switch type {
        case .workVehicle: return String(localized: "machine_type_work_vehicle")
        case .industrialMachine: return String(localized: "machine_type_industrial")
        case .other: return String(localized: "machine_type_other")
        }
    }
    
    private func timeshareTypeText(_ type: TimeshareType) -> String {
        switch type {
        case .hotel: return String(localized: "timeshare_type_hotel")
        case .thermalResort: return String(localized: "timeshare_type_thermal_resort")
        case .summerHouse: return String(localized: "timeshare_type_summer_house")
        case .villa: return String(localized: "timeshare_type_villa")
        case .apartment: return String(localized: "timeshare_type_apartment")
        case .residence: return String(localized: "timeshare_type_residence")
        }
    }
}
