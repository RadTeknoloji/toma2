//
//  PropertyFormStep.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation

enum PropertyFormStep: Int, CaseIterable {
    case basicInfo
    case buildingDetails
    case propertyAdvantages
    case locationInfo
    case ownerInfo
    case tenantInfo
    case agencyInfo
    case financialInfo
    case contractInfo
    case mediaUpload
    
    var title: String {
        switch self {
        case .basicInfo: return String(localized: "step_basic_info_title")
        case .buildingDetails: return String(localized: "step_building_details_title")
        case .propertyAdvantages: return String(localized: "step_property_advantages_title")
        case .locationInfo: return String(localized: "step_location_info_title")
        case .ownerInfo: return String(localized: "step_owner_info_title")
        case .tenantInfo: return String(localized: "step_tenant_info_title")
        case .agencyInfo: return String(localized: "step_agency_info_title")
        case .financialInfo: return String(localized: "step_financial_info_title")
        case .contractInfo: return String(localized: "step_contract_info_title")
        case .mediaUpload: return String(localized: "step_media_upload_title")
        }
    }
    
    var description: String {
        switch self {
        case .basicInfo: return String(localized: "step_basic_info_description")
        case .buildingDetails: return String(localized: "step_building_details_description")
        case .propertyAdvantages: return String(localized: "step_property_advantages_description")
        case .locationInfo: return String(localized: "step_location_info_description")
        case .ownerInfo: return String(localized: "step_owner_info_description")
        case .tenantInfo: return String(localized: "step_tenant_info_description")
        case .agencyInfo: return String(localized: "step_agency_info_description")
        case .financialInfo: return String(localized: "step_financial_info_description")
        case .contractInfo: return String(localized: "step_contract_info_description")
        case .mediaUpload: return String(localized: "step_media_upload_description")
        }
    }
    
    var systemImage: String {
        switch self {
        case .basicInfo: return "house.fill"
        case .buildingDetails: return "building.2.fill"
        case .propertyAdvantages: return "checklist"
        case .locationInfo: return "map.fill"
        case .ownerInfo: return "person.fill"
        case .tenantInfo: return "person.2.fill"
        case .agencyInfo: return "building.columns.fill"
        case .financialInfo: return "banknote.fill"
        case .contractInfo: return "doc.fill"
        case .mediaUpload: return "photo.fill"
        }
    }
}
