//
//  FinancialInfoStepView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct FinancialInfoStepView: View {
    @ObservedObject var viewModel: AddPropertyViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            Text(PropertyFormStep.financialInfo.description)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            if viewModel.isOwner {
                // Sale Price (Only for owners)
                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                    Text("sale_price_label")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                    
                    HStack {
                        TextField("0,00", text: $viewModel.salePrice)
                            .textFieldStyle(FormTextFieldStyle())
                            .padding(TLayout.spacingXS)
                            .background(TColor.surface)
                            .cornerRadius(TLayout.cornerRadius)
                            .keyboardType(.decimalPad)
                            .onChange(of: viewModel.salePrice) { oldValue, newValue in
                                viewModel.salePrice = formatCurrency(newValue)
                            }
                        
                        Picker("", selection: $viewModel.saleCurrency) {
                            ForEach(CurrencyType.allCases, id: \.self) { currency in
                                Text(currency.symbol).tag(currency)
                            }
                        }
                        .frame(width: 100)
                        .accentColor(TColor.areapolPrimary)
                    }
                }
            } else {
                // Sale Price Display (For tenants)
                if !viewModel.salePrice.isEmpty {
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text("sale_price_label")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        
                        Text("\(viewModel.salePrice) \(viewModel.saleCurrency.symbol)")
                            .font(TFont.bodyBold)
                            .foregroundColor(TColor.textPrimary)
                    }
                    .padding(TLayout.spacingS)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
            
            // Rent Price
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("rent_price_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                HStack {
                    TextField("0,00", text: $viewModel.rentPrice)
                        .textFieldStyle(FormTextFieldStyle())
                        .padding(TLayout.spacingXS)
                        .background(TColor.surface)
                        .cornerRadius(TLayout.cornerRadius)
                        .keyboardType(.decimalPad)
                        .onChange(of: viewModel.rentPrice) { oldValue, newValue in
                            viewModel.rentPrice = formatCurrency(newValue)
                        }
                    
                    Picker("", selection: $viewModel.rentCurrency) {
                        ForEach(CurrencyType.allCases, id: \.self) { currency in
                            Text(currency.symbol).tag(currency)
                        }
                    }
                    .frame(width: 100)
                    .accentColor(TColor.areapolPrimary)
                }
                
                if viewModel.rentPrice.isEmpty {
                    Text("rent_price_required")
                        .font(TFont.caption)
                        .foregroundColor(TColor.error)
                }
            }
            
            // Deposit Amount
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text("deposit_amount_label")
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                HStack {
                    TextField("0,00", text: $viewModel.depositAmount)
                        .textFieldStyle(FormTextFieldStyle())
                        .padding(TLayout.spacingXS)
                        .background(TColor.surface)
                        .cornerRadius(TLayout.cornerRadius)
                        .keyboardType(.decimalPad)
                        .onChange(of: viewModel.depositAmount) { oldValue, newValue in
                            viewModel.depositAmount = formatCurrency(newValue)
                        }
                    
                    Picker("", selection: $viewModel.depositCurrency) {
                        ForEach(CurrencyType.allCases, id: \.self) { currency in
                            Text(currency.symbol).tag(currency)
                        }
                    }
                    .frame(width: 100)
                    .accentColor(TColor.areapolPrimary)
                }
                
                if viewModel.depositAmount.isEmpty {
                    Text("deposit_amount_required")
                        .font(TFont.caption)
                        .foregroundColor(TColor.error)
                }
            }
        }
        .padding(TLayout.spacingS)
        .background(TColor.background)
    }
    
    private func formatCurrency(_ value: String) -> String {
        let cleaned = value.filter("0123456789,".contains)
        let parts = cleaned.split(separator: ",")
        
        if parts.count > 1 {
            let whole = parts[0]
            let fraction = parts[1].prefix(2)
            return "\(whole),\(fraction)"
        }
        
        return cleaned
    }
}
