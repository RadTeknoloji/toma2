//
//  EditPropertyView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct EditPropertyView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: EditPropertyViewModel
    
    init(property: PropertyModel) {
        let viewModel = EditPropertyViewModel(property: property)
        _viewModel = StateObject(wrappedValue: viewModel)
    }
    
    var body: some View {
        NavigationView {
            Form {
                // MARK: - Basic Info Section
                Section {
                    contentHeader("basic_info_section")
                    
                    TextField("title_label", text: $viewModel.title)
                        .textFieldStyle(TTextFieldStyle())
                    
                    Picker("property_type_label", selection: $viewModel.propertyType) {
                        ForEach(PropertyType.allCases, id: \.self) { type in
                            Text(type.rawValue.localized())
                                .tag(type)
                        }
                    }
                    .pickerStyle(.menu)
                    
                    propertySubTypeField
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Address Info Section
                Section {
                    contentHeader("address_info_section")
                    
                    addressField("street_address_label", text: $viewModel.streetAddress)
                    addressField("neighborhood_label", text: $viewModel.neighborhood)
                    addressField("district_label", text: $viewModel.district)
                    addressField("city_label", text: $viewModel.city)
                    addressField("province_label", text: $viewModel.province)
                    addressField("state_label", text: $viewModel.state)
                    addressField("country_label", text: $viewModel.country)
                    addressField("postal_code_label", text: $viewModel.postalCode)
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Building Details Section
                if viewModel.propertyType == .residential {
                    Section {
                        contentHeader("building_details_section")
                        
                        agePicker
                        floorCountPicker
                        floorLocationPicker
                        roomCountPicker
                        bathroomCountPicker
                        kitchenCountPicker
                        heatingTypePicker
                    }
                    .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                }
                
                // MARK: - Owner Info Section
                Section {
                    contentHeader("owner_info_section")
                    
                    TextField("owner_name_label", text: $viewModel.ownerName)
                        .textFieldStyle(TTextFieldStyle())
                    
                    TextField("owner_phone_label", text: $viewModel.ownerPhone)
                        .textFieldStyle(TTextFieldStyle())
                        .keyboardType(.phonePad)
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Tenant Info Section
                Section {
                    contentHeader("tenant_info_section")
                    
                    TextField("tenant_name_label", text: Binding(
                        get: { viewModel.tenantName ?? "" },
                        set: { viewModel.tenantName = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    
                    TextField("tenant_phone_label", text: Binding(
                        get: { viewModel.tenantPhone ?? "" },
                        set: { viewModel.tenantPhone = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    .keyboardType(.phonePad)
                    
                    TextField("tenant_email_label", text: Binding(
                        get: { viewModel.tenantEmail ?? "" },
                        set: { viewModel.tenantEmail = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Agency Info Section
                Section {
                    contentHeader("agency_info_section")
                    
                    TextField("agency_name_label", text: Binding(
                        get: { viewModel.agencyName ?? "" },
                        set: { viewModel.agencyName = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    
                    TextField("agent_name_label", text: Binding(
                        get: { viewModel.agentName ?? "" },
                        set: { viewModel.agentName = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    
                    TextField("agent_phone_label", text: Binding(
                        get: { viewModel.agentPhone ?? "" },
                        set: { viewModel.agentPhone = $0.isEmpty ? nil : $0 }
                    ))
                    .textFieldStyle(TTextFieldStyle())
                    .keyboardType(.phonePad)
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Financial Info Section
                Section {
                    contentHeader("financial_info_section")
                    
                    priceField("sale_price_label", text: $viewModel.salePrice, currency: $viewModel.saleCurrency)
                    priceField("rent_price_label", text: $viewModel.rentPrice, currency: $viewModel.rentCurrency)
                    priceField("deposit_amount_label", text: $viewModel.depositAmount, currency: $viewModel.depositCurrency)
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Contract Info Section
                Section {
                    contentHeader("contract_info_section")
                    
                    if let startDate = viewModel.rentStartDate {
                        DatePicker(
                            "rent_start_date_label",
                            selection: .constant(startDate),
                            displayedComponents: .date
                        )
                    }
                    
                    Picker("contract_time_label", selection: $viewModel.contractTime) {
                        ForEach(ContractTime.allCases, id: \.self) { time in
                            Text(time.description).tag(time)
                        }
                    }
                    
                    Picker("contract_type_label", selection: $viewModel.contractType) {
                        ForEach(ContractType.allCases, id: \.self) { type in
                            Text(type.rawValue.localized()).tag(type)
                        }
                    }
                    
                    Picker("payment_day_label", selection: $viewModel.paymentDay) {
                        ForEach(PaymentDay.allCases, id: \.self) { day in
                            Text(day.displayName)
                                .tag(day)
                        }
                    }
                }
                .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                
                // MARK: - Matching Status Section
                if viewModel.matchedToPropertyId != nil {
                    Section {
                        contentHeader("matching_status_section")
                        
                        InfoRow(
                            label: "matched_property_code",
                            value: viewModel.matchedToPropertyId ?? ""
                        )
                        
                        InfoRow(
                            label: "created_by_user_type",
                            value: viewModel.createdByUserType.rawValue.localized()
                        )
                    }
                    .listRowSeparatorTint(TColor.textSecondary.opacity(0.2))
                }
            }
            .scrollContentBackground(.hidden)
            .background(TColor.background)
            .navigationTitle("edit_property_title")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await viewModel.checkEditPermission()
            }
            .disabled(!viewModel.canEdit)
            .overlay {
                if !viewModel.canEdit {
                    Text(String(localized: "error_no_edit_permission"))
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.error)
                        .padding()
                        .background(TColor.border.opacity(0.1))
                        .cornerRadius(TLayout.cornerRadius)
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("cancel_button") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("save_button") {
                        Task {
                            await viewModel.save()
                        }
                    }
                    .disabled(!viewModel.canEdit)
                }
            }
            .overlay(loadingOverlay)
            .alert("error_alert_title", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok_button", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                        .font(TFont.body)
                        .foregroundColor(TColor.textPrimary)
                }
            }
        }
    }
    
    // MARK: - Helper Views
    private func contentHeader(_ title: LocalizedStringKey) -> some View {
        Text(title)
            .font(TFont.footnoteBold)
            .foregroundColor(TColor.textSecondary)
            .padding(.vertical, TLayout.spacingXS)
    }
    
    private func addressField(_ label: LocalizedStringKey, text: Binding<String?>) -> some View {
        TextField(label, text: Binding(
            get: { text.wrappedValue ?? "" },
            set: { text.wrappedValue = $0.isEmpty ? nil : $0 }
        ))
        .textFieldStyle(TTextFieldStyle())
    }
    
    private func priceField(_ label: LocalizedStringKey, text: Binding<String>, currency: Binding<CurrencyType>) -> some View {
        HStack {
            TextField(label, text: text)
                .keyboardType(.decimalPad)
                .textFieldStyle(TTextFieldStyle())
            
            Picker("", selection: currency) {
                ForEach(CurrencyType.allCases, id: \.self) { currency in
                    Text(currency.symbol).tag(currency)
                }
            }
            .frame(width: 100)
            .labelsHidden()
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: TColor.areapolPrimary))
                    .scaleEffect(1.5)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(TColor.background.opacity(0.8))
            }
        }
    }
    
    // MARK: - Pickers
    private var propertySubTypeField: some View {
        Group {
            switch viewModel.propertyType {
            case .residential:
                Picker("residential_type_label", selection: $viewModel.residentialType) {
                    Text("select_option").tag(Optional<ResidentialType>.none)
                    ForEach(ResidentialType.allCases, id: \.self) { type in
                        Text(type.rawValue.localized()).tag(Optional(type))
                    }
                }
                
            case .commercial:
                Picker("commercial_type_label", selection: $viewModel.commercialType) {
                    Text("select_option").tag(Optional<CommercialType>.none)
                    ForEach(CommercialType.allCases, id: \.self) { type in
                        Text(type.rawValue.localized()).tag(Optional(type))
                    }
                }
                
            case .land:
                Picker("land_type_label", selection: $viewModel.landType) {
                    Text("select_option").tag(Optional<LandType>.none)
                    ForEach(LandType.allCases, id: \.self) { type in
                        Text(type.rawValue.localized()).tag(Optional(type))
                    }
                }
                
            case .machine:
                Picker("machine_type_label", selection: $viewModel.machineType) {
                    Text("select_option").tag(Optional<MachineType>.none)
                    ForEach(MachineType.allCases, id: \.self) { type in
                        Text(type.rawValue.localized()).tag(Optional(type))
                    }
                }
                
            case .timeshareProperty:
                Picker("timeshare_type_label", selection: $viewModel.timeshareType) {
                    Text("select_option").tag(Optional<TimeshareType>.none)
                    ForEach(TimeshareType.allCases, id: \.self) { type in
                        Text(type.rawValue.localized()).tag(Optional(type))
                    }
                }
            }
        }
        .pickerStyle(.menu)
    }
    
    private var agePicker: some View {
        Picker("building_age_label", selection: $viewModel.buildingAge) {
            Text("select_option").tag(Optional<BuildingAge>.none)
            ForEach(BuildingAge.allCases, id: \.self) { age in
                Text("\(age.rawValue)").tag(Optional(age))
            }
        }
    }
    
    private var floorCountPicker: some View {
        Picker("floor_count_label", selection: $viewModel.buildingFloorCount) {
            Text("select_option").tag(Optional<BuildingFloorCount>.none)
            ForEach(BuildingFloorCount.allCases, id: \.self) { count in
                Text("\(count.rawValue)").tag(Optional(count))
            }
        }
    }
    
    private var floorLocationPicker: some View {
        Picker("floor_location_label", selection: $viewModel.floorLocation) {
            Text("select_option").tag(Optional<FloorLocation>.none)
            ForEach(FloorLocation.allCases, id: \.self) { location in
                Text(location.localizedText).tag(Optional(location))
            }
        }
    }
    
    private var roomCountPicker: some View {
        Picker("room_count_label", selection: $viewModel.roomCount) {
            Text("select_option").tag(Optional<RoomCount>.none)
            ForEach(RoomCount.allCases, id: \.self) { count in
                Text(count.rawValue.localized()).tag(Optional(count))
            }
        }
    }
    
    private var bathroomCountPicker: some View {
        Picker("bathroom_count_label", selection: $viewModel.bathroomCount) {
            Text("select_option").tag(Optional<BathroomCount>.none)
            ForEach(BathroomCount.allCases, id: \.self) { count in
                Text("\(count.rawValue)").tag(Optional(count))
            }
        }
    }
    
    private var kitchenCountPicker: some View {
        Picker("kitchen_count_label", selection: $viewModel.kitchenCount) {
            Text("select_option").tag(Optional<KitchenCount>.none)
            ForEach(KitchenCount.allCases, id: \.self) { count in
                Text(count == .none ? "kitchen_none".localized() : "\(count.rawValue)").tag(Optional(count))
            }
        }
    }
    
    private var heatingTypePicker: some View {
        Picker("heating_type_label", selection: $viewModel.heatingType) {
            Text("select_option").tag(Optional<HeatingType>.none)
            ForEach(HeatingType.allCases, id: \.self) { type in
                Text(type.rawValue.localized()).tag(Optional(type))
            }
        }
    }
}

// MARK: - Helper Components
struct InfoRow: View {
    let label: LocalizedStringKey
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            Spacer()
            Text(value)
                .font(TFont.footnote)
                .foregroundColor(TColor.textPrimary)
        }
    }
}

// MARK: - TTextFieldStyle
struct TTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            .padding(.horizontal, TLayout.spacingS)
            .frame(height: 44)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(TColor.border.opacity(0.3), lineWidth: 1)
            )
    }
}
