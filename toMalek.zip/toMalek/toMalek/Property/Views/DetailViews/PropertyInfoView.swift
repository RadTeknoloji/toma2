//
//  PropertyInfoView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

import SwiftUI
import MapKit

struct PropertyInfoView: View {
    @ObservedObject var viewModel: PropertyDetailViewModel
    @State private var isDescriptionExpanded = true
    @State private var isLocationExpanded = false
    
    var body: some View {
        VStack(spacing: TLayout.spacingXL) {
            // Header Section
            propertyHeaderSection
            
            // Pricing Section
            pricingSection
            
            // Status Section
            propertyStatusSection
            
            // Type Section
            propertyTypeSection
            
            // Description Section
            descriptionSection
            
            // Location Section
            locationSection
            
            // Advantages Section
            advantagesSection
            
            // Match Status Section
            if let matchStatus = viewModel.property.matchStatus {
                matchStatusSection(status: matchStatus)
            }
        }
    }
    
    // MARK: - Header Section
    private var propertyHeaderSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            Text(viewModel.property.title)
                .font(TFont.h2)
                .foregroundColor(TColor.textPrimary)
            
            HStack {
                Image(systemName: "number.circle.fill")
                    .foregroundColor(TColor.areapolPrimary)
                Text(viewModel.property.propertyCode)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Status Section
    private var propertyStatusSection: some View {
        VStack(spacing: TLayout.spacingM) {
            // Listing Status
            StatusRow(
                icon: "tag.fill",
                title: "listing_status",
                status: viewModel.property.listingStatus.localizedDescription,
                backgroundColor: TColor.areapolPrimary.opacity(0.1),
                textColor: TColor.areapolPrimary
            )
            
            // Reserve Status
            StatusRow(
                icon: "clock.fill",
                title: "reserve_status",
                status: viewModel.property.reserveStatus.localizedDescription,
                backgroundColor: viewModel.property.reserveStatus == .reserved ? TColor.warning.opacity(0.1) : TColor.success.opacity(0.1),
                textColor: viewModel.property.reserveStatus == .reserved ? TColor.warning : TColor.success
            )
            
            // Rental Status
            StatusRow(
                icon: "key.fill",
                title: "rental_status",
                status: viewModel.property.rentalStatus.rawValue.localized(),
                backgroundColor: TColor.areapolPrimary.opacity(0.1),
                textColor: TColor.areapolPrimary,
                isEditable: true,
                menuContent: {
                    AnyView(
                        Menu {
                            ForEach(RentalStatus.allCases, id: \.self) { status in
                                Button(status.rawValue.localized()) {
                                    Task {
                                        try await viewModel.updateRentalStatus(status)
                                    }
                                }
                            }
                        } label: {
                            HStack {
                                Text(viewModel.property.rentalStatus.rawValue.localized())
                                Image(systemName: "chevron.down")
                                    .font(.caption)
                            }
                        }
                    )
                }
            )
            
            // Sale Status
            if viewModel.canShowSaleStatus {
                StatusRow(
                    icon: "cart.fill",
                    title: "sale_status",
                    status: viewModel.property.saleStatus.rawValue.localized(),
                    backgroundColor: TColor.areapolPrimary.opacity(0.1),
                    textColor: TColor.areapolPrimary,
                    isEditable: true,
                    menuContent: {
                        AnyView(
                            Menu {
                                ForEach(SaleStatus.allCases, id: \.self) { status in
                                    Button(status.rawValue.localized()) {
                                        Task {
                                            try await viewModel.updateSaleStatus(status)
                                        }
                                    }
                                }
                            } label: {
                                HStack {
                                    Text(viewModel.property.saleStatus.rawValue.localized())
                                    Image(systemName: "chevron.down")
                                        .font(.caption)
                                }
                            }
                        )
                    }
                )
            }
        }
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    
    // MARK: - Type Section
    private var propertyTypeSection: some View {
        HStack(spacing: TLayout.spacingL) {
            propertyTypeItem(
                title: viewModel.propertyTypeText,
                subtitle: "property_type",
                icon: "building.2.fill"
            )
            
            if let subType = viewModel.subTypeText {
                propertyTypeItem(
                    title: subType,
                    subtitle: "sub_type",
                    icon: "building.fill"
                )
            }
        }
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Description Section
    private var descriptionSection: some View {
        DisclosureGroup(
            isExpanded: $isDescriptionExpanded,
            content: {
                Text(viewModel.property.description ?? "custom_description_placeholder")
                    .font(TFont.body)
                    .foregroundColor(TColor.textSecondary)
                    .padding(TLayout.spacing)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(TColor.onPrimary.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                HStack {
                    Image(systemName: "text.alignleft")
                        .foregroundColor(TColor.areapolPrimary)
                    Text("description")
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                }
            }
        )
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Location Section
    private var locationSection: some View {
        DisclosureGroup(
            isExpanded: $isLocationExpanded,
            content: {
                VStack(spacing: TLayout.spacingM) {
                    // Tam Adres her zaman gösterilir
                    if let address = viewModel.property.formattedAddress {
                        PropertyDetailRow(
                            title: "address",
                            value: address
                        )
                    }
                    
                    // Ülkeye göre adres detaylarını göster
                    if let country = viewModel.property.country {
                        switch country {
                        case "Turkey", "Türkiye":
                            // Mahalle
                            if let neighborhood = viewModel.property.neighborhood {
                                PropertyDetailRow(
                                    title: "neighborhood",
                                    value: neighborhood
                                )
                            }
                            
                            // İlçe
                            if let district = viewModel.property.district {
                                PropertyDetailRow(
                                    title: "district",
                                    value: district
                                )
                            }
                            
                            // İl (state olarak geliyor)
                            if let state = viewModel.property.state {
                                PropertyDetailRow(
                                    title: "city",
                                    value: state
                                )
                            }
                            
                        case "United States", "USA", "United States of America":
                            // Şehir
                            if let city = viewModel.property.city {
                                PropertyDetailRow(
                                    title: "city",
                                    value: city
                                )
                            }
                            
                            // Eyalet
                            if let state = viewModel.property.state {
                                PropertyDetailRow(
                                    title: "state",
                                    value: state
                                )
                            }
                            
                        default:
                            // Diğer ülkeler için genel format
                            if let city = viewModel.property.city {
                                PropertyDetailRow(
                                    title: "city",
                                    value: city
                                )
                            }
                            
                            if let state = viewModel.property.state {
                                PropertyDetailRow(
                                    title: "state",
                                    value: state
                                )
                            }
                        }
                        
                        // Ülke adı her zaman gösterilir
                        PropertyDetailRow(
                            title: "country",
                            value: country
                        )
                        
                        // Posta kodu varsa gösterilir
                        if let postalCode = viewModel.property.postalCode {
                            PropertyDetailRow(
                                title: "postal_code",
                                value: postalCode
                            )
                        }
                    }

                    // Koordinatlar ve Harita Butonu
                    if let latitude = viewModel.property.latitude,
                       let longitude = viewModel.property.longitude {
                        PropertyDetailRow(
                            title: "coordinates",
                            value: String(format: "%.6f, %.6f", latitude, longitude)
                        )
                        
                        Button {
                            openInMaps(latitude: latitude, longitude: longitude)
                        } label: {
                            HStack {
                                Image(systemName: "map.fill")
                                Text("open_in_maps")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(TColor.areapolPrimary)
                            .foregroundColor(.white)
                            .cornerRadius(TLayout.cornerRadius)
                        }
                    }
                }
                .padding()
                .background(TColor.onPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                HStack {
                    Image(systemName: "location.fill")
                        .foregroundColor(TColor.areapolPrimary)
                    Text("location")
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                }
            }
        )
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Advantage Section
    private var advantagesSection: some View {
        DisclosureGroup(
            content: {
                VStack(alignment: .leading, spacing: TLayout.spacingM) {
                    switch viewModel.property.propertyType {
                    case .residential:
                        if let advantages = viewModel.property.residentialAdvantages {
                            advantagesList(advantages.map { $0.rawValue.localized() })
                        }
                    case .commercial:
                        if let advantages = viewModel.property.commercialAdvantages {
                            advantagesList(advantages.map { $0.rawValue.localized() })
                        }
                    case .land:
                        if let advantages = viewModel.property.landAdvantages {
                            advantagesList(advantages.map { $0.rawValue.localized() })
                        }
                    case .machine:
                        if let advantages = viewModel.property.machineAdvantages {
                            advantagesList(advantages.map { $0.rawValue.localized() })
                        }
                    case .timeshareProperty:
                        if let advantages = viewModel.property.timeshareAdvantages {
                            advantagesList(advantages.map { $0.rawValue.localized() })
                        }
                    }
                }
                .padding()
                .background(TColor.onPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                HStack {
                    Image(systemName: "star.fill")
                        .foregroundColor(TColor.areapolPrimary)
                    Text("property_advantages")
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                }
            }
        )
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }

    private func advantagesList(_ advantages: [String]) -> some View {
        ForEach(advantages, id: \.self) { advantage in
            HStack(spacing: TLayout.spacingS) {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(TColor.success)
                Text(advantage)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
            }
        }
    }
    
    // MARK: - Pricing Section
    private var pricingSection: some View {
        VStack(spacing: TLayout.spacingL) {
            if let salePrice = viewModel.property.salePrice, salePrice > 0 {
                PriceRow(
                    title: "sale_price",
                    amount: salePrice,
                    currency: viewModel.property.saleCurrency,
                    color: TColor.areapolPrimary
                )
            }
            
            if let rentPrice = viewModel.property.rentPrice {
                PriceRow(
                    title: "rent_price",
                    amount: rentPrice,
                    currency: viewModel.property.rentCurrency,
                    color: TColor.success
                )
            }
            
            if let deposit = viewModel.property.depositAmount, deposit > 0 {
                PriceRow(
                    title: "deposit",
                    amount: deposit,
                    currency: viewModel.property.depositCurrency,
                    color: TColor.warning
                )
            }
        }
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Match Status Section
    private func matchStatusSection(status: MatchStatus) -> some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text("matching_status")
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            Text(status.localizedDescription)
                .font(TFont.bodyBold)
                .foregroundColor(TColor.areapolPrimary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
    }
    
    // MARK: - Helper Views
    private func propertyTypeItem(title: String, subtitle: LocalizedStringKey, icon: String) -> some View {
        VStack(spacing: TLayout.spacingXS) {
            HStack(spacing: TLayout.spacingXS) {
                Image(systemName: icon)
                    .foregroundColor(TColor.areapolPrimary)
                Text(title)
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.areapolPrimary)
            }
            Text(subtitle)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
        }
        .frame(maxWidth: .infinity)
    }
    
    // MARK: - Helper Functions
    private func openInMaps(latitude: Double, longitude: Double) {
        let coordinates = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let placemark = MKPlacemark(coordinate: coordinates)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.openInMaps()
    }
}
