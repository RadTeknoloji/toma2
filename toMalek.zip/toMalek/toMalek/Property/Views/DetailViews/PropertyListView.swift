//
//  PropertyListView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

// MARK: - Search Bar Component
struct SearchBarView: View {
    @Binding var searchText: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(TColor.textSecondary)
            
            TextField(LocalizedStringKey("search_property"), text: $searchText)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
        }
        .padding(TLayout.spacingS)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}

// MARK: - Filter Bar Component
struct FilterBarView: View {
    @Binding var selectedPropertyType: PropertyType?
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: TLayout.spacingS) {
                ForEach(PropertyType.allCases, id: \.self) { type in
                    FilterChip(
                        title: type.localizedKey,
                        isSelected: .init(
                            get: { selectedPropertyType == type },
                            set: { isSelected in
                                selectedPropertyType = isSelected ? type : nil
                            }
                        )
                    )
                }
            }
            .padding(.horizontal, TLayout.spacingXS)
        }
    }
}

// MARK: - Empty State View
struct EmptyStateView: View {
    let noSearchResults: Bool
    
    var body: some View {
        VStack(spacing: TLayout.spacingL) {
            if noSearchResults {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 48))
                    .foregroundColor(TColor.textSecondary)
                Text(LocalizedStringKey("no_search_results"))
                    .font(TFont.bodyBold)
            } else {
                Image(systemName: "house")
                    .font(.system(size: 48))
                    .foregroundColor(TColor.textSecondary)
                Text(LocalizedStringKey("no_properties"))
                    .font(TFont.bodyBold)
            }
            
            Text(LocalizedStringKey("add_property_hint"))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
        }
        .foregroundColor(TColor.textPrimary)
    }
}

// MARK: - Property Media Preview
struct PropertyMediaPreview: View {
    let mediaUrls: [String]
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: TLayout.spacingS) {
                ForEach(mediaUrls.prefix(5), id: \.self) { mediaUrl in
                    AsyncImage(url: URL(string: mediaUrl)) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .frame(width: 80, height: 80)
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 80)
                                .cornerRadius(TLayout.cornerRadius)
                                .clipped()
                        case .failure:
                            Image(systemName: "photo")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 80)
                                .cornerRadius(TLayout.cornerRadius)
                                .foregroundColor(TColor.textSecondary)
                        @unknown default:
                            EmptyView()
                        }
                    }
                }
                
                if mediaUrls.count > 5 {
                    Text("+\(mediaUrls.count - 5)")
                        .font(TFont.caption)
                        .foregroundColor(TColor.onPrimary)
                        .frame(width: 80, height: 80)
                        .background(TColor.areapolPrimary.opacity(0.8))
                        .cornerRadius(TLayout.cornerRadius)
                }
            }
            .padding(.vertical, TLayout.spacingXS)
        }
    }
}

// MARK: - Property Card View
struct PropertyCard: View {
    let property: PropertyModel
    let onDelete: () -> Void
    
    private var remainingRentalDays: Int? {
        guard let endDate = property.rentStartDate?.addingTimeInterval(
            TimeInterval(property.contractTime.rawValue * 30 * 24 * 60 * 60)
        ) else { return nil }
        
        let days = Calendar.current.dateComponents([.day], from: Date(), to: endDate).day ?? 0
        return days > 0 ? days : nil
    }
    
    var body: some View {
        NavigationLink {
            PropertyDetailView(property: property)
        } label: {
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                // Başlık ve Menü
                HStack {
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text(property.title)
                            .font(TFont.bodyBold)
                            .foregroundColor(TColor.textPrimary)
                        
                        Text(property.propertyCode)
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                    }
                    
                    Spacer()
                    
                    Menu {
                        NavigationLink {
                            EditPropertyView(property: property)
                        } label: {
                            Label(LocalizedStringKey("edit"), systemImage: "pencil")
                        }
                        
                        Button(role: .destructive) {
                            onDelete()
                        } label: {
                            Label(LocalizedStringKey("delete"), systemImage: "trash")
                        }
                    } label: {
                        Image(systemName: "ellipsis")
                            .font(TFont.body)
                            .foregroundColor(TColor.textSecondary)
                            .padding(TLayout.spacingXS)
                    }
                }
                
                // Medya Önizleme
                if !property.mediaUrls.isEmpty {
                    PropertyMediaPreview(mediaUrls: property.mediaUrls)
                }
                
                // Status Chips
                HStack(spacing: TLayout.spacingS) {
                    // Listing Status
                    Text(property.listingStatus.rawValue.localized())
                        .font(TFont.caption)
                        .foregroundColor(TColor.areapolPrimary)
                        .padding(.horizontal, TLayout.spacingXS)
                        .padding(.vertical, 4)
                        .background(TColor.areapolPrimary.opacity(0.1))
                        .cornerRadius(TLayout.cornerRadius)
                    
                    // Rental Status
                    Text(property.rentalStatus.rawValue.localized())
                        .font(TFont.caption)
                        .foregroundColor(property.rentalStatus == .rented ? TColor.error : TColor.success)
                        .padding(.horizontal, TLayout.spacingXS)
                        .padding(.vertical, 4)
                        .background((property.rentalStatus == .rented ? TColor.error : TColor.success).opacity(0.1))
                        .cornerRadius(TLayout.cornerRadius)
                }
                
                // Lokasyon Bilgileri
                if let district = property.district, let state = property.state {
                    Label("\(district), \(state)", systemImage: "location.fill")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
                
                // Alt Bilgiler
                VStack(spacing: TLayout.spacingXS) {
                    // Kira Bedeli
                    if let rentPrice = property.rentPrice {
                        HStack {
                            Text("rent_price_short")
                                .font(TFont.footnote)
                                .foregroundColor(TColor.textSecondary)
                            Spacer()
                            Text("\(String(format: "%.2f", rentPrice)) \(property.rentCurrency.symbol)")
                                .font(TFont.footnoteBold)
                                .foregroundColor(TColor.textPrimary)
                        }
                    }
                    
                    // Kalan Kira Süresi
                    if property.rentalStatus == .rented, let days = remainingRentalDays {
                        HStack {
                            Text("remaining_rental_period")
                                .font(TFont.footnote)
                                .foregroundColor(TColor.textSecondary)
                            Spacer()
                            Text(String(format: String(localized: "days_remaining"), days))
                                .font(TFont.footnoteBold)
                                .foregroundColor(days < 30 ? TColor.error : TColor.textPrimary)
                        }
                    }
                }
                .padding(.top, TLayout.spacingXS)
            }
            .padding(TLayout.spacingM)
            .background(TColor.card)
            .cornerRadius(TLayout.cornerRadiusL)
            .shadow(
                color: TColor.areapolPrimary.opacity(0.08),
                radius: 8,
                x: 0,
                y: 2
            )
        }
    }
}

// MARK: - Main Property List View
struct PropertyListView: View {
    @StateObject private var viewModel = PropertyListViewModel()
    
    var body: some View {
        ZStack {
            TColor.background
                .ignoresSafeArea()
            
            VStack(spacing: .zero) {
                VStack(spacing: TLayout.spacingM) {
                    SearchBarView(searchText: $viewModel.searchText)
                    FilterBarView(selectedPropertyType: $viewModel.selectedPropertyType)
                }
                .padding(TLayout.spacingM)
                .background(TColor.background)
                
                ScrollView {
                    LazyVStack(spacing: TLayout.spacingM) {
                        ForEach(viewModel.filteredProperties) { property in
                            PropertyCard(property: property) {
                                Task {
                                    await viewModel.deleteProperty(property)
                                }
                            }
                            .padding(.horizontal, TLayout.spacingM)
                        }
                    }
                    .padding(.vertical, TLayout.spacingM)
                }
                .refreshable {
                    await viewModel.refreshList()
                }
            }
            
            if viewModel.isEmptyResults {
                EmptyStateView(noSearchResults: viewModel.noSearchResults)
            }
            
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
            
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    IconButton(
                        icon: "plus",
                        action: { viewModel.showAddProperty = true }
                    )
                    .background(TColor.ColorRenksiz)
                    .foregroundColor(TColor.onPrimary)
                    .padding(TLayout.spacingL)
                }
            }
        }
        .navigationTitle(LocalizedStringKey("my_properties"))
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $viewModel.showAddProperty) {
            AddPropertyView()
        }
        .task {
            await viewModel.fetchProperties()
        }
        .overlay {
            if let error = viewModel.errorMessage {
                VStack {
                    Text(error)
                        .font(TFont.footnote)
                        .foregroundColor(TColor.onPrimary)
                        .padding()
                        .background(TColor.error)
                        .cornerRadius(TLayout.cornerRadius)
                        .padding()
                    Spacer()
                }
            }
        }
    }
}

struct PropertyListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            PropertyListView()
                .background(TColor.areapolPrimary)
        }
    }
}
