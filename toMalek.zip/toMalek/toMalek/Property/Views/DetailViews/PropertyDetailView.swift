//
//  PropertyDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import Firebase

struct PropertyDetailView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: PropertyDetailViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: PropertyDetailViewModel(property: property))
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // Ana içerik
            ScrollView {
                VStack(spacing: TLayout.spacingXL) {
                    PropertyMediaView(viewModel: viewModel)
                    PropertyInfoView(viewModel: viewModel)
                    PropertyContactView(viewModel: viewModel)
                    
                    // Alt bar için boşluk
                    Spacer().frame(height: 90)
                }
                .padding(TLayout.padding)
            }
            
            // Yeni Hızlı Eylemler Barı
            QuickActionsBar(viewModel: viewModel)
        }
        .navigationTitle(String(localized: "property_detail_title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
        .background(TColor.background.edgesIgnoringSafeArea(.all))
        .modifier(PropertyDetailModifiers(viewModel: viewModel))
        .onChange(of: viewModel.isDeleted) { if $1 { dismiss() } }
    }
    
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            Menu {
                Button {
                    viewModel.showEditProperty = true
                } label: {
                    Label("edit", systemImage: "pencil")
                        .foregroundColor(TColor.areapolPrimary)
                }
                
                Button(role: .destructive) {
                    viewModel.showDeleteAlert = true
                } label: {
                    Label("delete", systemImage: "trash")
                        .foregroundColor(TColor.error)
                }
            } label: {
                Image(systemName: "ellipsis")
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
    }
}

// MARK: - Hızlı Eylemler Barı (Güncellenmiş)
struct QuickActionsBar: View {
    @ObservedObject var viewModel: PropertyDetailViewModel
    private let buttonSize: CGFloat = 60
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(QuickAction.allCases, id: \.self) { action in
                    if action.isEnabled(viewModel.property) {
                        actionButton(for: action)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .frame(height: 72)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(TColor.background)
                .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 2)
        )
        .padding(.horizontal, 8)
        .padding(.bottom, 8)
    }
    
    private func actionButton(for action: QuickAction) -> some View {
        Button {
            viewModel.handleQuickAction(action)
        } label: {
            VStack(spacing: 4) {
                Image(systemName: action.iconName)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(action.iconColor)
                    .frame(width: 32, height: 32)
                
                Text(action.title)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(TColor.textSecondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(width: buttonSize)
            .padding(6)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white)
                    .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
            )
        }
    }
}

// MARK: - QuickAction Extension
extension QuickAction {
    var iconName: String {
        switch self {
        case .rentTracking: return "chart.line.uptrend.xyaxis"
        case .expenseTracking: return "list.clipboard"
        case .raiseRent: return "arrow.up.circle"
        case .renewContract: return "doc.text.fill"
        case .archive: return "archivebox"
        case .match: return "person.2.wave.2"
        case .rentOut: return "key.horizontal"
        case .listing: return "megaphone"
        case .createRequest: return "plus.message"
        case .assignAgent: return "person.badge.shield.checkmark"
        }
    }
    
    var iconColor: Color {
        switch self {
        case .rentTracking: return .green
        case .expenseTracking: return .orange
        case .raiseRent: return .blue
        case .renewContract: return .purple
        case .archive: return .gray
        case .match: return .pink
        case .rentOut: return .teal
        case .listing: return .indigo
        case .createRequest: return .mint
        case .assignAgent: return .brown
        }
    }
}

// MARK: - Modifiers
struct PropertyDetailModifiers: ViewModifier {
    @ObservedObject var viewModel: PropertyDetailViewModel
    
    func body(content: Content) -> some View {
        content
            .sheet(isPresented: $viewModel.showEditProperty) {
                EditPropertyView(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showRaiseRentSheet) {
                RaiseRentSheet(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showRenewContractSheet) {
                RenewContractSheet(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showRentOutSheet) {
                RentOutSheet(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showAssignAgentSheet) {
                AssignAgentSheet(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showMatchOptionsSheet) {
                MatchOptionsSheet(property: viewModel.property)
            }
            .sheet(isPresented: $viewModel.showArchiveConfirmation) {
                ArchiveConfirmationSheet(property: viewModel.property)
            }
            .alert("delete_property_title", isPresented: $viewModel.showDeleteAlert) {
                Button("delete", role: .destructive) {
                    Task { await viewModel.deleteProperty() }
                }
                Button("cancel", role: .cancel) {}
            }
    }
}
// MARK: - Helper Extensions
extension View {
    @ViewBuilder
    func ifLet<Value, Content: View>(_ value: Binding<Value?>, @ViewBuilder content: @escaping (Self, Binding<Value>) -> Content) -> some View {
        Group {
            if value.wrappedValue != nil {
                content(self, Binding(value)!)
            } else {
                self
            }
        }
    }
}
