//
//  PropertyComponents.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

// PropertyComponents.swift

import SwiftUI

struct PropertyDetailRow: View {
    let title: LocalizedStringKey
    let value: String
    
    var body: some View {
        GridRow {
            Text(title)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            Text(value)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textPrimary)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
    }
}

struct DetailSection: View {
    let title: LocalizedStringKey
    let items: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Text(title)
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
            
            VStack(spacing: TLayout.spacingM) {
                ForEach(items, id: \.self) { item in
                    HStack {
                        Text(item)
                            .font(TFont.subheadline)
                            .foregroundColor(TColor.textPrimary)
                        Spacer()
                    }
                }
            }
            .padding(TLayout.spacing)
            .background(TColor.areapolPrimary.opacity(0.1))
            .cornerRadius(TLayout.cornerRadius)
        }
    }
}

struct Badge: View {
    let text: String
    let backgroundColor: Color
    let textColor: Color
    
    var body: some View {
        Text(text)
            .font(TFont.caption)
            .foregroundColor(textColor)
            .padding(.horizontal, TLayout.spacingS)
            .padding(.vertical, TLayout.spacingXS)
            .background(backgroundColor)
            .cornerRadius(TLayout.cornerRadius)
    }
}

struct PriceRow: View {
    let title: LocalizedStringKey
    let amount: Double
    let currency: CurrencyType
    let color: Color
    
    var body: some View {
        HStack {
            Text(title)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
            Spacer()
            Text("\(amount.formatted()) \(currency.symbol)")
                .font(TFont.bodyBold)
                .foregroundColor(color)
        }
    }
}
