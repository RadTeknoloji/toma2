//
//  PropertyContactView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

// PropertyContactView.swift

import SwiftUI

struct PropertyContactView: View {
    @ObservedObject var viewModel: PropertyDetailViewModel
    
    
    @State private var isContractExpanded = false
    @State private var isOwnerExpanded = false
    @State private var isTenantExpanded = false
    @State private var isAgencyExpanded = false
    @State private var isPrimaryDetailsExpanded = false
    @State private var isSecondaryDetailsExpanded = false
    
    var body: some View {
        VStack(spacing: TLayout.spacingXL) {
            // Contract Section
            contractSection
            
            // Owner Section
            ownerSection
            
            // Tenant Section (if exists)
            if viewModel.property.tenantName != nil {
                tenantSection
            }
            
            // Agency Section (if exists)
            if viewModel.property.agencyName != nil {
                agencySection
            }
            
            // Dynamic Details Sections
            dynamicDetailsSections
            
            // Metadata Section
            metadataSection
        }
    }
    
    // MARK: - Contract Section
    private var contractSection: some View {
        DisclosureGroup(
            isExpanded: $isContractExpanded,
            content: {
                VStack(spacing: TLayout.spacingM) {
                    if let startDate = viewModel.property.rentStartDate {
                        PropertyDetailRow(
                            title: "start_date",
                            value: startDate.formatted(date: .long, time: .omitted)
                        )
                    }
                    
                    PropertyDetailRow(
                        title: "contract_duration",
                        value: viewModel.property.contractTime.description
                    )
                    
                    PropertyDetailRow(
                        title: "contract_type",
                        value: viewModel.property.contractType.localizedText
                    )
                }
                .padding()
                .background(TColor.areapolPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                sectionHeader(title: "contract_details", icon: "doc.text.fill")
            }
        )
        .cardStyle()
    }
    
    // MARK: - Owner Section
    private var ownerSection: some View {
        DisclosureGroup(
            isExpanded: $isOwnerExpanded,
            content: {
                VStack(spacing: TLayout.spacingM) {
                    contactRow(
                        name: viewModel.property.ownerName,
                        phone: viewModel.property.ownerPhone,
                        role: "owner",
                        callAction: viewModel.callOwner
                    )
                }
                .padding()
                .background(TColor.areapolPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                sectionHeader(title: "owner_info", icon: "person.fill")
            }
        )
        .cardStyle()
    }
    
    // MARK: - Tenant Section
    private var tenantSection: some View {
        DisclosureGroup(
            isExpanded: $isTenantExpanded,
            content: {
                VStack(spacing: TLayout.spacingM) {
                    if let tenantName = viewModel.property.tenantName {
                        contactRow(
                            name: tenantName,
                            phone: viewModel.property.tenantPhone,
                            email: viewModel.property.tenantEmail,
                            role: "tenant"
                        )
                    }
                }
                .padding()
                .background(TColor.areapolPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                sectionHeader(title: "tenant_info", icon: "person.2.fill")
            }
        )
        .cardStyle()
    }
    
    // MARK: - Agency Section
    private var agencySection: some View {
        DisclosureGroup(
            isExpanded: $isAgencyExpanded,
            content: {
                VStack(spacing: TLayout.spacingM) {
                    if let agencyName = viewModel.property.agencyName {
                        agencyRow(
                            agencyName: agencyName,
                            agentName: viewModel.property.agentName,
                            agentPhone: viewModel.property.agentPhone
                        )
                    }
                }
                .padding()
                .background(TColor.areapolPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            },
            label: {
                sectionHeader(title: "agency_info", icon: "building.2.fill")
            }
        )
        .cardStyle()
    }
    
    // MARK: - Dynamic Details Sections
    private var dynamicDetailsSections: some View {
        VStack(spacing: TLayout.spacingXL) {
            // Primary Details
            DisclosureGroup(
                isExpanded: $isPrimaryDetailsExpanded,
                content: {
                    DetailSection(title: "primary_details", items: viewModel.primaryDetails)
                },
                label: {
                    sectionHeader(title: "primary_details", icon: "list.bullet.circle.fill")
                }
            )
            .cardStyle()
            
            // Secondary Details
            DisclosureGroup(
                isExpanded: $isSecondaryDetailsExpanded,
                content: {
                    DetailSection(title: "additional_details", items: viewModel.secondaryDetails)
                },
                label: {
                    sectionHeader(title: "additional_details", icon: "list.bullet.rectangle.fill")
                }
            )
            .cardStyle()
        }
    }
    
    // MARK: - Metadata Section
    private var metadataSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            // Localized String + Tarih Formatı
            Text(
                String(
                    format: "created_at".localized(),
                    viewModel.property.createdAt.formatted()
                )
            )
            .metadataStyle()
            
            Text(
                String(
                    format: "updated_at".localized(),
                    viewModel.property.updatedAt.formatted()
                )
            )
            .metadataStyle()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(TColor.areapolPrimary.opacity(0.1))
        .cornerRadius(TLayout.cornerRadius)
    }
    
    // MARK: - Helper Views
    private func sectionHeader(title: LocalizedStringKey, icon: String) -> some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(TColor.areapolPrimary)
            Text(title)
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private func contactRow(name: String, phone: String?, email: String? = nil, role: LocalizedStringKey, callAction: (() -> Void)? = nil) -> some View {
        VStack(spacing: TLayout.spacingM) {
            HStack {
                Text(name)
                    .font(TFont.subheadline)
                Spacer()
                Image(systemName: "person.fill")
                    .foregroundColor(TColor.border)
            }
            
            if let phone = phone {
                Button {
                    if let action = callAction {
                        action()
                    } else if let url = URL(string: "tel://\(phone.filter { $0.isNumber })") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    HStack {
                        Text(phone)
                            .font(TFont.subheadline)
                        Spacer()
                        Image(systemName: "phone.fill")
                    }
                }
            }
            
            if let email = email {
                HStack {
                    Text(email)
                        .font(TFont.subheadline)
                    Spacer()
                    Image(systemName: "envelope.fill")
                        .foregroundColor(TColor.border)
                }
            }
        }
    }
    
    private func agencyRow(agencyName: String, agentName: String?, agentPhone: String?) -> some View {
        VStack(spacing: TLayout.spacingM) {
            HStack {
                Text(agencyName)
                    .font(TFont.subheadline)
                Spacer()
                Image(systemName: "building.2.fill")
                    .foregroundColor(TColor.border)
            }
            
            if let agentName = agentName {
                HStack {
                    Text(agentName)
                        .font(TFont.subheadline)
                    Spacer()
                    Image(systemName: "person.text.rectangle.fill")
                        .foregroundColor(TColor.border)
                }
            }
            
            if let agentPhone = agentPhone {
                Button {
                    if let url = URL(string: "tel://\(agentPhone.filter { $0.isNumber })") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    HStack {
                        Text(agentPhone)
                            .font(TFont.subheadline)
                        Spacer()
                        Image(systemName: "phone.fill")
                    }
                }
            }
        }
    }
}

// MARK: - View Modifiers
private extension View {
    func cardStyle() -> some View {
        self
            .padding()
            .background(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .fill(TColor.background)
                    .shadow(color: TColor.areapolPrimary.opacity(0.05), radius: 5)
            )
    }
    
    func metadataStyle() -> some View {
        self
            .font(TFont.caption)
            .foregroundColor(TColor.textSecondary)
    }
}

