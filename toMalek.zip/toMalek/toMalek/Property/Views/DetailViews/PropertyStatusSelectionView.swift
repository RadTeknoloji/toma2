//
//  PropertyStatusSelectionView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

import SwiftUI

struct PropertyStatusSelectionView: View {
    @Binding var rentalStatus: RentalStatus
    @Binding var saleStatus: SaleStatus
    var canShowSaleStatus: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            // Rental Status Selection
            RentalStatusSelectionView(selectedStatus: $rentalStatus)
            
            // Sale Status Selection
            if canShowSaleStatus {
                SaleStatusSelectionView(selectedStatus: $saleStatus)
            }
        }
    }
}

// MARK: - Rental Status Selection View
private struct RentalStatusSelectionView: View {
    @Binding var selectedStatus: RentalStatus
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text("rental_status_label")
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: TLayout.spacingS) {
                    ForEach(RentalStatus.allCases, id: \.self) { status in
                        StatusButton(
                            title: status.localizedDescription,
                            isSelected: selectedStatus == status,
                            color: getRentalStatusColor(status)
                        ) {
                            selectedStatus = status
                        }
                    }
                }
                .padding(.horizontal, TLayout.spacingXS)
            }
        }
    }
    
    private func getRentalStatusColor(_ status: RentalStatus) -> Color {
        switch status {
        case .rented: return TColor.error
        case .reserved: return TColor.warning
        case .available: return TColor.success
        case .notRent: return TColor.success
        }
    }
}

// MARK: - Sale Status Selection View
private struct SaleStatusSelectionView: View {
    @Binding var selectedStatus: SaleStatus
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text("sale_status_label")
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: TLayout.spacingS) {
                    ForEach(SaleStatus.allCases, id: \.self) { status in
                        StatusButton(
                            title: status.localizedDescription,
                            isSelected: selectedStatus == status,
                            color: getSaleStatusColor(status)
                        ) {
                            selectedStatus = status
                        }
                    }
                }
                .padding(.horizontal, TLayout.spacingXS)
            }
        }
    }
    
    private func getSaleStatusColor(_ status: SaleStatus) -> Color {
        switch status {
        case .forSale, .available: return TColor.success
        case .sold: return TColor.error
        case .reserved: return TColor.warning
        }
    }
}

// MARK: - Status Button View
private struct StatusButton: View {
    let title: String
    let isSelected: Bool
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(TFont.footnote)
                .padding(.horizontal, TLayout.spacingM)
                .padding(.vertical, TLayout.spacingS)
                .background(isSelected ? color.opacity(0.1) : TColor.surface)
                .foregroundColor(isSelected ? color : TColor.textPrimary)
                .cornerRadius(TLayout.cornerRadius)
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(isSelected ? color : TColor.surface, lineWidth: 1)
                )
        }
    }
}

#Preview {
    PropertyStatusSelectionView(
        rentalStatus: .constant(.available),
        saleStatus: .constant(.available),
        canShowSaleStatus: true
    )
    .padding()
}
