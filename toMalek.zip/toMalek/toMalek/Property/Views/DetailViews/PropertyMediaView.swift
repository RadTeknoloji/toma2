//
//  PropertyMediaView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

// PropertyMediaView.swift

import SwiftUI

struct PropertyMediaView: View {
    @ObservedObject var viewModel: PropertyDetailViewModel
    @State private var selectedImage: UIImage?
    @State private var showImagePreview = false
    
    var body: some View {
        VStack(spacing: TLayout.spacingL) {
            // Media Carousel Section
            mediaCarouselSection

        }
        .sheet(isPresented: $viewModel.showMediaPicker) {
            MediaPickerView(propertyId: viewModel.property.id)
        }
        .fullScreenCover(isPresented: $showImagePreview) {
            if let image = selectedImage {
                ImagePreviewView(image: image)
            }
        }
        
        .task { await viewModel.loadImages() }
        .onChange(of: viewModel.showMediaPicker) {
            if !$1 {
                Task {
                    await viewModel.loadImages()
                }
            }
        }
    }
    
    // MARK: - Media Carousel
    private var mediaCarouselSection: some View {
        ZStack(alignment: .bottomTrailing) {
            if viewModel.mediaImages.isEmpty {
                placeholderMediaContent
            } else {
                mediaCarousel
            }
            
            addMediaButton
        }
        .background(TColor.onPrimary.opacity(0.1))
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var placeholderMediaContent: some View {
        Rectangle()
            .fill(TColor.background)
            .frame(height: 250) // Yüksekliği artırıldı
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                        .tint(TColor.areapolPrimary)
                } else {
                    VStack(spacing: TLayout.spacingM) {
                        Image(systemName: "photo")
                            .font(.system(size: 50)) // İkon boyutu artırıldı
                            .foregroundColor(TColor.border)
                        Text("no_media")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
    }
    
    private var mediaCarousel: some View {
        TabView {
            ForEach(viewModel.mediaImages.indices, id: \.self) { index in
                GeometryReader { geometry in
                    Image(uiImage: viewModel.mediaImages[index])
                        .resizable()
                        .scaledToFill()
                        .frame(width: geometry.size.width, height: 250) // Yükseklik artırıldı
                        .clipped()
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedImage = viewModel.mediaImages[index]
                            showImagePreview = true
                        }
                }
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .always))
        .frame(height: 250) // Yükseklik artırıldı
    }
    
    private var addMediaButton: some View {
        Button {
            viewModel.showMediaPicker = true
        } label: {
            Image(systemName: "plus.circle.fill")
                .font(.title)
                .foregroundColor(TColor.areapolPrimary)
                .background(
                    Circle()
                        .fill(TColor.onPrimary)
                        .shadow(radius: 2)
                )
        }
        .padding(TLayout.spacing)
    }
    
}
