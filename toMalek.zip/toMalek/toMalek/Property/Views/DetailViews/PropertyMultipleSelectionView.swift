//
//  PropertyMultipleSelectionView.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

import SwiftUI

struct PropertyMultipleSelectionView<T: Hashable & CaseIterable>: View where T: RawRepresentable, T.RawValue == String {
    let title: LocalizedStringKey
    @Binding var selectedItems: Set<T>
    let isEditable: Bool
    
    init(title: LocalizedStringKey, selectedItems: Binding<Set<T>>, isEditable: Bool = true) {
        self.title = title
        self._selectedItems = selectedItems
        self.isEditable = isEditable
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            Text(title)
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
            
            if isEditable {
                LazyVGrid(
                    columns: [
                        GridItem(.adaptive(minimum: 150, maximum: .infinity), spacing: TLayout.spacingS)
                    ],
                    spacing: TLayout.spacingS
                ) {
                    ForEach(Array(T.allCases), id: \.self) { item in
                        SelectionItemView(
                            title: LocalizedStringKey(item.rawValue),
                            isSelected: selectedItems.contains(item)
                        ) {
                            if selectedItems.contains(item) {
                                selectedItems.remove(item)
                            } else {
                                selectedItems.insert(item)
                            }
                        }
                    }
                }
            } else {
                FlowLayout(spacing: TLayout.spacingXS) {
                    ForEach(Array(selectedItems), id: \.self) { item in
                        Text(LocalizedStringKey(item.rawValue))
                            .font(TFont.footnote)
                            .foregroundColor(TColor.areapolPrimary)
                            .padding(.horizontal, TLayout.spacingS)
                            .padding(.vertical, TLayout.spacingXS)
                            .background(TColor.areapolPrimary)
                            .cornerRadius(TLayout.cornerRadius)
                    }
                }
            }
        }
        .padding()
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
    }
}

private struct SelectionItemView: View {
    let title: LocalizedStringKey
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(TFont.footnote)
                    .foregroundColor(isSelected ? TColor.onPrimary : TColor.textPrimary) // Değişti
                    .lineLimit(1)
                
                Spacer(minLength: TLayout.spacingXS)
                
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(isSelected ? TColor.onPrimary : TColor.textSecondary) // Değişti
            }
            .padding(.horizontal, TLayout.spacingS)
            .padding(.vertical, TLayout.spacingXS)
            .background(isSelected ? TColor.areapolPrimary : TColor.surface) // Değişti
            .cornerRadius(TLayout.cornerRadius)
        }
    }
}

private struct FlowLayout: Layout {
    var spacing: CGFloat
    
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let sizes = subviews.map { $0.sizeThatFits(.unspecified) }
        return arrangeSubviews(sizes: sizes, proposal: proposal).size
    }
    
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let sizes = subviews.map { $0.sizeThatFits(.unspecified) }
        let offsets = arrangeSubviews(sizes: sizes, proposal: proposal).offsets
        
        for (offset, subview) in zip(offsets, subviews) {
            subview.place(at: CGPoint(x: bounds.minX + offset.x, y: bounds.minY + offset.y), proposal: .unspecified)
        }
    }
    
    private func arrangeSubviews(sizes: [CGSize], proposal: ProposedViewSize) -> (offsets: [CGPoint], size: CGSize) {
        let width = proposal.width ?? .infinity
        var offsets: [CGPoint] = []
        var currentPosition = CGPoint.zero
        var maxY: CGFloat = 0
        
        for size in sizes {
            if currentPosition.x + size.width > width {
                currentPosition.x = 0
                currentPosition.y = maxY + spacing
            }
            
            offsets.append(currentPosition)
            
            currentPosition.x += size.width + spacing
            maxY = max(maxY, currentPosition.y + size.height)
        }
        
        return (offsets, CGSize(width: width, height: maxY))
    }
}
