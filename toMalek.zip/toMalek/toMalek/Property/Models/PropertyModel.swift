//
//  PropertyModel.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation

struct PropertyModel: Codable, Identifiable, Hashable {
    // MARK: - Basic Properties
    let id: UUID
    let propertyCode: String
    var title: String
    var propertyType: PropertyType
    var matchStatus: MatchStatus?
    var reserveStatus: ReserveStatus = .available
    var rentalStatus: RentalStatus = .available
    var saleStatus: SaleStatus = .available
    
    var isArchived: Bool = false // Eşleşme sonrası arşivlenen mülk
    var matchedToPropertyId: String? // Eşleşilen mülk ID'si
    
    // Eşleşme için gereken bilgiler
    var originalUserId: String // İlk oluşturan kullanıcı ID'si
    var createdByUserType: UserType // Mülkü oluşturan kullanıcı tipi
    
    // MARK: - Sub Types
    var residentialType: ResidentialType?
    var commercialType: CommercialType?
    var landType: LandType?
    var machineType: MachineType?
    var timeshareType: TimeshareType?
    
    // MARK: - Location Info
    var latitude: Double?
    var longitude: Double?
    var formattedAddress: String?
    var streetAddress: String?
    var neighborhood: String?
    var district: String?
    var city: String?
    var province: String?
    var state: String?
    var country: String?
    var postalCode: String?
    
    var description: String?
    
    // MARK: - Building Details
    var buildingAge: BuildingAge?
    var buildingFloorCount: BuildingFloorCount?
    var floorLocation: FloorLocation?
    var roomCount: RoomCount?
    var bathroomCount: BathroomCount?
    var kitchenCount: KitchenCount?
    var heatingType: HeatingType?
    var constructionMaterial: ConstructionMaterial? // Yeni eklendi
    var directionFacade: DirectionFacade? // Yeni eklendi
    var netSquareMeters: String? // Yeni eklendi
    
    // MARK: - Land Specific
    var adaNo: String? // Yeni eklendi
    var parselNo: String? // Yeni eklendi
    
    // MARK: - Machine Specific
    var machineAge: BuildingAge? // Yeni eklendi
    var warrantyStatus: WarrantyStatus? // Yeni eklendi
    var serviceSupport: ServiceSupport? // Yeni eklendi
    
    // MARK: - Timeshare Specific
    var periodStartDate: Date? // Yeni eklendi
    var periodEndDate: Date? // Yeni eklendi
    
    // MARK: - Owner Info
    var ownerName: String
    var ownerPhone: String
    
    // MARK: - Tenant Info
    var tenantId: String?
    var tenantName: String?
    var tenantPhone: String?
    var tenantEmail: String?
    
    // MARK: - Financial Info
    var salePrice: Double?
    var rentPrice: Double?
    var depositAmount: Double?
    var saleCurrency: CurrencyType
    var rentCurrency: CurrencyType
    var depositCurrency: CurrencyType
    
    // MARK: - Contract Info
    var rentStartDate: Date?
    var contractTime: ContractTime
    var contractType: ContractType
    let paymentDay: PaymentDay
    var isActive: Bool
    
    // MARK: - Agency Info
    var agencyName: String?
    var agentName: String?
    var agentPhone: String?
    
    // MARK: - Media
    var mediaUrls: [String]
    var thumbnailUrl: String?
    
    // MARK: - Meta Info
    var createdAt: Date
    var updatedAt: Date
    var createdBy: String
    
    // MARK: - Property Advantages
    var residentialAdvantages: [ResidentialAdvantage]?
    var commercialAdvantages: [CommercialAdvantage]?
    var landAdvantages: [LandAdvantage]?
    var machineAdvantages: [MachineAdvantage]?
    var timeshareAdvantages: [TimeshareAdvantage]?
    
    
    // MARK: - Listing Status
    enum ListingStatus: String, Codable {
        case published = "published"
        case pending = "pending"
        
        var localizedDescription: String {
            switch self {
            case .published:
                return String(localized: "listing_status_published")
            case .pending:
                return String(localized: "listing_status_pending")
            }
        }
    }
    
    var listingStatus: ListingStatus = .pending
    
    // MARK: - Responsible Personnel
    var responsiblePersonId: String?
    var responsiblePersonName: String?
    
    // MARK: - Hashable
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: PropertyModel, rhs: PropertyModel) -> Bool {
        lhs.id == rhs.id
    }
    
    // MARK: - Property Code Generator
    static func generatePropertyCode() -> String {
        let prefix = "RT"
        let timestamp = Int(Date().timeIntervalSince1970)
        let random = Int.random(in: 1000...9999)
        return "\(prefix)-\(timestamp)-\(random)"
    }
    
    // MARK: - Validation
    var isValidTitle: Bool {
        !title.isEmpty && title.count >= 3
    }
    
    var isValidOwnerInfo: Bool {
        !ownerName.isEmpty && !ownerPhone.isEmpty
    }
    
    var isValidFinancialInfo: Bool {
        let rentPriceValue = rentPrice ?? 0
        let depositValue = depositAmount ?? 0
        return rentPriceValue > 0 && depositValue > 0
    }
    
    var hasRequiredFields: Bool {
        isValidTitle &&
        isValidOwnerInfo &&
        isValidFinancialInfo &&
        latitude != nil &&
        longitude != nil &&
        formattedAddress != nil
    }
}
