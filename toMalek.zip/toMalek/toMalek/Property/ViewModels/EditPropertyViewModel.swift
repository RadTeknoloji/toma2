//
//  EditPropertyViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore
import PhotosUI

@MainActor
final class EditPropertyViewModel: ObservableObject {
   // MARK: - Services
   private let propertyService: PropertyService
   private let authService: AuthenticationService
   private let property: PropertyModel
   
   // MARK: - State
   @Published var isLoading = false
   @Published var errorMessage: String?
   @Published var canEdit = false
   
   // MARK: - Eşleşme Bilgileri
   var isArchived: Bool
   var matchedToPropertyId: String?
   var originalUserId: String
   
   // MARK: - Basic Info
   @Published var title: String
   @Published var propertyType: PropertyType
   @Published var createdByUserType: UserType
   @Published var residentialType: ResidentialType?
   @Published var commercialType: CommercialType?
   @Published var landType: LandType?
   @Published var machineType: MachineType?
   @Published var timeshareType: TimeshareType?
   
   // MARK: - Address Info
   @Published var streetAddress: String?
   @Published var neighborhood: String?
   @Published var district: String?
   @Published var city: String?
   @Published var province: String?
   @Published var state: String?
   @Published var country: String?
   @Published var postalCode: String?
   
   // MARK: - Building Details
   @Published var buildingAge: BuildingAge?
   @Published var buildingFloorCount: BuildingFloorCount?
   @Published var floorLocation: FloorLocation?
   @Published var roomCount: RoomCount?
   @Published var bathroomCount: BathroomCount?
   @Published var kitchenCount: KitchenCount?
   @Published var heatingType: HeatingType?
   
   // MARK: - Owner Info
   @Published var ownerName: String
   @Published var ownerPhone: String
   
   // MARK: - Tenant Info
   @Published var tenantId: String?
   @Published var tenantName: String?
   @Published var tenantPhone: String?
   @Published var tenantEmail: String?
   @Published var isOwner: Bool = false
   
   // MARK: - Agency Info
   @Published var agencyName: String?
   @Published var agentName: String?
   @Published var agentPhone: String?
   
   // MARK: - Financial Info
   @Published var salePrice: String
   @Published var rentPrice: String
   @Published var depositAmount: String
   @Published var saleCurrency: CurrencyType
   @Published var rentCurrency: CurrencyType
   @Published var depositCurrency: CurrencyType
   
   // MARK: - Contract Info
   @Published var rentStartDate: Date?
   @Published var contractTime: ContractTime
   @Published var contractType: ContractType
   @Published var paymentDay: PaymentDay
   
   // MARK: - Media Info
   @Published var selectedPhotosPickerItems: [PhotosPickerItem] = []
   @Published var selectedImageData: [UIImage] = []
   @Published var mediaUrls: [String]
   @Published var thumbnailUrl: String?
   
   // MARK: - UI States
   @Published var showImagePicker = false
   
   // MARK: - Validation Properties
   var isValidForm: Bool {
       !title.isEmpty &&
       validateBasicInfo() &&
       validateBuildingDetails() &&
       validateOwnerInfo() &&
       validateFinancialInfo() &&
       validateContractInfo()
   }
   
   // MARK: - Initialization
   init(property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        authService: AuthenticationService = ServiceContainer.shared.authService) {
       self.propertyService = propertyService
       self.authService = authService
       self.property = property
       
       // Eşleşme Bilgileri
       self.isArchived = property.isArchived
       self.matchedToPropertyId = property.matchedToPropertyId
       self.originalUserId = property.originalUserId
        
       // Basic Info
       self.title = property.title
       self.propertyType = property.propertyType
       self.createdByUserType = property.createdByUserType
       self.residentialType = property.residentialType
       self.commercialType = property.commercialType
       self.landType = property.landType
       self.machineType = property.machineType
       self.timeshareType = property.timeshareType
       
       // Address Info
       self.streetAddress = property.streetAddress
       self.neighborhood = property.neighborhood
       self.district = property.district
       self.city = property.city
       self.province = property.province
       self.state = property.state
       self.country = property.country
       self.postalCode = property.postalCode
       
       // Building Details
       self.buildingAge = property.buildingAge
       self.buildingFloorCount = property.buildingFloorCount
       self.floorLocation = property.floorLocation
       self.roomCount = property.roomCount
       self.bathroomCount = property.bathroomCount
       self.kitchenCount = property.kitchenCount
       self.heatingType = property.heatingType
       
       // Owner Info
       self.ownerName = property.ownerName
       self.ownerPhone = property.ownerPhone
       
       // Tenant Info
       self.tenantId = property.tenantId
       self.tenantName = property.tenantName
       self.tenantPhone = property.tenantPhone
       self.tenantEmail = property.tenantEmail
       
       // Agency Info
       self.agencyName = property.agencyName
       self.agentName = property.agentName
       self.agentPhone = property.agentPhone
       
       // Financial Info
       self.salePrice = "\(property.salePrice ?? 0)"
       self.rentPrice = "\(property.rentPrice ?? 0)"
       self.depositAmount = "\(property.depositAmount ?? 0)"
       self.saleCurrency = property.saleCurrency
       self.rentCurrency = property.rentCurrency
       self.depositCurrency = property.depositCurrency
       
       // Contract Info
       self.rentStartDate = property.rentStartDate
       self.contractTime = property.contractTime
       self.contractType = property.contractType
       self.paymentDay = property.paymentDay
       
       // Media Info
       self.mediaUrls = property.mediaUrls
       self.thumbnailUrl = property.thumbnailUrl
       
       if let currentUser = authService.currentUser {
           self.isOwner = currentUser.uid == property.createdBy
       }
   }
   
   // MARK: - Permission Check
   func checkEditPermission() async {
       guard let currentUser = authService.currentUser else {
           canEdit = false
           return
       }
       
       do {
           guard let firestoreService = propertyService as? FirestorePropertyService else {
               canEdit = false
               return
           }
           
           let userProfile = try await firestoreService.db.collection("profiles")
               .document(currentUser.uid)
               .getDocument()
               .data(as: ProfilModel.self)
           
           // Sadece mülkü oluşturan kullanıcı tipi düzenleyebilir
           canEdit = property.createdBy == currentUser.uid &&
                    userProfile.activeUserType == property.createdByUserType
       } catch {
           canEdit = false
           errorMessage = String(localized: "error_loading_profile")
       }
   }
   
   // MARK: - Validation Methods
   private func validateBasicInfo() -> Bool {
       if title.isEmpty { return false }
       switch propertyType {
       case .residential:
           return residentialType != nil
       case .commercial:
           return commercialType != nil
       case .land:
           return landType != nil
       case .machine:
           return machineType != nil
       case .timeshareProperty:
           return timeshareType != nil
       }
   }
   
   private func validateBuildingDetails() -> Bool {
       if propertyType == .residential {
           return buildingAge != nil &&
                  buildingFloorCount != nil &&
                  floorLocation != nil &&
                  roomCount != nil &&
                  bathroomCount != nil &&
                  kitchenCount != nil &&
                  heatingType != nil
       }
       return true
   }
   
   private func validateOwnerInfo() -> Bool {
       !ownerName.isEmpty && isValidPhone(ownerPhone)
   }
   
   private func validateFinancialInfo() -> Bool {
       let rentPriceValue = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0
       let depositValue = Double(depositAmount.replacingOccurrences(of: ",", with: ".")) ?? 0
       return rentPriceValue > 0 && depositValue > 0
   }
   
   private func validateContractInfo() -> Bool {
       rentStartDate != nil
   }
   
   private func isValidPhone(_ phone: String) -> Bool {
       let phoneRegex = "^[0-9+]{10,13}$"
       let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
       let cleanPhone = phone.filter { $0.isNumber }
       return phonePredicate.evaluate(with: cleanPhone)
   }
   
   // MARK: - Save Method
   func save() async {
       guard canEdit else {
           errorMessage = String(localized: "error_no_edit_permission")
           return
       }
       
       guard isValidForm else {
           errorMessage = String(localized: "error_required_fields")
           return
       }
       
       isLoading = true
       
       do {
           let updatedProperty = PropertyModel(
               id: property.id,
               propertyCode: property.propertyCode,
               title: title,
               propertyType: propertyType,
               matchStatus: property.matchStatus,
               reserveStatus: property.reserveStatus,
               rentalStatus: property.rentalStatus,
               saleStatus: property.saleStatus,
               isArchived: isArchived,
               matchedToPropertyId: matchedToPropertyId,
               originalUserId: originalUserId,
               createdByUserType: createdByUserType,
               residentialType: residentialType,
               commercialType: commercialType,
               landType: landType,
               machineType: machineType,
               timeshareType: timeshareType,
               latitude: property.latitude,
               longitude: property.longitude,
               formattedAddress: property.formattedAddress,
               streetAddress: streetAddress,
               neighborhood: neighborhood,
               district: district,
               city: city,
               province: province,
               state: state,
               country: country,
               postalCode: postalCode,
               description: property.description,
               buildingAge: buildingAge,
               buildingFloorCount: buildingFloorCount,
               floorLocation: floorLocation,
               roomCount: roomCount,
               bathroomCount: bathroomCount,
               kitchenCount: kitchenCount,
               heatingType: heatingType,
               constructionMaterial: property.constructionMaterial,
               directionFacade: property.directionFacade,
               netSquareMeters: property.netSquareMeters,
               adaNo: property.adaNo,
               parselNo: property.parselNo,
               machineAge: property.machineAge,
               warrantyStatus: property.warrantyStatus,
               serviceSupport: property.serviceSupport,
               periodStartDate: property.periodStartDate,
               periodEndDate: property.periodEndDate,
               ownerName: ownerName,
               ownerPhone: ownerPhone,
               tenantId: tenantId,
               tenantName: tenantName,
               tenantPhone: tenantPhone,
               tenantEmail: tenantEmail,
               salePrice: Double(salePrice.replacingOccurrences(of: ",", with: ".")),
               rentPrice: Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0,
               depositAmount: Double(depositAmount.replacingOccurrences(of: ",", with: ".")) ?? 0,
               saleCurrency: saleCurrency,
               rentCurrency: rentCurrency,
               depositCurrency: depositCurrency,
               rentStartDate: rentStartDate,
               contractTime: contractTime,
               contractType: contractType,
               paymentDay: paymentDay,
               isActive: property.isActive,
               agencyName: agencyName,
               agentName: agentName,
               agentPhone: agentPhone,
               mediaUrls: mediaUrls,
               thumbnailUrl: thumbnailUrl,
               createdAt: property.createdAt,
               updatedAt: Date(),
               createdBy: property.createdBy,
               residentialAdvantages: property.residentialAdvantages,
               commercialAdvantages: property.commercialAdvantages,
               landAdvantages: property.landAdvantages,
               machineAdvantages: property.machineAdvantages,
               timeshareAdvantages: property.timeshareAdvantages,
               listingStatus: property.listingStatus,
               responsiblePersonId: property.responsiblePersonId,
               responsiblePersonName: property.responsiblePersonName
           )
           
           try await propertyService.updateProperty(updatedProperty)
           errorMessage = nil
           isLoading = false
       } catch {
           errorMessage = error.localizedDescription
           isLoading = false
       }
   }
}
