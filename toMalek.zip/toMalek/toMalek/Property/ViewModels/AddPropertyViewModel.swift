//
//  AddPropertyViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore
import PhotosUI
import UIKit

enum ActiveUserType: String, Codable {
    case owner
    case tenant
    case agency
}

@MainActor
final class AddPropertyViewModel: ObservableObject {
    @ObservedObject var authState = AuthenticationState.shared
    
    @Published var rentalStatus: RentalStatus = .available
    @Published var saleStatus: SaleStatus = .available
    @Published var paymentDay: PaymentDay = .fifth
    
    // MARK: - Services
    private let propertyService: PropertyService
    private let authService: AuthenticationService
    private let mediaService: MediaService
    
    // MARK: - Active User Type
    @Published var activeUserType: ActiveUserType = .owner
    
    // MARK: - Step Control
    @Published private(set) var currentStep: PropertyFormStep = .basicInfo
    
    // MARK: - Basic Info
    @Published var title = ""
    @Published var propertyType: PropertyType = .residential
    @Published var residentialType: ResidentialType?
    @Published var commercialType: CommercialType?
    @Published var landType: LandType?
    @Published var machineType: MachineType?
    @Published var timeshareType: TimeshareType?
    
    // MARK: - Property Advantages
    @Published var residentialAdvantages: Set<ResidentialAdvantage> = []
    @Published var commercialAdvantages: Set<CommercialAdvantage> = []
    @Published var landAdvantages: Set<LandAdvantage> = []
    @Published var machineAdvantages: Set<MachineAdvantage> = []
    @Published var timeshareAdvantages: Set<TimeshareAdvantage> = []
    
    // MARK: - Location Info
    @Published var latitude: Double?
    @Published var longitude: Double?
    @Published var formattedAddress: String?
    @Published var streetAddress: String?
    @Published var neighborhood: String?
    @Published var district: String?
    @Published var city: String?
    @Published var province: String?
    @Published var state: String?
    @Published var country: String?
    @Published var postalCode: String?
    
    // MARK: - Building Details
    @Published var buildingAge: BuildingAge?
    @Published var buildingFloorCount: BuildingFloorCount?
    @Published var floorLocation: FloorLocation?
    @Published var roomCount: RoomCount?
    @Published var bathroomCount: BathroomCount?
    @Published var kitchenCount: KitchenCount?
    @Published var heatingType: HeatingType?
    @Published var constructionMaterial: ConstructionMaterial? // Yeni
    @Published var directionFacade: DirectionFacade? // Yeni
    @Published var netSquareMeters: String = "" // Yeni
    
    // MARK: - Land Specific
    @Published var adaNo: String = "" // Yeni
    @Published var parselNo: String = "" // Yeni
    
    // MARK: - Machine Specific
    @Published var machineAge: BuildingAge? // Yeni
    @Published var warrantyStatus: WarrantyStatus? // Yeni
    @Published var serviceSupport: ServiceSupport? // Yeni
    
    // MARK: - Timeshare Specific
    @Published var periodStartDate: Date? // Yeni
    @Published var periodEndDate: Date? // Yeni
    
    // MARK: - Owner Info
    @Published var ownerName = ""
    @Published var ownerPhone = ""
    
    // MARK: - Tenant Info
    @Published var tenantId: String?
    @Published var tenantName: String?
    @Published var tenantPhone: String?
    @Published var tenantEmail: String?
    @Published var isOwner: Bool = false
    
    // MARK: - Financial Info
    @Published var salePrice: String = ""
    @Published var rentPrice: String = ""
    @Published var depositAmount: String = ""
    @Published var saleCurrency: CurrencyType = .try
    @Published var rentCurrency: CurrencyType = .try
    @Published var depositCurrency: CurrencyType = .try
    
    // MARK: - Contract Info
    @Published var contractType: ContractType = .individual
    @Published var rentStartDate: Date?
    @Published var contractTime: ContractTime = .month12
    
    // MARK: - Media Upload
    @Published var selectedPhotosPickerItems: [PhotosPickerItem] = []
    @Published var selectedImageData: [UIImage] = []
    @Published var mediaUrls: [String] = []
    @Published var thumbnailUrl: String?
    
    // MARK: - UI States
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    
    // MARK: - Agency Info
    @Published var agencyName: String?
    @Published var agentName: String?
    @Published var agentPhone: String?
    
    // MARK: - Validation Properties
    var canMoveToNextStep: Bool {
        switch currentStep {
        case .locationInfo:
            return latitude != nil && longitude != nil && formattedAddress != nil
        case .basicInfo:
            return !title.isEmpty && validateBasicInfo()
        case .buildingDetails:
            return validateBuildingDetails()
        case .propertyAdvantages:
            return validatePropertyAdvantages()
        case .ownerInfo:
            return validateOwnerInfo()
        case .tenantInfo:
            return validateTenantInfo()
        case .agencyInfo:
            return validateAgencyInfo()
        case .financialInfo:
            return validateFinancialInfo()
        case .contractInfo:
            return validateContractInfo()
        case .mediaUpload:
            return true
        }
    }
    // MARK: - Initialization
    init(propertyService: PropertyService = ServiceContainer.shared.propertyService,
         authService: AuthenticationService = ServiceContainer.shared.authService,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.propertyService = propertyService
        self.authService = authService
        self.mediaService = mediaService
        
        // Başlangıçta owner olarak set edelim
        self.activeUserType = .owner
        
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(0.5))
            
            guard let currentUser = authService.currentUser else { return }
            
            // Firestore'dan kullanıcı bilgilerini alalım
            let userDoc = try? await Firestore.firestore()
                .collection("profiles")
                .document(currentUser.uid)
                .getDocument()
            
            if let userData = userDoc?.data() {
                let userType = userData["activeUserType"] as? String ?? ""
                let fullName = userData["fullName"] as? String ?? ""
                let phoneNumber = userData["phoneNumber"] as? String ?? ""
                
                // Aktif kullanıcı tipini güncelle
                self.activeUserType = {
                    switch userType {
                    case "owner": return .owner
                    case "tenant": return .tenant
                    case "agency": return .agency
                    default: return .owner
                    }
                }()
                
                // Kullanıcı bilgilerini güncelle
                switch userType {
                case "owner":
                    self.isOwner = true
                    self.ownerName = fullName
                    self.ownerPhone = phoneNumber
                case "tenant":
                    self.tenantId = currentUser.uid
                    self.tenantName = fullName
                    self.tenantPhone = phoneNumber
                case "agency":
                    self.agentName = fullName
                    self.agentPhone = phoneNumber
                default:
                    break
                }
            }
        }
    }
    
    // MARK: - Navigation Methods
    func moveToNextStep() {
        guard canMoveToNextStep else { return }
        
        switch currentStep {
        case .basicInfo: currentStep = .buildingDetails
        case .buildingDetails: currentStep = .propertyAdvantages
        case .propertyAdvantages: currentStep = .locationInfo
        case .locationInfo: currentStep = .ownerInfo
        case .ownerInfo: currentStep = .tenantInfo
        case .tenantInfo: currentStep = .agencyInfo
        case .agencyInfo: currentStep = .financialInfo
        case .financialInfo: currentStep = .contractInfo
        case .contractInfo: currentStep = .mediaUpload
        case .mediaUpload: break
        }
    }

    func moveToPreviousStep() {
        switch currentStep {
        case .mediaUpload: currentStep = .contractInfo
        case .contractInfo: currentStep = .financialInfo
        case .financialInfo: currentStep = .agencyInfo
        case .agencyInfo: currentStep = .tenantInfo
        case .tenantInfo: currentStep = .ownerInfo
        case .ownerInfo: currentStep = .locationInfo
        case .locationInfo: currentStep = .propertyAdvantages
        case .propertyAdvantages: currentStep = .buildingDetails
        case .buildingDetails: currentStep = .basicInfo
        case .basicInfo: break
        }
    }
    
    // MARK: - Validation Methods
    private func validateBasicInfo() -> Bool {
        switch propertyType {
        case .residential: return residentialType != nil
        case .commercial: return commercialType != nil
        case .land: return landType != nil
        case .machine: return machineType != nil
        case .timeshareProperty: return timeshareType != nil
        }
    }
    
    private func validatePropertyAdvantages() -> Bool {
        switch propertyType {
        case .residential:
            return !residentialAdvantages.isEmpty
        case .commercial:
            return !commercialAdvantages.isEmpty
        case .land:
            return !landAdvantages.isEmpty
        case .machine:
            return !machineAdvantages.isEmpty
        case .timeshareProperty:
            return !timeshareAdvantages.isEmpty
        }
    }
    
    private func validateBuildingDetails() -> Bool {
        switch propertyType {
        case .residential:
            return buildingAge != nil &&
                   buildingFloorCount != nil &&
                   floorLocation != nil &&
                   roomCount != nil &&
                   bathroomCount != nil &&
                   kitchenCount != nil &&
                   heatingType != nil &&
                   constructionMaterial != nil &&
                   directionFacade != nil &&
                   !netSquareMeters.isEmpty
        case .commercial:
            return buildingAge != nil &&
                   buildingFloorCount != nil &&
                   floorLocation != nil &&
                   roomCount != nil &&
                   heatingType != nil &&
                   constructionMaterial != nil &&
                   !netSquareMeters.isEmpty
        case .land:
            return !adaNo.isEmpty &&
                   !parselNo.isEmpty &&
                   !netSquareMeters.isEmpty
        case .machine:
            return machineAge != nil &&
                   warrantyStatus != nil &&
                   serviceSupport != nil
        case .timeshareProperty:
            return buildingFloorCount != nil &&
                   floorLocation != nil &&
                   roomCount != nil &&
                   bathroomCount != nil &&
                   kitchenCount != nil &&
                   heatingType != nil &&
                   constructionMaterial != nil &&
                   periodStartDate != nil &&
                   periodEndDate != nil &&
                   !netSquareMeters.isEmpty
        }
    }
    
    private func validateOwnerInfo() -> Bool {
        return !ownerName.isEmpty && isValidPhone(ownerPhone)
    }
    
    private func validateTenantInfo() -> Bool {
        guard let phone = tenantPhone else { return true }
        return isValidPhone(phone)
    }
    
    private func validateFinancialInfo() -> Bool {
        let rent = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0
        let deposit = Double(depositAmount.replacingOccurrences(of: ",", with: ".")) ?? 0
        return rent > 0 && deposit > 0
    }
    
    private func validateContractInfo() -> Bool {
        return rentStartDate != nil
    }
    
    private func isValidPhone(_ phone: String) -> Bool {
        let cleanPhone = phone.filter { $0.isNumber }
        return cleanPhone.count >= 10 && cleanPhone.count <= 13
    }
    
    private func validateAgencyInfo() -> Bool {
        guard let phone = agentPhone else { return true }
        return isValidPhone(phone)
    }
    
    // MARK: - Image Methods
    func loadSelectedImages() async {
        selectedImageData.removeAll()
        for item in selectedPhotosPickerItems {
            guard let data = try? await item.loadTransferable(type: Data.self),
                  let image = UIImage(data: data) else { continue }
            selectedImageData.append(image)
        }
    }
    
    @MainActor
    func removePhoto(at index: Int) {
        if selectedImageData.indices.contains(index) {
            selectedImageData.remove(at: index)
        }
        if selectedPhotosPickerItems.indices.contains(index) {
            selectedPhotosPickerItems.remove(at: index)
        }
    }
    
    // MARK: - Save Method
    func save() async {
        guard canMoveToNextStep else {
            errorMessage = "Lütfen tüm zorunlu alanları doldurun"
            return
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            // Media Upload
            if !selectedImageData.isEmpty {
                mediaUrls = try await mediaService.uploadImages(selectedImageData)
                thumbnailUrl = mediaUrls.first
            }
            
            // Create Property Model
            let property = PropertyModel(
                id: UUID(),
                propertyCode: PropertyModel.generatePropertyCode(),
                title: title,
                propertyType: propertyType,
                matchStatus: nil,
                reserveStatus: .available,
                rentalStatus: .available,
                saleStatus: .available,
                isArchived: false,
                matchedToPropertyId: nil,
                originalUserId: authService.currentUser?.uid ?? "",
                createdByUserType: UserType(rawValue: activeUserType.rawValue) ?? .tenant,
                residentialType: residentialType,
                commercialType: commercialType,
                landType: landType,
                machineType: machineType,
                timeshareType: timeshareType,
                latitude: latitude,
                longitude: longitude,
                formattedAddress: formattedAddress,
                streetAddress: streetAddress,
                neighborhood: neighborhood,
                district: district,
                city: city,
                province: province,
                state: state,
                country: country,
                postalCode: postalCode,
                description: nil,
                buildingAge: buildingAge,
                buildingFloorCount: buildingFloorCount,
                floorLocation: floorLocation,
                roomCount: roomCount,
                bathroomCount: bathroomCount,
                kitchenCount: kitchenCount,
                heatingType: heatingType,
                constructionMaterial: constructionMaterial,
                directionFacade: directionFacade,
                netSquareMeters: netSquareMeters,
                adaNo: adaNo,
                parselNo: parselNo,
                machineAge: machineAge,
                warrantyStatus: warrantyStatus,
                serviceSupport: serviceSupport,
                periodStartDate: periodStartDate,
                periodEndDate: periodEndDate,
                ownerName: ownerName,
                ownerPhone: ownerPhone,
                tenantId: tenantId,
                tenantName: tenantName,
                tenantPhone: tenantPhone,
                tenantEmail: tenantEmail,
                salePrice: Double(salePrice.replacingOccurrences(of: ",", with: ".")),
                rentPrice: Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0,
                depositAmount: Double(depositAmount.replacingOccurrences(of: ",", with: ".")) ?? 0,
                saleCurrency: saleCurrency,
                rentCurrency: rentCurrency,
                depositCurrency: depositCurrency,
                rentStartDate: rentStartDate,
                contractTime: contractTime,
                contractType: contractType,
                paymentDay: paymentDay,
                isActive: true,
                agencyName: agencyName,
                agentName: agentName,
                agentPhone: agentPhone,
                mediaUrls: mediaUrls,
                thumbnailUrl: thumbnailUrl,
                createdAt: Date(),
                updatedAt: Date(),
                createdBy: authService.currentUser?.uid ?? "",
                residentialAdvantages: Array(residentialAdvantages),
                commercialAdvantages: Array(commercialAdvantages),
                landAdvantages: Array(landAdvantages),
                machineAdvantages: Array(machineAdvantages),
                timeshareAdvantages: Array(timeshareAdvantages),
                listingStatus: .pending,
                responsiblePersonId: nil,
                responsiblePersonName: nil
            )
            
            try await propertyService.createProperty(property)
            isSuccessful = true
            
        } catch {
            errorMessage = "Kayıt sırasında hata oluştu: \(error.localizedDescription)"
        }
    }
    
    // MARK: - Reset Method
    func resetForm() {
        currentStep = .basicInfo
        title = ""
        propertyType = .residential
        residentialType = nil
        commercialType = nil
        landType = nil
        machineType = nil
        timeshareType = nil
        buildingAge = nil
        buildingFloorCount = nil
        floorLocation = nil
        roomCount = nil
        bathroomCount = nil
        kitchenCount = nil
        heatingType = nil
        constructionMaterial = nil
        directionFacade = nil
        netSquareMeters = ""
        adaNo = ""
        parselNo = ""
        machineAge = nil
        warrantyStatus = nil
        serviceSupport = nil
        periodStartDate = nil
        periodEndDate = nil
        ownerName = ""
        ownerPhone = ""
        agencyName = nil
        agentName = nil
        agentPhone = nil
        salePrice = ""
        rentPrice = ""
        depositAmount = ""
        saleCurrency = .try
        rentCurrency = .try
        depositCurrency = .try
        rentStartDate = nil
        contractTime = .month12
        contractType = .individual
        selectedPhotosPickerItems = []
        selectedImageData = []
        mediaUrls = []
        thumbnailUrl = nil
        errorMessage = nil
        isSuccessful = false
    }
    
    // MARK: - Form Steps
    var formSteps: [PropertyFormStep] {
        var steps: [PropertyFormStep] = [.basicInfo, .locationInfo]
        
        // Tenant kullanıcı tipi için bina detayları ve mülk özellikleri adımlarını atlıyoruz
        if authState.userType != "tenant" {
            steps.append(contentsOf: [.buildingDetails, .propertyAdvantages])
        }
        
        steps.append(contentsOf: [.ownerInfo, .tenantInfo, .agencyInfo, .financialInfo, .contractInfo, .mediaUpload])
        return steps
    }
}
