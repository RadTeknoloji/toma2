//
//  PropertyDetailViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class PropertyDetailViewModel: ObservableObject {
    // MARK: - Services
    private let propertyService: PropertyService
    private let mediaService: MediaService
    
    // MARK: - Published Properties
    @Published var property: PropertyModel
    @Published var mediaUrls: [String] = []
    @Published var mediaImages: [UIImage] = []
    @Published var medias: [MediaModel] = []
    
    // UI States
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isDeleted = false
    
    // Main Sheets & Alerts
    @Published var showEditProperty = false
    @Published var showDeleteAlert = false
    @Published var showMediaPicker = false
    @Published var showQuickActionPicker = false
    
    // Quick Action States
    @Published var showRentTrackingSheet = false
    @Published var showExpenseTrackingSheet = false
    @Published var showRaiseRentSheet = false
    @Published var showRenewContractSheet = false
    @Published var showRentOutSheet = false
    @Published var showAssignAgentSheet = false
    @Published var showCreateListingSheet = false
    @Published var showRemoveFromListingSheet = false
    @Published var showCreateRequestSheet = false
    @Published var showArchiveConfirmation = false
    @Published var showMatchOptionsSheet = false
    
    // MARK: - Private Properties
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter
    }()
    
    // MARK: - Initialization
    init(property: PropertyModel,
         propertyService: PropertyService = ServiceContainer.shared.propertyService,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.propertyService = propertyService
        self.mediaService = mediaService
        self.property = property
    }
    
    // MARK: - Quick Action Handler
    func handleQuickAction(_ action: QuickAction) {
        guard action.isEnabled(property) else { return }
        
        switch action {
        case .rentTracking:
            navigateToRentTracking()
        case .expenseTracking:
            navigateToExpenseTracking()
        case .raiseRent:
            showRaiseRentSheet = true
        case .renewContract:
            showRenewContractSheet = true
        case .rentOut:
            showRentOutSheet = true
        case .listing:
            handleListing()
        case .createRequest:
            if canCreateRequest {
                navigateToCreateRequest()
            }
        case .assignAgent:
            showAssignAgentSheet = true
        case .archive:
            showArchiveConfirmation = true
        case .match:
            showMatchOptionsSheet = true
        }
    }
    
    // MARK: - Navigation Methods
    func navigateToRentTracking() {
        ServiceContainer.shared.navigationCoordinator.navigateToRentTracking(
            withPropertyId: property.id.uuidString
        )
    }
    
    func navigateToExpenseTracking() {
        ServiceContainer.shared.navigationCoordinator.navigateToExpenseTracking(
            withPropertyId: property.id.uuidString
        )
    }
    
    func navigateToCreateListing() {
        ServiceContainer.shared.navigationCoordinator.navigateToCreateListing(
            withPropertyId: property.id.uuidString,
            propertyTitle: property.title
        )
    }
    
    func navigateToCreateRequest() {
        guard canCreateRequest else { return }
        ServiceContainer.shared.navigationCoordinator.navigateToCreateRequest(
            withPropertyId: property.id.uuidString,
            propertyTitle: property.title
        )
    }
    
    // MARK: - Quick Action Operations
    func handleListing() {
        if property.listingStatus == .published {
            showRemoveFromListingSheet = true
        } else {
            navigateToCreateListing()
        }
    }
    
    func removeFromListing() async {
        do {
            var updatedProperty = property
            updatedProperty.listingStatus = .pending
            try await propertyService.updateProperty(updatedProperty)
            property = updatedProperty
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - Property Details Extension
extension PropertyDetailViewModel {
    var propertyTypeText: String {
        switch property.propertyType {
        case .residential: return String(localized: "property_type_residential")
        case .commercial: return String(localized: "property_type_commercial")
        case .land: return String(localized: "property_type_land")
        case .machine: return String(localized: "property_type_machine")
        case .timeshareProperty: return String(localized: "property_type_timeshare")
        }
    }
    
    var subTypeText: String? {
        switch property.propertyType {
        case .residential: return property.residentialType?.rawValue.localized()
        case .commercial: return property.commercialType?.rawValue.localized()
        case .land: return property.landType?.rawValue.localized()
        case .machine: return property.machineType?.rawValue.localized()
        case .timeshareProperty: return property.timeshareType?.rawValue.localized()
        }
    }
    
    var constructionMaterialText: String? {
        guard let material = property.constructionMaterial else { return nil }
        return material.rawValue.localized()
    }
    
    var directionFacadeText: String? {
        guard let direction = property.directionFacade else { return nil }
        return direction.rawValue.localized()
    }
    
    var netSquareMetersText: String? {
        guard let squareMeters = property.netSquareMeters, !squareMeters.isEmpty else { return nil }
        return "\(squareMeters) m²"
    }
    
    var landDetailsText: String? {
        guard property.propertyType == .land else { return nil }
        let adaText = (property.adaNo?.isEmpty ?? true) ? nil : "Ada: \(property.adaNo ?? "")"
        let parselText = (property.parselNo?.isEmpty ?? true) ? nil : "Parsel: \(property.parselNo ?? "")"
        return [adaText, parselText].compactMap { $0 }.joined(separator: "\n")
    }
    
    var machineDetailsText: String? {
        guard property.propertyType == .machine else { return nil }
        let ageText = property.machineAge.map { "\($0.rawValue) \("years_old".localized())" }
        let warrantyText = property.warrantyStatus?.rawValue.localized()
        let serviceText = property.serviceSupport?.rawValue.localized()
        return [ageText, warrantyText, serviceText].compactMap { $0 }.joined(separator: "\n")
    }
    
    var timesharePeriodText: String? {
        guard property.propertyType == .timeshareProperty,
              let start = property.periodStartDate,
              let end = property.periodEndDate else { return nil }
        return "\(dateFormatter.string(from: start)) - \(dateFormatter.string(from: end))"
    }
    
    var heatingTypeText: String? {
        property.heatingType?.rawValue.localized()
    }
    
    var floorDetailsText: String? {
        guard let floor = property.floorLocation else { return nil }
        return "\(floor.localizedText) • \(property.buildingFloorCount?.localizedText ?? "")"
    }
    
    var roomDetailsText: String? {
        [property.roomCount?.rawValue.localized(),
         property.bathroomCount?.localizedText,
         property.kitchenCount?.localizedText]
            .compactMap { $0 }
            .joined(separator: " • ")
    }
    
    var primaryDetails: [String] {
        var details: [String] = []
        
        if let netSquare = netSquareMetersText {
            details.append(netSquare)
        }
        
        switch property.propertyType {
        case .residential:
            if let material = constructionMaterialText {
                details.append(material)
            }
            if let direction = directionFacadeText {
                details.append(direction)
            }
            
        case .commercial:
            if let material = constructionMaterialText {
                details.append(material)
            }
            
        case .land:
            if let landDetails = landDetailsText {
                details.append(landDetails)
            }
            
        case .machine:
            if let machineDetails = machineDetailsText {
                details.append(machineDetails)
            }
            
        case .timeshareProperty:
            if let period = timesharePeriodText {
                details.append(period)
            }
            if let material = constructionMaterialText {
                details.append(material)
            }
        }
        
        return details
    }
    
    var secondaryDetails: [String] {
        var details: [String] = []
        
        if let heating = heatingTypeText {
            details.append(heating)
        }
        
        if let floors = floorDetailsText {
            details.append(floors)
        }
        
        if let rooms = roomDetailsText {
            details.append(rooms)
        }
        
        if let age = property.buildingAge?.localizedText {
            details.append(age)
        }
        
        return details.filter { !$0.isEmpty }
    }
}

// MARK: - Media Operations
extension PropertyDetailViewModel {
    func loadImages() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            // Önce medyaları çek
            medias = try await mediaService.fetchMedias(propertyId: property.id.uuidString)
            
            // Önbellekten ve Firebase'den resimleri kontrol et ve yükle
            for media in medias {
                // Önce önbellekten kontrol et
                if let cachedImage = MediaCacheManager.shared.getImage(forKey: media.id.uuidString) {
                    await MainActor.run {
                        if !self.mediaImages.contains(where: { $0.pngData() == cachedImage.pngData() }) {
                            self.mediaImages.append(cachedImage)
                            self.mediaUrls.append(media.url)
                        }
                    }
                    continue
                }
                
                // Önbellekte yoksa Firebase'den indir
                do {
                    let imageData = try await mediaService.downloadMedia(url: media.url)
                    
                    if let image = UIImage(data: imageData) {
                        // Önbelleğe ekle
                        MediaCacheManager.shared.cacheImage(image, forKey: media.id.uuidString)
                        
                        await MainActor.run {
                            if !self.mediaImages.contains(where: { $0.pngData() == image.pngData() }) {
                                self.mediaImages.append(image)
                                self.mediaUrls.append(media.url)
                            }
                        }
                    }
                } catch {
                    print(String(localized: "error_downloading_image"), error)
                }
            }
        } catch {
            print(String(localized: "error_fetching_medias"), error)
        }
    }
    
    func deleteMedia(_ media: MediaModel) async {
        do {
            try await mediaService.deleteMedia(media)
            if let index = medias.firstIndex(where: { $0.id == media.id }) {
                medias.remove(at: index)
                mediaImages.remove(at: index)
                mediaUrls.remove(at: index)
            }
        } catch {
            errorMessage = String(localized: "error_deleting_media")
        }
    }
}

// MARK: - Status Updates
extension PropertyDetailViewModel {
    func updateRentalStatus(_ status: RentalStatus) async throws {
        property.rentalStatus = status
        try await propertyService.updateProperty(property)
    }
    
    func updateSaleStatus(_ status: SaleStatus) async throws {
        property.saleStatus = status
        try await propertyService.updateProperty(property)
    }
    
    func deleteProperty() async {
        isLoading = true
        do {
            try await propertyService.deleteProperty(id: property.id.uuidString)
            isDeleted = true
        } catch {
            errorMessage = String(localized: "error_deleting_property")
        }
        isLoading = false
    }
    
    func callOwner() {
        let cleanPhone = property.ownerPhone.filter { $0.isNumber }
        guard let url = URL(string: "tel://\(cleanPhone)") else { return }
        UIApplication.shared.open(url)
    }
    
    // MARK: - Computed Properties
    var canShowSaleStatus: Bool {
        ServiceContainer.shared.authenticationState.userType != "tenant"
    }
    
    var canCreateRequest: Bool {
        property.matchStatus != nil
    }
}
