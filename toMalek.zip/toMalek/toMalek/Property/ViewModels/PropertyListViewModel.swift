//
//  PropertyListViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseAuth

@MainActor
final class PropertyListViewModel: ObservableObject {
    // MARK: - Services
    private let propertyService: PropertyService
    private let mediaService: MediaService
    private let authState: AuthenticationState
    
    // MARK: - Published Properties
    @Published var properties: [PropertyModel] = []
    @Published var searchText = ""
    @Published var selectedPropertyType: PropertyType?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showAddProperty = false
    
    // MARK: - Filtered Properties
    var filteredProperties: [PropertyModel] {
        var filtered = properties
        
        // Kullanıcı ve kullanıcı tipine göre kısıtlama
        if let userId = Auth.auth().currentUser?.uid {
            filtered = filtered.filter { property in
                // 1. Kullanıcının kendi oluşturduğu mülk VE aktif rolüyle oluşturmuş
                if property.createdBy == userId && property.createdByUserType.rawValue == authState.userType {
                    return true
                }
                
                // 2. Match durumuna göre görüntüleme
                if let matchStatus = property.matchStatus {
                    switch matchStatus {
                    case .tenantOwner:
                        // Kiracı-Mal Sahibi eşleşmesi
                        if property.createdByUserType == .owner && authState.userType == "tenant" {
                            return true
                        }
                        if property.createdByUserType == .tenant && authState.userType == "owner" {
                            return true
                        }
                    case .tenantAgent:
                        // Kiracı-Emlakçı eşleşmesi
                        if property.createdByUserType == .tenant && authState.userType == "agency" {
                            return true
                        }
                        if property.createdByUserType == .agency && authState.userType == "tenant" {
                            return true
                        }
                    case .ownerAgent:
                        // Mal Sahibi-Emlakçı eşleşmesi
                        if property.createdByUserType == .owner && authState.userType == "agency" {
                            return true
                        }
                        if property.createdByUserType == .agency && authState.userType == "owner" {
                            return true
                        }
                    case .ownerAgentTenant:
                        // Mal Sahibi-Emlakçı-Kiracı eşleşmesi (3'lü match)
                        if property.createdByUserType == .owner && (authState.userType == "agency" || authState.userType == "tenant") {
                            return true
                        }
                        if property.createdByUserType == .tenant && (authState.userType == "agency" || authState.userType == "owner") {
                            return true
                        }
                        if property.createdByUserType == .agency && (authState.userType == "owner" || authState.userType == "tenant") {
                            return true
                        }
                    }
                }
                
                // Debug için yazdırma
                print("Debug - PropertyListViewModel:")
                print("Property:", property.title)
                print("Active User ID:", userId)
                print("Created By:", property.createdBy)
                print("Active User Type:", authState.userType)
                print("Created By User Type:", property.createdByUserType.rawValue)
                print("Match Status:", property.matchStatus?.rawValue ?? "nil")
                print("---")
                
                // Hiçbir koşul sağlanmadıysa mülkü gösterme
                return false
            }
        }
        
        if !searchText.isEmpty {
            filtered = filtered.filter { property in
                property.title.localizedCaseInsensitiveContains(searchText) ||
                property.propertyCode.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        if let type = selectedPropertyType {
            filtered = filtered.filter { $0.propertyType == type }
        }
        
        return filtered
    }
    
    // MARK: - Helper Properties
    var isEmptyResults: Bool {
        filteredProperties.isEmpty && !isLoading
    }
    
    var noSearchResults: Bool {
        !searchText.isEmpty && filteredProperties.isEmpty && !isLoading
    }
    
    // MARK: - Initialization
    @MainActor
    init(
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        mediaService: MediaService = ServiceContainer.shared.mediaService,
        authState: AuthenticationState = AuthenticationState.shared
    ) {
        self.propertyService = propertyService
        self.mediaService = mediaService
        self.authState = authState
    }
    
    // MARK: - Methods
    func fetchProperties() async {
        isLoading = true
        errorMessage = nil
        
        do {
            var fetchedProperties = try await propertyService.fetchProperties()
            
            print("Debug - fetchProperties:")
            print("Total Fetched Properties:", fetchedProperties.count)
            fetchedProperties.forEach { property in
                print("---")
                print("Property ID:", property.id.uuidString)
                print("Property Title:", property.title)
                print("Created By User Type:", property.createdByUserType.rawValue)
            }
            
            for index in fetchedProperties.indices {
                let medias = try await mediaService.fetchMedias(propertyId: fetchedProperties[index].id.uuidString)
                fetchedProperties[index].mediaUrls = medias.map { $0.url }
            }
            
            properties = fetchedProperties
            
            // Properties atandıktan sonra filteredProperties'i kontrol et
            print("\nDebug - After Assignment:")
            print("Active User Type:", authState.userType)
            print("Total Properties:", properties.count)
            print("Filtered Properties:", filteredProperties.count)
        } catch {
            errorMessage = String(localized: "error_loading_properties")
            print(String(localized: "error_fetching_properties_debug"), error)
        }
        
        isLoading = false
    }
    
    func deleteProperty(_ property: PropertyModel) async {
        do {
            try await propertyService.deleteProperty(id: property.id.uuidString)
            if let index = properties.firstIndex(where: { $0.id == property.id }) {
                properties.remove(at: index)
            }
        } catch {
            errorMessage = String(localized: "error_deleting_property")
            print(String(localized: "error_deleting_property_debug"), error)
        }
    }
    
    func refreshList() async {
        await fetchProperties()
    }
}
