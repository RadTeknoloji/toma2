//
//  FirestorePropertyService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore
import SwiftUI

final class FirestorePropertyService: PropertyService, PropertyMatchService {
    internal let db = Firestore.firestore()
    internal let collection = "properties"
    
    // MARK: - Helper Properties
    internal var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // MARK: - Update Thumbnail
    func updatePropertyThumbnail(id: String, thumbnailUrl: String?) async throws {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        // Check if property belongs to current user
        let document = try await db.collection(collection).document(id).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw PropertyError.unauthorized
        }
        
        let propertyRef = db.collection(collection).document(id)
        
        try await propertyRef.updateData([
            "thumbnailUrl": thumbnailUrl ?? NSNull(),
            "updatedAt": FieldValue.serverTimestamp()
        ])
    }
    
    func initiateMatch(fromProperty: PropertyModel, targetUserType: UserType, targetPhone: String) async throws {
            let userDoc = try await db.collection("users")
                .whereField("phone", isEqualTo: targetPhone)
                .getDocuments()
                .documents
                .first
                
            guard let userId = userDoc?.documentID else {
                throw PropertyError.notFound
            }
            
            let matchRequest = PropertyMatchRequest(
                id: UUID().uuidString,
                sourcePropertyId: fromProperty.id.uuidString,
                targetUserId: userId,
                targetUserType: targetUserType,
                sourceUserType: fromProperty.createdByUserType,
                status: .pending,
                createdAt: Date()
            )
            
            try db.collection("matchRequests").document(matchRequest.id).setData(from: matchRequest)
        }
        
        func acceptMatch(request: PropertyMatchRequest, selectedPropertyId: String) async throws {
            // Implement
            throw PropertyError.unknown
        }
        
        func rejectMatch(request: PropertyMatchRequest) async throws {
            // Implement
            throw PropertyError.unknown
        }
        
        func getMatchRequests(forUserId: String) async throws -> [PropertyMatchRequest] {
            // Implement
            return []
        }
    
    
    // MARK: - Search & Filter
    func searchProperties(query: String) async throws -> [PropertyModel] {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("title", isGreaterThanOrEqualTo: query)
            .whereField("title", isLessThanOrEqualTo: query + "\u{f8ff}")
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeProperty(from: document)
        }
    }
    
    func filterProperties(by type: PropertyType) async throws -> [PropertyModel] {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("propertyType", isEqualTo: type.rawValue)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeProperty(from: document)
        }
    }
    
    
    
    // MARK: - Helper Methods
    internal func decodeProperty(from document: DocumentSnapshot) throws -> PropertyModel {
            guard let data = document.data() else {
                throw PropertyError.invalidData
            }
            
            // Basic Info
            let basicInfo = decodeBasicInfo(from: data)
            let locationInfo = decodeLocationInfo(from: data)
            let statusInfo = decodeStatusInfo(from: data)
            let buildingDetails = decodeBuildingDetails(from: data)
            let specialInfo = decodeSpecialInfo(from: data)
            let contactInfo = decodeContactInfo(from: data)
            let financialInfo = decodeFinancialInfo(from: data)
            let contractInfo = decodeContractInfo(from: data)
            let mediaInfo = decodeMediaInfo(from: data)
            let metaInfo = decodeMetaInfo(from: data)
            let advantages = decodePropertyAdvantages(from: data)

            
        return PropertyModel(
            // Basic Info
            id: basicInfo.id,
            propertyCode: basicInfo.propertyCode,
            title: basicInfo.title,
            propertyType: basicInfo.propertyType,
            
            // Match & Status Info
            matchStatus: statusInfo.matchStatus,
            reserveStatus: statusInfo.reserveStatus,
            rentalStatus: statusInfo.rentalStatus,
            saleStatus: statusInfo.saleStatus,
            isArchived: data["isArchived"] as? Bool ?? false,
            matchedToPropertyId: data["matchedToPropertyId"] as? String,
            originalUserId: metaInfo.originalUserId,
            createdByUserType: metaInfo.createdByUserType,
            
            // Types
            residentialType: basicInfo.residentialType,
            commercialType: basicInfo.commercialType,
            landType: basicInfo.landType,
            machineType: basicInfo.machineType,
            timeshareType: basicInfo.timeshareType,
            
            // Location Info
            latitude: locationInfo.latitude,
            longitude: locationInfo.longitude,
            formattedAddress: locationInfo.formattedAddress,
            streetAddress: data["streetAddress"] as? String,
            neighborhood: data["neighborhood"] as? String,
            district: data["district"] as? String,
            city: data["city"] as? String,
            province: data["province"] as? String,
            state: data["state"] as? String,
            country: data["country"] as? String,
            postalCode: data["postalCode"] as? String,
            description: data["description"] as? String,
            
            // Building Details
            buildingAge: buildingDetails.buildingAge,
            buildingFloorCount: buildingDetails.buildingFloorCount,
            floorLocation: buildingDetails.floorLocation,
            roomCount: buildingDetails.roomCount,
            bathroomCount: buildingDetails.bathroomCount,
            kitchenCount: buildingDetails.kitchenCount,
            heatingType: buildingDetails.heatingType,
            constructionMaterial: buildingDetails.constructionMaterial,
            directionFacade: buildingDetails.directionFacade,
            netSquareMeters: buildingDetails.netSquareMeters,
            
            // Special Info
            adaNo: specialInfo.adaNo,
            parselNo: specialInfo.parselNo,
            machineAge: specialInfo.machineAge,
            warrantyStatus: specialInfo.warrantyStatus,
            serviceSupport: specialInfo.serviceSupport,
            periodStartDate: specialInfo.periodStartDate,
            periodEndDate: specialInfo.periodEndDate,
            
            // Contact Info
            ownerName: contactInfo.ownerName,
            ownerPhone: contactInfo.ownerPhone,
            tenantId: contactInfo.tenantId,
            tenantName: contactInfo.tenantName,
            tenantPhone: contactInfo.tenantPhone,
            tenantEmail: contactInfo.tenantEmail,
            
            // Financial Info
            salePrice: financialInfo.salePrice,
            rentPrice: financialInfo.rentPrice,
            depositAmount: financialInfo.depositAmount,
            saleCurrency: financialInfo.saleCurrency,
            rentCurrency: financialInfo.rentCurrency,
            depositCurrency: financialInfo.depositCurrency,
            
            // Contract Info
            rentStartDate: contractInfo.rentStartDate,
            contractTime: contractInfo.contractTime,
            contractType: contractInfo.contractType,
            paymentDay: contractInfo.paymentDay,
            isActive: contractInfo.isActive,
            
            // Agency Info
            agencyName: contactInfo.agencyName,
            agentName: contactInfo.agentName,
            agentPhone: contactInfo.agentPhone,
            
            // Media Info
            mediaUrls: mediaInfo.mediaUrls,
            thumbnailUrl: mediaInfo.thumbnailUrl,
            
            // Meta Info
            createdAt: metaInfo.createdAt,
            updatedAt: metaInfo.updatedAt,
            createdBy: metaInfo.createdBy,
            
            // Property Advantages
            residentialAdvantages: advantages.residentialAdvantages,
            commercialAdvantages: advantages.commercialAdvantages,
            landAdvantages: advantages.landAdvantages,
            machineAdvantages: advantages.machineAdvantages,
            timeshareAdvantages: advantages.timeshareAdvantages,
            
            // Additional Info
            listingStatus: PropertyModel.ListingStatus(rawValue: data["listingStatus"] as? String ?? "") ?? .pending,
            responsiblePersonId: data["responsiblePersonId"] as? String,
            responsiblePersonName: data["responsiblePersonName"] as? String
        )
        }
        
        // MARK: - Decode Helper Methods
        private func decodeBasicInfo(from data: [String: Any]) -> (id: UUID, propertyCode: String, title: String, propertyType: PropertyType, residentialType: ResidentialType?, commercialType: CommercialType?, landType: LandType?, machineType: MachineType?, timeshareType: TimeshareType?) {
            return (
                id: UUID(uuidString: data["id"] as? String ?? "") ?? UUID(),
                propertyCode: data["propertyCode"] as? String ?? "",
                title: data["title"] as? String ?? "",
                propertyType: PropertyType(rawValue: data["propertyType"] as? String ?? "") ?? .residential,
                residentialType: ResidentialType(rawValue: data["residentialType"] as? String ?? ""),
                commercialType: CommercialType(rawValue: data["commercialType"] as? String ?? ""),
                landType: LandType(rawValue: data["landType"] as? String ?? ""),
                machineType: MachineType(rawValue: data["machineType"] as? String ?? ""),
                timeshareType: TimeshareType(rawValue: data["timeshareType"] as? String ?? "")
            )
        }
        
        private func decodeLocationInfo(from data: [String: Any]) -> (latitude: Double?, longitude: Double?, formattedAddress: String?) {
            return (
                latitude: data["latitude"] as? Double,
                longitude: data["longitude"] as? Double,
                formattedAddress: data["formattedAddress"] as? String
            )
        }
        
        private func decodeStatusInfo(from data: [String: Any]) -> (matchStatus: MatchStatus?, reserveStatus: ReserveStatus, rentalStatus: RentalStatus, saleStatus: SaleStatus) {
            return (
                matchStatus: MatchStatus(rawValue: data["matchStatus"] as? String ?? ""),
                reserveStatus: ReserveStatus(rawValue: data["reserveStatus"] as? String ?? "") ?? .available,
                rentalStatus: RentalStatus(rawValue: data["rentalStatus"] as? String ?? "") ?? .available,
                saleStatus: SaleStatus(rawValue: data["saleStatus"] as? String ?? "") ?? .available
            )
        }
        
        private func decodeBuildingDetails(from data: [String: Any]) -> (buildingAge: BuildingAge?, buildingFloorCount: BuildingFloorCount?, floorLocation: FloorLocation?, roomCount: RoomCount?, bathroomCount: BathroomCount?, kitchenCount: KitchenCount?, heatingType: HeatingType?, constructionMaterial: ConstructionMaterial?, directionFacade: DirectionFacade?, netSquareMeters: String?) {
            return (
                buildingAge: BuildingAge(rawValue: data["buildingAge"] as? Int ?? 0),
                buildingFloorCount: BuildingFloorCount(rawValue: data["buildingFloorCount"] as? Int ?? 1),
                floorLocation: FloorLocation(rawValue: data["floorLocation"] as? Int ?? 0),
                roomCount: RoomCount(rawValue: data["roomCount"] as? String ?? ""),
                bathroomCount: BathroomCount(rawValue: data["bathroomCount"] as? Int ?? 1),
                kitchenCount: KitchenCount(rawValue: data["kitchenCount"] as? Int ?? 1),
                heatingType: HeatingType(rawValue: data["heatingType"] as? String ?? ""),
                constructionMaterial: ConstructionMaterial(rawValue: data["constructionMaterial"] as? String ?? ""),
                directionFacade: DirectionFacade(rawValue: data["directionFacade"] as? String ?? ""),
                netSquareMeters: data["netSquareMeters"] as? String
            )
        }
        
        private func decodeSpecialInfo(from data: [String: Any]) -> (adaNo: String?, parselNo: String?, machineAge: BuildingAge?, warrantyStatus: WarrantyStatus?, serviceSupport: ServiceSupport?, periodStartDate: Date?, periodEndDate: Date?) {
            return (
                adaNo: data["adaNo"] as? String,
                parselNo: data["parselNo"] as? String,
                machineAge: BuildingAge(rawValue: data["machineAge"] as? Int ?? 0),
                warrantyStatus: WarrantyStatus(rawValue: data["warrantyStatus"] as? String ?? ""),
                serviceSupport: ServiceSupport(rawValue: data["serviceSupport"] as? String ?? ""),
                periodStartDate: (data["periodStartDate"] as? Timestamp)?.dateValue(),
                periodEndDate: (data["periodEndDate"] as? Timestamp)?.dateValue()
            )
        }
        
        private func decodeContactInfo(from data: [String: Any]) -> (ownerName: String, ownerPhone: String, tenantId: String?, tenantName: String?, tenantPhone: String?, tenantEmail: String?, agencyName: String?, agentName: String?, agentPhone: String?) {
            return (
                ownerName: data["ownerName"] as? String ?? "",
                ownerPhone: data["ownerPhone"] as? String ?? "",
                tenantId: data["tenantId"] as? String,
                tenantName: data["tenantName"] as? String,
                tenantPhone: data["tenantPhone"] as? String,
                tenantEmail: data["tenantEmail"] as? String,
                agencyName: data["agencyName"] as? String,
                agentName: data["agentName"] as? String,
                agentPhone: data["agentPhone"] as? String
            )
        }
        
        private func decodeFinancialInfo(from data: [String: Any]) -> (salePrice: Double?, rentPrice: Double?, depositAmount: Double?, saleCurrency: CurrencyType, rentCurrency: CurrencyType, depositCurrency: CurrencyType) {
            return (
                salePrice: data["salePrice"] as? Double,
                rentPrice: data["rentPrice"] as? Double,
                depositAmount: data["depositAmount"] as? Double,
                saleCurrency: CurrencyType(rawValue: data["saleCurrency"] as? String ?? "TRY") ?? .try,
                rentCurrency: CurrencyType(rawValue: data["rentCurrency"] as? String ?? "TRY") ?? .try,
                depositCurrency: CurrencyType(rawValue: data["depositCurrency"] as? String ?? "TRY") ?? .try
            )
        }
        
    private func decodeContractInfo(from data: [String: Any]) -> (rentStartDate: Date?, contractTime: ContractTime, contractType: ContractType, paymentDay: PaymentDay, isActive: Bool) {
        return (
            rentStartDate: (data["rentStartDate"] as? Timestamp)?.dateValue(),
            contractTime: ContractTime(rawValue: data["contractTime"] as? Int ?? 12) ?? .month12,
            contractType: ContractType(rawValue: data["contractType"] as? String ?? "") ?? .individual,
            paymentDay: PaymentDay(rawValue: data["paymentDay"] as? Int ?? 5) ?? .fifth,
            isActive: data["isActive"] as? Bool ?? true
        )
    }
        
        private func decodeMediaInfo(from data: [String: Any]) -> (mediaUrls: [String], thumbnailUrl: String?) {
            return (
                mediaUrls: data["mediaUrls"] as? [String] ?? [],
                thumbnailUrl: data["thumbnailUrl"] as? String
            )
        }
        
    private func decodeMetaInfo(from data: [String: Any]) -> (createdAt: Date, updatedAt: Date, createdBy: String, originalUserId: String, createdByUserType: UserType) {
        return (
            createdAt: (data["createdAt"] as? Timestamp)?.dateValue() ?? Date(),
            updatedAt: (data["updatedAt"] as? Timestamp)?.dateValue() ?? Date(),
            createdBy: data["createdBy"] as? String ?? "",
            originalUserId: data["originalUserId"] as? String ?? "",
            createdByUserType: UserType(rawValue: data["createdByUserType"] as? String ?? "") ?? .tenant
        )
    }
    }

private func decodePropertyAdvantages(from data: [String: Any]) -> (
    residentialAdvantages: [ResidentialAdvantage]?,
    commercialAdvantages: [CommercialAdvantage]?,
    landAdvantages: [LandAdvantage]?,
    machineAdvantages: [MachineAdvantage]?,
    timeshareAdvantages: [TimeshareAdvantage]?
) {
    return (
        residentialAdvantages: (data["residentialAdvantages"] as? [String] ?? []).compactMap { ResidentialAdvantage(rawValue: $0) },
        commercialAdvantages: (data["commercialAdvantages"] as? [String] ?? []).compactMap { CommercialAdvantage(rawValue: $0) },
        landAdvantages: (data["landAdvantages"] as? [String] ?? []).compactMap { LandAdvantage(rawValue: $0) },
        machineAdvantages: (data["machineAdvantages"] as? [String] ?? []).compactMap { MachineAdvantage(rawValue: $0) },
        timeshareAdvantages: (data["timeshareAdvantages"] as? [String] ?? []).compactMap { TimeshareAdvantage(rawValue: $0) }
    )
}
