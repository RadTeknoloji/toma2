//
//  PropertyService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseFirestore

protocol PropertyService {
    // Create
    func createProperty(_ property: PropertyModel) async throws
    
    // Read
    func fetchProperties() async throws -> [PropertyModel]
    func fetchProperty(id: String) async throws -> PropertyModel?
    func fetchProperties(forUser userId: String) async throws -> [PropertyModel]
    
    // Update
    func updateProperty(_ property: PropertyModel) async throws
    func updatePropertyThumbnail(id: String, thumbnailUrl: String?) async throws
    
    // Delete
    func deleteProperty(id: String) async throws
    
    // Search & Filter
    func searchProperties(query: String) async throws -> [PropertyModel]
    func filterProperties(by type: PropertyType) async throws -> [PropertyModel]
    
    // Eşleşmeli mülkleri getirmek için.

}

// MARK: - Property Errors
enum PropertyError: LocalizedError {
    case invalidData
    case notFound
    case alreadyExists
    case unauthorized
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "property_error_invalid_data")
        case .notFound:
            return String(localized: "property_error_not_found")
        case .alreadyExists:
            return String(localized: "property_error_already_exists")
        case .unauthorized:
            return String(localized: "property_error_unauthorized")
        case .unknown:
            return String(localized: "property_error_unknown")
        }
    }
}

extension PropertyService {
    func fetchMatchedProperties() async throws -> [PropertyModel] {
        // Sadece eşleşmesi olan mülkleri getir
        return try await fetchProperties().filter { $0.matchedToPropertyId != nil }
    }
}
