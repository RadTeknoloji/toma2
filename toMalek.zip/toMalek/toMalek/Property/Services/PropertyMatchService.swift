//
//  PropertyMatchService.swift
//  toMalek
//
//  Created by Selman Erbay on 6.02.2025.
//

import SwiftUI
import Foundation

protocol PropertyMatchService {
    func initiateMatch(fromProperty: PropertyModel, targetUserType: UserType, targetPhone: String) async throws
    func acceptMatch(request: PropertyMatchRequest, selectedPropertyId: String) async throws
    func rejectMatch(request: PropertyMatchRequest) async throws
    func getMatchRequests(forUserId: String) async throws -> [PropertyMatchRequest]
}

struct PropertyMatchRequest: Codable {
    let id: String
    let sourcePropertyId: String
    let targetUserId: String
    let targetUserType: UserType
    let sourceUserType: UserType
    let status: MatchRequestStatus
    let createdAt: Date
    
    enum MatchRequestStatus: String, Codable {
        case pending, accepted, rejected
    }
}
