//
//  FirestorePropertyService+Delete.swift
//  toMalek
//
//  Created by Selman Erbay on 26.01.2025.
//

import Foundation
import FirebaseFirestore
import SwiftUI

extension FirestorePropertyService {
    // MARK: - Delete
    func deleteProperty(id: String) async throws {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        // Check if property belongs to current user
        let document = try await db.collection(collection).document(id).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw PropertyError.unauthorized
        }
        
        try await db.collection(collection).document(id).delete()
    }
}
