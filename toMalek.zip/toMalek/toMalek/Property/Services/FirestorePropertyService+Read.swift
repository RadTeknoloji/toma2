//
//  FirestorePropertyService+Read.swift
//  toMalek
//
//  Created by Selman Erbay on 26.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import SwiftUI

extension FirestorePropertyService {
    // MARK: - Read
    func fetchProperties() async throws -> [PropertyModel] {
        guard let userId = Auth.auth().currentUser?.uid else {
            throw PropertyError.unauthorized
        }
        
        // Sadece kullanıcı ID'sine göre sorgulama yapıyoruz
        // Kullanıcı tipine göre filtreleme ViewModel'de yapılacak
        let snapshot = try await db.collection(String(localized: "firestore_collection_properties"))
            .whereField(String(localized: "firestore_field_userid"), isEqualTo: userId)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeProperty(from: document)
        }
    }
    
    func fetchProperty(id: String) async throws -> PropertyModel? {
        let document = try await db.collection(collection).document(id).getDocument()
        guard document.exists else { return nil }
        return try decodeProperty(from: document)
    }
    
    func fetchProperties(forUser userId: String) async throws -> [PropertyModel] {
        let snapshot = try await db.collection(collection)
            .whereField(String(localized: "firestore_field_userid"), isEqualTo: userId)
            .order(by: String(localized: "firestore_field_createdat"), descending: true)
            .getDocuments()
            
        return try snapshot.documents.compactMap { document in
            try decodeProperty(from: document)
        }
    }
}
