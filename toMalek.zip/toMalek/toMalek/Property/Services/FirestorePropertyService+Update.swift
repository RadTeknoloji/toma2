//
//  FirestorePropertyService+Update.swift
//  toMalek
//
//  Created by Selman Erbay on 26.01.2025.
//

import Foundation
import FirebaseFirestore
import SwiftUI

extension FirestorePropertyService {
    // MARK: - Update
    func updateProperty(_ property: PropertyModel) async throws {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        // Check if property belongs to current user
        let document = try await db.collection(collection).document(property.id.uuidString).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw PropertyError.unauthorized
        }
        
        let propertyRef = db.collection(collection).document(property.id.uuidString)
        
        let data: [String: Any] = [
            "title": property.title,
            "propertyType": property.propertyType.rawValue,
            "residentialType": property.residentialType?.rawValue as Any,
            "commercialType": property.commercialType?.rawValue as Any,
            "landType": property.landType?.rawValue as Any,
            "machineType": property.machineType?.rawValue as Any,
            "latitude": property.latitude as Any,
            "longitude": property.longitude as Any,
            "formattedAddress": property.formattedAddress as Any,
            "matchStatus": property.matchStatus?.rawValue as Any,
            "reserveStatus": property.reserveStatus.rawValue,
            "rentalStatus": property.rentalStatus.rawValue,
            "saleStatus": property.saleStatus.rawValue,
            "buildingAge": property.buildingAge?.rawValue as Any,
            "buildingFloorCount": property.buildingFloorCount?.rawValue as Any,
            "floorLocation": property.floorLocation?.rawValue as Any,
            "roomCount": property.roomCount?.rawValue as Any,
            "bathroomCount": property.bathroomCount?.rawValue as Any,
            "kitchenCount": property.kitchenCount?.rawValue as Any,
            "heatingType": property.heatingType?.rawValue as Any,
            "tenantName": property.tenantName as Any,
            "tenantPhone": property.tenantPhone as Any,
            "ownerName": property.ownerName,
            "ownerPhone": property.ownerPhone,
            "agencyName": property.agencyName as Any,
            "agentName": property.agentName as Any,
            "agentPhone": property.agentPhone as Any,
            "salePrice": property.salePrice as Any,
            "rentPrice": property.rentPrice as Any,
            "depositAmount": property.depositAmount as Any,
            "saleCurrency": property.saleCurrency.rawValue,
            "rentCurrency": property.rentCurrency.rawValue,
            "depositCurrency": property.depositCurrency.rawValue,
            "rentStartDate": property.rentStartDate as Any,
            "contractTime": property.contractTime.rawValue,
            "contractType": property.contractType.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ]
        
        try await propertyRef.updateData(data)
    }
}
