//
//  FirestorePropertyService+Create.swift
//  toMalek
//
//  Created by Selman Erbay on 26.01.2025.
//

import Foundation
import FirebaseFirestore
import SwiftUI

extension FirestorePropertyService {
    // MARK: - Create Property
    func createProperty(_ property: PropertyModel) async throws {
        guard let userId = currentUserId else {
            throw PropertyError.unauthorized
        }
        
        print("Debug - createProperty:")
        print("User ID:", userId)
        print("Property Title:", property.title)
        print("Created By User Type:", property.createdByUserType.rawValue)
        
        let propertyRef = db.collection(collection).document(property.id.uuidString)
        
        var data: [String: Any] = [
            "id": property.id.uuidString,
            "userId": userId,
            "propertyCode": property.propertyCode,
            "title": property.title,
            "propertyType": property.propertyType.rawValue,
            "residentialType": property.residentialType?.rawValue as Any,
            "commercialType": property.commercialType?.rawValue as Any,
            "landType": property.landType?.rawValue as Any,
            "machineType": property.machineType?.rawValue as Any,
            "timeshareType": property.timeshareType?.rawValue as Any,
            "buildingAge": property.buildingAge?.rawValue as Any,
            "buildingFloorCount": property.buildingFloorCount?.rawValue as Any,
            "floorLocation": property.floorLocation?.rawValue as Any,
            "roomCount": property.roomCount?.rawValue as Any,
            "bathroomCount": property.bathroomCount?.rawValue as Any,
            "kitchenCount": property.kitchenCount?.rawValue as Any,
            "heatingType": property.heatingType?.rawValue as Any,
            "constructionMaterial": property.constructionMaterial?.rawValue as Any,
            "directionFacade": property.directionFacade?.rawValue as Any,
            "netSquareMeters": property.netSquareMeters as Any,
            "adaNo": property.adaNo as Any,
            "parselNo": property.parselNo as Any,
            "machineAge": property.machineAge?.rawValue as Any,
            "warrantyStatus": property.warrantyStatus?.rawValue as Any,
            "serviceSupport": property.serviceSupport?.rawValue as Any,
            "periodStartDate": property.periodStartDate as Any,
            "periodEndDate": property.periodEndDate as Any,
            "tenantId": property.tenantId as Any,
            "tenantName": property.tenantName as Any,
            "tenantPhone": property.tenantPhone as Any,
            "tenantEmail": property.tenantEmail as Any,
            "ownerName": property.ownerName,
            "ownerPhone": property.ownerPhone,
            "agencyName": property.agencyName as Any,
            "agentName": property.agentName as Any,
            "agentPhone": property.agentPhone as Any,
            "salePrice": property.salePrice as Any,
            "rentPrice": property.rentPrice as Any,
            "depositAmount": property.depositAmount as Any,
            "saleCurrency": property.saleCurrency.rawValue,
            "rentCurrency": property.rentCurrency.rawValue,
            "depositCurrency": property.depositCurrency.rawValue,
            "rentStartDate": property.rentStartDate as Any,
            "contractTime": property.contractTime.rawValue,
            "contractType": property.contractType.rawValue,
            "paymentDay": property.paymentDay.rawValue,
            "isActive": property.isActive,
            "mediaUrls": property.mediaUrls,
            "thumbnailUrl": property.thumbnailUrl as Any,
            "createdAt": FieldValue.serverTimestamp(),
            "updatedAt": FieldValue.serverTimestamp(),
            "createdBy": property.createdBy,
            "originalUserId": userId, // Mülkü ilk oluşturan kullanıcı
            "createdByUserType": property.createdByUserType.rawValue, // Mülkü oluşturan kullanıcı tipi
            "latitude": property.latitude as Any,
            "longitude": property.longitude as Any,
            "formattedAddress": property.formattedAddress as Any,
            "streetAddress": property.streetAddress as Any,
            "neighborhood": property.neighborhood as Any,
            "district": property.district as Any,
            "city": property.city as Any,
            "province": property.province as Any,
            "state": property.state as Any,
            "country": property.country as Any,
            "postalCode": property.postalCode as Any,
            "description": property.description as Any,
            "residentialAdvantages": property.residentialAdvantages?.map { $0.rawValue } ?? [],
            "commercialAdvantages": property.commercialAdvantages?.map { $0.rawValue } ?? [],
            "landAdvantages": property.landAdvantages?.map { $0.rawValue } ?? [],
            "machineAdvantages": property.machineAdvantages?.map { $0.rawValue } ?? [],
            "timeshareAdvantages": property.timeshareAdvantages?.map { $0.rawValue } ?? [],
            "listingStatus": property.listingStatus.rawValue,
            "matchStatus": property.matchStatus?.rawValue as Any,
            "reserveStatus": property.reserveStatus.rawValue,
            "rentalStatus": property.rentalStatus.rawValue,
            "saleStatus": property.saleStatus.rawValue
            
        ]
        
        // GeoPoint'i sadece geçerli koordinatlar varsa ekle
        if let latitude = property.latitude,
           let longitude = property.longitude {
            data["location"] = GeoPoint(latitude: latitude, longitude: longitude)
        } else {
            data["location"] = NSNull()
        }
        
        try await propertyRef.setData(data)
    }
}
