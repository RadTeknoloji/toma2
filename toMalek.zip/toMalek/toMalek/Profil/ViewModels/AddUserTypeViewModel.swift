//
//  AddUserTypeViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

@MainActor
final class AddUserTypeViewModel: ObservableObject {
    // MARK: - Services
    private let db = Firestore.firestore()
    private let userType: UserType

    // MARK: - Init
    init(userType: UserType) {
        self.userType = userType
        // Her seferinde state'i sıfırla
        self.companyName = ""
        self.officialName = ""
        self.brandName = ""
        self.taxNumber = ""
        self.managerName = ""
        self.secondaryPhone = ""
        self.agentName = ""
        self.agentPhone = ""
        
        // Location state'lerini sıfırla
        self.latitude = nil
        self.longitude = nil
        self.formattedAddress = nil
        self.streetAddress = nil
        self.neighborhood = nil
        self.district = nil
        self.city = nil
        self.province = nil
        self.state = nil
        self.country = nil
        self.postalCode = nil
        
        // Diğer state'leri sıfırla
        self.isLoading = false
        self.errorMessage = nil
        self.isSuccessful = false
    }
    
    // MARK: - Published Properties
    // Owner Properties
    @Published var companyName = ""
    
    // Agency Properties
    @Published var officialName = ""
    @Published var brandName = ""
    @Published var taxNumber = ""
    @Published var managerName = ""
    @Published var secondaryPhone = ""
    @Published var agentName = ""
    @Published var agentPhone = ""
    
    // Location Properties
    @Published var latitude: Double?
    @Published var longitude: Double?
    @Published var formattedAddress: String?
    @Published var streetAddress: String?
    @Published var neighborhood: String?
    @Published var district: String?
    @Published var city: String?
    @Published var province: String?
    @Published var state: String?
    @Published var country: String?
    @Published var postalCode: String?
    
    // UI States
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    
    // MARK: - Computed Properties
    var isValidForm: Bool {
        switch userType {
        case .tenant:
            return true
        case .owner:
            return true // companyName opsiyonel
        case .agency:
            return !officialName.isEmpty &&
                   !brandName.isEmpty &&
                   isValidTaxNumber(taxNumber) &&
                   formattedAddress != nil
        }
    }
    
    private var isValidAgencyInfo: Bool {
        !officialName.isEmpty &&
        !brandName.isEmpty &&
        isValidTaxNumber(taxNumber) &&
        !managerName.isEmpty &&
        isValidPhone(secondaryPhone)
    }
    
    // MARK: - Methods
    func save(_ type: UserType) async {
        guard isValidForm,
              let userId = Auth.auth().currentUser?.uid else {
            errorMessage = String(localized: "fill_required_fields")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let doc = try await db.collection("profiles").document(userId).getDocument()
            guard let data = doc.data() else { throw ProfileError.notFound }
            
            var userTypes = Set((data["userTypes"] as? [String] ?? []).compactMap { UserType(rawValue: $0) })
            userTypes.insert(type)
            
            var updateData: [String: Any] = [
                "userTypes": Array(userTypes).map { $0.rawValue }
            ]
            
            switch type {
            case .owner:
                // Şirket bilgisi opsiyonel
                if !companyName.isEmpty {
                    updateData["ownerInfo"] = [
                        "companyName": companyName
                    ]
                }
                
            case .agency:
                var agencyInfo: [String: Any] = [
                    "officialName": officialName,
                    "brandName": brandName,
                    "taxNumber": taxNumber,
                    "managerName": managerName,
                    "secondaryPhone": secondaryPhone
                ]
                
                // Opsiyonel alanları ekle
                if !agentName.isEmpty {
                    agencyInfo["agentName"] = agentName
                }
                if !agentPhone.isEmpty {
                    agencyInfo["agentPhone"] = agentPhone
                }
                
                // Konum bilgileri için detaylı ekleme
                if let lat = latitude {
                    agencyInfo["latitude"] = lat
                }
                if let lon = longitude {
                    agencyInfo["longitude"] = lon
                }
                if let address = formattedAddress {
                    agencyInfo["formattedAddress"] = address
                }
                if let street = streetAddress {
                    agencyInfo["streetAddress"] = street
                }
                if let hood = neighborhood {
                    agencyInfo["neighborhood"] = hood
                }
                if let dist = district {
                    agencyInfo["district"] = dist
                }
                if let cityName = city {
                    agencyInfo["city"] = cityName
                }
                if let prov = province {
                    agencyInfo["province"] = prov
                }
                if let st = state {
                    agencyInfo["state"] = st
                }
                if let cnt = country {
                    agencyInfo["country"] = cnt
                }
                if let postal = postalCode {
                    agencyInfo["postalCode"] = postal
                }
                
                updateData["agencyInfo"] = agencyInfo
                
            default:
                break
            }
            
            try await db.collection("profiles")
                .document(userId)
                .updateData(updateData)
            
            isSuccessful = true
            
        } catch {
            errorMessage = String(localized: "role_add_error \(error.localizedDescription)")
            isSuccessful = false
        }
        
        isLoading = false
    }
    
    private func isValidTaxNumber(_ number: String) -> Bool {
        let taxRegex = "^[0-9]{10}$"
        let taxPredicate = NSPredicate(format: "SELF MATCHES %@", taxRegex)
        return taxPredicate.evaluate(with: number)
    }
    
    private func isValidPhone(_ phone: String) -> Bool {
        let phoneRegex = "^[0-9+]{10,13}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let cleanPhone = phone.filter { $0.isNumber }
        return phonePredicate.evaluate(with: cleanPhone)
    }
}
