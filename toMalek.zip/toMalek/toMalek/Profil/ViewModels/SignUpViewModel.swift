//
//  SignUpViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class SignUpViewModel: ObservableObject {
    // MARK: - Services
    private let authService: AuthenticationService
    private let db = Firestore.firestore()
    
    // MARK: - Basic Info Published Properties
    @Published var fullName = ""
    @Published var email = ""
    @Published var phoneNumber = ""
    @Published var password = ""
    @Published var confirmPassword = ""
    @Published var userType: UserType = .tenant
    
    // MARK: - Owner Published Properties
    @Published var companyName = ""
    
    // MARK: - Agency Published Properties
    @Published var officialName = ""
    @Published var brandName = ""
    @Published var taxNumber = ""
    @Published var managerName = ""
    @Published var secondaryPhone = ""
    @Published var agentName = ""    // Emlakçı danışmanı bilgisi
    @Published var agentPhone = ""   // Emlakçı danışmanı telefonu
    @Published var latitude: Double?
    @Published var longitude: Double?
    @Published var formattedAddress: String?
    @Published var streetAddress: String?
    @Published var neighborhood: String?
    @Published var district: String?
    @Published var city: String?
    @Published var province: String?
    @Published var state: String?
    @Published var country: String?
    @Published var postalCode: String?
    
    // MARK: - UI State
    @Published var showPassword = false
    @Published var showConfirmPassword = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isAuthenticated = false
    
    // MARK: - Validation Properties
    var isValidForm: Bool {
        let basicValidation = isValidBasicInfo && isValidPassword
        
        switch userType {
        case .tenant:
            return basicValidation
        case .owner:
            return basicValidation
        case .agency:
            return basicValidation && isValidAgencyInfo
        }
    }
    
    private var isValidBasicInfo: Bool {
        isValidFullName && isValidEmail && isValidPhone
    }
    
    var isValidFullName: Bool {
        fullName.count >= 3
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    var isValidPhone: Bool {
        let numbers = phoneNumber.filter { $0.isNumber }
        return numbers.count >= 10
    }
    
    var isValidSecondaryPhone: Bool {
        guard !secondaryPhone.isEmpty else { return true }
        let numbers = secondaryPhone.filter { $0.isNumber }
        return numbers.count >= 10
    }
    
    var isValidAgentPhone: Bool {
        guard !agentPhone.isEmpty else { return true }
        let numbers = agentPhone.filter { $0.isNumber }
        return numbers.count >= 10
    }
    
    var isValidPassword: Bool {
        password.count >= 6 && password == confirmPassword
    }
    
    private var isValidAgencyInfo: Bool {
        !officialName.isEmpty &&
        !brandName.isEmpty &&
        isValidTaxNumber(taxNumber) &&
        isValidPhone
    }
    
    // MARK: - Initialization
    init(authService: AuthenticationService = ServiceContainer.shared.authService) {
        self.authService = authService
    }
    
    // MARK: - Methods
    private func isValidTaxNumber(_ number: String) -> Bool {
        let taxRegex = "^[0-9]{10}$"
        let taxPredicate = NSPredicate(format: "SELF MATCHES %@", taxRegex)
        return taxPredicate.evaluate(with: number)
    }
    
    @MainActor
    func signUp() async {
        guard isValidForm else {
            errorMessage = String(localized: "fill_fields_correctly")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let user = try await authService.signUp(email: email, password: password)
            
            // Kullanıcı tipine göre ek bilgileri hazırla
            var additionalInfo: [String: Any] = [:]
            
            switch userType {
            case .owner:
                if !companyName.isEmpty {
                    additionalInfo["ownerInfo"] = [
                        "companyName": companyName
                    ]
                }
                
            case .agency:
                let agencyInfo: [String: Any] = [
                    "officialName": officialName,
                    "brandName": brandName,
                    "taxNumber": taxNumber,
                    "managerName": managerName,
                    "secondaryPhone": secondaryPhone,
                    "agentName": agentName,
                    "agentPhone": agentPhone
                ]
                
                let locationInfo: [String: Any] = [
                    "latitude": latitude ?? 0.0,
                    "longitude": longitude ?? 0.0,
                    "formattedAddress": formattedAddress ?? "",
                    "streetAddress": streetAddress ?? "",
                    "neighborhood": neighborhood ?? "",
                    "district": district ?? "",
                    "city": city ?? "",
                    "province": province ?? "",
                    "state": state ?? "",
                    "country": country ?? "",
                    "postalCode": postalCode ?? ""
                ]
                
                // İki dictionary'i birleştir
                var combinedInfo = agencyInfo
                combinedInfo.merge(locationInfo) { current, _ in current }
                
                additionalInfo["agencyInfo"] = combinedInfo
                
            default:
                break
            }
            
            // Profil oluştur
            let profile = ProfilModel(
                id: UUID(uuidString: user.uid) ?? UUID(),
                fullName: fullName,
                phoneNumber: phoneNumber,
                email: email,
                userTypes: [userType],
                activeUserType: userType
            )
            
            var data: [String: Any] = [
                "fullName": profile.fullName,
                "phoneNumber": profile.phoneNumber,
                "email": profile.email,
                "userTypes": [userType.rawValue],
                "activeUserType": userType.rawValue,
                "createdAt": FieldValue.serverTimestamp()
            ]
            
            // Ek bilgileri ekle
            data.merge(additionalInfo) { current, _ in current }
            
            try await db.collection("profiles")
                .document(user.uid)
                .setData(data)
            
            isAuthenticated = true
            
        } catch {
            if let authError = error as? AuthError {
                errorMessage = authError.localizedDescription
            } else {
                errorMessage = String(localized: "registration_error")
                if let user = authService.currentUser {
                    try? await user.delete()
                }
            }
            try? authService.signOut()
            isAuthenticated = false
        }
        
        isLoading = false
    }
    
    func resetForm() {
        // Basic info
        fullName = ""
        email = ""
        phoneNumber = ""
        password = ""
        confirmPassword = ""
        userType = .tenant
        
        // Owner info
        companyName = ""
        
        // Agency info
        officialName = ""
        brandName = ""
        taxNumber = ""
        managerName = ""
        secondaryPhone = ""
        agentName = ""
        agentPhone = ""
        
        // UI state
        errorMessage = nil
        isLoading = false
        showPassword = false
        showConfirmPassword = false
        isAuthenticated = false
    }
}
