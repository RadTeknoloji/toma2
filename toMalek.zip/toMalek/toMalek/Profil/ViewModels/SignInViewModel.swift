//
//  SignInViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class SignInViewModel: ObservableObject {
    // MARK: - Services
    private let authService: AuthenticationService
    private let db = Firestore.firestore()
    
    // MARK: - Published Properties
    @Published var email = ""
    @Published var password = ""
    @Published var isLoading = false
    @Published var showPassword = false
    @Published var errorMessage: String?
    @Published var isAuthenticated = false
    @Published var showUserTypeSelection = false
    @Published var userTypes: Set<UserType> = []
    @Published var selectedUserType: UserType?
    
    // MARK: - Validation Properties
    var isValidForm: Bool {
        isValidEmail && password.count >= 6
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    // MARK: - Initialization
    init(authService: AuthenticationService = ServiceContainer.shared.authService) {
        self.authService = authService
    }
    
    // MARK: - Methods
    func signIn() async {
        guard isValidForm else {
            errorMessage = String(localized: "fill_fields_correctly")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            try await authService.signIn(email: email, password: password)
            
            // Kullanıcı girişi başarılı, profili kontrol et
            if let userId = Auth.auth().currentUser?.uid {
                let document = try await db.collection("profiles").document(userId).getDocument()
                
                if let data = document.data() {
                    // Kullanıcı rollerini al
                    let userTypeStrings = data["userTypes"] as? [String] ?? []
                    let types = Set(userTypeStrings.compactMap { rawValue in
                        UserType.allCases.first { $0.rawValue == rawValue }
                    })
                    
                    self.userTypes = types
                    
                    if types.count > 1 {
                        // Birden fazla rol varsa seçim yaptır
                        self.showUserTypeSelection = true
                    } else if let singleType = types.first {
                        // Tek rol varsa direkt onu seç
                        try await updateActiveUserType(singleType)
                        self.isAuthenticated = true
                    }
                }
            }
            
        } catch {
            if let authError = error as? AuthError {
                errorMessage = authError.localizedDescription
            } else {
                errorMessage = String(localized: "sign_in_error")
            }
        }
        
        isLoading = false
    }
    
    func updateActiveUserType(_ type: UserType) async throws {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        let updateData: [String: Sendable] = [
            "activeUserType": type.rawValue
        ]
        
        try await db.collection("profiles")
            .document(userId)
            .updateData(updateData)
        
        self.selectedUserType = type
        self.showUserTypeSelection = false
        self.isAuthenticated = true
    }
    
    func resetForm() {
        email = ""
        password = ""
        errorMessage = nil
        isLoading = false
        showPassword = false
        userTypes = []
        selectedUserType = nil
        showUserTypeSelection = false
    }
}
