//
//  ForgetPasswordViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class ForgetPasswordViewModel: ObservableObject {
    // MARK: - Services
    private let authService: AuthenticationService
    
    // MARK: - Published Properties
    @Published var email = ""
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccess = false
    
    // MARK: - Validation Properties
    var isValidForm: Bool {
        isValidEmail
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    // MARK: - Initialization
    init(authService: AuthenticationService = ServiceContainer.shared.authService) {
        self.authService = authService
    }
    
    // MARK: - Methods
    func resetPassword() async {
        guard isValidForm else {
            errorMessage = String(localized: "enter_valid_email")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            try await authService.resetPassword(email: email)
            isSuccess = true
        } catch {
            if let authError = error as? AuthError {
                errorMessage = authError.localizedDescription
            } else {
                errorMessage = String(localized: "password_reset_failed")
            }
            isSuccess = false
        }
        
        isLoading = false
    }
    
    func resetForm() {
        email = ""
        errorMessage = nil
        isLoading = false
        isSuccess = false
    }
}
