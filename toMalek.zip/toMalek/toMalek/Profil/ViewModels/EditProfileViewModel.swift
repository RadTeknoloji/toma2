//
//  EditProfileViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class EditProfileViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var fullName: String
    @Published var email: String
    @Published var phoneNumber: String
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    
    // MARK: - Properties
    private let profile: ProfilModel
    private let db = Firestore.firestore()
    
    // MARK: - Agency Location Properties
    @Published var latitude: Double?
    @Published var longitude: Double?
    @Published var formattedAddress: String?
    @Published var streetAddress: String?
    @Published var neighborhood: String?
    @Published var district: String?
    @Published var city: String?
    @Published var province: String?
    @Published var state: String?
    @Published var country: String?
    @Published var postalCode: String?
    
    // MARK: - Validation Properties
    var isValidForm: Bool {
        !fullName.isEmpty &&
        isValidEmail &&
        isValidPhone
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    var isValidPhone: Bool {
        let phoneRegex = "^[0-9+]{10,13}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let cleanPhone = phoneNumber.filter { $0.isNumber }
        return phonePredicate.evaluate(with: cleanPhone)
    }
    
    // MARK: - Initialization
    init(profile: ProfilModel) {
        self.profile = profile
        self.fullName = profile.fullName
        self.email = profile.email
        self.phoneNumber = profile.phoneNumber
        
        // Agency bilgileri varsa yükle
        if profile.activeUserType == .agency, let agencyInfo = profile.agencyInfo {
            self.latitude = agencyInfo.latitude
            self.longitude = agencyInfo.longitude
            self.formattedAddress = agencyInfo.formattedAddress
            self.streetAddress = agencyInfo.streetAddress
            self.neighborhood = agencyInfo.neighborhood
            self.district = agencyInfo.district
            self.city = agencyInfo.city
            self.province = agencyInfo.province
            self.state = agencyInfo.state
            self.country = agencyInfo.country
            self.postalCode = agencyInfo.postalCode
        }
    }
    
    // MARK: - Methods
    func save() async {
        guard isValidForm else {
            errorMessage = String(localized: "fill_required_fields_correctly")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            guard let userId = Auth.auth().currentUser?.uid else {
                throw AuthError.signInRequired
            }

            var updateData: [String: Any] = [
                "fullName": fullName,
                "phoneNumber": phoneNumber,
                "email": email
            ]
            
            // Agency kullanıcısı için adres bilgilerini ekle
            if profile.activeUserType == .agency {
                var agencyInfo: [String: Any] = [
                    "officialName": profile.agencyInfo?.officialName ?? "",
                    "brandName": profile.agencyInfo?.brandName ?? "",
                    "taxNumber": profile.agencyInfo?.taxNumber ?? "",
                    "managerName": profile.agencyInfo?.managerName ?? "",
                    "secondaryPhone": profile.agencyInfo?.secondaryPhone ?? ""
                ]
                
                // Location bilgilerini ekle
                if let lat = latitude {
                    agencyInfo["latitude"] = lat
                }
                if let lon = longitude {
                    agencyInfo["longitude"] = lon
                }
                if let address = formattedAddress {
                    agencyInfo["formattedAddress"] = address
                }
                if let street = streetAddress {
                    agencyInfo["streetAddress"] = street
                }
                if let hood = neighborhood {
                    agencyInfo["neighborhood"] = hood
                }
                if let dist = district {
                    agencyInfo["district"] = dist
                }
                if let cityName = city {
                    agencyInfo["city"] = cityName
                }
                if let prov = province {
                    agencyInfo["province"] = prov
                }
                if let st = state {
                    agencyInfo["state"] = st
                }
                if let cnt = country {
                    agencyInfo["country"] = cnt
                }
                if let postal = postalCode {
                    agencyInfo["postalCode"] = postal
                }
                
                updateData["agencyInfo"] = agencyInfo
            }
            
            try await db.collection("profiles")
                .document(userId)
                .updateData(updateData)
            
            isSuccessful = true
            
        } catch {
            errorMessage = String(localized: "profile_update_error")
            isSuccessful = false
        }
        
        isLoading = false
    }
    
    func resetForm() {
        fullName = profile.fullName
        email = profile.email
        phoneNumber = profile.phoneNumber
        
        // Agency bilgilerini sıfırla
        if profile.activeUserType == .agency, let agencyInfo = profile.agencyInfo {
            latitude = agencyInfo.latitude
            longitude = agencyInfo.longitude
            formattedAddress = agencyInfo.formattedAddress
            streetAddress = agencyInfo.streetAddress
            neighborhood = agencyInfo.neighborhood
            district = agencyInfo.district
            city = agencyInfo.city
            province = agencyInfo.province
            state = agencyInfo.state
            country = agencyInfo.country
            postalCode = agencyInfo.postalCode
        }
        
        errorMessage = nil
        isLoading = false
        isSuccessful = false
    }
}
