//
//  ProfileViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class ProfileViewModel: ObservableObject {
    // MARK: - Services
    private let db = Firestore.firestore()
    private let authService: AuthenticationService
    private let authState: AuthenticationState
    
    // MARK: - Published Properties
    @Published var profile: ProfilModel?
    @Published var showEditProfile = false
    @Published var showLogoutAlert = false
    @Published var showUserTypeAlert = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSignedOut = false
    @Published var selectedUserType: UserType?
    @Published var shouldReload = false
    
    // MARK: - Stats Properties
    @Published var totalProperties = 0
    @Published var totalExpenses: Double = 0
    @Published var totalRentPayments: Double = 0
    @Published var unpaidRents: Double = 0
    
    // MARK: - Initialization
    private init(
        authService: AuthenticationService,
        authState: AuthenticationState
    ) {
        self.authService = authService
        self.authState = authState
    }
    
    // Public factory method
    @MainActor
    static func create() -> ProfileViewModel {
        return ProfileViewModel(
            authService: ServiceContainer.shared.authService,
            authState: AuthenticationState.shared
        )
    }
    
    // MARK: - Methods
    func fetchProfile() async {
        isLoading = true
        errorMessage = nil
        
        do {
            guard let userId = Auth.auth().currentUser?.uid else {
                throw AuthError.signInRequired
            }
            
            let document = try await db.collection("profiles").document(userId).getDocument()
            guard let data = document.data() else {
                throw AuthError.userNotFound
            }
            
            let userTypeStrings = data["userTypes"] as? [String] ?? []
            let userTypes = Set(userTypeStrings.compactMap { rawValue in
                UserType.allCases.first { $0.rawValue == rawValue }
            })
            
            let activeUserTypeString = data["activeUserType"] as? String ?? userTypeStrings.first ?? ""
            let activeUserType = UserType.allCases.first { $0.rawValue == activeUserTypeString } ?? .tenant
            
            var ownerInfo: OwnerInfo?
            var agencyInfo: AgencyInfo?
            
            if let ownerData = data["ownerInfo"] as? [String: Any] {
                ownerInfo = OwnerInfo(
                    companyName: ownerData["companyName"] as? String
                )
            }
            
            if let agencyData = data["agencyInfo"] as? [String: Any] {
                agencyInfo = AgencyInfo(
                    officialName: agencyData["officialName"] as? String ?? "",
                    brandName: agencyData["brandName"] as? String ?? "",
                    taxNumber: agencyData["taxNumber"] as? String ?? "",
                    managerName: agencyData["managerName"] as? String ?? "",
                    secondaryPhone: agencyData["secondaryPhone"] as? String ?? "",
                    latitude: agencyData["latitude"] as? Double,
                    longitude: agencyData["longitude"] as? Double,
                    formattedAddress: agencyData["formattedAddress"] as? String,
                    streetAddress: agencyData["streetAddress"] as? String,
                    neighborhood: agencyData["neighborhood"] as? String,
                    district: agencyData["district"] as? String,
                    city: agencyData["city"] as? String,
                    province: agencyData["province"] as? String,
                    state: agencyData["state"] as? String,
                    country: agencyData["country"] as? String,
                    postalCode: agencyData["postalCode"] as? String
                )
            }

            
            self.profile = ProfilModel(
                id: UUID(uuidString: userId) ?? UUID(),
                fullName: data["fullName"] as? String ?? "",
                phoneNumber: data["phoneNumber"] as? String ?? "",
                email: data["email"] as? String ?? "",
                userTypes: userTypes,
                activeUserType: activeUserType,
                ownerInfo: ownerInfo,
                agencyInfo: agencyInfo
            )
            
        } catch {
            errorMessage = String(localized: "profile_load_error \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    func addUserType(_ type: UserType) async {
        guard let currentProfile = profile else { return }

        isLoading = true
        errorMessage = nil
        
        do {
            guard let userId = Auth.auth().currentUser?.uid else {
                throw AuthError.signInRequired
            }
            
            var updatedTypes = currentProfile.userTypes
            updatedTypes.insert(type)
            
            let updateData: [String: Sendable] = [
                "userTypes": Array(updatedTypes).map { $0.rawValue }
            ]
            
            try await db.collection("profiles")
                .document(userId)
                .updateData(updateData)
            
            // Aktif kullanıcı tipini yeni eklenen tipe güncelle
            let updatedProfile = ProfilModel(
                id: currentProfile.id,
                fullName: currentProfile.fullName,
                phoneNumber: currentProfile.phoneNumber,
                email: currentProfile.email,
                userTypes: updatedTypes,
                activeUserType: type // Aktif tipi yeni eklenen tipe ayarla
            )
            
            self.profile = updatedProfile
            
        } catch {
            errorMessage = String(localized: "role_add_error \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    func changeUserType(_ type: UserType) async {
        guard var currentProfile = profile else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            guard let userId = Auth.auth().currentUser?.uid else {
                throw AuthError.signInRequired
            }
            
            // Firebase'i güncelle
            let updateData: [String: Sendable] = [
                "activeUserType": type.rawValue
            ]
            
            try await db.collection("profiles")
                .document(userId)
                .updateData(updateData)
            
            // Local state'i güncelle
            currentProfile.activeUserType = type
            self.profile = currentProfile
            
            // AuthenticationState'i güncelle
            authState.updateUserType(type)
            
            // Kullanıcı türü değiştiğinde yeniden başlatma için alert göster
            self.selectedUserType = type
            self.showUserTypeAlert = true
            
        } catch {
            errorMessage = String(localized: "user_type_change_error \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    func signOut() async {
        isLoading = true
        errorMessage = nil
        
        do {
            try authService.signOut()
            isSignedOut = true
        } catch {
            errorMessage = String(localized: "sign_out_error")
        }
        
        isLoading = false
    }
    
    func fetchStats() async {
        // TODO: Firebase'den istatistikleri çek
        // Şimdilik mock data
        totalProperties = 0
        totalExpenses = 0
        totalRentPayments = 0
        unpaidRents = 0
    }
    
    func restartApp() {
        // 1. State'i temizle
        profile = nil
        totalProperties = 0
        totalExpenses = 0
        totalRentPayments = 0
        unpaidRents = 0
        
        // 2. Yeniden yükleme sinyali ver
        shouldReload = true
        
        // 3. Kısa bir delay sonra yeniden yükle
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.shouldReload = false
            // Direkt olarak verileri yeniden yükle
            Task {
                await self.fetchProfile()
                await self.fetchStats()
            }
        }
    }
}
