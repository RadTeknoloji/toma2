//
//  UserManager.swift
//  toMalek
//
//  Created by Selman Erbay on 5.02.2025.
//

import Foundation

class UserManager {
    static let shared = UserManager()
    
    private let defaults = UserDefaults.standard
    private let managerCapabilitiesKey = "userManagerCapabilities"
    
    // Dictionary'yi UserDefaults'tan yükle
    private var managerCapabilities: [UUID: Set<UserType>] {
        get {
            guard let data = defaults.data(forKey: managerCapabilitiesKey),
                  let capabilities = try? JSONDecoder().decode([String: [String]].self, from: data) else {
                return [:]
            }
            
            // String dictionary'yi UUID ve Set<UserType>'a dönüştür
            return capabilities.reduce(into: [:]) { result, pair in
                guard let uuid = UUID(uuidString: pair.key) else { return }
                let types = Set(pair.value.compactMap { UserType(rawValue: $0) })
                result[uuid] = types
            }
        }
        set {
            // UUID ve Set<UserType>'ı String dictionary'ye dönüştür
            let capabilities = newValue.reduce(into: [:]) { result, pair in
                result[pair.key.uuidString] = Array(pair.value.map { $0.rawValue })
            }
            
            if let data = try? JSONEncoder().encode(capabilities) {
                defaults.set(data, forKey: managerCapabilitiesKey)
            }
        }
    }
    
    // MARK: - Manager Capability Methods
    func setManagerCapability(for userId: UUID, type: UserType) {
        var current = managerCapabilities
        if var userTypes = current[userId] {
            userTypes.insert(type)
            current[userId] = userTypes
        } else {
            current[userId] = [type]
        }
        managerCapabilities = current  // Bu atama otomatik olarak UserDefaults'a kaydeder
    }
    
    func removeManagerCapability(for userId: UUID, type: UserType) {
        var current = managerCapabilities
        current[userId]?.remove(type)
        if current[userId]?.isEmpty == true {
            current.removeValue(forKey: userId)
        }
        managerCapabilities = current
    }
    
    func hasManagerCapability(userId: UUID, for type: UserType) -> Bool {
        return managerCapabilities[userId]?.contains(type) ?? false
    }
    
    func clearManagerCapabilities(for userId: UUID) {
        var current = managerCapabilities
        current.removeValue(forKey: userId)
        managerCapabilities = current
    }
    
    // MARK: - Backend Sync
    func syncManagerCapabilities(userId: UUID, capabilities: Set<UserType>) {
        var current = managerCapabilities
        current[userId] = capabilities
        managerCapabilities = current
    }
    
    // Tüm yönetici yetkilerini getir
    func getAllManagerCapabilities(for userId: UUID) -> Set<UserType> {
        return managerCapabilities[userId] ?? []
    }
}
