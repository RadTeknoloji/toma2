import SwiftUI
import MapKit

extension ProfileView {
    // Owner Section
    func ownerInfoSection(viewModel: ProfileViewModel) -> some View {
        Group {
            if let profile = viewModel.profile,
               profile.activeUserType == .owner {
                ProfileSection(title: LocalizedStringKey("owner_info")) {
                    if let ownerInfo = profile.ownerInfo {
                        VStack(spacing: 12) {
                            if let companyName = ownerInfo.companyName {
                                ProfileInfoRow(
                                    title: LocalizedStringKey("company_title"),
                                    value: companyName,
                                    icon: "building.2",
                                    isCopyable: true
                                )
                            }
                        }
                    } else {
                        Text(LocalizedStringKey("individual_owner"))
                            .font(.subheadline)
                            .foregroundColor(.border)
                    }
                }
            }
        }
    }

    // Agency Section
    // Agency Section
    func agencyInfoSection(viewModel: ProfileViewModel) -> some View {
        Group {
            if let profile = viewModel.profile,
               profile.activeUserType == .agency,
               let agencyInfo = profile.agencyInfo {
                ProfileSection(title: LocalizedStringKey("agency_info")) {
                    VStack(spacing: TLayout.spacingL) {
                        agencyBasicInfo(agencyInfo)
                        
                        // Konum Bilgileri
                        if let formattedAddress = agencyInfo.formattedAddress {
                            DisclosureGroup {
                                VStack(alignment: .leading, spacing: TLayout.spacingM) {
                                    Text(formattedAddress)
                                        .font(TFont.footnote)
                                        .foregroundColor(TColor.textPrimary)
                                    
                                    // Ülkeye göre adres detayları
                                    if let country = agencyInfo.country {
                                        switch country {
                                        case "Turkey", "Türkiye":
                                            if let neighborhood = agencyInfo.neighborhood {
                                                ProfileInfoRow(title: "neighborhood", value: neighborhood, icon: "house")
                                            }
                                            if let district = agencyInfo.district {
                                                ProfileInfoRow(title: "district", value: district, icon: "building.2")
                                            }
                                            if let state = agencyInfo.state {
                                                ProfileInfoRow(title: "city", value: state, icon: "mappin.circle")
                                            }
                                        default:
                                            if let city = agencyInfo.city {
                                                ProfileInfoRow(title: "city", value: city, icon: "building.2")
                                            }
                                            if let state = agencyInfo.state {
                                                ProfileInfoRow(title: "state", value: state, icon: "mappin.circle")
                                            }
                                        }
                                    }
                                    
                                    // Ortak alanlar
                                    if let country = agencyInfo.country {
                                        ProfileInfoRow(title: "country", value: country, icon: "globe")
                                    }
                                    if let postalCode = agencyInfo.postalCode {
                                        ProfileInfoRow(title: "postal_code", value: postalCode, icon: "envelope")
                                    }
                                    
                                    // Haritada Göster Butonu
                                    if let latitude = agencyInfo.latitude,
                                       let longitude = agencyInfo.longitude {
                                        Button {
                                            let coordinates = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                                            let placemark = MKPlacemark(coordinate: coordinates)
                                            let mapItem = MKMapItem(placemark: placemark)
                                            mapItem.openInMaps()
                                        } label: {
                                            HStack {
                                                Image(systemName: "map.fill")
                                                Text("open_in_maps")
                                            }
                                            .frame(maxWidth: .infinity)
                                            .padding()
                                            .background(TColor.areapolPrimary)
                                            .foregroundColor(.white)
                                            .cornerRadius(TLayout.cornerRadius)
                                        }
                                    }
                                }
                                .padding()
                                .background(TColor.surface)
                                .cornerRadius(TLayout.cornerRadius)
                            } label: {
                                HStack {
                                    Image(systemName: "location.fill")
                                        .foregroundColor(TColor.areapolPrimary)
                                    Text("location")
                                        .font(TFont.bodyBold)
                                        .foregroundColor(TColor.textPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    

    
    private func agencyBasicInfo(_ agencyInfo: AgencyInfo) -> some View {
        VStack(spacing: TLayout.spacing) {
            ProfileInfoRow(
                title: LocalizedStringKey("official_title"),
                value: agencyInfo.officialName,
                icon: "building.2",
                isCopyable: true
            )
            
            ProfileInfoRow(
                title: LocalizedStringKey("brand_name"),
                value: agencyInfo.brandName,
                icon: "signpost.right"
            )
            
            ProfileInfoRow(
                title: LocalizedStringKey("tax_number"),
                value: agencyInfo.taxNumber,
                icon: "number",
                isCopyable: true
            )
            
            ProfileInfoRow(
                title: LocalizedStringKey("manager"),
                value: agencyInfo.managerName,
                icon: "person.fill"
            )
            
            ProfileInfoRow(
                title: LocalizedStringKey("secondary_phone"),
                value: agencyInfo.secondaryPhone,
                icon: "phone.fill",
                isCopyable: true
            )
            
            // Ajans Danışmanı Bilgileri (Opsiyonel)
            if let agentName = agencyInfo.agentName {
                ProfileInfoRow(
                    title: LocalizedStringKey("agent_name"),
                    value: agentName,
                    icon: "person.2"
                )
            }
            
            if let agentPhone = agencyInfo.agentPhone {
                ProfileInfoRow(
                    title: LocalizedStringKey("agent_phone"),
                    value: agentPhone,
                    icon: "phone.fill",
                    isCopyable: true
                )
            }
        }
    }
    // Add User Type Section
    func addUserTypeSection(
        viewModel: ProfileViewModel,
        selectedUserTypeToAdd: Binding<UserType?>,
        showAddUserTypeSheet: Binding<Bool>
    ) -> some View {
        ProfileSection(title: LocalizedStringKey("add_role")) {
            if let availableTypes = viewModel.profile?.availableUserTypes {
                ForEach(availableTypes, id: \.self) { type in
                    addUserTypeButton(type, selectedUserTypeToAdd: selectedUserTypeToAdd, showAddUserTypeSheet: showAddUserTypeSheet)
                }
            }
        }
    }
    
    private func addUserTypeButton(_ type: UserType, selectedUserTypeToAdd: Binding<UserType?>, showAddUserTypeSheet: Binding<Bool>) -> some View {
        Button {
            selectedUserTypeToAdd.wrappedValue = type
            showAddUserTypeSheet.wrappedValue = true
        } label: {
            HStack {
                Text(type.localizedText) // ✅ localizedKey yerine localizedText kullan
                    .foregroundColor(.areapolPrimary)
                Spacer()
                Image(systemName: "plus.circle.fill")
                    .foregroundColor(.blue)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(8)
        }
    }

    // Actions Section
    func actionsSection(viewModel: ProfileViewModel) -> some View {
        VStack(spacing: 12) {
            editProfileButton(viewModel)
            logoutButton(viewModel)
        }
    }
    
    private func editProfileButton(_ viewModel: ProfileViewModel) -> some View {
        Button {
            viewModel.showEditProfile = true
        } label: {
            HStack {
                Label(LocalizedStringKey("edit_profile"), systemImage: "pencil")
                Spacer()
                Image(systemName: "chevron.right")
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(8)
        }
    }
    
    private func logoutButton(_ viewModel: ProfileViewModel) -> some View {
        Button {
            viewModel.showLogoutAlert = true
        } label: {
            HStack {
                Label(LocalizedStringKey("logout_action"), systemImage: "rectangle.portrait.and.arrow.right")
                    .foregroundColor(.red)
                Spacer()
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(8)
        }
    }
}
