//
//  UserTypeModels.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation

// MARK: - User Type Specific Models
struct OwnerInfo: Codable {
    var companyName: String?
}

struct AgencyInfo: Codable, UserTypeValidatable {
    var officialName: String
    var brandName: String
    var taxNumber: String
    var managerName: String
    var secondaryPhone: String
    var agentName: String?
    var agentPhone: String?
    
    // Adres bilgilerini ekleyelim
    var latitude: Double?
    var longitude: Double?
    var formattedAddress: String?
    var streetAddress: String?
    var neighborhood: String?
    var district: String?
    var city: String?
    var province: String?
    var state: String?
    var country: String?
    var postalCode: String?
    
    var isValid: Bool {
        !officialName.isEmpty &&
        !brandName.isEmpty &&
        !taxNumber.isEmpty &&
        !managerName.isEmpty &&
        !secondaryPhone.isEmpty
    }
}


// MARK: - Protocols
protocol UserTypeValidatable {
    var isValid: Bool { get }
}

// MARK: - Errors
enum ProfileError: LocalizedError {
    case notFound
    case invalidData
    case unauthorized
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .notFound:
            return String(localized: "profile_not_found")
        case .invalidData:
            return String(localized: "invalid_profile_data")
        case .unauthorized:
            return String(localized: "unauthorized_action")
        case .unknown:
            return String(localized: "unknown_error")
        }
    }
}
