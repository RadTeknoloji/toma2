//
//  ProfilModel.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation
import SwiftUI

enum UserType: String, Codable, CaseIterable {
    case tenant = "tenant"
    case owner = "owner"
    case agency = "agency"
    
    var localizedText: String {
        String(localized: String.LocalizationValue(self.rawValue))
    }
}

struct ProfilModel: Codable, Identifiable {
    let id: UUID
    
    // Temel Bilgiler
    var fullName: String
    var phoneNumber: String
    var email: String
    var secondaryPhone: String?
    var agentPhone: String?
    
    // Kullanıcı Tipleri
    var userTypes: Set<UserType>
    var activeUserType: UserType
    
    // Tip Spesifik Bilgiler
    var ownerInfo: OwnerInfo?
    var agencyInfo: AgencyInfo?
    
    // MARK: - Codable Implementation
    private enum CodingKeys: String, CodingKey {
        case id, fullName, phoneNumber, email, userTypes, activeUserType
        case ownerInfo, agencyInfo
        case secondaryPhone, agentPhone
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Decode basic info
        id = try container.decode(UUID.self, forKey: .id)
        fullName = try container.decode(String.self, forKey: .fullName)
        phoneNumber = try container.decode(String.self, forKey: .phoneNumber)
        email = try container.decode(String.self, forKey: .email)
        secondaryPhone = try container.decodeIfPresent(String.self, forKey: .secondaryPhone)
        agentPhone = try container.decodeIfPresent(String.self, forKey: .agentPhone)
        
        // Decode user types
        let typeStrings = try container.decode([String].self, forKey: .userTypes)
        userTypes = Set(typeStrings.compactMap { UserType(rawValue: $0) })
        
        let activeTypeString = try container.decode(String.self, forKey: .activeUserType)
        activeUserType = UserType(rawValue: activeTypeString) ?? .tenant
        
        // Decode optional role-specific info
        ownerInfo = try container.decodeIfPresent(OwnerInfo.self, forKey: .ownerInfo)
        agencyInfo = try container.decodeIfPresent(AgencyInfo.self, forKey: .agencyInfo)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        // Encode basic info
        try container.encode(id, forKey: .id)
        try container.encode(fullName, forKey: .fullName)
        try container.encode(phoneNumber, forKey: .phoneNumber)
        try container.encode(email, forKey: .email)
        try container.encodeIfPresent(secondaryPhone, forKey: .secondaryPhone)
        try container.encodeIfPresent(agentPhone, forKey: .agentPhone)
        
        // Encode user types
        try container.encode(userTypes.map { $0.rawValue }, forKey: .userTypes)
        try container.encode(activeUserType.rawValue, forKey: .activeUserType)
        
        // Encode optional role-specific info
        try container.encodeIfPresent(ownerInfo, forKey: .ownerInfo)
        try container.encodeIfPresent(agencyInfo, forKey: .agencyInfo)

    }
    
    // MARK: - Convenience Initializer
    init(id: UUID, fullName: String, phoneNumber: String, email: String,
         userTypes: Set<UserType>, activeUserType: UserType,
         ownerInfo: OwnerInfo? = nil, agencyInfo: AgencyInfo? = nil, secondaryPhone: String? = nil, agentPhone: String? = nil) {
        self.id = id
        self.fullName = fullName
        self.phoneNumber = phoneNumber
        self.email = email
        self.userTypes = userTypes
        self.activeUserType = activeUserType
        self.ownerInfo = ownerInfo
        self.agencyInfo = agencyInfo
        self.secondaryPhone = secondaryPhone
        self.agentPhone = agentPhone
    }
    
    // Validation için hesaplanan özellikler
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    var isValidPhoneNumber: Bool {
        let numbers = phoneNumber.filter { $0.isNumber }
        return numbers.count >= 10
    }
    
    var isValidSecondaryPhoneNumber: Bool {
        guard let phone = secondaryPhone else { return true }
        let numbers = phone.filter { $0.isNumber }
        return numbers.isEmpty || numbers.count >= 10
    }
    
    var isValidAgentPhoneNumber: Bool {
        guard let phone = agentPhone else { return true }
        let numbers = phone.filter { $0.isNumber }
        return numbers.isEmpty || numbers.count >= 10
    }
    
    var formattedPhoneNumber: String {
        phoneNumber.formatPhoneNumber()
    }
    
    var formattedSecondaryPhoneNumber: String {
        secondaryPhone?.formatPhoneNumber() ?? ""
    }
    
    var formattedAgentPhoneNumber: String {
        agentPhone?.formatPhoneNumber() ?? ""
    }
    
    // Kullanıcının ekleyebileceği rolleri hesapla
    var availableUserTypes: [UserType] {
        // 1. Tüm olası rolleri al
        // 2. Kullanıcının mevcut rollerini çıkar
        // 3. Aktif rolü kesinlikle çıkar (zaten eklenmiş demektir)
        Set(UserType.allCases)
            .subtracting(userTypes)  // mevcut rolleri çıkar
            .subtracting([activeUserType]) // aktif rolü kesinlikle çıkar
            .sorted { $0.rawValue < $1.rawValue }
    }
    
    // Tip bazlı validasyon
    func isValidForType(_ type: UserType) -> Bool {
        let basicValid = isValidEmail && isValidPhoneNumber && !fullName.isEmpty
        
        switch type {
        case .tenant:
            return basicValid
        case .owner:
            return basicValid
        case .agency:
            return basicValid && agencyInfo?.isValid == true
        }
    }
}
