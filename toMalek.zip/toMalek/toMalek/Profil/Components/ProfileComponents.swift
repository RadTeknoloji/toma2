//
//  ProfileComponents.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct ProfileSection<Content: View>: View {
    let title: LocalizedStringKey
    let content: Content
    
    init(title: LocalizedStringKey, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(title)
                .font(.headline)
            
            content
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
    }
}

struct StatCard: View {
    let title: LocalizedStringKey
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                Spacer()
            }
            
            Text(title)
                .font(.footnote)
                .foregroundColor(.border)
            
            Text(value)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(.areapolPrimary)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(color.opacity(0.2), lineWidth: 2)
        )
    }
}

struct ProfileInfoRow: View {
    let title: LocalizedStringKey
    let value: String
    let icon: String
    var isCopyable: Bool = false
    
    var body: some View {
        Button(action: {
            if isCopyable {
                UIPasteboard.general.string = value
            }
        }) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.border)
                    .frame(width: 24)
                
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.border)
                
                Spacer()
                
                Text(value)
                    .font(.subheadline)
                    .foregroundColor(.areapolPrimary)
                
                if isCopyable {
                    Image(systemName: "doc.on.doc")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }
        }
        .disabled(!isCopyable)
    }
}
