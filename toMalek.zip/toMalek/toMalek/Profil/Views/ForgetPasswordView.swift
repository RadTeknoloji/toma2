//
//  ForgetPasswordView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct ForgetPasswordView: View {
    @StateObject private var viewModel = ForgetPasswordViewModel()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: TLayout.spacingL) {
            // Icon ve Başlık
            headerSection
            
            // Form
            formSection
            
            // Mesajlar
            messageSection
            
            // Butonlar
            buttonsSection
            
            Spacer()
        }
        .padding(.top, TLayout.paddingXL)
        .navigationBarTitleDisplayMode(.inline)
        .background(TColor.background)
    }
    
    // MARK: - View Components
    private var headerSection: some View {
        VStack(spacing: TLayout.spacing) {
            Image(systemName: "lock.rotation")
                .font(.system(size: TLayout.iconSize * 2))
                .foregroundColor(TColor.areapolPrimary)
            
            Text(String(localized: "password_reset"))
                .font(TFont.title2)
                .foregroundColor(TColor.textPrimary)
            
            Text(String(localized: "password_reset_description"))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, TLayout.padding)
        }
    }
    
    private var formSection: some View {
        VStack(spacing: TLayout.spacing) {
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(String(localized: "email"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                TextField(String(localized: "email_placeholder"), text: $viewModel.email)
                    .font(TFont.body)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .padding(TLayout.padding)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
            }
            .padding(.horizontal, TLayout.padding)
        }
    }
    
    private var messageSection: some View {
        Group {
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, TLayout.padding)
            }
            
            if viewModel.isSuccess {
                VStack(spacing: TLayout.spacingXS) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.title)
                        .foregroundColor(TColor.success)
                    
                    Text(String(localized: "password_reset_success"))
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, TLayout.padding)
            }
        }
    }
    
    private var buttonsSection: some View {
        VStack(spacing: TLayout.spacing) {
            if !viewModel.isSuccess {
                PrimaryButton(
                    title: LocalizedStringKey(String(localized: "reset_password")),
                    action: {
                        Task { await viewModel.resetPassword() }
                    },
                    isLoading: viewModel.isLoading,
                    isDisabled: !viewModel.isValidForm
                )
            } else {
                SecondaryButton(
                    title: LocalizedStringKey(String(localized: "return_to_login")),
                    action: { dismiss() }
                )
            }
        }
        .padding(.horizontal, TLayout.padding)
    }
}

struct ForgetPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ForgetPasswordView()
            .background(TColor.background)
    }
}
