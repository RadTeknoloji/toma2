//
//  EditProfileView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct EditProfileView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: EditProfileViewModel
    let profile: ProfilModel
    
    init(profile: ProfilModel) {
        self.profile = profile
        _viewModel = StateObject(wrappedValue: EditProfileViewModel(profile: profile))
    }
    
    var body: some View {
        NavigationView {
            Form {
                userInfoSection
                
                // Agency kullanıcısı için konum section'ını ekle
                if profile.activeUserType == .agency {
                    locationSection
                }
            }
            .navigationTitle(String(localized: "edit_profile"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { navigationToolbar }
            .overlay { loadingOverlay }
            .background(TColor.background)
            .onChange(of: viewModel.isSuccessful) { _, newValue in
                if newValue {
                    dismiss()
                }
            }
            .alert(
                String(localized: "error"),
                isPresented: .constant(viewModel.errorMessage != nil)
            ) {
                Button(String(localized: "ok"), role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(TColor.error)
                }
            }
        }
    }

    // MARK: - View Components
    private var userInfoSection: some View {
        Section(String(localized: "user_info")) {
            fullNameField
            emailField
            phoneField
        }
        .listRowBackground(TColor.surface)
    }
    
    private var locationSection: some View {
        Section {
            NavigationLink {
                AgencyLocationStepView(
                    latitude: $viewModel.latitude,
                    longitude: $viewModel.longitude,
                    formattedAddress: $viewModel.formattedAddress,
                    streetAddress: $viewModel.streetAddress,
                    neighborhood: $viewModel.neighborhood,
                    district: $viewModel.district,
                    city: $viewModel.city,
                    province: $viewModel.province,
                    state: $viewModel.state,
                    country: $viewModel.country,
                    postalCode: $viewModel.postalCode
                )
            } label: {
                HStack {
                    Text("Konum Bilgisi")
                        .font(TFont.body)
                    
                    Spacer()
                    
                    if viewModel.formattedAddress != nil {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(TColor.success)
                    }
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(TColor.textSecondary)
                }
            }
            
            if let address = viewModel.formattedAddress {
                Text(address)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
            }
        } header: {
            Text("Konum Bilgileri (Opsiyonel)")
                .font(TFont.footnoteBold)
                .foregroundColor(TColor.textSecondary)
        }
    }
    
    private var fullNameField: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            TextField(String(localized: "full_name"), text: $viewModel.fullName)
                .textContentType(.name)
                .textInputAutocapitalization(.words)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            if viewModel.fullName.isEmpty {
                Text(String(localized: "full_name_required"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
            }
        }
    }
    
    private var emailField: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            TextField(String(localized: "email"), text: $viewModel.email)
                .textContentType(.emailAddress)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            if !viewModel.isValidEmail {
                Text(String(localized: "enter_valid_email"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
            }
        }
    }
    
    private var phoneField: some View {
        VStack(alignment: .leading) {
            PhoneInputView(
                text: $viewModel.phoneNumber,
                label: "phone",
                placeholder: "phone_placeholder",
                error: !viewModel.isValidPhone ? "error_phone" : nil
            )
        }
    }
    
    @ToolbarContentBuilder
    private var navigationToolbar: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button(String(localized: "cancel")) {
                dismiss()
            }
            .foregroundColor(TColor.areapolPrimary)
        }
        
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(String(localized: "save")) {
                Task {
                    await viewModel.save()
                }
            }
            .foregroundColor(viewModel.isValidForm ? TColor.areapolPrimary : TColor.textSecondary)
            .disabled(!viewModel.isValidForm || viewModel.isLoading)
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
    }
}

#Preview {
    EditProfileView(profile: ProfilModel(
        id: UUID(),
        fullName: "John Doe",
        phoneNumber: "+905551234567",
        email: "john@example.com",
        userTypes: [.tenant],
        activeUserType: .tenant
    ))
    .background(TColor.background)
}
