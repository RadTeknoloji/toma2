//
//  ProfileView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct ProfileView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var authState: AuthenticationState
    @StateObject var viewModel = ProfileViewModel.create()
    @StateObject var tokenViewModel = TokenViewModel()
    @State private var showUserTypeActionSheet = false
    @State private var showAddUserTypeSheet = false
    @State private var selectedUserTypeToAdd: UserType?
    @State private var showTokenView = false
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: TLayout.spacingM) {
                // Profile Header
                profileHeader
                    .padding(.top, TLayout.spacingL)
                
                // Token Balance Card
                tokenBalanceSection
                
                // Main Content Area
                contentSection
            }
        }
        .background(TColor.background)
        .navigationBarTitleDisplayMode(.inline)
        .applyNavigationBarStyle()
        .sheet(isPresented: $viewModel.showEditProfile) {
            if let profile = viewModel.profile {
                EditProfileView(profile: profile)
                    .background(TColor.background)
            }
        }
        .sheet(isPresented: $showTokenView) {
            TokenView()
        }
        .sheet(isPresented: $showAddUserTypeSheet) {
            if let typeToAdd = selectedUserTypeToAdd {
                AddUserTypeView(userType: typeToAdd)
                    .presentationDetents([.medium, .large])
                    .background(TColor.background)
            }
        }
        .alert("logout".localized(), isPresented: $viewModel.showLogoutAlert) {
            Button("logout_action".localized(), role: .destructive) {
                Task { await signOut() }
            }
            Button("cancel".localized(), role: .cancel) {}
        } message: {
            Text("logout_confirmation".localized())
        }
        .alert("user_type_changed".localized(), isPresented: $viewModel.showUserTypeAlert) {
            Button("restart_app".localized()) {
                viewModel.restartApp()
            }
        } message: {
            Text("restart_required".localized())
        }
        .confirmationDialog(
            "select_user_type".localized(),
            isPresented: $showUserTypeActionSheet,
            titleVisibility: .visible
        ) {
            if let profile = viewModel.profile {
                ForEach(Array(profile.userTypes), id: \.self) { type in
                    Button(type.localizedText) {
                        Task {
                            await viewModel.changeUserType(type)
                        }
                    }
                }
            }
            Button("cancel".localized(), role: .cancel) {}
        }
        .task {
            await viewModel.fetchProfile()
            await tokenViewModel.fetchUserTokens()
        }
        .overlay {
            if viewModel.isLoading {
                ProfilLoadingView()
            }
        }
        .refreshable {
            await viewModel.fetchProfile()
            await tokenViewModel.fetchUserTokens()
        }
    }
    // MARK: - Profile Header
        private var profileHeader: some View {
            VStack(spacing: TLayout.spacingS) {
                ZStack {
                    Circle()
                        .fill(TColor.areapolPrimary.opacity(0.1))
                        .frame(width: 90, height: 90)
                    
                    Text(viewModel.profile?.fullName.prefix(1).uppercased() ?? "")
                        .font(.system(size: 32, weight: .semibold, design: .rounded))
                        .foregroundColor(TColor.areapolPrimary)
                }
                .shadow(color: TColor.areapolPrimary.opacity(0.1), radius: 8, x: 0, y: 4)
                
                VStack(spacing: TLayout.spacingXXS) {
                    Text(viewModel.profile?.fullName ?? "")
                        .font(.system(size: 22, weight: .semibold, design: .rounded))
                        .foregroundColor(TColor.textPrimary)
                    
                    if let activeUserType = viewModel.profile?.activeUserType {
                        Text(activeUserType.localizedText)
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundColor(TColor.areapolPrimary)
                            .padding(.horizontal, TLayout.spacingM)
                            .padding(.vertical, 4)
                            .background(
                                Capsule()
                                    .fill(TColor.areapolPrimary.opacity(0.1))
                            )
                    }
                }
            }
        }
        
        // MARK: - Token Balance Section
        private var tokenBalanceSection: some View {
            NavigationLink {
                TokenView()
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: TLayout.spacingXXS) {
                        Text("token_balance".localized())
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundColor(TColor.textSecondary)
                        
                        Text("\(tokenViewModel.totalBalance)")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                            .foregroundColor(TColor.areapolPrimary)
                    }
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(TColor.textSecondary)
                        .font(.system(size: 16, weight: .medium))
                }
                .padding(TLayout.spacingL)
                .background(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .fill(TColor.surface)
                        .shadow(color: TColor.border.opacity(0.1), radius: 12, x: 0, y: 4)
                )
                .padding(.horizontal, TLayout.spacingM)
            }
        }
        
        // MARK: - Main Content Section
        private var contentSection: some View {
            VStack(spacing: TLayout.spacingL) {
                // Basic Info
                infoSection
                
                // User Types
                if let profile = viewModel.profile {
                    userTypesSection(profile: profile)
                }
                
                // Type Specific Info
                if let profile = viewModel.profile {
                    typeSpecificInfo(profile: profile)
                }
                
                // Available Types
                if let profile = viewModel.profile,
                   !profile.availableUserTypes.isEmpty {
                    availableTypesSection(profile: profile)
                }
                
                // Actions
                actionButtonsSection
            }
            .padding(.horizontal, TLayout.spacingM)
        }
    // MARK: - Info Section
        private var infoSection: some View {
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text("basic_info".localized())
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundColor(TColor.textPrimary)
                
                VStack(spacing: TLayout.spacingM) {
                    ProfilInfoRow(icon: "person.fill", title: "full_name".localized(), value: viewModel.profile?.fullName ?? "")
                    
                    ProfilInfoRow(icon: "envelope.fill",
                           title: "email".localized(),
                           value: viewModel.profile?.email ?? "",
                           isCopyable: true)
                    
                    contactRow(
                        icon: "phone.fill",
                        title: "phone".localized(),
                        number: viewModel.profile?.formattedPhoneNumber ?? ""
                    )
                    
                    if let secondaryPhone = viewModel.profile?.formattedSecondaryPhoneNumber,
                       !secondaryPhone.isEmpty {
                        contactRow(
                            icon: "phone.circle.fill",
                            title: "secondary_phone".localized(),
                            number: secondaryPhone
                        )
                    }
                    
                    if let agentPhone = viewModel.profile?.formattedAgentPhoneNumber,
                       !agentPhone.isEmpty {
                        contactRow(
                            icon: "phone.badge.plus.fill",
                            title: "agent_phone".localized(),
                            number: agentPhone
                        )
                    }
                }
                .padding(TLayout.padding)
                .background(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .fill(TColor.surface)
                )
            }
        }
        
        // MARK: - User Types Section
        private func userTypesSection(profile: ProfilModel) -> some View {
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text("user_types".localized())
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundColor(TColor.textPrimary)
                
                VStack(spacing: TLayout.spacingS) {
                    ForEach(Array(profile.userTypes), id: \.self) { type in
                        userTypeButton(type: type, isActive: type == profile.activeUserType)
                    }
                }
            }
        }
        
        private func userTypeButton(type: UserType, isActive: Bool) -> some View {
            Button {
                Task {
                    await viewModel.changeUserType(type)
                }
            } label: {
                HStack {
                    Text(type.localizedText)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(TColor.textPrimary)
                    
                    Spacer()
                    
                    if isActive {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(TColor.success)
                    }
                }
                .padding(.vertical, TLayout.spacingS)
                .padding(.horizontal, TLayout.padding)
                .background(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .fill(isActive ? TColor.areapolPrimary.opacity(0.1) : TColor.surface)
                )
            }
            .disabled(!isActive && viewModel.profile?.userTypes.count ?? 0 <= 1)
        }
        
        // MARK: - Type Specific Info
        private func typeSpecificInfo(profile: ProfilModel) -> some View {
            Group {
                switch profile.activeUserType {
                case .owner:
                    ownerInfoSection(viewModel: viewModel)
                case .agency:
                    agencyInfoSection(viewModel: viewModel)
                default:
                    EmptyView()
                }
            }
        }
    // MARK: - Available Types Section
        private func availableTypesSection(profile: ProfilModel) -> some View {
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text("add_user_type".localized())
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundColor(TColor.textPrimary)
                
                ForEach(Array(profile.availableUserTypes), id: \.self) { type in
                    addTypeButton(for: type)
                }
            }
        }
        
        private func addTypeButton(for type: UserType) -> some View {
            Button {
                if type == .tenant {
                    Task {
                        await viewModel.addUserType(type)
                    }
                } else {
                    selectedUserTypeToAdd = type
                    showAddUserTypeSheet = true
                }
            } label: {
                HStack {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Text(type.localizedText)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(TColor.textPrimary)
                    
                    Spacer()
                }
                .padding(.vertical, TLayout.spacingS)
                .padding(.horizontal, TLayout.padding)
                .background(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .fill(TColor.surface)
                )
            }
        }
        
        // MARK: - Action Buttons Section
        private var actionButtonsSection: some View {
            VStack(spacing: TLayout.spacingM) {
                Button {
                    viewModel.showEditProfile = true
                } label: {
                    HStack {
                        Image(systemName: "pencil")
                        Text("edit_profile".localized())
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(TButton.Primary())
                
                Button {
                    viewModel.showLogoutAlert = true
                } label: {
                    HStack {
                        Image(systemName: "arrow.right.square")
                        Text("logout".localized())
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(TButton.Destructive())
            }
            .padding(.bottom, TLayout.spacingL)
        }
        
        // MARK: - Helper Views & Functions
        private func contactRow(icon: String, title: String, number: String) -> some View {
            Button {
                let formattedNumber = number
                    .replacingOccurrences(of: " ", with: "")
                    .replacingOccurrences(of: "(", with: "")
                    .replacingOccurrences(of: ")", with: "")
                guard let url = URL(string: "tel:\(formattedNumber)") else { return }
                UIApplication.shared.open(url)
            } label: {
                ProfilInfoRow(icon: icon, title: title, value: number)
            }
        }
        
        private func signOut() async {
            await authState.signOut()
        }
    }

    // MARK: - Info Row Component
    struct ProfilInfoRow: View {
        let icon: String
        let title: String
        let value: String
        var isCopyable: Bool = false
        
        var body: some View {
            HStack(spacing: TLayout.spacingM) {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(TColor.areapolPrimary)
                    .frame(width: 24)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(TColor.textSecondary)
                    
                    Text(value)
                        .font(.system(size: 16))
                        .foregroundColor(TColor.textPrimary)
                }
                
                Spacer()
                
                if isCopyable {
                    Button {
                        UIPasteboard.general.string = value
                    } label: {
                        Image(systemName: "doc.on.doc")
                            .font(.system(size: 14))
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
        }
    }

    // MARK: - Loading View
    private struct ProfilLoadingView: View {
        var body: some View {
            ZStack {
                TColor.background.opacity(0.8)
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
    }

    // MARK: - Preview
    struct ProfileView_Previews: PreviewProvider {
        static var previews: some View {
            ProfileView()
                .environmentObject(AuthenticationState())
                .background(TColor.background)
        }
    }

