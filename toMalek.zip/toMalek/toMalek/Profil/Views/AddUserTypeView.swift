//
//  AddUserTypeView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct AddUserTypeView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: AddUserTypeViewModel
    let userType: UserType
    @State private var renderingPhase: RenderPhase = .initial
    
    enum RenderPhase {
        case initial
        case loading
        case ready
    }
    
    init(userType: UserType) {
        self.userType = userType
        _viewModel = StateObject(wrappedValue: AddUserTypeViewModel(userType: userType))
    }
    
    var body: some View {
        NavigationView {
            Group {
                switch renderingPhase {
                case .initial:
                    Color.clear
                case .loading:
                    ProgressView()
                        .tint(TColor.areapolPrimary)
                case .ready:
                    mainContent
                }
            }
            .background(TColor.background)
        }
        .onAppear(perform: handleAppear)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
    
    private var mainContent: some View {
        Form {
            userSpecificContent
        }
        .navigationTitle(String(format: String(localized: "add_role_title_%@"), userType.rawValue))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { navigationToolbar }
        .overlay(loadingOverlay)
        .modifier(AlertHandler(viewModel: viewModel, dismiss: dismiss))
    }
    
    @ToolbarContentBuilder
    private var navigationToolbar: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button(String(localized: "cancel")) {
                dismiss()
            }
            .foregroundColor(TColor.areapolPrimary)
        }
        
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(String(localized: "save")) {
                Task {
                    await viewModel.save(userType)
                }
            }
            .foregroundColor(viewModel.isValidForm ? TColor.areapolPrimary : TColor.textSecondary)
            .disabled(!viewModel.isValidForm || viewModel.isLoading)
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
                    .padding()
                    .background(TColor.background.opacity(0.9))
                    .cornerRadius(TLayout.cornerRadius)
            }
        }
    }
    
    private var userSpecificContent: some View {
        Group {
            switch userType {
            case .owner:
                ownerSection
            case .agency:
                agencySection
            default:
                EmptyView()
            }
        }
    }
    
    private var ownerSection: some View {
        Section {
            TextField(String(localized: "company_name_optional"), text: $viewModel.companyName)
                .textInputAutocapitalization(.words)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
        } footer: {
            Text(String(localized: "company_name_footer"))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
        }
    }
    
    private var agencySection: some View {
        Group {
            companyInfoSection
            locationSection
        }
    }
    
    private var companyInfoSection: some View {
        Section {
            TextField(String(localized: "official_company_name"), text: $viewModel.officialName)
                .textInputAutocapitalization(.words)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            TextField(String(localized: "brand_name"), text: $viewModel.brandName)
                .textInputAutocapitalization(.words)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            TextField(String(localized: "tax_number"), text: $viewModel.taxNumber)
                .keyboardType(.numberPad)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
        } header: {
            SectionHeader(text: String(localized: "company_info"))
        }
    }
    
    private var locationSection: some View {
        Section {
            NavigationLink {
                AgencyLocationStepView(
                    latitude: $viewModel.latitude,
                    longitude: $viewModel.longitude,
                    formattedAddress: $viewModel.formattedAddress,
                    streetAddress: $viewModel.streetAddress,
                    neighborhood: $viewModel.neighborhood,
                    district: $viewModel.district,
                    city: $viewModel.city,
                    province: $viewModel.province,
                    state: $viewModel.state,
                    country: $viewModel.country,
                    postalCode: $viewModel.postalCode
                )
            } label: {
                HStack {
                    Text("Konum Bilgisi")
                        .font(TFont.body)
                    
                    Spacer()
                    
                    if viewModel.formattedAddress != nil {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(TColor.success)
                    }
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(TColor.textSecondary)
                }
            }
            
            if let address = viewModel.formattedAddress {
                Text(address)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
            }
        } header: {
            SectionHeader(text: "Konum Bilgileri (Opsiyonel)")
        }
    }
    
    private func handleAppear() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            renderingPhase = .loading
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                renderingPhase = .ready
            }
        }
    }
}

private struct SectionHeader: View {
    let text: String
    
    var body: some View {
        Text(text)
            .font(TFont.footnoteBold)
            .foregroundColor(TColor.textSecondary)
    }
}

struct AlertHandler: ViewModifier {
    @ObservedObject var viewModel: AddUserTypeViewModel
    let dismiss: DismissAction
    
    func body(content: Content) -> some View {
        content
            .onChange(of: viewModel.isSuccessful) { _, success in
                if success {
                    dismiss()
                }
            }
            .alert(
                String(localized: "error"),
                isPresented: .constant(viewModel.errorMessage != nil)
            ) {
                Button(String(localized: "ok"), role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                        .foregroundColor(TColor.error)
                }
            }
    }
}

#Preview {
    AddUserTypeView(userType: .owner)
        .background(TColor.background)
}
