//
//  SignUpView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct SignUpView: View {
    @StateObject private var viewModel = SignUpViewModel()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ScrollView {
            VStack(spacing: TLayout.spacingXL) {
                // Logo ve Başlık
                headerSection
                
                // Form
                VStack(spacing: TLayout.spacingM) {
                    userTypeSection
                    basicInfoSection
                    dynamicFormSection
                    passwordSection
                }
                .padding(.horizontal, TLayout.padding)
                
                errorMessageSection
                signUpButtonSection
                signInNavigationSection
            }
            .padding(.top, TLayout.paddingXL)
        }
        .background(TColor.background)
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(isPresented: $viewModel.isAuthenticated) {
            MainTabView()
                .background(TColor.background)
        }
    }
    
    // MARK: - View Components
    private var headerSection: some View {
        VStack(spacing: TLayout.spacing) {
            Image("Rentack-1024x1024.png")
                .resizable()
                .scaledToFit()
                .frame(width: TLayout.logoSize, height: TLayout.logoSize)
                .foregroundColor(TColor.areapolPrimary)
            
            Text(LocalizedStringKey("create_account".localized()))
                .font(TFont.title2)
                .fontWeight(.semibold)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var userTypeSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(LocalizedStringKey("user_type".localized()))
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            Picker(LocalizedStringKey("user_type".localized()), selection: $viewModel.userType) {
                ForEach(UserType.allCases, id: \.self) { type in
                    Text(type.localizedText) // ✅ rawValue yerine localizedText kullan
                        .tag(type)
                        .font(TFont.body)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .background(TColor.background)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    private var basicInfoSection: some View {
        VStack(spacing: TLayout.spacingL) {
            FormField(
                title: LocalizedStringKey("full_name".localized()),
                text: $viewModel.fullName,
                placeholder: LocalizedStringKey("full_name_placeholder".localized()),
                isValid: viewModel.isValidFullName
            )
            
            FormField(
                title: LocalizedStringKey("email".localized()),
                text: $viewModel.email,
                placeholder: LocalizedStringKey("email_placeholder".localized()),
                isValid: viewModel.isValidEmail,
                keyboardType: .emailAddress,
                textInputAutocapitalization: .never
            )
            
            PhoneInputView(
                text: $viewModel.phoneNumber,
                label: LocalizedStringKey("phone".localized()),
                placeholder: LocalizedStringKey("phone_placeholder".localized()),
                error: !viewModel.isValidPhone ? "error_phone".localized() : nil
            )
        }
    }
    
    private var dynamicFormSection: some View {
        Group {
            switch viewModel.userType {
            case .tenant:
                EmptyView()
            case .owner:
                ownerInfoSection
            case .agency:
                agencyInfoSection
            }
        }
    }
    
    private var ownerInfoSection: some View {
        VStack(spacing: TLayout.spacingL) {
            FormField(
                title: LocalizedStringKey("company_name".localized()),
                text: $viewModel.companyName,
                placeholder: LocalizedStringKey("company_name_placeholder".localized())
            )
        }
    }
    
    private var agencyInfoSection: some View {
        VStack(spacing: TLayout.spacingL) {
            FormField(
                title: LocalizedStringKey("official_name".localized()),
                text: $viewModel.officialName,
                placeholder: LocalizedStringKey("official_name_placeholder".localized())
            )
            
            FormField(
                title: LocalizedStringKey("brand_name".localized()),
                text: $viewModel.brandName,
                placeholder: LocalizedStringKey("brand_name_placeholder".localized())
            )
            
            FormField(
                title: LocalizedStringKey("tax_number".localized()),
                text: $viewModel.taxNumber,
                placeholder: LocalizedStringKey("tax_number_placeholder".localized()),
                keyboardType: .numberPad
            )
            
            // Konum alanını ekleyelim
            FormField(
                title: LocalizedStringKey("location".localized()),
                text: .init(
                    get: { viewModel.formattedAddress ?? "" },
                    set: { viewModel.formattedAddress = $0 }
                ),
                placeholder: LocalizedStringKey("select_location".localized()),
                isValid: true
            )
            .overlay(
                NavigationLink {
                    AgencyLocationStepView(
                        latitude: $viewModel.latitude,
                        longitude: $viewModel.longitude,
                        formattedAddress: $viewModel.formattedAddress,
                        streetAddress: $viewModel.streetAddress,
                        neighborhood: $viewModel.neighborhood,
                        district: $viewModel.district,
                        city: $viewModel.city,
                        province: $viewModel.province,
                        state: $viewModel.state,
                        country: $viewModel.country,
                        postalCode: $viewModel.postalCode
                    )
                } label: {
                    Color.clear
                }
            )
        }
    }

    
    private var passwordSection: some View {
        VStack(spacing: TLayout.spacingL) {
            FormSecureField(
                title: LocalizedStringKey("password".localized()),
                text: $viewModel.password,
                placeholder: "••••••",
                showPassword: $viewModel.showPassword,
                isValid: viewModel.isValidPassword
            )
            
            FormSecureField(
                title: LocalizedStringKey("confirm_password".localized()),
                text: $viewModel.confirmPassword,
                placeholder: "••••••",
                showPassword: $viewModel.showConfirmPassword,
                isValid: viewModel.password == viewModel.confirmPassword
            )
        }
    }
    
    private var errorMessageSection: some View {
        Group {
            if let errorMessage = viewModel.errorMessage {
                Text(LocalizedStringKey(errorMessage.localized()))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
        }
    }
    
    private var signUpButtonSection: some View {
        Button(action: {
            Task {
                await viewModel.signUp()
            }
        }) {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.onPrimary)
            } else {
                Text(LocalizedStringKey("sign_up".localized()))
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.onPrimary)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, TLayout.padding)
        .background(
            RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                .fill(viewModel.isValidForm ? TColor.areapolPrimary : TColor.areapolPrimary.opacity(0.5))
        )
        .padding(.horizontal, TLayout.padding)
        .disabled(!viewModel.isValidForm || viewModel.isLoading)
    }
    
    private var signInNavigationSection: some View {
        Button {
            dismiss()
        } label: {
            HStack(spacing: TLayout.spacingXS) {
                Text(LocalizedStringKey("have_account".localized()))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                Text(LocalizedStringKey("sign_in".localized()))
                    .font(TFont.footnoteBold)
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
        .padding(.vertical, TLayout.paddingL)
    }
}

// MARK: - Form Components
struct FormField: View {
    let title: LocalizedStringKey
    @Binding var text: String
    let placeholder: LocalizedStringKey
    var isValid: Bool = true
    var keyboardType: UIKeyboardType = .default
    var textInputAutocapitalization: TextInputAutocapitalization = .words
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(title)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            TextField(placeholder, text: $text)
                .font(TFont.body)
                .keyboardType(keyboardType)
                .textInputAutocapitalization(textInputAutocapitalization)
                .padding(TLayout.padding)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(isValid ? Color.clear : TColor.error, lineWidth: 1)
                )
        }
    }
}

struct FormSecureField: View {
    let title: LocalizedStringKey
    @Binding var text: String
    let placeholder: String
    @Binding var showPassword: Bool
    var isValid: Bool = true
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(title)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
            
            HStack {
                Group {
                    if showPassword {
                        TextField(placeholder, text: $text)
                    } else {
                        SecureField(placeholder, text: $text)
                    }
                }
                .font(TFont.body)
                
                Button {
                    showPassword.toggle()
                } label: {
                    Image(systemName: showPassword ? "eye.slash" : "eye")
                        .foregroundColor(TColor.textSecondary)
                }
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(isValid ? Color.clear : TColor.error, lineWidth: 1)
            )
        }
    }
}

// MARK: - Preview
#Preview {
    NavigationView {
        SignUpView()
            .background(TColor.background)
    }
}
