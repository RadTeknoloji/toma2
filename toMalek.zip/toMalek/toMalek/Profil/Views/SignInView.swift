//
//  SignInView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct SignInView: View {
    @StateObject private var viewModel = SignInViewModel()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                TColor.background
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: TLayout.spacingXL) {
                        // Logo ve Başlık
                        headerSection
                        
                        // Form
                        VStack(spacing: TLayout.spacingL) {
                            emailFieldSection
                            passwordFieldSection
                        }
                        .padding(.horizontal, TLayout.padding)
                        
                        errorMessageSection
                        signInButtonSection
                        signUpNavigationSection
                    }
                    .padding(.top, TLayout.paddingXL)
                }
            }
            .navigationBarHidden(true)
        }
        .confirmationDialog(
            String(localized: "select_user_type"),
            isPresented: $viewModel.showUserTypeSelection,
            titleVisibility: .visible
        ) {
            userTypeSelectionButtons
        }
        .fullScreenCover(isPresented: $viewModel.isAuthenticated) {
            MainTabView()
                .background(TColor.background)
        }
    }
    
    // MARK: - View Components
    private var headerSection: some View {
        VStack(spacing: TLayout.spacing) {
            Image("LaunchLogo")
                .resizable()
                .scaledToFit()
                .frame(width: TLayout.logoSize, height: TLayout.logoSize)
                .foregroundColor(TColor.areapolPrimary)
            
            Text(String(localized: "welcome_to_tomalek"))
                .font(TFont.h2)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var emailFieldSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(String(localized: "email"))
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
            
            TextField(String(localized: "email_placeholder"), text: $viewModel.email)
                .font(TFont.body)
                .keyboardType(.emailAddress)
                .autocapitalization(.none)
                .padding(TLayout.padding)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
                .overlay(
                    RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                        .stroke(TColor.border, lineWidth: 1)
                )
        }
    }
    
    private var passwordFieldSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(String(localized: "password"))
                .font(TFont.bodyBold)
                .foregroundColor(TColor.textPrimary)
            
            HStack {
                Group {
                    if viewModel.showPassword {
                        TextField("••••••", text: $viewModel.password)
                    } else {
                        SecureField("••••••", text: $viewModel.password)
                    }
                }
                .font(TFont.body)
                
                Button {
                    viewModel.showPassword.toggle()
                } label: {
                    Image(systemName: viewModel.showPassword ? "eye.slash" : "eye")
                        .foregroundColor(TColor.textSecondary)
                }
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .stroke(TColor.border, lineWidth: 1)
            )
        }
    }
    
    private var errorMessageSection: some View {
        Group {
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
        }
    }
    
    private var signInButtonSection: some View {
        VStack(spacing: TLayout.spacing) {
            Button(action: {
                Task { await viewModel.signIn() }
            }) {
                if viewModel.isLoading {
                    ProgressView()
                        .tint(TColor.onPrimary)
                } else {
                    Text(String(localized: "sign_in"))
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.onPrimary)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, TLayout.padding)
            .background(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .fill(viewModel.isValidForm ? TColor.areapolPrimary : TColor.areapolPrimary.opacity(0.5))
            )
            .disabled(!viewModel.isValidForm || viewModel.isLoading)
            
            NavigationLink {
                ForgetPasswordView()
            } label: {
                Text(String(localized: "forgot_password"))
                    .font(TFont.footnoteBold)
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
        .padding(.horizontal, TLayout.padding)
    }
    
    private var signUpNavigationSection: some View {
        NavigationLink {
            SignUpView()
        } label: {
            HStack(spacing: TLayout.spacingXS) {
                Text(String(localized: "no_account"))
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                
                Text(String(localized: "sign_up"))
                    .font(TFont.footnoteBold)
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
        .padding(.vertical, TLayout.paddingL)
    }
    
    private var userTypeSelectionButtons: some View {
        ForEach(Array(viewModel.userTypes), id: \.self) { type in
            Button(type.rawValue) {
                Task {
                    try await viewModel.updateActiveUserType(type)
                }
            }
        }
    }
}

// MARK: - Preview
struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
            .background(TColor.background)
    }
}
