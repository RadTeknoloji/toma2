import SwiftUI
import MapKit

struct AgencyLocationStepView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var locationManager = LocationManager()
    
    @Binding var latitude: Double?
    @Binding var longitude: Double?
    @Binding var formattedAddress: String?
    @Binding var streetAddress: String?
    @Binding var neighborhood: String?
    @Binding var district: String?
    @Binding var city: String?
    @Binding var province: String?
    @Binding var state: String?
    @Binding var country: String?
    @Binding var postalCode: String?
    
    @State private var selectedCoordinate: CLLocationCoordinate2D?
    @State private var mapPosition: MapCameraPosition = .automatic
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            VStack {
                // Search ve Map kısmını ekleyin, LocationStepView'dan benzer şekilde
                searchSection
                mapSection
                locationDetailsSection
                
                Spacer()
            }
            .navigationTitle("Konumu Seç")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Kaydet") {
                        if let details = locationManager.addressDetails,
                           let formattedAddress = locationManager.formattedAddress,
                           !formattedAddress.isEmpty {
                            self.formattedAddress = formattedAddress
                            streetAddress = details.streetAddress
                            neighborhood = details.neighborhood
                            district = details.district
                            city = details.city
                            province = details.province
                            state = details.state
                            country = details.country
                            postalCode = details.postalCode
                            
                            latitude = details.latitude
                            longitude = details.longitude
                            
                            dismiss()
                        }
                    }
                    .disabled(locationManager.addressDetails == nil ||
                              (locationManager.formattedAddress ?? "").isEmpty)
                }
            }
            .onChange(of: locationManager.formattedAddress) { _, newValue in
                print("AgencyLocationStepView - Formatted Address Değişti: \(String(describing: newValue))")
            }
        }
    }
    
    // MARK: - Search Section
    private var searchSection: some View {
        return VStack {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(TColor.textSecondary)
                
                TextField("search_address_placeholder", text: $searchText)
                    .foregroundColor(TColor.textPrimary)
                    .onChange(of: searchText) { _, newValue in
                        locationManager.searchAddress(newValue)
                    }
                
                if !searchText.isEmpty {
                    Button(action: { searchText = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
            .padding(TLayout.spacingS)
            .background(TColor.backgroundDark)
            .cornerRadius(TLayout.cornerRadius)
            
            // Arama sonuçları
            if !searchText.isEmpty && !locationManager.searchResults.isEmpty {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        ForEach(locationManager.searchResults, id: \.self) { result in
                            Button {
                                selectSearchResult(result)
                            } label: {
                                VStack(alignment: .leading) {
                                    Text(result.title)
                                        .font(TFont.footnote)
                                        .foregroundColor(TColor.textPrimary)
                                    Text(result.subtitle)
                                        .font(TFont.caption)
                                        .foregroundColor(TColor.textSecondary)
                                }
                            }
                            Divider()
                        }
                    }
                    .padding(TLayout.spacingS)
                }
                .frame(maxHeight: 200)
            }
        }
    }
    
    // MARK: - Map Section
    private var mapSection: some View {
        MapReader { proxy in
            Map(position: $mapPosition) {
                UserAnnotation()
                if let selectedCoordinate = selectedCoordinate {
                    Annotation("", coordinate: selectedCoordinate) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title)
                            .foregroundColor(TColor.error)
                            .shadow(radius: 2)
                    }
                }
            }
            .mapStyle(.standard(elevation: .realistic))
            .gesture(
                LongPressGesture(minimumDuration: 0.3)
                    .sequenced(before: DragGesture(minimumDistance: 0))
                    .onEnded { value in
                        handleLongPress(value: value, proxy: proxy)
                    }
            )
            .frame(height: 300)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    // MARK: - Location Details Section
    private var locationDetailsSection: some View {
        Group {
            if locationManager.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            } else if let details = locationManager.addressDetails {
                VStack(alignment: .leading, spacing: TLayout.spacingM) {
                    Text("Seçilen Konum")
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                    
                    VStack(alignment: .leading, spacing: TLayout.spacingS) {
                        detailRow("Adres", details.streetAddress)
                        detailRow("Mahalle", details.neighborhood)
                        detailRow("İlçe", details.district)
                        detailRow("Şehir", details.city)
                        detailRow("Bölge", details.province)
                        detailRow("Eyalet", details.state)
                        detailRow("Ülke", details.country)
                        detailRow("Posta Kodu", details.postalCode)
                    }
                    .padding(TLayout.spacingS)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    private func detailRow(_ label: String, _ value: String?) -> some View {
        Group {
            if let value = value {
                HStack {
                    Text(label)
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                    Spacer()
                    Text(value)
                        .font(TFont.footnote)
                }
            }
        }
    }
    
    private func handleLongPress(value: SequenceGesture<LongPressGesture, DragGesture>.Value, proxy: MapProxy) {
        guard case .second(_, let drag) = value,
              let dragLocation = drag?.location,
              let coordinate = proxy.convert(dragLocation, from: .local) else {
            return
        }
        
        selectedCoordinate = coordinate
        
        Task {
            await locationManager.getAddressFromLocation(coordinate)
        }
    }
    
    private func selectSearchResult(_ result: MKLocalSearchCompletion) {
        locationManager.selectSearchResult(result)
        searchText = ""
    }
}
