//
//  ExpenseModel.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation

struct ExpenseModel: Codable, Identifiable, Hashable {
    let id: UUID
    let propertyId: UUID
    let userId: String          // Firebase UID olduğu için String
    let userType: UserType      // ProfilModel'deki UserType enum'ını kullanıyoruz
    let fullName: String
    
    var expenseCategory: ExpenseCategory
    var expenseStatus: ExpenseStatus
    var expenseAmount: Double
    var currency: CurrencyType
    var paymentMethod: PaymentMethod
    var expenseDescription: String?
    var mediaUrls: [String]
    var createdDate: Date
    var paidDate: Date?
    

    // Hashable için gerekli metodlar
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: ExpenseModel, rhs: ExpenseModel) -> Bool {
        lhs.id == rhs.id
    }
}
