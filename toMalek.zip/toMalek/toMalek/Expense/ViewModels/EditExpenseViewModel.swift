//
//  EditExpenseViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import PhotosUI

@MainActor
final class EditExpenseViewModel: ObservableObject {
    // MARK: - Services
    private let expenseService: ExpenseService
    private let propertyService: PropertyService
    private let mediaService: MediaService

    // MARK: - Published Properties
    @Published var selectedProperty: PropertyModel?
    @Published var expenseCategory: ExpenseCategory
    @Published var expenseStatus: ExpenseStatus
    @Published var expenseAmount: String
    @Published var currency: CurrencyType
    @Published var paymentMethod: PaymentMethod
    @Published var expenseDescription: String
    
    // Media Properties
    @Published var imageSelections: [PhotosPickerItem] = []
    @Published var selectedImages: [UIImage] = []
    @Published var existingMediaUrls: [String]
    @Published var deletedMediaUrls: Set<String> = []
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    
    // MARK: - Properties
    private let expense: ExpenseModel
    @Published var properties: [PropertyModel] = []

    // MARK: - Validation Properties
    var isValidForm: Bool {
        selectedProperty != nil &&
        !expenseAmount.isEmpty &&
        isValidAmount &&
        !expenseDescription.isEmpty
    }
    
    private var isValidAmount: Bool {
        if let amount = Double(expenseAmount.replacingOccurrences(of: ",", with: ".")) {
            return amount > 0
        }
        return false
    }
    
    var photoLabelText: String {
        if selectedImages.isEmpty {
            return String(localized: "edit_expense_add_photo")
        } else {
            return String(format: String(localized: "edit_expense_photos_selected"), selectedImages.count)
        }
    }
    
    // MARK: - Initialization
    init(expense: ExpenseModel,
         expenseService: ExpenseService = ServiceContainer.shared.expenseService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.expense = expense
        self.expenseService = expenseService
        self.propertyService = propertyService
        self.mediaService = mediaService
        
        // Initialize published properties
        self.expenseCategory = expense.expenseCategory
        self.expenseStatus = expense.expenseStatus
        self.expenseAmount = "\(expense.expenseAmount)"
        self.currency = expense.currency
        self.paymentMethod = expense.paymentMethod
        self.expenseDescription = expense.expenseDescription ?? ""
        self.existingMediaUrls = expense.mediaUrls
        
        // Fetch properties
        Task { await fetchProperties() }
    }
    
    // MARK: - Methods
    func loadImages() async {
        for selection in imageSelections {
            do {
                guard let data = try await selection.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { continue }
                selectedImages.append(image)
            } catch {
                print("Error loading image: \(error)")
            }
        }
    }
    
    func uploadNewImages() async throws -> [String] {
        var urls: [String] = []
        
        for image in selectedImages {
            guard let imageData = image.jpegData(compressionQuality: 0.7) else { continue }
            
            let media = MediaModel(
                id: UUID(),
                propertyId: selectedProperty?.id ?? UUID(),
                mediaType: .image,
                url: "",
                createdDate: Date(),
                fileSize: imageData.count,
                fileExtension: "jpg"
            )
            
            try await mediaService.uploadMedia(media, data: imageData)
            
            if let uploadedMedia = try await mediaService.fetchMedia(id: media.id.uuidString) {
                urls.append(uploadedMedia.url)
            }
        }
        
        return urls
    }
    
    func save() async {
        guard isValidForm else {
            errorMessage = String(localized: "edit_expense_error_required_fields")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            // Upload new images if any
            let newMediaUrls = try await uploadNewImages()
            
            // Combine existing (not deleted) and new media URLs
            let finalMediaUrls = existingMediaUrls.filter { !deletedMediaUrls.contains($0) } + newMediaUrls
            
            let updatedExpense = ExpenseModel(
                id: expense.id,
                propertyId: selectedProperty?.id ?? expense.propertyId,
                userId: expense.userId,
                userType: expense.userType,
                fullName: expense.fullName,
                expenseCategory: expenseCategory,
                expenseStatus: expenseStatus,
                expenseAmount: Double(expenseAmount.replacingOccurrences(of: ",", with: ".")) ?? 0,
                currency: currency,
                paymentMethod: paymentMethod,
                expenseDescription: expenseDescription,
                mediaUrls: finalMediaUrls,
                createdDate: expense.createdDate,
                paidDate: expenseStatus == .paid ? (expense.paidDate ?? Date()) : nil
            )
            
            try await expenseService.updateExpense(updatedExpense)
            isSuccessful = true
            
        } catch {
            errorMessage = String(localized: "edit_expense_error_updating")
            isSuccessful = false
        }
        
        isLoading = false
    }
    
    // MARK: - Private Methods
    private func fetchProperties() async {
        isLoading = true
        do {
            properties = try await propertyService.fetchProperties()
            // Find and set the selected property
            self.selectedProperty = properties.first { $0.id == expense.propertyId }
        } catch {
            errorMessage = String(localized: "edit_expense_error_loading_properties")
        }
        isLoading = false
    }
    
    func removeExistingMedia(at url: String) {
        deletedMediaUrls.insert(url)
    }
}
