//
//  AddExpenseViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import PhotosUI
import FirebaseAuth

@MainActor
final class AddExpenseViewModel: ObservableObject {
    // MARK: - Services
    private let expenseService: ExpenseService
    private let propertyService: PropertyService
    private let mediaService: MediaService
    @ObservedObject private var authState: AuthenticationState

    
    
    // MARK: - Published Properties
    @Published var selectedProperty: PropertyModel?
    @Published var expenseCategory: ExpenseCategory = .dues
    @Published var expenseStatus: ExpenseStatus = .unpaid
    @Published var expenseAmount = ""
    @Published var currency: CurrencyType = .try
    @Published var paymentMethod: PaymentMethod = .bankTransfer
    @Published var expenseDescription = ""
    
    
    // Media Properties
    @Published var imageSelections: [PhotosPickerItem] = []
    @Published var selectedImages: [UIImage] = []
    @Published var mediaUrls: [String] = []
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    
    @Published var properties: [PropertyModel] = []
    
    // MARK: - Validation Properties
    var isValidForm: Bool {
        selectedProperty != nil &&
        !expenseAmount.isEmpty &&
        isValidAmount &&
        !expenseDescription.isEmpty
    }
    
    private var isValidAmount: Bool {
        if let amount = Double(expenseAmount.replacingOccurrences(of: ",", with: ".")) {
            return amount > 0
        }
        return false
    }
    
    var selectedImagesCount: String {
        if selectedImages.isEmpty {
            return String(localized: "add_expense_add_photo")
        }
        return String(format: String(localized: "add_expense_photos_selected"), selectedImages.count)
    }
    
    var photoLabelText: String {
        if selectedImages.isEmpty {
            return String(localized: "add_expense_add_photo")
        } else {
            return String(format: String(localized: "add_expense_photos_selected"), selectedImages.count)
        }
    }
    
    // MARK: - Initialization
    init(expenseService: ExpenseService = ServiceContainer.shared.expenseService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.expenseService = expenseService
        self.propertyService = propertyService
        self.mediaService = mediaService
        self.authState = AuthenticationState.shared
        Task { await fetchProperties() }
    }

    
    // MARK: - Methods
    func fetchProperties() async {
        isLoading = true
        do {
            properties = try await propertyService.fetchProperties()
        } catch {
            errorMessage = String(localized: "add_expense_error_loading_properties")
            print("Error fetching properties: \(error)")
        }
        isLoading = false
    }
    
    func loadImages() async {
        for selection in imageSelections {
            do {
                guard let data = try await selection.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { continue }
                selectedImages.append(image)
            } catch {
                print("Error loading image: \(error)")
            }
        }
    }
    
    func uploadImages() async throws -> [String] {
        var urls: [String] = []
        
        for image in selectedImages {
            guard let imageData = image.jpegData(compressionQuality: 0.7) else { continue }
            
            let media = MediaModel(
                id: UUID(),
                propertyId: selectedProperty?.id ?? UUID(),
                mediaType: .image,
                url: "",
                createdDate: Date(),
                fileSize: imageData.count,
                fileExtension: "jpg"
            )
            
            try await mediaService.uploadMedia(media, data: imageData)
            
            if let uploadedMedia = try await mediaService.fetchMedia(id: media.id.uuidString) {
                urls.append(uploadedMedia.url)
            }
        }
        
        return urls
    }
    
    func save() async {
        guard isValidForm else {
            errorMessage = String(localized: "add_expense_error_required_fields")
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        do {
            // Önce medyaları yükle
            let mediaUrls = try await uploadImages()
            
            let expense = ExpenseModel(
                id: UUID(),
                propertyId: selectedProperty!.id,
                userId: Auth.auth().currentUser?.uid ?? "",
                userType: UserType(rawValue: authState.userType) ?? .tenant,
                fullName: authState.fullName,
                expenseCategory: expenseCategory,
                expenseStatus: expenseStatus,
                expenseAmount: Double(expenseAmount.replacingOccurrences(of: ",", with: ".")) ?? 0,
                currency: currency,
                paymentMethod: paymentMethod,
                expenseDescription: expenseDescription,
                mediaUrls: mediaUrls,
                createdDate: Date(),
                paidDate: expenseStatus == .paid ? Date() : nil
            )
            
            try await expenseService.createExpense(expense)
            isSuccessful = true
            
        } catch {
            errorMessage = String(localized: "add_expense_error_saving")
            print("Error creating expense: \(error)")
            isSuccessful = false
        }
        
        isLoading = false
    }
    
    func resetForm() {
        selectedProperty = nil
        expenseCategory = .dues
        expenseStatus = .unpaid
        expenseAmount = ""
        currency = .try
        paymentMethod = .bankTransfer
        expenseDescription = ""
        imageSelections = []
        selectedImages = []
        mediaUrls = []
        errorMessage = nil
        isLoading = false
        isSuccessful = false
    }
}
