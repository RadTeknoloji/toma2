//
//  ExpenseDetailViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI

@MainActor
final class ExpenseDetailViewModel: ObservableObject {
    // MARK: - Services
    private let expenseService: ExpenseService
    private let propertyService: PropertyService

    // MARK: - Published Properties
    @Published var expense: ExpenseModel
    @Published var property: PropertyModel?
    @Published var showEditExpense = false
    @Published var showDeleteAlert = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isDeleted = false
    
    // MARK: - Computed Properties
    var propertyText: String {
        property?.title ?? String(localized: "expense_detail_property_not_found")
    }
    
    var statusColor: Color {
        switch expense.expenseStatus {
        case .paid: return .green
        case .unpaid: return .red
        }
    }
    
    var statusText: String {
        switch expense.expenseStatus {
        case .paid: return String(localized: "expense_status_paid")
        case .unpaid: return String(localized: "expense_status_unpaid")
        }
    }
    
    var userTypeText: String {
        switch expense.userType {
        case .owner: return String(localized: "user_type_owner")
        case .tenant: return String(localized: "user_type_tenant")
        case .agency: return String(localized: "user_type_agency")
        }
    }
    
    var categoryIcon: String {
        switch expense.expenseCategory {
        case .dues: return "building.2"
        case .bill: return "doc.text"
        case .maintenance: return "wrench.and.screwdriver"
        case .renovation: return "hammer"
        case .tax: return "percent"
        case .penalty: return "exclamationmark.triangle"
        case .insurance: return "checkmark.shield"
        case .other: return "ellipsis.circle"
        }
    }
    
    var paymentIcon: String {
        switch expense.paymentMethod {
        case .cash: return "banknote"
        case .bankTransfer: return "building.columns"
        case .creditCard: return "creditcard"
        case .other: return "ellipsis.circle"
        }
    }
    
    // MARK: - Initialization
    init(expense: ExpenseModel,
         expenseService: ExpenseService = ServiceContainer.shared.expenseService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.expense = expense
        self.expenseService = expenseService
        self.propertyService = propertyService
        
        Task { await fetchProperty() }
    }
    
    // MARK: - Methods
    func deleteExpense() async {
        isLoading = true
        errorMessage = nil
        
        do {
            try await expenseService.deleteExpense(id: expense.id.uuidString)
            isDeleted = true
        } catch {
            errorMessage = String(localized: "expense_detail_error_deleting")
        }
        
        isLoading = false
    }
    
    func markAsPaid() async {
        isLoading = true
        errorMessage = nil
        
        do {
            var updatedExpense = expense
            updatedExpense.expenseStatus = .paid
            updatedExpense.paidDate = Date()
            
            try await expenseService.updateExpense(updatedExpense)
            expense = updatedExpense
        } catch {
            errorMessage = String(localized: "expense_detail_error_updating_status")
        }
        
        isLoading = false
    }
    
    // MARK: - Private Methods
    private func fetchProperty() async {
        isLoading = true
        do {
            print("Fetching property with ID: \(expense.propertyId.uuidString)")
            property = try await propertyService.fetchProperty(id: expense.propertyId.uuidString)
            print("Property fetched successfully: \(String(describing: property))")
        } catch {
            print("Error fetching property: \(error)")
            errorMessage = String(localized: "expense_detail_error_loading_property")
        }
        isLoading = false
    }
}
