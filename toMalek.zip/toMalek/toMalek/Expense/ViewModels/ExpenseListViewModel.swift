//
//  ExpenseListViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation

@MainActor
final class ExpenseListViewModel: ObservableObject {
    // MARK: - Services
    private let expenseService: ExpenseService
    private let propertyService: PropertyService
    
    // MARK: - Published Properties
    @Published var expenses: [ExpenseModel] = []
    @Published var properties: [PropertyModel] = []
    @Published var selectedProperty: PropertyModel? = nil
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    
    
    
    // MARK: - Computed Properties
    var filteredExpenses: [ExpenseModel] {
        guard let selectedProperty = selectedProperty else {
            return expenses // selectedProperty nil ise tüm giderleri göster
        }
        return expenses.filter { $0.propertyId == selectedProperty.id }
    }
    
    var totalAmount: Double {
        filteredExpenses.reduce(0) { $0 + $1.expenseAmount }
    }
    
    var paidAmount: Double {
        filteredExpenses
            .filter { $0.expenseStatus == .paid }
            .reduce(0) { $0 + $1.expenseAmount }
    }
    
    var unpaidAmount: Double {
        filteredExpenses
            .filter { $0.expenseStatus != .paid }
            .reduce(0) { $0 + $1.expenseAmount }
    }
    
    // MARK: - Initialization
    init(expenseService: ExpenseService = ServiceContainer.shared.expenseService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.expenseService = expenseService
        self.propertyService = propertyService
    }
    
    // MARK: - Methods
    func fetchExpenses() async {
        isLoading = true
        errorMessage = nil
        
        do {
            // Fetch properties and existing expenses
            let fetchedProperties = try await propertyService.fetchProperties()
            self.properties = fetchedProperties
            
            let fetchedExpenses = try await expenseService.fetchExpenses()
            self.expenses = fetchedExpenses
            
            // Otomatik seçim yapan kısmı kaldırdık
            
        } catch {
            errorMessage = String(localized: "expense_list_error_loading_data")
            print("Error:", error.localizedDescription)
        }
        
        isLoading = false
    }
    
    func refreshList() async {
        await fetchExpenses()
    }
    
    func deleteExpense(_ expense: ExpenseModel) async {
        do {
            try await expenseService.deleteExpense(id: expense.id.uuidString)
            
            // Remove the expense from the local array
            if let index = expenses.firstIndex(where: { $0.id == expense.id }) {
                expenses.remove(at: index)
            }
        } catch {
            errorMessage = String(localized: "expense_list_error_deleting")
            print("Error deleting expense:", error.localizedDescription)
        }
    }
}
