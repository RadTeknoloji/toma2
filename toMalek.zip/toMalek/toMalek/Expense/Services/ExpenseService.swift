//
//  ExpenseService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseFirestore

protocol ExpenseService {
    // Create
    func createExpense(_ expense: ExpenseModel) async throws
    
    // Read
    func fetchExpenses() async throws -> [ExpenseModel]
    func fetchExpense(id: String) async throws -> ExpenseModel?
    func fetchExpenses(forProperty propertyId: String) async throws -> [ExpenseModel]
    
    // Update
    func updateExpense(_ expense: ExpenseModel) async throws
    func updateExpenseStatus(_ expense: ExpenseModel, to status: ExpenseStatus) async throws
    
    // Delete
    func deleteExpense(id: String) async throws
    
    // Filter & Stats
    func filterExpenses(by category: ExpenseCategory) async throws -> [ExpenseModel]
    func filterExpenses(by status: ExpenseStatus) async throws -> [ExpenseModel]
    func calculateTotalExpenses(forProperty propertyId: String) async throws -> Double
    func calculateMonthlyExpenses(forMonth date: Date) async throws -> Double
}

// MARK: - Expense Errors
enum ExpenseError: LocalizedError {
    case invalidData
    case notFound
    case invalidProperty
    case unauthorized
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "expense_error_invalid_data")
        case .notFound:
            return String(localized: "expense_error_not_found")
        case .invalidProperty:
            return String(localized: "expense_error_invalid_property")
        case .unauthorized:
            return String(localized: "expense_error_unauthorized")
        case .unknown:
            return String(localized: "expense_error_unknown")
        }
    }
}
