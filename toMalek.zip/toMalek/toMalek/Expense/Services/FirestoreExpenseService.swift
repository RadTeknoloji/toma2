//
//  FirestoreExpenseService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//


import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

final class FirestoreExpenseService: ExpenseService {
    private let db = Firestore.firestore()
    private let collection = "expenses"
    private let propertyService: PropertyService
    
    // MARK: - Helper Properties
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // MARK: - Initialization
    init(propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.propertyService = propertyService
    }
    
    // MARK: - Create
    func createExpense(_ expense: ExpenseModel) async throws {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        // Validate property exists and belongs to user
        let propertyExists = try await propertyService.fetchProperty(id: expense.propertyId.uuidString) != nil
        guard propertyExists else {
            throw ExpenseError.invalidProperty
        }
        
        let expenseRef = db.collection(collection).document(expense.id.uuidString)
        
        let data: [String: Any] = [
            "id": expense.id.uuidString,
            "userId": userId,
            "propertyId": expense.propertyId.uuidString,
            "expenseCategory": expense.expenseCategory.rawValue,
            "expenseStatus": expense.expenseStatus.rawValue,
            "expenseAmount": expense.expenseAmount,
            "currency": expense.currency.rawValue,
            "paymentMethod": expense.paymentMethod.rawValue,
            "createdDate": expense.createdDate,
            "expenseDescription": expense.expenseDescription as Any,
            "mediaUrls": expense.mediaUrls,
            "paidDate": expense.paidDate as Any? ?? NSNull(), // Null veya tarih olarak ekle
            "createdAt": FieldValue.serverTimestamp()
        ]
        
        try await expenseRef.setData(data)
    }
    
    // MARK: - Read
    func fetchExpenses() async throws -> [ExpenseModel] {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeExpense(from: document)
        }
    }
    
    func fetchExpense(id: String) async throws -> ExpenseModel? {
        let document = try await db.collection(collection).document(id).getDocument()
        guard document.exists else { return nil }
        return try decodeExpense(from: document)
    }
    
    func fetchExpenses(forProperty propertyId: String) async throws -> [ExpenseModel] {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("propertyId", isEqualTo: propertyId)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeExpense(from: document)
        }
    }
    
    // MARK: - Update
    func updateExpense(_ expense: ExpenseModel) async throws {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        // Check if expense belongs to current user
        let document = try await db.collection(collection).document(expense.id.uuidString).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw ExpenseError.unauthorized
        }
        
        let expenseRef = db.collection(collection).document(expense.id.uuidString)
        
        let data: [String: Any] = [
            "id": expense.id.uuidString,
            "userId": userId,
            "propertyId": expense.propertyId.uuidString,
            "userType": expense.userType.rawValue,     // Eklendi
            "fullName": expense.fullName,              // Eklendi
            "expenseCategory": expense.expenseCategory.rawValue,
            "expenseStatus": expense.expenseStatus.rawValue,
            "expenseAmount": expense.expenseAmount,
            "currency": expense.currency.rawValue,
            "paymentMethod": expense.paymentMethod.rawValue,
            "createdDate": expense.createdDate,
            "expenseDescription": expense.expenseDescription as Any,
            "mediaUrls": expense.mediaUrls,
            "paidDate": expense.paidDate as Any? ?? NSNull(),
            "createdAt": FieldValue.serverTimestamp()
        ]
        try await expenseRef.updateData(data)
    }
    
    func updateExpenseStatus(_ expense: ExpenseModel, to status: ExpenseStatus) async throws {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let expenseRef = db.collection(collection).document(expense.id.uuidString)
        let document = try await expenseRef.getDocument()
        
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw ExpenseError.unauthorized
        }
        
        try await expenseRef.updateData([
            "expenseStatus": status.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ])
    }
    
    // MARK: - Delete
    func deleteExpense(id: String) async throws {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        // Check if expense belongs to current user
        let document = try await db.collection(collection).document(id).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw ExpenseError.unauthorized
        }
        
        try await db.collection(collection).document(id).delete()
    }
    
    // MARK: - Filter & Stats
    func filterExpenses(by category: ExpenseCategory) async throws -> [ExpenseModel] {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("expenseCategory", isEqualTo: category.rawValue)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeExpense(from: document)
        }
    }
    
    func filterExpenses(by status: ExpenseStatus) async throws -> [ExpenseModel] {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("expenseStatus", isEqualTo: status.rawValue)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeExpense(from: document)
        }
    }
    
    func calculateTotalExpenses(forProperty propertyId: String) async throws -> Double {
        let expenses = try await fetchExpenses(forProperty: propertyId)
        return expenses.reduce(0) { $0 + $1.expenseAmount }
    }
    
    func calculateMonthlyExpenses(forMonth date: Date) async throws -> Double {
        guard let userId = currentUserId else {
            throw ExpenseError.unauthorized
        }
        
        let calendar = Calendar.current
        let startOfMonth = calendar.startOfMonth(for: date)
        let endOfMonth = calendar.endOfMonth(for: date)
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("createdDate", isGreaterThanOrEqualTo: startOfMonth)
            .whereField("createdDate", isLessThanOrEqualTo: endOfMonth)
            .getDocuments()
        
        let expenses = try snapshot.documents.compactMap { document in
            try decodeExpense(from: document)
        }
        
        return expenses.reduce(0) { $0 + $1.expenseAmount }
    }
    
    // MARK: - Helper Methods
    private func decodeExpense(from document: DocumentSnapshot) throws -> ExpenseModel {
        guard let data = document.data() else {
            throw ExpenseError.invalidData
        }
        
        return ExpenseModel(
            id: UUID(uuidString: data["id"] as? String ?? "") ?? UUID(),
            propertyId: UUID(uuidString: data["propertyId"] as? String ?? "") ?? UUID(),
            userId: data["userId"] as? String ?? "",
            userType: UserType(rawValue: data["userType"] as? String ?? "") ?? .tenant,
            fullName: data["fullName"] as? String ?? "",
            expenseCategory: ExpenseCategory(rawValue: data["expenseCategory"] as? String ?? "") ?? .other,
            expenseStatus: ExpenseStatus(rawValue: data["expenseStatus"] as? String ?? "") ?? .unpaid,
            expenseAmount: data["expenseAmount"] as? Double ?? 0,
            currency: CurrencyType(rawValue: data["currency"] as? String ?? "") ?? .try,
            paymentMethod: PaymentMethod(rawValue: data["paymentMethod"] as? String ?? "") ?? .other,
            expenseDescription: data["expenseDescription"] as? String,
            mediaUrls: (data["mediaUrls"] as? [String]) ?? [],
            createdDate: (data["createdDate"] as? Timestamp)?.dateValue() ?? Date(),
            paidDate: (data["paidDate"] as? Timestamp)?.dateValue()
        )
    }
}

// MARK: - Calendar Extensions
private extension Calendar {
    func startOfMonth(for date: Date) -> Date {
        let components = dateComponents([.year, .month], from: date)
        return self.date(from: components) ?? date
    }
    
    func endOfMonth(for date: Date) -> Date {
        var components = DateComponents()
        components.month = 1
        components.second = -1
        return self.date(byAdding: components, to: startOfMonth(for: date)) ?? date
    }
}
