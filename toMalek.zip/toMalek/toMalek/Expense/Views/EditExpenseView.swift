//
//  EditExpenseView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct EditExpenseView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: EditExpenseViewModel
    
    init(expense: ExpenseModel) {
        _viewModel = StateObject(wrappedValue: EditExpenseViewModel(expense: expense))
    }
    
    var body: some View {
        NavigationView {
            Form {
                propertySelectionSection
                expenseDetailsSection
                existingMediaSection
                newMediaSection
            }
            .background(TColor.surface)
            .navigationTitle(String(localized: "edit_expense_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "edit_expense_cancel")) {
                        dismiss()
                    }
                    .foregroundColor(TColor.areapolPrimary)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(String(localized: "edit_expense_save")) {
                        Task { await viewModel.save() }
                    }
                    .font(TFont.bodyBold)
                    .foregroundColor(viewModel.isValidForm ? TColor.areapolPrimary : TColor.surfaceDark)
                    .disabled(!viewModel.isValidForm || viewModel.isLoading)
                }
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                        .tint(TColor.areapolPrimary)
                }
            }
            .onChange(of: viewModel.imageSelections) { _, _ in
                Task { await viewModel.loadImages() }
            }
            .onChange(of: viewModel.isSuccessful) { _, newValue in
                if newValue { dismiss() }
            }
            .alert(
                String(localized: "edit_expense_error_title"),
                isPresented: .constant(viewModel.errorMessage != nil),
                actions: {
                    Button(String(localized: "edit_expense_ok"), role: .cancel) {
                        viewModel.errorMessage = nil
                    }
                },
                message: {
                    if let error = viewModel.errorMessage {
                        Text(error)
                            .font(TFont.body)
                    }
                }
            )
        }
    }
    
    // MARK: - Section Views
    private var propertySelectionSection: some View {
        Section {
            Picker(String(localized: "edit_expense_property"), selection: $viewModel.selectedProperty) {
                Text(String(localized: "edit_expense_select"))
                    .tag(Optional<PropertyModel>.none)
                
                ForEach(viewModel.properties) { property in
                    Text(property.title)
                        .tag(Optional(property))
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
        } header: {
            Text(String(localized: "edit_expense_property_section"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var expenseDetailsSection: some View {
        Section {
            Picker(String(localized: "edit_expense_category"), selection: $viewModel.expenseCategory) {
                ForEach(ExpenseCategory.allCases, id: \.self) { category in
                    Label(category.rawValue, systemImage: categoryIcon(for: category))
                        .tag(category)
                        .font(TFont.body)
                }
            }
            
            Picker(String(localized: "edit_expense_status"), selection: $viewModel.expenseStatus) {
                ForEach(ExpenseStatus.allCases, id: \.self) { status in
                    Text(status.rawValue)
                        .tag(status)
                        .font(TFont.body)
                }
            }
            
            HStack {
                TextField(String(localized: "edit_expense_amount"), text: $viewModel.expenseAmount)
                    .keyboardType(.decimalPad)
                    .font(TFont.body)
                
                Picker("", selection: $viewModel.currency) {
                    ForEach(CurrencyType.allCases, id: \.self) { currency in
                        Text(currency.symbol)
                            .tag(currency)
                            .font(TFont.body)
                    }
                }
                .frame(width: 100)
            }
            
            Picker(String(localized: "edit_expense_payment_method"), selection: $viewModel.paymentMethod) {
                ForEach(PaymentMethod.allCases, id: \.self) { method in
                    Label(method.rawValue.capitalized, systemImage: paymentIcon(for: method))
                        .tag(method)
                        .font(TFont.body)
                }
            }
            
            TextField(String(localized: "edit_expense_description"), text: $viewModel.expenseDescription, axis: .vertical)
                .lineLimit(3...5)
                .font(TFont.body)
        } header: {
            Text(String(localized: "edit_expense_details_section"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var existingMediaSection: some View {
        Section {
            if !viewModel.existingMediaUrls.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: TLayout.spacingS) {
                        ForEach(viewModel.existingMediaUrls.filter { !viewModel.deletedMediaUrls.contains($0) }, id: \.self) { url in
                            VStack {
                                AsyncImage(url: URL(string: url)) { phase in
                                    switch phase {
                                    case .empty:
                                        ProgressView()
                                            .tint(TColor.areapolPrimary)
                                    case .success(let image):
                                        image
                                            .resizable()
                                            .scaledToFill()
                                    case .failure:
                                        Image(systemName: "photo.fill")
                                            .foregroundColor(TColor.textSecondary)
                                    @unknown default:
                                        EmptyView()
                                    }
                                }
                                .frame(width: 100, height: 100)
                                .clipShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                                
                                Button(role: .destructive) {
                                    viewModel.removeExistingMedia(at: url)
                                } label: {
                                    Image(systemName: "trash.fill")
                                        .foregroundColor(TColor.error)
                                }
                            }
                        }
                    }
                    .padding(.vertical, TLayout.paddingXXS)
                }
            }
        } header: {
            Text(String(localized: "edit_expense_existing_photos"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var newMediaSection: some View {
        Section {
            PhotosPicker(
                selection: $viewModel.imageSelections,
                maxSelectionCount: 5,
                matching: .images
            ) {
                photoPickerLabel
            }
        } header: {
            Text(String(localized: "edit_expense_new_photos"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    // MARK: - Components
    @ViewBuilder
    private var photoPickerLabel: some View {
        Label {
            Text(viewModel.photoLabelText)
                .font(TFont.body)
                .foregroundColor(TColor.areapolPrimary)
        } icon: {
            Image(systemName: "photo.on.rectangle.angled")
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    // MARK: - Helper Methods
    private func categoryIcon(for category: ExpenseCategory) -> String {
        switch category {
        case .dues: return "building.2"
        case .bill: return "doc.text"
        case .maintenance: return "wrench.and.screwdriver"
        case .renovation: return "hammer"
        case .tax: return "percent"
        case .penalty: return "exclamationmark.triangle"
        case .insurance: return "checkmark.shield"
        case .other: return "ellipsis.circle"
        }
    }
    
    private func paymentIcon(for method: PaymentMethod) -> String {
        switch method {
        case .cash: return "banknote"
        case .bankTransfer: return "building.columns"
        case .creditCard: return "creditcard"
        case .other: return "ellipsis.circle"
        }
    }
}

struct EditExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            EditExpenseView(expense: ExpenseModel(
                id: UUID(),
                propertyId: UUID(),
                userId: "preview-user-id",
                userType: .owner,
                fullName: "Preview User",
                expenseCategory: .maintenance,
                expenseStatus: .unpaid,
                expenseAmount: 1500,
                currency: .try,
                paymentMethod: .bankTransfer,
                expenseDescription: "Örnek gider açıklaması",
                mediaUrls: [],
                createdDate: Date(),
                paidDate: nil
            ))
            .background(TColor.background)
        }
    }
}
