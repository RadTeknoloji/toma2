//
//  ExpenseListView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct ExpenseListView: View {
    @StateObject private var viewModel = ExpenseListViewModel()
    
    var body: some View {
        VStack(spacing: TLayout.spacing) {
            propertyPickerSection
                .padding(TLayout.padding)
            
            summaryCardsSection(for: viewModel.selectedProperty)
                .padding(.horizontal, TLayout.padding)
                .padding(.bottom, TLayout.padding)
            
            expensesTableSection
                .padding(.horizontal, TLayout.padding)
            
            Spacer()
        }
        .background(TColor.background)
        .navigationTitle(String(localized: "expenses_title"))
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: addButton)
        .task { await viewModel.fetchExpenses() }
        .refreshable { await viewModel.refreshList() }
        .overlay { loadingOverlay }
        .alert("Hata", isPresented: .constant(viewModel.errorMessage != nil), actions: alertActions)
    }
    
    // MARK: - Components
    private var propertyPickerSection: some View {
        VStack(spacing: TLayout.spacingS) {
            Menu {
                // Önce "Tümü" seçeneği
                Button {
                    viewModel.selectedProperty = nil // nil yaparak tümünü seçmiş oluyoruz
                } label: {
                    HStack {
                        Text(String(localized: "expenses_all"))
                            .font(TFont.body)
                        if viewModel.selectedProperty == nil {
                            Image(systemName: "checkmark")
                                .foregroundColor(TColor.areapolPrimary)
                        }
                    }
                }
                
                // Sonra diğer mülkler
                ForEach(viewModel.properties) { property in
                    Button {
                        viewModel.selectedProperty = property
                    } label: {
                        HStack {
                            Text(property.title)
                                .font(TFont.body)
                            if viewModel.selectedProperty?.id == property.id {
                                Image(systemName: "checkmark")
                                    .foregroundColor(TColor.areapolPrimary)
                            }
                        }
                    }
                }
            } label: {
                HStack {
                    Image(systemName: "building.2.fill")
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Text(viewModel.selectedProperty?.title ?? String(localized: "expenses_all"))
                        .font(TFont.bodyBold)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.down")
                        .foregroundColor(TColor.areapolPrimary)
                }
                .padding(TLayout.padding)
                .frame(maxWidth: .infinity)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
            }
        }
    }
    
    private func summaryCardsSection(for property: PropertyModel?) -> some View {
        HStack(spacing: TLayout.spacingM) {
            SummaryCard(
                title: String(localized: "expenses_total"),
                value: "\(viewModel.totalAmount.formatted()) ₺",
                icon: "banknote.fill",
                color: TColor.areapolPrimary
            )
            
            SummaryCard(
                title: String(localized: "expenses_paid"),
                value: "\(viewModel.paidAmount.formatted()) ₺",
                icon: "checkmark.circle.fill",
                color: TColor.success
            )
            
            SummaryCard(
                title: String(localized: "expenses_unpaid"),
                value: "\(viewModel.unpaidAmount.formatted()) ₺",
                icon: "exclamationmark.circle.fill",
                color: TColor.error
            )
        }
    }
    
    private var expensesTableSection: some View {
        VStack(spacing: 0) {
            tableHeader
            
            if viewModel.filteredExpenses.isEmpty {
                ContentUnavailableView(
                    "Gider Bulunamadı",
                    systemImage: "doc.text.magnifyingglass",
                    description: Text("Henüz gider eklenmemiş")
                )
                .padding()
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(viewModel.filteredExpenses) { expense in
                            NavigationLink {
                                ExpenseDetailView(expense: expense)
                            } label: {
                                expenseRow(expense)
                                    .background(TColor.surface)
                            }
                            
                            Divider()
                                .background(TColor.textSecondary.opacity(0.1))
                        }
                    }
                }
            }
        }
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
    }
    
    private var tableHeader: some View {
        HStack {
            Text(String(localized: "expenses_category"))
                .frame(width: 100, alignment: .leading)
            Text(String(localized: "expenses_amount"))
                .frame(width: 100)
            Text(String(localized: "expenses_date"))
                .frame(width: 100)
            Text(String(localized: "expenses_status"))
                .frame(maxWidth: .infinity)
        }
        .font(TFont.footnote)
        .foregroundColor(TColor.textSecondary)
        .padding(.horizontal)
        .padding(.vertical, TLayout.paddingXS)
        .background(TColor.background)
    }
    
    private func expenseRow(_ expense: ExpenseModel) -> some View {
        HStack {
            VStack(alignment: .leading) {
                Image(systemName: categoryIcon(for: expense.expenseCategory))
                    .foregroundColor(TColor.info)
                Text(expense.expenseCategory.localized)
                    .font(TFont.footnote)
            }
            .frame(width: 100, alignment: .leading)
            
            Text("\(expense.expenseAmount.formatted()) ₺")
                .font(TFont.body)
                .frame(width: 100)
            
            Text(expense.createdDate.formatted(.dateTime.month().day()))
                .font(TFont.body)
                .frame(width: 80) 
            
            ExpenseStatusBadge(status: expense.expenseStatus)
                .frame(width: 80)
        }
        .padding(.horizontal)
        .padding(.vertical, TLayout.paddingXS)
    }
    
    // MARK: - Helper Views
    private var emptyStateView: some View {
        ContentUnavailableView(
            "Mülk Seçiniz",
            systemImage: "building.2",
            description: Text("Giderleri görüntülemek için mülk seçin")
        )
        .foregroundColor(TColor.textSecondary)
    }
    
    private var addButton: some View {
        NavigationLink(destination: AddExpenseView()) {
            Image(systemName: "plus")
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
    }
    
    private func alertActions() -> some View {
        Group {
            Button("Tamam", role: .cancel) {
                viewModel.errorMessage = nil
            }
        }
    }
    
    private func categoryIcon(for category: ExpenseCategory) -> String {
        switch category {
        case .dues: return "building.2"
        case .bill: return "doc.text"
        case .maintenance: return "wrench.and.screwdriver"
        case .renovation: return "hammer"
        case .tax: return "percent"
        case .penalty: return "exclamationmark.triangle"
        case .insurance: return "checkmark.shield"
        case .other: return "ellipsis.circle"
        }
    }
}

// MARK: - Status Badge
struct ExpenseStatusBadge: View {
    let status: ExpenseStatus
    
    var body: some View {
        Text(statusText)
            .font(TFont.caption) // Daha küçük font
            .foregroundColor(statusColor) // Metin rengi
            .padding(.horizontal, 8) // Yatay padding'i azalttık
            .padding(.vertical, 4) // Dikey padding'i azalttık
            .background(
                Capsule() // Yuvarlak köşeli chip görünümü
                    .fill(statusColor.opacity(0.15))
            )
    }
    
    private var statusColor: Color {
        switch status {
        case .paid: TColor.success
        case .unpaid: TColor.error
        }
    }
    
    private var statusText: String {
        switch status {
        case .paid: String(localized: "expense_status_paid")
        case .unpaid: String(localized: "expense_status_unpaid")
        }
    }
}

struct ExpenseListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ExpenseListView()
                .background(TColor.background)
        }
    }
}
