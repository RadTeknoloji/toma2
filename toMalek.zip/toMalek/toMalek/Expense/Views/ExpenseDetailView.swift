//
//  ExpenseDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct ExpenseDetailView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: ExpenseDetailViewModel
    
    init(expense: ExpenseModel) {
        _viewModel = StateObject(wrappedValue: ExpenseDetailViewModel(expense: expense))
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: TLayout.spacingL) {
                statusCard
                    .padding(.horizontal, TLayout.padding)
                
                propertyCard
                    .padding(.horizontal, TLayout.padding)
                
                expenseDetailsSection
                    .padding(.horizontal, TLayout.padding)
                
                if !viewModel.expense.mediaUrls.isEmpty {
                    mediaSection
                        .padding(.horizontal, TLayout.padding)
                }
            }
            .padding(.vertical, TLayout.padding)
        }
        .background(TColor.background)
        .navigationTitle("Gider Detayı")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarItems }
        .sheet(isPresented: $viewModel.showEditExpense) {
            EditExpenseView(expense: viewModel.expense)
        }
        .alert("Gider Sil", isPresented: $viewModel.showDeleteAlert, actions: deleteAlertActions)
        .onChange(of: viewModel.isDeleted) { _, newValue in
            if newValue { dismiss() }
        }
        .overlay { loadingOverlay }
    }
    
    // MARK: - Components
    private var statusCard: some View {
        VStack(spacing: TLayout.spacingS) {
            VStack(spacing: TLayout.spacingXXS) {
                Text(viewModel.statusText)
                    .font(TFont.title3)
                    .foregroundColor(viewModel.statusColor)
                
                if let paidDate = viewModel.expense.paidDate {
                    Text(paidDate.formatted(date: .numeric, time: .shortened))
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
            }
            
            if viewModel.expense.expenseStatus != .paid {
                Button {
                    Task { await viewModel.markAsPaid() }
                } label: {
                    Label("Ödemeyi Tamamla", systemImage: "checkmark.circle.fill")
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.areapolPrimary)
                }
            }
        }
        .padding(TLayout.padding)
        .frame(maxWidth: .infinity)
        .background(viewModel.statusColor.opacity(0.1))
        .cornerRadius(TLayout.cornerRadiusL)
    }
    
    private var propertyCard: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingS) {
            Label("Mülk Bilgisi", systemImage: "house.fill")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            if let property = viewModel.property {
                Button {
                    let detailView = PropertyDetailView(property: property)
                    let hostingController = UIHostingController(rootView: detailView)
                    
                    // Güncel window'u al
                    if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                       let window = windowScene.windows.first {
                        window.rootViewController?.present(hostingController, animated: true)
                    }
                } label: {
                    HStack {
                        Text(viewModel.propertyText)
                            .font(TFont.body)
                            .foregroundColor(TColor.textPrimary)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                    }
                    .padding(TLayout.padding)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                }
            } else {
                HStack {
                    Text(viewModel.propertyText)
                        .font(TFont.body)
                        .foregroundColor(TColor.textPrimary)
                        .redacted(reason: .placeholder)
                    
                    Spacer()
                }
                .padding(TLayout.padding)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
            }
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
    }

    private var propertyRowContent: some View {
        HStack {
            Text(viewModel.propertyText)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var expenseDetailsSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Label("Gider Detayları", systemImage: "doc.text.fill")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            VStack(spacing: TLayout.spacingS) {
                DetailRow(
                    title: "Kategori",
                    value: viewModel.expense.expenseCategory.rawValue,
                    icon: viewModel.categoryIcon
                )
                
                DetailRow(
                    title: "Tutar",
                    value: "\(viewModel.expense.expenseAmount.formatted()) \(viewModel.expense.currency.symbol)",
                    icon: "banknote.fill"
                )
                
                DetailRow(
                    title: "Ödeme Yöntemi",
                    value: viewModel.expense.paymentMethod.rawValue.capitalized,
                    icon: viewModel.paymentIcon
                )
                
                DetailRow(
                    title: "Tarih",
                    value: viewModel.expense.createdDate.formatted(date: .numeric, time: .shortened),
                    icon: "calendar"
                )
                
                DetailRow(
                    title: "Oluşturan",
                    value: viewModel.expense.fullName,
                    icon: "person.fill"
                )
                
                DetailRow(
                    title: "Kullanıcı Tipi",
                    value: viewModel.userTypeText,
                    icon: "person.badge.key.fill"
                )
                
                if let description = viewModel.expense.expenseDescription {
                    Divider()
                        .background(TColor.textSecondary.opacity(0.1))
                    
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text("Açıklama")
                            .font(TFont.footnote)
                            .foregroundColor(TColor.textSecondary)
                        
                        Text(description)
                            .font(TFont.body)
                            .foregroundColor(TColor.textPrimary)
                    }
                }
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
    }
    
    private var mediaSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Label("Fotoğraflar", systemImage: "photo.stack")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: TLayout.spacingS) {
                    ForEach(viewModel.expense.mediaUrls, id: \.self) { url in
                        AsyncImage(url: URL(string: url)) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                                    .tint(TColor.areapolPrimary)
                            case .success(let image):
                                image
                                    .resizable()
                                    .scaledToFill()
                            case .failure:
                                Image(systemName: "photo.fill")
                                    .foregroundColor(TColor.textSecondary)
                            @unknown default:
                                EmptyView()
                            }
                        }
                        .frame(width: 200, height: 200)
                        .clipShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                    }
                }
                .padding(.vertical, TLayout.paddingXXS)
            }
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
    }
    
    // MARK: - Helper Views
    private var toolbarItems: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            Menu {
                Button {
                    viewModel.showEditExpense = true
                } label: {
                    Label("Düzenle", systemImage: "pencil")
                }
                
                Button(role: .destructive) {
                    viewModel.showDeleteAlert = true
                } label: {
                    Label("Sil", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .foregroundColor(TColor.areapolPrimary)
            }
        }
    }
    
    private func deleteAlertActions() -> some View {
        Group {
            Button("Sil", role: .destructive) {
                Task { await viewModel.deleteExpense() }
            }
            Button("İptal", role: .cancel) {}
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
    }
}

// MARK: - Detail Row Component
private struct DetailRow: View {
    let title: String
    let value: String
    let icon: String
    
    var body: some View {
        HStack(spacing: TLayout.spacingS) {
            Image(systemName: icon)
                .foregroundColor(TColor.textSecondary)
                .frame(width: 24)
            
            Text(title)
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
            
            Spacer()
            
            Text(value)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
        }
    }
}

struct ExpenseDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ExpenseDetailView(expense: ExpenseModel(
                id: UUID(),
                propertyId: UUID(),
                userId: "test-user-id",
                userType: .owner,
                fullName: "Test User",
                expenseCategory: .maintenance,
                expenseStatus: .unpaid,
                expenseAmount: 1500,
                currency: .try,
                paymentMethod: .bankTransfer,
                expenseDescription: "Örnek gider açıklaması",
                mediaUrls: [],
                createdDate: Date(),
                paidDate: nil
            ))

            .background(TColor.background)
        }
    }
}
