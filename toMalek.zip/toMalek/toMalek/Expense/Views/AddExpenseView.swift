//
//  AddExpenseView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct AddExpenseView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel = AddExpenseViewModel()
    
    var body: some View {
        NavigationView {
            Form {
                propertySelectionSection
                expenseDetailsSection
                mediaSelectionSection
            }
            .background(TColor.surface)
            .navigationTitle(String(localized: "add_expense_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "add_expense_cancel")) {
                        dismiss()
                    }
                    .foregroundColor(TColor.areapolPrimary)
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(String(localized: "add_expense_save")) {
                        Task {
                            await viewModel.save()
                        }
                    }
                    .font(TFont.bodyBold)
                    .foregroundColor(viewModel.isValidForm ? TColor.areapolPrimary : TColor.surfaceDark)
                    .disabled(!viewModel.isValidForm || viewModel.isLoading)
                }
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                        .tint(TColor.areapolPrimary)
                }
            }
            .onChange(of: viewModel.imageSelections) { _, _ in
                Task { @MainActor in
                    await viewModel.loadImages()
                }
            }
            .onChange(of: viewModel.isSuccessful) { _, success in
                if success {
                    dismiss()
                }
            }
            .alert(
                String(localized: "add_expense_error_title"),
                isPresented: .constant(viewModel.errorMessage != nil),
                actions: {
                    Button(String(localized: "add_expense_ok"), role: .cancel) {
                        viewModel.errorMessage = nil
                    }
                },
                message: {
                    if let error = viewModel.errorMessage {
                        Text(error)
                            .font(TFont.body)
                    }
                }
            )
        }
    }
    
    // MARK: - Section Views
    private var propertySelectionSection: some View {
        Section {
            Picker(String(localized: "add_expense_property"), selection: $viewModel.selectedProperty) {
                Text(String(localized: "add_expense_select"))
                    .tag(Optional<PropertyModel>.none)
                
                ForEach(viewModel.properties) { property in
                    Text(property.title)
                        .tag(Optional(property))
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
        } header: {
            Text(String(localized: "add_expense_property_section"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var expenseDetailsSection: some View {
        Section {
            Picker(String(localized: "add_expense_category"), selection: $viewModel.expenseCategory) {
                ForEach(ExpenseCategory.allCases, id: \.self) { category in
                    Label(
                        category.localized,
                        systemImage: categoryIcon(for: category)
                    )
                    .tag(category)
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            
            Picker(String(localized: "add_expense_status"), selection: $viewModel.expenseStatus) {
                ForEach(ExpenseStatus.allCases, id: \.self) { status in
                    Text(status.localized)
                        .tag(status)
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            
            HStack {
                TextField(String(localized: "add_expense_amount"), text: $viewModel.expenseAmount)
                    .keyboardType(.decimalPad)
                    .font(TFont.body)
                
                Picker("", selection: $viewModel.currency) {
                    ForEach(CurrencyType.allCases, id: \.self) { currency in
                        Text(currency.symbol).tag(currency)
                    }
                }
                .frame(width: 100)
                .font(TFont.body)
            }
            
            Picker(String(localized: "add_expense_payment_method"), selection: $viewModel.paymentMethod) {
                ForEach(PaymentMethod.allCases, id: \.self) { method in
                    Label(
                        method.localized,
                        systemImage: paymentIcon(for: method)
                    )
                    .tag(method)
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            
            TextField(String(localized: "add_expense_description"), text: $viewModel.expenseDescription, axis: .vertical)
                .lineLimit(3...5)
                .font(TFont.body)
        } header: {
            Text(String(localized: "add_expense_details_section"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var mediaSelectionSection: some View {
        Section {
            PhotosPicker(
                selection: $viewModel.imageSelections,
                maxSelectionCount: 5,
                matching: .images
            ) {
                photoPickerLabel
            }
        } header: {
            Text(String(localized: "add_expense_photos_section"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
    }
    
    // MARK: - Components
    @ViewBuilder
    private var photoPickerLabel: some View {
        Label {
            Text(viewModel.photoLabelText)
                .font(TFont.body)
                .foregroundColor(TColor.areapolPrimary)
        } icon: {
            Image(systemName: "photo.on.rectangle.angled")
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    // MARK: - Helper Methods
    private func categoryIcon(for category: ExpenseCategory) -> String {
        switch category {
        case .dues: return "building.2"
        case .bill: return "doc.text"
        case .maintenance: return "wrench.and.screwdriver"
        case .renovation: return "hammer"
        case .tax: return "percent"
        case .penalty: return "exclamationmark.triangle"
        case .insurance: return "checkmark.shield"
        case .other: return "ellipsis.circle"
        }
    }
    
    private func paymentIcon(for method: PaymentMethod) -> String {
        switch method {
        case .cash: return "banknote"
        case .bankTransfer: return "building.columns"
        case .creditCard: return "creditcard"
        case .other: return "ellipsis.circle"
        }
    }
}

struct AddExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AddExpenseView()
                .background(TColor.background)
        }
    }
}
 
