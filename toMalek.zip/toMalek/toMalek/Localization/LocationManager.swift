//
//  LocationManager.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import CoreLocation
import MapKit

@preconcurrency protocol LocationManagerProtocol {
    @MainActor func requestLocation(completion: @escaping (CLLocation?) -> Void)
}

@MainActor
class LocationManager: NSObject, ObservableObject, LocationManagerProtocol, CLLocationManagerDelegate {

    private let manager = CLLocationManager()
    private var completer: MKLocalSearchCompleter?
    private var locationCompletion: ((CLLocation?) -> Void)?
    
    struct AddressDetails: Equatable {
        var latitude: Double?
        var longitude: Double?
        var formattedAddress: String?
        var streetAddress: String?
        var neighborhood: String?
        var district: String?
        var city: String?
        var province: String?
        var state: String?
        var country: String?
        var postalCode: String?
        
        static func == (lhs: LocationManager.AddressDetails, rhs: LocationManager.AddressDetails) -> Bool {
            lhs.formattedAddress == rhs.formattedAddress &&
            lhs.latitude == rhs.latitude &&
            lhs.longitude == rhs.longitude
        }
    }
    
    
    // MARK: - Kullanıcının aradığı adrese haritayı odaklar
    func getCoordinateFromResult(_ result: MKLocalSearchCompletion) async -> CLLocationCoordinate2D? {
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = [result.title, result.subtitle].joined(separator: ", ")
        
        let search = MKLocalSearch(request: searchRequest)
        do {
            let response = try await search.start()
            return response.mapItems.first?.placemark.coordinate
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
            }
            return nil
        }
    }
    
    // MARK: - Published Properties
    @Published var lastLocation: CLLocation?
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 41.0082, longitude: 28.9784),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )
    @Published var formattedAddress: String?
    @Published var addressDetails: AddressDetails?
    @Published var searchResults: [MKLocalSearchCompletion] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        setupCompleter()
    }
    
    // MARK: - Protocol Implementation
    func requestLocation(completion: @escaping (CLLocation?) -> Void) {
        locationCompletion = completion
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
    }

    // MARK: - Location Search
    func searchAddress(_ query: String) {
        completer?.queryFragment = query
    }
    
    func selectSearchResult(_ result: MKLocalSearchCompletion) {
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = [result.title, result.subtitle].joined(separator: ", ")
        
        MKLocalSearch(request: searchRequest).start { [weak self] response, error in
            guard let self else { return }
            
            if let error {
                Task { @MainActor in
                    self.errorMessage = error.localizedDescription
                }
                return
            }
            
            guard let coordinate = response?.mapItems.first?.placemark.coordinate else {
                Task { @MainActor in
                    self.errorMessage = String(localized: "location_error_not_found")
                }
                return
            }
            
            Task { @MainActor in
                self.region.center = coordinate
                await self.getAddressFromLocation(coordinate)
            }
        }
    }
    
    // MARK: - Reverse Geocoding
    func getAddressFromLocation(_ coordinate: CLLocationCoordinate2D) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let placemarks = try await CLGeocoder().reverseGeocodeLocation(
                CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            )
            
            if let placemark = placemarks.first {
                // Sokak adresi oluştur
                let streetNumber = placemark.subThoroughfare ?? ""
                let streetName = placemark.thoroughfare ?? ""
                let fullStreetAddress = "\(streetNumber) \(streetName)".trimmingCharacters(in: .whitespaces)
                
                // Sadece değeri olan alanları al
                let details = AddressDetails(
                    streetAddress: fullStreetAddress.isEmpty ? nil : fullStreetAddress,
                    neighborhood: placemark.subLocality?.isEmpty == false ? placemark.subLocality : nil,
                    district: placemark.subAdministrativeArea?.isEmpty == false ? placemark.subAdministrativeArea : nil,
                    city: placemark.locality?.isEmpty == false ? placemark.locality : nil,
                    province: placemark.administrativeArea?.isEmpty == false ? placemark.administrativeArea : nil,
                    state: placemark.administrativeArea?.isEmpty == false ? placemark.administrativeArea : nil,
                    country: placemark.country?.isEmpty == false ? placemark.country : nil,
                    postalCode: placemark.postalCode?.isEmpty == false ? placemark.postalCode : nil
                )
                
                // Adres detaylarını güncelle
                addressDetails = details
                
                // Formatlanmış adresi oluştur - sadece değeri olan alanları kullan
                let addressComponents = [
                    details.streetAddress,
                    details.neighborhood,
                    details.district,
                    details.city,
                    details.state,
                    details.country
                ].compactMap { $0 }
                
                formattedAddress = addressComponents.joined(separator: ", ")
                
                // Debug için yazdır
                print("📍 Adres Detayları:")
                print("Bulunan tüm adres bileşenleri:")
                if let streetAddress = details.streetAddress { print("Sokak: \(streetAddress)") }
                if let neighborhood = details.neighborhood { print("Mahalle: \(neighborhood)") }
                if let district = details.district { print("İlçe: \(district)") }
                if let city = details.city { print("Şehir: \(city)") }
                if let province = details.province { print("Bölge: \(province)") }
                if let state = details.state { print("İl/Eyalet: \(state)") }
                if let country = details.country { print("Ülke: \(country)") }
                if let postalCode = details.postalCode { print("Posta Kodu: \(postalCode)") }
                
            } else {
                errorMessage = String(localized: "location_error_address_not_found")
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
}
// MARK: - CLLocationManagerDelegate
extension LocationManager {
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        
        Task { @MainActor in
            self.lastLocation = location
            self.region.center = location.coordinate
            self.locationCompletion?(location)
            self.locationCompletion = nil
        }
    }
    
    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        Task { @MainActor in
            self.errorMessage = error.localizedDescription
            self.locationCompletion?(nil)
            self.locationCompletion = nil
        }
    }
}

// MARK: - Search Completer
extension LocationManager: MKLocalSearchCompleterDelegate {
    private func setupCompleter() {
        completer = MKLocalSearchCompleter()
        completer?.delegate = self
        completer?.resultTypes = .address
    }
    
    nonisolated func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        Task { @MainActor in
            self.searchResults = completer.results
        }
    }
    
    nonisolated func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        Task { @MainActor in
            self.errorMessage = error.localizedDescription
        }
    }
}
