import Foundation

enum Language: String, CaseIterable {
    case english = "en"
    case turkish = "tr"
    case german = "de"
    case french = "fr"
    case spanish = "es"
    case arabic = "ar"
    
    var displayName: String {
        switch self {
        case .english: return "English"
        case .turkish: return "Türkçe"
        case .german: return "Deutsch"
        case .french: return "Français"
        case .spanish: return "Español"
        case .arabic: return "العربية"
        }
    }
}

class LocalizationManager {
    static let shared = LocalizationManager()
    
    private init() {
        // Başlangıç dilini ayarla
        if let savedLanguage = UserDefaults.standard.string(forKey: "AppLanguage"),
           let language = Language(rawValue: savedLanguage) {
            currentLanguage = language
        } else {
            // Sistem dilini kontrol et
            if let systemLanguage = Bundle.main.preferredLocalizations.first,
               let language = Language(rawValue: systemLanguage) {
                currentLanguage = language
            }
        }
        print("🔵 Initialization - Current Language: \(currentLanguage.rawValue)")
    }
    
    var currentLanguage: Language = .english {
        didSet {
            UserDefaults.standard.set(currentLanguage.rawValue, forKey: "AppLanguage")
            NotificationCenter.default.post(name: .languageChanged, object: nil)
        }
    }
    
    func setLanguage(_ language: Language) {
        print("🔵 Setting language to: \(language.rawValue)")
        currentLanguage = language
        
        // Bundle ve UserDefaults güncelleme
        UserDefaults.standard.set([language.rawValue], forKey: "AppleLanguages")
        UserDefaults.standard.set(language.rawValue, forKey: "AppLanguage")
        UserDefaults.standard.synchronize()
        
        // Yeniden başlatma ihtiyacı için bildirim
        NotificationCenter.default.post(name: .languageChanged, object: nil)
    }
    
    func getCurrentLanguage() -> Language {
        if let languageCode = UserDefaults.standard.string(forKey: "AppLanguage"),
           let language = Language(rawValue: languageCode) {
            return language
        }
        return .english // Varsayılan dil
    }
}

// Dil değişikliği bildirim extension'ı
extension Notification.Name {
    static let languageChanged = Notification.Name("LanguageChangedNotification")
}

// Yerelleştirme extension'ı
extension String {
    func localized(bundle: Bundle = .main, tableName: String = "Localizable") -> String {
        let currentLang = LocalizationManager.shared.currentLanguage.rawValue
        print("🔍 Checking translation for: \(self) in language: \(currentLang)")
        
        // Bundle içeriğini kontrol et
        let resourcePath = bundle.bundlePath
        do {
            let resourceContents = try FileManager.default.contentsOfDirectory(atPath: resourcePath)
            print("📁 Bundle contents: \(resourceContents)")
            
            if let lprojPath = bundle.path(forResource: currentLang, ofType: "lproj") {
                print("📂 Found .lproj at: \(lprojPath)")
                let lprojContents = try FileManager.default.contentsOfDirectory(atPath: lprojPath)
                print("📑 .lproj contents: \(lprojContents)")
            }
        } catch {
            print("❌ Error reading bundle: \(error)")
        }
        
        // Mevcut yöntemle devam et
        guard let path = bundle.path(forResource: currentLang, ofType: "lproj"),
              let languageBundle = Bundle(path: path) else {
            return self
        }
        
        // Strings dosyasını doğrudan oku
        if let stringsPath = languageBundle.path(forResource: "Localizable", ofType: "strings") {
            print("📝 Found strings file at: \(stringsPath)")
            if let dict = NSDictionary(contentsOfFile: stringsPath) {
                print("🔤 Available translations: \(dict)")
            }
        }
        
        return NSLocalizedString(self, tableName: tableName, bundle: languageBundle, value: self, comment: "")
    }
}
