//
//  ContentView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

struct ContentView: View {
    @StateObject private var authState = AuthenticationState()
    
    var body: some View {
        Group {
            if authState.isSignedIn {
                MainTabView()
                    .onAppear {
                        // Navigation bar varsayılan rengini ayarla
                        let appearance = UINavigationBarAppearance()
                        appearance.configureWithOpaqueBackground()
                        appearance.backgroundColor = UIColor(TColor.areapolSecondary)
                        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
                        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
                        
                        // Standart ve scroll edge görünümünü ayarla
                        UINavigationBar.appearance().standardAppearance = appearance
                        UINavigationBar.appearance().compactAppearance = appearance
                        UINavigationBar.appearance().scrollEdgeAppearance = appearance
                        
                        // Tint color'ı ayarla (bar button items için)
                        UINavigationBar.appearance().tintColor = .white
                    }
            } else {
                SignInView()
            }
        }
        .environmentObject(authState)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
