//
//  AuthenticationState.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore


@MainActor
class AuthenticationState: ObservableObject {
    @Published var isSignedIn = false
    @Published var currentUser: User?
    @Published var userType: String = ""
    @Published var userTypes: Set<String> = []
    @Published var fullName: String = ""
    @Published var phoneNumber: String = ""
    
    private var authStateDidChangeListenerHandle: AuthStateDidChangeListenerHandle?
    private let db = Firestore.firestore()
    
    static let shared = AuthenticationState()

        
    init() {
        authStateDidChangeListenerHandle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            self?.isSignedIn = user != nil
            self?.currentUser = user
            if let userId = user?.uid {
                self?.fetchUserProfile(userId: userId)
            }
        }
    }
    
    private func fetchUserProfile(userId: String) {
        db.collection("profiles")
            .document(userId)
            .getDocument { [weak self] documentSnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print(String(localized: "error_fetching_profile \(error.localizedDescription)"))
                    return
                }
                
                if let data = documentSnapshot?.data() {
                    if let activeUserType = data["activeUserType"] as? String {
                        self.userType = activeUserType
                        print(String(localized: "user_type_fetched \(activeUserType)"))
                    }
                    
                    // Kullanıcı profil bilgilerini çek
                    self.fullName = data["fullName"] as? String ?? ""
                    self.phoneNumber = data["phoneNumber"] as? String ?? ""
                    
                    if let userTypes = data["userTypes"] as? [String] {
                        self.userTypes = Set(userTypes)
                    }
                } else {
                    print(String(localized: "no_profile_data_found"))
                }
            }
    }
    
    func signOut() async {
        do {
            try Auth.auth().signOut()
            self.isSignedIn = false
            self.currentUser = nil
            self.userType = ""
            self.userTypes = []
            self.fullName = ""
            self.phoneNumber = ""
            print(String(localized: "signed_out_success"))
        } catch {
            let errorMessage = String(format: String(localized: "sign_out_error"), error.localizedDescription)
            print(errorMessage)
        }
    }
    
    // MARK: - User Type Management
    func updateUserType(_ type: UserType) {
        self.userType = type.rawValue
        print(String(localized: "user_type_updated \(type.rawValue)"))
    }
}
