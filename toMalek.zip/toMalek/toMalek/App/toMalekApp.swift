//
//  toMalekApp.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@main
struct toMalekApp: App {
    // Register app delegate for Firebase setup
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State private var showingSplash = true
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                
                if showingSplash {
                    SplashScreen()
                        .transition(.opacity)
                        .zIndex(1)
                }
            }
            .onAppear {
                // Splash ekranını 2 saniye sonra kaldır
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    withAnimation {
                        showingSplash = false
                    }
                }
            }
        }
    }
}

// MARK: - SplashScreen
struct SplashScreen: View {
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()
            
            Image("LaunchLogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 150, height: 150)
        }
    }
}

// MARK: - AppDelegate
class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        
        // Başlangıç dilini ayarla
        if let savedLanguage = UserDefaults.standard.string(forKey: "AppLanguage"),
           let language = Language(rawValue: savedLanguage) {
            print("🔵 Setting saved language: \(language.rawValue)")
            LocalizationManager.shared.setLanguage(language)
        } else {
            // Sistem dilini kontrol et
            if let preferredLanguage = Bundle.main.preferredLocalizations.first,
               let language = Language(rawValue: preferredLanguage) {
                print("🔵 Setting system language: \(language.rawValue)")
                LocalizationManager.shared.setLanguage(language)
            } else {
                print("🔵 Setting default language: english")
                LocalizationManager.shared.setLanguage(.english)
            }
        }
        
        // Debug için bundle bilgilerini yazdır
        print("🔵 Main bundle path: \(Bundle.main.bundlePath)")
        print("🔵 Available localizations: \(Bundle.main.localizations)")
        print("🔵 Development language: \(Bundle.main.developmentLocalization ?? "unknown")")
        
        return true
    }
    
    func checkBundleStructure() {
        let mainBundle = Bundle.main
        print("📦 Main Bundle Path: \(mainBundle.bundlePath)")
        
        if let resourcePath = mainBundle.resourcePath {
            do {
                let contents = try FileManager.default.contentsOfDirectory(atPath: resourcePath)
                print("📂 Resource Contents: \(contents)")
                
                // .lproj dosyalarını ara
                let lprojFiles = contents.filter { $0.hasSuffix(".lproj") }
                print("🌐 Found .lproj directories: \(lprojFiles)")
                
                // Her .lproj içini kontrol et
                for lprojFile in lprojFiles {
                    let lprojPath = (resourcePath as NSString).appendingPathComponent(lprojFile)
                    let lprojContents = try FileManager.default.contentsOfDirectory(atPath: lprojPath)
                    print("📑 Contents of \(lprojFile): \(lprojContents)")
                }
            } catch {
                print("❌ Error reading bundle: \(error)")
            }
        }
    }
}
