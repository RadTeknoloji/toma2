//
//  Untitled.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI

@MainActor
final class MainTabViewModel: ObservableObject {
    @Published var selectedTab = 0
    @Published var isAuthenticated = true // TODO: Firebase auth state'i ile güncellenecek
    
    // Tab değişimini izlemek için
    func tabChanged(to index: Int) {
        selectedTab = index
        // TODO: Analytics tracking eklenebilir
    }
    
    func signOut() {
        // TODO: Firebase sign out işlemi
        isAuthenticated = false
    }
}
