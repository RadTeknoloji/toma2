import SwiftUI

struct MainTabView: View {
    @StateObject private var viewModel = MainTabViewModel()
    @EnvironmentObject var authState: AuthenticationState
    
    var body: some View {
        Group {
            if viewModel.isAuthenticated {
                TabView(selection: $viewModel.selectedTab) {
                    NavigationStack {
                        HomeView()
                            .environmentObject(authState)
                    }
                    .tabItem {
                        Image(systemName: "house")
                        Text(LocalizedStringKey("main_tab_home"))
                    }
                    .tag(0)
                    
                    NavigationStack {
                        PropertyListView()
                            .environmentObject(authState)
                    }
                    .tabItem {
                        Image(systemName: "building.2.fill")
                        Text(LocalizedStringKey("main_tab_properties"))
                    }
                    .tag(1)
                    
                    NavigationStack {
                        ExpenseListView()
                            .environmentObject(authState)
                    }
                    .tabItem {
                        Image(systemName: "banknote.fill")
                        Text(LocalizedStringKey("main_tab_expenses"))
                    }
                    .tag(2)
                    
                    NavigationStack {
                        RentPaymentListView()
                            .environmentObject(authState)
                    }
                    .tabItem {
                        Image(systemName: "creditcard.fill")
                        Text(LocalizedStringKey("main_tab_payments"))
                    }
                    .tag(3)
                    
                    NavigationStack {
                        ProfileView()
                            .environmentObject(authState)
                    }
                    .tabItem {
                        Image(systemName: "person.fill")
                        Text(LocalizedStringKey("main_tab_profile"))
                    }
                    .tag(4)
                }
                .tint(TColor.areapolPrimary) // Seçili ikon rengi
                .onChange(of: viewModel.selectedTab) { oldValue, newValue in
                    viewModel.tabChanged(to: newValue)
                }
                .environment(\.symbolVariants, .none) // Seçili olmayan ikonlar için
            } else {
                SignInView()
            }
        }
        .onAppear {
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor(TColor.areapolPrimary)
            
            // Seçili olmayan item stilleri
            appearance.stackedLayoutAppearance.normal.iconColor = UIColor(TColor.onPrimary)
            appearance.stackedLayoutAppearance.normal.titleTextAttributes = [
                .foregroundColor: UIColor(TColor.onPrimary)
            ]
            
            // Seçili item stilleri
            appearance.stackedLayoutAppearance.selected.iconColor = UIColor(TColor.areapolSecondary)
            appearance.stackedLayoutAppearance.selected.titleTextAttributes = [
                .foregroundColor: UIColor(TColor.areapolSecondary)
            ]
            
            // iOS 15 + uyumluluk
            UITabBar.appearance().scrollEdgeAppearance = appearance
            UITabBar.appearance().standardAppearance = appearance
        }

    }
}
