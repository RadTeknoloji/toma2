//
//  MyAgencyModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseFirestore

struct MyAgencyModel: Identifiable, Codable, Sendable {
    let id: UUID
    @UppercaseFormat var officialName: String
    @UppercaseFormat var brandName: String
    @UppercaseFormat var taxNumber: String
    @UppercaseFormat var managerName: String
    @PhoneFormat var phoneNumber: String
    @PhoneFormat var secondaryPhone: String
    var email: String
    var ratings: [AgencyRating]
    var isFavorite: Bool
    var createdBy: String
    
    var averageRating: Double? {
        guard !ratings.isEmpty else { return nil }
        
        let validRatings = ratings.compactMap { $0.overallRating }
        return validRatings.isEmpty ? nil : validRatings.reduce(0, +) / Double(validRatings.count)
    }
    
    var isValidOfficialName: Bool {
        !officialName.isEmpty && officialName.count >= 3
    }
    
    var isValidBrandName: Bool {
        !brandName.isEmpty
    }
    
    var isValidTaxNumber: Bool {
        let taxRegex = "^[0-9]{10}$"
        let taxPredicate = NSPredicate(format: "SELF MATCHES %@", taxRegex)
        return taxPredicate.evaluate(with: taxNumber)
    }
    
    var isValidManagerName: Bool {
        !managerName.isEmpty && managerName.count >= 3
    }
    
    var isValidPhoneNumber: Bool {
        let phoneRegex = "^\\+?\\d{1,3}?[-. ]?\\(?\\d{3}\\)?[-. ]?\\d{3}[-. ]?\\d{4,6}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: phoneNumber)
    }
    
    var isValidSecondaryPhone: Bool {
        let phoneRegex = "^\\+?\\d{1,3}?[-. ]?\\(?\\d{3}\\)?[-. ]?\\d{3}[-. ]?\\d{4,6}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: secondaryPhone)
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    // Kodlama için özel init metodu
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(UUID.self, forKey: .id)
        officialName = try container.decode(String.self, forKey: .officialName)
        brandName = try container.decode(String.self, forKey: .brandName)
        taxNumber = try container.decode(String.self, forKey: .taxNumber)
        managerName = try container.decode(String.self, forKey: .managerName)
        phoneNumber = try container.decode(String.self, forKey: .phoneNumber)
        secondaryPhone = try container.decode(String.self, forKey: .secondaryPhone)
        email = try container.decode(String.self, forKey: .email)
        
        // Ratings için düzeltilmiş decode işlemi
        do {
            ratings = try container.decode([AgencyRating].self, forKey: .ratings)
        } catch {
            ratings = [] // Eğer decode edilemezse boş array
        }
        
        isFavorite = try container.decode(Bool.self, forKey: .isFavorite)
        createdBy = try container.decode(String.self, forKey: .createdBy)
    }
    
    // Standard initializer
    init(
        id: UUID = UUID(),
        officialName: String,
        brandName: String,
        taxNumber: String,
        managerName: String,
        phoneNumber: String,
        secondaryPhone: String,
        email: String,
        ratings: [AgencyRating] = [],
        isFavorite: Bool = false,
        createdBy: String
    ) {
        self.id = id
        self.officialName = officialName
        self.brandName = brandName
        self.taxNumber = taxNumber
        self.managerName = managerName
        self.phoneNumber = phoneNumber
        self.secondaryPhone = secondaryPhone
        self.email = email
        self.ratings = ratings
        self.isFavorite = isFavorite
        self.createdBy = createdBy
    }
}

// MARK: - Hashable Conformance
extension MyAgencyModel: Hashable {
    static func == (lhs: MyAgencyModel, rhs: MyAgencyModel) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

