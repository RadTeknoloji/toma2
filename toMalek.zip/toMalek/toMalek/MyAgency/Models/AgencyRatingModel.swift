//
//  AgencyRatingModel.swift
//  toMalek
//
//  Created by Selman Erbay on 27.01.2025.
//

import Foundation
import SwiftUI

struct AgencyRating: Codable, Hashable, Sendable {
    enum Criterion: String, Codable, CaseIterable, Sendable {
        case communicationSkills = "criterion_communication_skills"
        case trustworthiness = "criterion_trustworthiness"
        case marketingSkills = "criterion_marketing_skills"
        case pricingAccuracy = "criterion_pricing_accuracy"
        case professionalism = "criterion_professionalism"
        case knowledgeAndExperience = "criterion_knowledge_experience"
        
        var localizedName: LocalizedStringKey {
            LocalizedStringKey(self.rawValue) // Yerelleştirilmiş isim
        }
        
        var weight: Double {
            switch self {
            case .communicationSkills: return 0.25
            case .trustworthiness: return 0.20
            case .marketingSkills: return 0.20
            case .pricingAccuracy: return 0.15
            case .professionalism: return 0.10
            case .knowledgeAndExperience: return 0.10
            }
        }
    }
    
    let id: UUID
    let userId: String
    var ratings: [Criterion: Int]
    let date: Date
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId
        case ratings
        case date
    }
    
    init(
        id: UUID = UUID(),
        userId: String,
        ratings: [Criterion: Int],
        date: Date = Date()
    ) {
        self.id = id
        self.userId = userId
        self.ratings = ratings
        self.date = date
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        userId = try container.decode(String.self, forKey: .userId)
        date = try container.decode(Date.self, forKey: .date)
        
        do {
            ratings = try container.decode([Criterion: Int].self, forKey: .ratings)
        } catch {
            if let ratingsDict = try? container.decode([String: Int].self, forKey: .ratings) {
                ratings = ratingsDict.compactMapKeys { Criterion(rawValue: $0) }
            } else {
                ratings = [:]
            }
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(id, forKey: .id)
        try container.encode(userId, forKey: .userId)
        try container.encode(date, forKey: .date)
        
        let ratingsDict = Dictionary(uniqueKeysWithValues:
            ratings.map { ($0.key.rawValue, $0.value) }
        )
        try container.encode(ratingsDict, forKey: .ratings)
    }
    
    var overallRating: Double? {
        let filledCriteria = ratings.filter { $0.value > 0 }
        guard !filledCriteria.isEmpty else { return nil }
        
        let totalWeightedScore = filledCriteria.reduce(0.0) { partialResult, entry in
            partialResult + (Double(entry.value) * entry.key.weight)
        }
        
        let totalWeight = filledCriteria.reduce(0.0) { $0 + $1.key.weight }
        
        return (totalWeightedScore / totalWeight) * 20
    }
    
    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [
            "id": id.uuidString,
            "userId": userId,
            "date": date
        ]
        
        var ratingsDict: [String: Int] = [:]
        ratings.forEach { criterion, rating in
            ratingsDict[criterion.rawValue] = rating
        }
        
        dict["ratings"] = ratingsDict
        return dict
    }
    
    init?(dictionary: [String: Any]) {
        guard
            let idString = dictionary["id"] as? String,
            let id = UUID(uuidString: idString),
            let userId = dictionary["userId"] as? String,
            let date = dictionary["date"] as? Date,
            let ratingsDict = dictionary["ratings"] as? [String: Int]
        else { return nil }
        
        self.id = id
        self.userId = userId
        self.date = date
        
        var convertedRatings: [Criterion: Int] = [:]
        ratingsDict.forEach { key, value in
            if let criterion = Criterion(rawValue: key) {
                convertedRatings[criterion] = value
            }
        }
        
        self.ratings = convertedRatings
    }
}

extension Dictionary {
    func compactMapKeys<T>(_ transform: (Key) throws -> T?) rethrows -> [T: Value] {
        var result: [T: Value] = [:]
        for (key, value) in self {
            if let newKey = try transform(key) {
                result[newKey] = value
            }
        }
        return result
    }
}
