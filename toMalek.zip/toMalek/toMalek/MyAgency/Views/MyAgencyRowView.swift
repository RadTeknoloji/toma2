//
//  MyAgencyRowView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

// MARK: - Emlakçı Satır Görünümü
struct MyAgencyRowView: View {
    let agency: MyAgencyModel
    
    var body: some View {
        HStack(spacing: TLayout.spacingM) {
            // Icon Container
            ZStack {
                Circle()
                    .fill(TColor.surface)
                    .frame(width: 80, height: 80)
                
                Image(systemName: "building.2")
                    .font(.system(size: 32))
                    .foregroundColor(TColor.textSecondary)
            }
            
            // Content
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                // Brand Name and Favorite Icon
                HStack {
                    Text(agency.brandName)
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                    
                    Spacer()
                    
                    if agency.isFavorite {
                        Image(systemName: "star.fill")
                            .foregroundColor(TColor.warning)
                            .font(.system(size: 16))
                    }
                }
                
                // Official Name
                Text(agency.officialName)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                    .lineLimit(1)
                
                // Contact Info
                HStack(spacing: TLayout.spacingXS) {
                    Image(systemName: "phone.fill")
                        .font(.system(size: 12))
                        .foregroundColor(TColor.areapolSecondary)
                    
                    Text(agency.phoneNumber)
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                }
                
                // Rating if available
                if let rating = agency.averageRating {
                    HStack(spacing: TLayout.spacingXS) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 12))
                            .foregroundColor(TColor.warning)
                        
                        Text(String(format: "%.1f", rating))
                            .font(TFont.caption)
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}
