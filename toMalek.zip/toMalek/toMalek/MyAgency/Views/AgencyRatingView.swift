//
//  AgencyRatingView.swift
//  toMalek
//
//  Created by Selman Erbay on 27.01.2025.
//

import SwiftUI

struct AgencyRatingView: View {
    @ObservedObject var viewModel: MyAgenciesViewModel
    let agency: MyAgencyModel
    let onComplete: (Bool) -> Void
    
    var body: some View {
        Form {
            ratingCriteriaSection
            actionSection
        }
        .background(TColor.background)
        .scrollContentBackground(.hidden)
        .navigationTitle(String(localized: "rate_agency"))
        .navigationBarItems(
            leading: Button(String(localized: "cancel")) {
                viewModel.clearRating()
                onComplete(false)
            }
            .foregroundColor(TColor.areapolPrimary)
        )
    }
    
    private var ratingCriteriaSection: some View {
        Section(String(localized: "rating_criteria")) {
            ForEach(AgencyRating.Criterion.allCases, id: \.self) { criterion in
                VStack(alignment: .leading, spacing: TLayout.spacing) {
                    criterionHeader(criterion: criterion)
                    scorePicker(criterion: criterion)
                }
                .padding(.vertical, TLayout.padding)
            }
        }
    }
    
    private func criterionHeader(criterion: AgencyRating.Criterion) -> some View {
        HStack {
            Text(criterion.localizedName) // Yerelleştirilmiş ad
                .font(TFont.bodyBold)
            
            Text("(\(Int(criterion.weight * 100))%)")
                .font(TFont.caption)
                .foregroundColor(TColor.border)
        }
    }
    
    private func scorePicker(criterion: AgencyRating.Criterion) -> some View {
        Picker(String(localized: "score"), selection: viewModel.bindingForCriterion(criterion)) {
            ForEach(0...5, id: \.self) { score in
                Text(score == 0 ? String(localized: "score") : "\(score)")
                    .tag(score)
            }
        }
        .pickerStyle(.segmented)
        .padding(.vertical, TLayout.padding)
    }
    
    private var actionSection: some View {
        Section {
            VStack(alignment: .leading, spacing: TLayout.spacing) {
                if let simulatedRating = simulateOverallRating() {
                    ratingPreview(simulatedRating: simulatedRating)
                }
                
                saveButton
            }
        }
    }
    
    private func ratingPreview(simulatedRating: Double) -> some View {
        HStack {
            Text(String(localized: "estimated_overall_score"))
                .font(TFont.bodyBold)
            
            Text(String(format: "%.1f", simulatedRating))
                .font(TFont.bodyBold)
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    private var saveButton: some View {
        Button {
            Task {
                let success = await viewModel.saveRating(for: agency)
                onComplete(success)
            }
        } label: {
            Text(String(localized: "save_rating"))
                .frame(maxWidth: .infinity)
                .font(TFont.bodyBold)
        }
        .buttonStyle(TButton.Primary())
        .disabled(viewModel.currentRating.isEmpty)
    }
    
    private func simulateOverallRating() -> Double? {
        let rating = AgencyRating(
            userId: viewModel.currentUserId ?? "",
            ratings: viewModel.currentRating
        )
        return rating.overallRating
    }
}
