//
//  MyAgencyFormView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct MyAgencyFormView: View {
    @ObservedObject var viewModel: MyAgenciesViewModel
    let agency: MyAgencyModel?
    let onSave: (Bool) -> Void
    
    var body: some View {
        Form(content: {
            Section(LocalizedStringKey("company_info")) {
                TextField(LocalizedStringKey("company_official_title_placeholder"), text: $viewModel.officialName)
                    .textInputAutocapitalization(.characters)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
                
                TextField(LocalizedStringKey("brand_name_placeholder"), text: $viewModel.brandName)
                    .textInputAutocapitalization(.characters)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
                
                TextField(LocalizedStringKey("tax_number_placeholder"), text: $viewModel.taxNumber)
                    .keyboardType(.numberPad)
                    .textInputAutocapitalization(.characters)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
                
                TextField(LocalizedStringKey("manager_name_placeholder"), text: $viewModel.managerName)
                    .textInputAutocapitalization(.characters)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
            }
            
            Section(LocalizedStringKey("contact_info")) {
                PhoneInputView(
                    text: $viewModel.phoneNumber,
                    label: LocalizedStringKey("phone_placeholder"),
                    placeholder: LocalizedStringKey("phone_placeholder"),
                    error: "phone_number_invalid"
                )
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
                
                PhoneInputView(
                    text: $viewModel.secondaryPhone,
                    label: LocalizedStringKey("secondary_phone_placeholder"),
                    placeholder: LocalizedStringKey("secondary_phone_placeholder"),
                    error: "phone_number_invalid"
                )
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
                
                TextField(LocalizedStringKey("email_placeholder"), text: $viewModel.email)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
            }
            
            Section {
                Button {
                    Task {
                        let success: Bool
                        if let agency = agency {
                            success = await viewModel.updateAgency(agency)
                        } else {
                            success = await viewModel.createAgency()
                        }
                        onSave(success)
                    }
                } label: {
                    Text(LocalizedStringKey("save"))
                        .frame(maxWidth: .infinity)
                        .font(TFont.bodyBold)
                }
                .buttonStyle(TButton.Primary())
                .disabled(!viewModel.isValidForm)
                .listRowBackground(TColor.areapolPrimary.opacity(0.1))
            }
        })
        .background(TColor.background)
        .scrollContentBackground(.hidden)
        .onAppear {
            if let agency = agency {
                viewModel.loadAgencyData(agency)
            }
        }
        .shadow(color: TElevation.low.color, radius: TElevation.low.radius, x: TElevation.low.x, y: TElevation.low.y)
    }
}
