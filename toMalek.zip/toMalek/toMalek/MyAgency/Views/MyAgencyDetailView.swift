//
//  MyAgencyDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct MyAgencyDetailView: View {
    @ObservedObject var viewModel: MyAgenciesViewModel
    let agency: MyAgencyModel
    @Environment(\.dismiss) private var dismiss
    @State private var showingEditSheet = false
    @State private var showingRatingSheet = false
    
    var body: some View {
        List {
            Section(String(localized: "general_info")) {
                MyAgencyDetailRow(
                    title: String(localized: "brand_name"),
                    value: agency.brandName,
                    icon: "building.2.fill"
                )
                
                MyAgencyDetailRow(
                    title: String(localized: "company_official_title"),
                    value: agency.officialName,
                    icon: "doc.text.fill"
                )
                
                MyAgencyDetailRow(
                    title: String(localized: "tax_number"),
                    value: agency.taxNumber,
                    icon: "number.circle.fill"
                )
                
                MyAgencyDetailRow(
                    title: String(localized: "manager"),
                    value: agency.managerName,
                    icon: "person.crop.circle.badge.checkmark"
                )
            }
            
            Section(String(localized: "contact")) {
                Button {
                    let formattedNumber = agency.phoneNumber.formatPhoneNumber()
                        .replacingOccurrences(of: " ", with: "")
                        .replacingOccurrences(of: "(", with: "")
                        .replacingOccurrences(of: ")", with: "")
                    guard let url = URL(string: "tel:\(formattedNumber)") else { return }
                    UIApplication.shared.open(url)
                } label: {
                    MyAgencyDetailRow(
                        title: String(localized: "phone"),
                        value: agency.phoneNumber.formatPhoneNumber(),
                        icon: "phone.fill",
                        showChevron: true
                    )
                }
                .foregroundColor(TColor.textPrimary)
                
                Button {
                    let formattedNumber = agency.secondaryPhone.formatPhoneNumber()
                        .replacingOccurrences(of: " ", with: "")
                        .replacingOccurrences(of: "(", with: "")
                        .replacingOccurrences(of: ")", with: "")
                    guard let url = URL(string: "tel:\(formattedNumber)") else { return }
                    UIApplication.shared.open(url)
                } label: {
                    MyAgencyDetailRow(
                        title: String(localized: "secondary_phone"),
                        value: agency.secondaryPhone.formatPhoneNumber(),
                        icon: "phone.fill",
                        showChevron: true
                    )
                }
                .foregroundColor(TColor.textPrimary)
                
                Button {
                    guard let url = URL(string: "mailto:\(agency.email)") else { return }
                    UIApplication.shared.open(url)
                } label: {
                    MyAgencyDetailRow(
                        title: String(localized: "email"),
                        value: agency.email,
                        icon: "envelope.fill",
                        showChevron: true
                    )
                }
                .foregroundColor(TColor.textPrimary)
            }
            
            Section(String(localized: "rating")) {
                if let rating = agency.averageRating {
                    VStack(alignment: .leading, spacing: TLayout.spacingS) {
                        HStack {
                            ForEach(1...5, id: \.self) { index in
                                Image(systemName: index <= Int(rating / 4) ? "star.fill" : "star")
                                    .foregroundColor(TColor.warning)
                                    .font(.system(size: 16))
                            }
                            Text(String(format: "%.1f", rating))
                                .font(TFont.bodyBold)
                                .foregroundColor(TColor.textPrimary)
                                .padding(.leading, TLayout.spacingS)
                        }
                        
                        if !agency.ratings.isEmpty {
                            Text(String(format: String(localized: "ratings"), agency.ratings.count))
                                .font(TFont.caption)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                    .padding(.vertical, TLayout.spacingS)
                } else {
                    Text(String(localized: "not_rated_yet"))
                        .foregroundColor(TColor.textSecondary)
                        .padding(.vertical, TLayout.spacingS)
                }
                
                Button {
                    showingRatingSheet = true
                } label: {
                    Text(String(localized: "rate"))
                        .frame(maxWidth: .infinity)
                        .font(TFont.bodyBold)
                }
                .buttonStyle(TButton.Primary())
            }
        }
        .background(TColor.background)
        .scrollContentBackground(.hidden)
        .navigationTitle(agency.brandName)
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack {
                    Button {
                        Task {
                            await viewModel.toggleFavorite(agency)
                        }
                    } label: {
                        Image(systemName: agency.isFavorite ? "star.fill" : "star")
                            .foregroundColor(TColor.warning)
                            .font(.system(size: TLayout.iconSize))
                    }
                    
                    Menu {
                        Button {
                            viewModel.loadAgencyData(agency)
                            showingEditSheet = true
                        } label: {
                            Label(String(localized: "edit"), systemImage: "pencil")
                                .foregroundColor(TColor.surface)
                        }
                        
                        Button(role: .destructive) {
                            viewModel.agencyToDelete = agency
                            viewModel.showDeleteConfirmation = true
                        } label: {
                            Label(String(localized: "delete"), systemImage: "trash")
                                .foregroundColor(TColor.error)
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundColor(TColor.areapolPrimary)
                    }
                }
            }
        }
        .sheet(isPresented: $showingRatingSheet) {
            NavigationView {
                AgencyRatingView(
                    viewModel: viewModel,
                    agency: agency
                ) { success in
                    showingRatingSheet = !success
                }
                .background(TColor.background)
            }
        }
        .sheet(isPresented: $showingEditSheet) {
            NavigationView {
                MyAgencyFormView(
                    viewModel: viewModel,
                    agency: agency
                ) { success in
                    if success {
                        showingEditSheet = false
                        dismiss()
                    }
                }
                .navigationTitle(String(localized: "edit_agency"))
                .navigationBarItems(
                    leading: Button(String(localized: "cancel")) {
                        showingEditSheet = false
                    }
                    .foregroundColor(TColor.areapolPrimary)
                )
                .background(TColor.background)
            }
        }
        .shadow(color: TElevation.low.color, radius: TElevation.low.radius, x: TElevation.low.x, y: TElevation.low.y)
    }
}
