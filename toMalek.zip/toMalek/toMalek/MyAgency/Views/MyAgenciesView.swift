//
//  MyAgenciesView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct MyAgenciesView: View {
    @StateObject private var viewModel = MyAgenciesViewModel()
    @State private var showingForm = false
    @State private var showingFindAgency = false
    
    var body: some View {
        VStack(spacing: 0) {
            Button {
                showingFindAgency = true
            } label: {
                HStack(spacing: TLayout.spacing) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: TLayout.iconSize))
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Text(String(localized: "find_agency"))
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .font(TFont.caption)
                        .foregroundColor(TColor.areapolSecondary)
                }
                .padding()
                .background(TColor.areapolPrimary.opacity(0.1))
                .cornerRadius(TLayout.cornerRadius)
            }
            .padding(.horizontal, TLayout.padding)
            .padding(.vertical, TLayout.padding)
            
            Picker(String(localized: "view_mode"), selection: $viewModel.selectedTab) {
                Text(String(localized: "all")).tag(0)
                Text(String(localized: "favorites")).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(TLayout.padding)
            .font(TFont.body)
            
            List {
                ForEach(viewModel.filteredAgencies) { agency in
                    NavigationLink {
                        MyAgencyDetailView(viewModel: viewModel, agency: agency)
                            .background(TColor.background)
                    } label: {
                        MyAgencyRowView(agency: agency)
                    }
                    .listRowBackground(TColor.background)
                }
                .onDelete { indexSet in
                    guard let index = indexSet.first else { return }
                    viewModel.agencyToDelete = viewModel.filteredAgencies[index]
                    viewModel.showDeleteConfirmation = true
                }
            }
            .scrollContentBackground(.hidden)
            .background(TColor.background)
        }
        .background(TColor.background)
        .navigationTitle(String(localized: "my_agencies"))
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    viewModel.clearForm()
                    showingForm = true
                } label: {
                    Image(systemName: "plus")
                        .foregroundColor(TColor.areapolPrimary)
                        .font(.system(size: TLayout.iconSize))
                }
            }
        }
        .sheet(isPresented: $showingForm) {
            NavigationView {
                MyAgencyFormView(
                    viewModel: viewModel,
                    agency: viewModel.selectedAgency
                ) { success in
                    if success {
                        showingForm = false
                    }
                }
                .navigationTitle(viewModel.selectedAgency == nil ?
                    String(localized: "new_agency") :
                    String(localized: "edit_agency"))
                .navigationBarItems(
                    leading: Button(String(localized: "cancel")) {
                        showingForm = false
                    }
                    .foregroundColor(TColor.areapolPrimary)
                )
                .background(TColor.background)
            }
        }
        .sheet(isPresented: $showingFindAgency) {
            NavigationView {
                FindAgencyView()
                    .background(TColor.background)
            }
        }
        .loadingOverlay(isLoading: viewModel.isLoading)
        .alert(String(localized: "error"), isPresented: .constant(viewModel.errorMessage != nil)) {
            Button(String(localized: "ok"), role: .cancel) {
                viewModel.errorMessage = nil
            }
        } message: {
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
        .confirmationDialog(
            String(localized: "delete_agency"),
            isPresented: $viewModel.showDeleteConfirmation,
            presenting: viewModel.agencyToDelete
        ) { agency in
            Button(String(localized: "delete"), role: .destructive) {
                Task {
                    await viewModel.deleteAgency(agency)
                }
            }
            Button(String(localized: "cancel"), role: .cancel) {}
        } message: { agency in
            Text(String(format: String(localized: "delete_confirmation"), agency.brandName))
                .font(TFont.body)
        }
    }
}

#Preview {
    NavigationView {
        MyAgenciesView()
    }
    .background(TColor.background)
}
