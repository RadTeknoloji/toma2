//
//  MyAgencyDetailRow.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct MyAgencyDetailRow: View {
    let title: String
    let value: String
    var icon: String? = nil
    var showChevron: Bool = false
    
    var body: some View {
        HStack(spacing: TLayout.spacingS) {
            if let icon = icon {
                Image(systemName: icon)
                    .foregroundColor(TColor.areapolPrimary)
                    .font(.system(size: 20))
                    .frame(width: 24)
            }
            
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(title)
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
                
                Text(value)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textPrimary)
            }
            
            if showChevron {
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 14))
                    .foregroundColor(TColor.textSecondary)
            }
        }
        .padding(.vertical, TLayout.spacingS)
    }
}

#Preview {
    VStack {
        MyAgencyDetailRow(
            title: String(localized: "sample_title"),
            value: String(localized: "sample_value"),
            icon: "person.fill"
        )
        
        MyAgencyDetailRow(
            title: String(localized: "clickable_area"),
            value: "+90 555 555 55 55",
            icon: "phone.fill",
            showChevron: true
        )
    }
    .padding()
    .background(TColor.background)
}
