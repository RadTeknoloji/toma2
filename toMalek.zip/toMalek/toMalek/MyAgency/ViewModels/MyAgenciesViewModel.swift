//
//  MyAgenciesViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import SwiftUI

@MainActor
final class MyAgenciesViewModel: ObservableObject {
    private let db = Firestore.firestore()
    let currentUserId = Auth.auth().currentUser?.uid
    
    @Published private(set) var agencies: [MyAgencyModel] = []
    @Published var selectedAgency: MyAgencyModel?
    @Published var showDeleteConfirmation = false
    @Published var agencyToDelete: MyAgencyModel?
    @Published var selectedTab: Int = 0
    
    @Published var currentRating: [AgencyRating.Criterion: Int] = [:]
    @Published var showRatingSheet = false
    
    @Published var officialName = ""
    @Published var brandName = ""
    @Published var taxNumber = ""
    @Published var managerName = ""
    @Published var phoneNumber = ""
    @Published var secondaryPhone = ""
    @Published var email = ""
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var filteredAgencies: [MyAgencyModel] {
        let uniqueAgencies = Array(Set(agencies))
        return selectedTab == 0 ? uniqueAgencies : uniqueAgencies.filter { $0.isFavorite }
    }
    
    init() {
        fetchAgencies()
    }
    
    var isValidForm: Bool {
        !officialName.isEmpty && officialName.count >= 3 &&
        !brandName.isEmpty &&
        isValidTaxNumber &&
        !managerName.isEmpty && managerName.count >= 3 &&
        isValidPhoneNumber &&
        isValidSecondaryPhone &&
        isValidEmail
    }
    
    private var isValidTaxNumber: Bool {
        let taxRegex = "^[0-9]{10}$"
        let taxPredicate = NSPredicate(format: "SELF MATCHES %@", taxRegex)
        return taxPredicate.evaluate(with: taxNumber)
    }
    
    private var isValidPhoneNumber: Bool {
        let cleanedNumber = phoneNumber.filter { $0.isNumber }
        return cleanedNumber.count >= 10
    }
    
    private var isValidSecondaryPhone: Bool {
        let cleanedNumber = secondaryPhone.filter { $0.isNumber }
        return cleanedNumber.count >= 10
    }
    
    private var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    func saveRating(for agency: MyAgencyModel) async -> Bool {
        guard let userId = currentUserId else {
            errorMessage = String(localized: "error_user_not_logged_in")
            return false
        }
        
        guard !currentRating.isEmpty else {
            errorMessage = String(localized: "error_rating_required")
            return false
        }
        
        let newRating = AgencyRating(
            userId: userId,
            ratings: currentRating
        )
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("agencies").document(agency.id.uuidString)
            
            let updateData: [String: Any] = [
                "ratings": FieldValue.arrayUnion([newRating.toDictionary()])
            ]
            
            try await ref.updateData(updateData)
            clearRating()
            fetchAgencies()
            
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_saving_rating"), error.localizedDescription)
            return false
        }
    }
    
    func clearRating() {
        currentRating.removeAll()
    }
    
    func bindingForCriterion(_ criterion: AgencyRating.Criterion) -> Binding<Int> {
        Binding(
            get: { self.currentRating[criterion] ?? 0 },
            set: { self.currentRating[criterion] = $0 }
        )
    }

    
    func fetchAgencies() {
        guard let userId = currentUserId else {
            errorMessage = String(localized: "error_user_not_logged_in")
            return
        }
        
        isLoading = true
        
        db.collection("agencies")
            .whereField("createdBy", isEqualTo: userId)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.errorMessage = String(format: String(localized: "error_fetching_data"), error.localizedDescription)
                    self.isLoading = false
                    return
                }
                
                var uniqueAgencies: Set<MyAgencyModel> = []
                querySnapshot?.documents.forEach { doc in
                    if let agency = try? doc.data(as: MyAgencyModel.self) {
                        uniqueAgencies.insert(agency)
                    }
                }
                
                self.agencies = Array(uniqueAgencies)
                self.isLoading = false
            }
    }
    
    func loadAgencyData(_ agency: MyAgencyModel) {
        officialName = agency.officialName
        brandName = agency.brandName
        taxNumber = agency.taxNumber
        managerName = agency.managerName
        phoneNumber = agency.phoneNumber
        secondaryPhone = agency.secondaryPhone
        email = agency.email
    }
    
    func clearForm() {
        officialName = ""
        brandName = ""
        taxNumber = ""
        managerName = ""
        phoneNumber = ""
        secondaryPhone = ""
        email = ""
        selectedAgency = nil
    }
    
    func createAgency() async -> Bool {
        guard let userId = currentUserId, isValidForm else {
            errorMessage = String(localized: "error_required_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        let newAgency = MyAgencyModel(
            officialName: officialName.uppercased(),
            brandName: brandName.uppercased(),
            taxNumber: taxNumber.uppercased(),
            managerName: managerName.uppercased(),
            phoneNumber: phoneNumber,
            secondaryPhone: secondaryPhone,
            email: email,
            ratings: [],
            isFavorite: false,
            createdBy: userId
        )
        
        do {
            let ref = db.collection("agencies").document(newAgency.id.uuidString)
            try ref.setData(from: newAgency)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_adding_agency"), error.localizedDescription)
            return false
        }
    }
    
    func updateAgency(_ agency: MyAgencyModel) async -> Bool {
        guard isValidForm else {
            errorMessage = String(localized: "error_required_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        let updatedAgency = MyAgencyModel(
            id: agency.id,
            officialName: officialName.uppercased(),
            brandName: brandName.uppercased(),
            taxNumber: taxNumber.uppercased(),
            managerName: managerName.uppercased(),
            phoneNumber: phoneNumber,
            secondaryPhone: secondaryPhone,
            email: email,
            ratings: agency.ratings,
            isFavorite: agency.isFavorite,
            createdBy: agency.createdBy
        )
        
        do {
            let ref = db.collection("agencies").document(agency.id.uuidString)
            try ref.setData(from: updatedAgency)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_updating_agency"), error.localizedDescription)
            return false
        }
    }
    
    func toggleFavorite(_ agency: MyAgencyModel) async {
        isLoading = true
        defer { isLoading = false }
        
        let updatedAgency = MyAgencyModel(
            id: agency.id,
            officialName: agency.officialName,
            brandName: agency.brandName,
            taxNumber: agency.taxNumber,
            managerName: agency.managerName,
            phoneNumber: agency.phoneNumber,
            secondaryPhone: agency.secondaryPhone,
            email: agency.email,
            ratings: agency.ratings,
            isFavorite: !agency.isFavorite,
            createdBy: agency.createdBy
        )
        
        do {
            let ref = db.collection("agencies").document(agency.id.uuidString)
            try ref.setData(from: updatedAgency)
        } catch {
            errorMessage = String(format: String(localized: "error_updating_favorite"), error.localizedDescription)
        }
    }
    
    func deleteAgency(_ agency: MyAgencyModel) async {
        isLoading = true
        defer {
            isLoading = false
            agencyToDelete = nil
        }
        
        do {
            let ref = db.collection("agencies").document(agency.id.uuidString)
            try await ref.delete()
        } catch {
            errorMessage = String(format: String(localized: "error_deleting"), error.localizedDescription)
        }
    }
}
