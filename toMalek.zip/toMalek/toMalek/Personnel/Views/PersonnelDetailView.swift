//
//  PersonnelDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI
import FirebaseFirestore

struct PersonnelDetailView: View {
    @ObservedObject var viewModel: PersonnelViewModel
    @State var personnel: PersonnelModel
    @Environment(\.dismiss) private var dismiss
    @State private var showingEditSheet = false
    @State private var showingPropertySelection = false
    @State private var showingEndDatePicker = false
    
    var body: some View {
        List {
            // Header Section
            Section {
                VStack(alignment: .leading, spacing: TLayout.spacingM) {
                    HStack(alignment: .center) {
                        Text(personnel.fullName)
                            .font(TFont.h2)
                            .foregroundColor(TColor.textPrimary)
                        
                        Spacer()
                        
                        Text(personnel.status.localizedKey)
                            .font(TFont.caption)
                            .foregroundColor(.white)
                            .padding(.horizontal, TLayout.paddingS)
                            .padding(.vertical, TLayout.paddingXS)
                            .background(personnel.status == .active ? TColor.success : TColor.error)
                            .cornerRadius(TLayout.cornerRadiusS)
                    }
                    
                    Text(personnel.personnelNumber)
                        .font(TFont.footnote)
                        .foregroundColor(TColor.textSecondary)
                }
                .padding(.vertical, TLayout.paddingS)
            }
            .listRowBackground(TColor.surface)
            .listRowInsets(EdgeInsets(top: 0, leading: TLayout.paddingS, bottom: 0, trailing: TLayout.paddingS))
            
            // İletişim Bilgileri
            Section {
                VStack(spacing: TLayout.spacingM) {
                    ContactInfoRow(
                        icon: "phone.fill",
                        title: String(localized: "phone_number"),
                        value: personnel.formattedPhoneNumber,
                        action: { callPhoneNumber(personnel.phoneNumber) }
                    )
                    
                    ContactInfoRow(
                        icon: "envelope.fill",
                        title: String(localized: "email_address"),
                        value: personnel.email
                    )
                }
                .padding(.vertical, TLayout.paddingS)
            }
            .listRowBackground(TColor.surface)
            
            // İstihdam Bilgileri
            Section {
                VStack(spacing: TLayout.spacingM) {
                    EmploymentInfoRow(
                        icon: "calendar",
                        title: String(localized: "start_date"),
                        value: personnel.formattedStartDate
                    )
                    
                    if let endDate = personnel.formattedEndDate {
                        EmploymentInfoRow(
                            icon: "calendar.badge.clock",
                            title: String(localized: "end_date"),
                            value: endDate
                        )
                    }
                }
                .padding(.vertical, TLayout.paddingS)
            }
            .listRowBackground(TColor.surface)
            
            // İlgilendiği Mülkler
            Section {
                ForEach(viewModel.properties.filter { property in
                    personnel.propertyIds.contains(property.id.uuidString)
                }) { property in
                    NavigationLink {
                        PropertyDetailView(property: property)
                            .task {
                                // View yüklendiğinde property detaylarını yükle
                                await viewModel.fetchProperties()
                            }
                    } label: {
                        PropertyListItem(property: property, assignmentDate: personnel.propertyAssignmentDates[property.id.uuidString])
                    }
                }
                
                if personnel.status == .active {
                    Button {
                        showingPropertySelection = true
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                                .foregroundColor(TColor.areapolPrimary)
                            Text(String(localized: "add_property"))
                                .font(TFont.bodyBold)
                                .foregroundColor(TColor.areapolPrimary)
                        }
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.vertical, TLayout.paddingS)
                    }
                }
            }
            .listRowBackground(TColor.surface)
            
            if personnel.status == .active {
                Section {
                    Button {
                        showingEndDatePicker = true
                    } label: {
                        Text(String(localized: "terminate_employment"))
                            .frame(maxWidth: .infinity)
                            .font(TFont.bodyBold)
                    }
                    .buttonStyle(Theme.ButtonStyles.Destructive())
                }
                .listRowBackground(TColor.surface)
            }
        }
        .background(TColor.background)
        .scrollContentBackground(.hidden)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if personnel.status == .active {
                ToolbarItem(placement: .navigationBarTrailing) {
                    editButton
                }
            }
        }
        
        .task {
            // View her görüntülendiğinde personel ve mülk verilerini güncelle
            await refreshData()
        }
        .sheet(isPresented: $showingPropertySelection) {
            PropertySelectionView(viewModel: viewModel, personnel: personnel)
                .onDisappear {
                    Task {
                        await refreshData()
                    }
                }
        }
        .onChange(of: showingPropertySelection) { oldValue, newValue in
            if !newValue {
                Task {
                    await refreshData()
                }
            }
        }
        
        .sheet(isPresented: $showingEditSheet) {
            PersonnelFormView(viewModel: viewModel, personnel: personnel) { success in
                if success {
                    dismiss()
                }
            }
        }
        .sheet(isPresented: $showingEndDatePicker) {
            EndDatePickerView(
                viewModel: viewModel,
                personnel: personnel,
                isPresented: $showingEndDatePicker
            )
        }
    }
    
    // MARK: - Helper Functions
    private func refreshData() async {
        await withTaskGroup(of: Void.self) { group in
            group.addTask { await viewModel.fetchProperties() }
            group.addTask { await viewModel.fetchPersonnel() }
        }
        
        if let updatedPersonnel = viewModel.personnel.first(where: { $0.id == personnel.id }) {
            self.personnel = updatedPersonnel
        }
    }
    
    private var editButton: some View {
        Button(String(localized: "edit")) {
            showingEditSheet = true
        }
        .font(TFont.bodyBold)
        .foregroundColor(TColor.areapolPrimary)
    }
    
    private func callPhoneNumber(_ number: String) {
        let formattedNumber = number.formatPhoneNumber()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "(", with: "")
            .replacingOccurrences(of: ")", with: "")
        guard let url = URL(string: "tel:\(formattedNumber)") else { return }
        UIApplication.shared.open(url)
    }
}

// MARK: - Helper Views
struct ContactInfoRow: View {
    let icon: String
    let title: String
    let value: String
    var action: (() -> Void)? = nil
    
    var body: some View {
        Button(action: { action?() }) {
            HStack(spacing: TLayout.spacingS) {
                Image(systemName: icon)
                    .font(.system(size: 16))
                    .foregroundColor(TColor.areapolSecondary)
                    .frame(width: 24)
                
                VStack(alignment: .leading, spacing: TLayout.spacingXXS) {
                    Text(title)
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                    
                    Text(value)
                        .font(TFont.body)
                        .foregroundColor(TColor.textPrimary)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

struct EmploymentInfoRow: View {
    let icon: String
    let title: String
    let value: String
    
    var body: some View {
        HStack(spacing: TLayout.spacingS) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(TColor.areapolSecondary)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: TLayout.spacingXXS) {
                Text(title)
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
                
                Text(value)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
            }
        }
    }
}

struct PropertyListItem: View {
    let property: PropertyModel
    let assignmentDate: Timestamp?
    
    private var formattedDuration: String {
        guard let assignedDate = assignmentDate else { return "" }
        
        let duration = Calendar.current.dateComponents([.day, .hour], from: assignedDate.dateValue(), to: Date())
        let days = duration.day ?? 0
        let hours = duration.hour ?? 0
        
        if days > 0 {
            return String(format: String(localized: "duration_days_hours"), days, hours)
        } else {
            return String(format: String(localized: "duration_hours"), hours)
        }
    }
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                Text(property.title)
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                if let address = property.formattedAddress {
                    Text(address)
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                }
            }
            
            Spacer()
            
            if assignmentDate != nil {
                Text(formattedDuration)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                    .padding(.horizontal, TLayout.paddingXS)
                    .padding(.vertical, 4)
                    .background(TColor.border.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadiusXS)
            }
        }
        .padding(.vertical, TLayout.paddingXS)
    }
}

struct EndDatePickerView: View {
    @ObservedObject var viewModel: PersonnelViewModel
    let personnel: PersonnelModel
    @Binding var isPresented: Bool
    
    var body: some View {
        NavigationView {
            Form {
                DatePicker(
                    String(localized: "end_date"),
                    selection: Binding(
                        get: { viewModel.endDate ?? Date() },
                        set: { viewModel.endDate = $0 }
                    ),
                    in: personnel.startDate...,
                    displayedComponents: .date
                )
                .datePickerStyle(.graphical)
                
                Button {
                    Task {
                        let success = await viewModel.updatePersonnel(personnel)
                        if success {
                            isPresented = false
                        }
                    }
                } label: {
                    Text(String(localized: "confirm_termination"))
                        .frame(maxWidth: .infinity)
                        .font(TFont.bodyBold)
                }
                .buttonStyle(Theme.ButtonStyles.Destructive())
            }
            .navigationTitle(String(localized: "select_end_date"))
            .navigationBarItems(
                trailing: Button(String(localized: "cancel")) {
                    isPresented = false
                }
                .font(TFont.bodyBold)
                .foregroundColor(TColor.areapolPrimary)
            )
        }
    }
}
