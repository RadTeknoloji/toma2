//
//  PersonnelRowView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI

// MARK: - Personel Satır Görünümü
struct PersonnelRowView: View {
    let personnel: PersonnelModel
    
    var body: some View {
        HStack(spacing: TLayout.spacingM) {
            // Avatar/İkon
            ZStack {
                Circle()
                    .fill(TColor.areapolPrimary.opacity(0.1))
                    .frame(width: 48, height: 48)
                
                Text(personnel.fullName.prefix(1).uppercased())
                    .font(TFont.h2)
                    .foregroundColor(TColor.areapolPrimary)
            }
            
            // Bilgi Alanı
            VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                // İsim ve Durum
                HStack {
                    Text(personnel.fullName)
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                    
                    Spacer()
                    
                    PersonnelStatusBadge(status: personnel.status)
                }
                
                // Personel Numarası
                Text(personnel.personnelNumber)
                    .font(TFont.body)
                    .foregroundColor(TColor.textSecondary)
                
                // Alt Bilgiler
                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                    // İletişim
                    if !personnel.phoneNumber.isEmpty {
                        HStack(spacing: TLayout.spacingXS) {
                            Image(systemName: "phone.fill")
                                .foregroundColor(.green)
                            Text(personnel.formattedPhoneNumber)
                                .font(TFont.caption)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                    
                    // Başlangıç Tarihi
                    HStack(spacing: TLayout.spacingXS) {
                        Image(systemName: "calendar")
                            .foregroundColor(.blue)
                        Text(personnel.formattedStartDate)
                            .font(TFont.caption)
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
        }
        .padding(TLayout.paddingS)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}

struct PersonnelStatusBadge: View {
    let status: PersonnelStatus
    
    var body: some View {
        Text(status.localizedKey)
            .font(TFont.caption)
            .foregroundColor(.white)
            .padding(.horizontal, TLayout.paddingXS)
            .padding(.vertical, 4)
            .background(statusBackground)
            .cornerRadius(TLayout.cornerRadiusS)
    }
    
    private var statusBackground: Color {
        switch status {
        case .active:
            return TColor.success
        case .inactive:
            return TColor.warning
        }
    }
}
