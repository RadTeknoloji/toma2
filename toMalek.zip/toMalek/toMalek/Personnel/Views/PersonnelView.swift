//
//  PersonnelView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct PersonnelView: View {
    @StateObject private var viewModel: PersonnelViewModel
    @State private var isShowingPersonnelForm = false
    @State private var selectedPersonnel: PersonnelModel?
    @EnvironmentObject var authState: AuthenticationState
    
    init(authState: AuthenticationState) {
        let viewModel = PersonnelViewModel.create()
        _viewModel = StateObject(wrappedValue: viewModel)
    }
    
    static func createDefault() -> PersonnelView {
        return PersonnelView(authState: AuthenticationState.shared)
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: TLayout.spacingS) {
                    ForEach(viewModel.personnel) { personnel in
                        personnelLink(for: personnel)
                    }
                }
                .padding(.horizontal, TLayout.paddingS)
            }
            .background(TColor.background)
            .navigationTitle(String(localized: "personnel"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        viewModel.clearForm()
                        isShowingPersonnelForm = true
                    } label: {
                        Image(systemName: "plus")
                            .font(.system(size: TLayout.iconSize))
                            .foregroundColor(TColor.areapolPrimary)
                    }
                }
            }
            .sheet(isPresented: $isShowingPersonnelForm) {
                Task {
                    await viewModel.fetchPersonnel()
                }
            } content: {
                NavigationStack {
                    PersonnelFormView(
                        viewModel: viewModel,
                        personnel: viewModel.selectedPersonnel,
                        onSave: { success in
                            if success {
                                Task {
                                    await viewModel.fetchPersonnel()
                                    isShowingPersonnelForm = false
                                }
                            }
                        }
                    )
                    .environmentObject(authState)
                    .navigationTitle(viewModel.selectedPersonnel == nil ?
                        String(localized: "new_personnel") :
                        String(localized: "edit_personnel"))
                    .navigationBarItems(
                        leading: Button(String(localized: "cancel")) {
                            isShowingPersonnelForm = false
                        }
                        .foregroundColor(TColor.areapolPrimary)
                    )
                    .background(TColor.background)
                }
            }
        }
        .task {
            await viewModel.fetchPersonnel()
            await viewModel.fetchProperties()
        }
        .onChange(of: isShowingPersonnelForm) { oldValue, newValue in
            if !newValue {
                Task {
                    await viewModel.fetchPersonnel()
                }
            }
        }
        .background(TColor.background)
        .alert(String(localized: "error"),
               isPresented: Binding(
                   get: { viewModel.errorMessage != nil },
                   set: { if !$0 { viewModel.errorMessage = nil } }
               )
        ) {
            Button(String(localized: "ok"), role: .cancel) {
                viewModel.errorMessage = nil
            }
        } message: {
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
        .confirmationDialog(
            String(localized: "delete_personnel"),
            isPresented: $viewModel.showDeleteConfirmation,
            presenting: viewModel.personnelToDelete
        ) { personnel in
            Button(String(localized: "delete"), role: .destructive) {
                Task {
                    await viewModel.deletePersonnel(personnel)
                }
            }
            Button(String(localized: "cancel_action"), role: .cancel) {}
        } message: { personnel in
            Text(String(format: String(localized: "confirm_delete_personnel"), personnel.fullName))
                .font(TFont.body)
        }
    }
    
    private func personnelLink(for personnel: PersonnelModel) -> some View {
        NavigationLink {
            PersonnelDetailView(viewModel: viewModel, personnel: personnel)
                .background(TColor.background)
                .environmentObject(authState)
                .onDisappear {
                    Task {
                        await viewModel.fetchPersonnel()
                    }
                }
        } label: {
            PersonnelRowView(personnel: personnel)
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button(role: .destructive) {
                viewModel.personnelToDelete = personnel
                viewModel.showDeleteConfirmation = true
            } label: {
                Label(String(localized: "delete"), systemImage: "trash")
            }
        }
    }
}

struct LoadingOverlay: ViewModifier {
    let isLoading: Bool
    
    func body(content: Content) -> some View {
        ZStack {
            content
                .disabled(isLoading)
            
            if isLoading {
                TColor.border.opacity(0.8)
                    .ignoresSafeArea()
                
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: TColor.surfaceDark))
                    .padding()
                    .background(TColor.border.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadius)
            }
        }
    }
}

extension View {
    func loadingOverlay(isLoading: Bool) -> some View {
        modifier(LoadingOverlay(isLoading: isLoading))
    }
}
