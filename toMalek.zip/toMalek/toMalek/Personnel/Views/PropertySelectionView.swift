//
//  PropertySelectionView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI

struct PropertySelectionView: View {
    @ObservedObject var viewModel: PersonnelViewModel
    @State var personnel: PersonnelModel
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var authState: AuthenticationState
    @State private var selectedProperties: Set<PropertyModel> = []
    @State private var isProcessing = false
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(viewModel.properties) { property in
                        propertyRow(property: property)
                            .listRowBackground(TColor.background)
                            .listRowInsets(EdgeInsets(
                                top: TLayout.paddingXS,
                                leading: TLayout.paddingS,
                                bottom: TLayout.paddingXS,
                                trailing: TLayout.paddingS
                            ))
                    }
                }
                .scrollContentBackground(.hidden)
                .listStyle(.plain)
                
                Button {
                    saveChanges()
                } label: {
                    if isProcessing {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text(String(localized: "done"))
                            .font(TFont.bodyBold)
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, TLayout.paddingS)
                .background(isProcessing ? TColor.areapolPrimary.opacity(0.7) : TColor.areapolPrimary)
                .cornerRadius(TLayout.cornerRadius)
                .padding(.horizontal, TLayout.padding)
                .padding(.bottom, TLayout.paddingS)
                .disabled(isProcessing)
            }
            .background(TColor.background)
            .navigationTitle(String(localized: "select_property"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(String(localized: "cancel")) {
                        dismiss()
                    }
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.areapolPrimary)
                    .disabled(isProcessing)
                }
            }
            .task {
                // Başlangıçta mevcut seçimleri yükle
                selectedProperties = Set(viewModel.properties.filter { property in
                    personnel.propertyIds.contains(property.id.uuidString)
                })
                await viewModel.fetchProperties()
            }
        }

    }
    
    private func propertyRow(property: PropertyModel) -> some View {
        let isSelected = selectedProperties.contains(property)
        
        return Button {
            handlePropertySelection(property: property)
        } label: {
            HStack(spacing: TLayout.spacingM) {
                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                    Text(property.title)
                        .font(TFont.bodyBold)
                        .foregroundColor(TColor.textPrimary)
                    
                    Text(property.ownerName)
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                    
                    if let address = property.formattedAddress {
                        Text(address)
                            .font(TFont.caption)
                            .foregroundColor(TColor.textSecondary)
                            .lineLimit(1)
                    }
                }
                
                Spacer()
                
                // Seçim İkonu
                ZStack {
                    Circle()
                        .stroke(isSelected ? TColor.areapolPrimary : TColor.border, lineWidth: 2)
                        .frame(width: 24, height: 24)
                    
                    if isSelected {
                        Circle()
                            .fill(TColor.areapolPrimary)
                            .frame(width: 16, height: 16)
                    }
                }
            }
            .padding(TLayout.paddingS)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
        .buttonStyle(.plain)
        .disabled(isProcessing)
    }
    
    private func handlePropertySelection(property: PropertyModel) {
        if selectedProperties.contains(property) {
            selectedProperties.remove(property)
        } else {
            selectedProperties.insert(property)
        }
    }
    
    private func saveChanges() {
        Task {
            isProcessing = true
            
            // Eski seçimleri bul
            let oldSelection = Set(viewModel.properties.filter { property in
                personnel.propertyIds.contains(property.id.uuidString)
            })
            
            // Yeni eklenecek ve silinecek property'leri belirle
            let toAdd = selectedProperties.subtracting(oldSelection)
            let toRemove = oldSelection.subtracting(selectedProperties)
            
            // Ekle ve sil
            if !toAdd.isEmpty {
                await viewModel.assignPropertiesToPersonnel(Array(toAdd), personnel: personnel)
            }
            
            if !toRemove.isEmpty {
                await viewModel.removePropertiesFromPersonnel(Array(toRemove), personnel: personnel)
            }
            
            // Personnel'i güncelle
            await viewModel.fetchPersonnel()
            await viewModel.fetchProperties()
            if let updatedPersonnel = viewModel.personnel.first(where: { $0.id == personnel.id }) {
                personnel = updatedPersonnel
            }
            
            isProcessing = false
            dismiss()
        }
    }
}
