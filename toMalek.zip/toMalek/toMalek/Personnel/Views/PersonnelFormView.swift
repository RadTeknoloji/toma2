//
//  PersonnelFormView.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI

struct PersonnelFormView: View {
    @ObservedObject var viewModel: PersonnelViewModel
    var personnel: PersonnelModel?
    var onSave: (Bool) -> Void
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        Form {
            personalInfoSection
            employmentSection
            saveButtonSection
        }
        .scrollDismissesKeyboard(.immediately)
        .background(TColor.background)
        .scrollContentBackground(.hidden)
        .navigationTitle(personnel == nil ?
            String(localized: "add_new_personnel") :
            String(localized: "edit_personnel"))
    }
    
    // MARK: - Form Sections
    private var personalInfoSection: some View {
        Section(String(localized: "personal_information")) {
            fullNameField
            phoneNumberField
            emailField
        }
        .listRowBackground(TColor.border.opacity(0.1))
    }
    
    private var employmentSection: some View {
        Section(String(localized: "employment_information")) {
            DatePicker(
                String(localized: "start_date"),
                selection: $viewModel.startDate,
                displayedComponents: .date
            )
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
        }
        .listRowBackground(TColor.border.opacity(0.1))
    }
    
    private var saveButtonSection: some View {
        Section {
            Button {
                savePersonnel()
            } label: {
                Text(String(localized: "save"))
                    .frame(maxWidth: .infinity)
                    .font(TFont.bodyBold)
            }
            .buttonStyle(TButton.Primary())
            .disabled(!isFormValid)
        }
    }
    
    // MARK: - Form Fields
    private var fullNameField: some View {
        TextField(String(localized: "full_name"), text: $viewModel.fullName)
            .textContentType(.name)
            .autocapitalization(.words)
            .disableAutocorrection(true)
            .overlay(alignment: .trailing) {
                if !viewModel.fullName.isEmpty && !isValidFullName {
                    Image(systemName: "exclamationmark.circle")
                        .foregroundColor(TColor.error)
                        .help(String(localized: "error_fullname"))
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
    }
    
    private var phoneNumberField: some View {
        PhoneInputView(
            text: $viewModel.phoneNumber,
            label: "phone_number",
            placeholder: "phone_number_placeholder",
            error: !isValidPhone ? "error_phone" : nil
        )
    }
    
    private var emailField: some View {
        TextField(String(localized: "email_address"), text: $viewModel.email)
            .textContentType(.emailAddress)
            .keyboardType(.emailAddress)
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .overlay(alignment: .trailing) {
                if !viewModel.email.isEmpty && !isValidEmail {
                    Image(systemName: "exclamationmark.circle")
                        .foregroundColor(TColor.error)
                        .help(String(localized: "error_email"))
                }
            }
            .font(TFont.body)
            .foregroundColor(TColor.surfaceDark)
    }
    
    // MARK: - Validation
    private var isValidFullName: Bool {
        viewModel.fullName.count >= 3
    }
    
    private var isValidPhone: Bool {
        let cleanNumber = viewModel.phoneNumber.filter { $0.isNumber }
        return cleanNumber.count >= 10 && cleanNumber.count <= 13
    }
    
    private var isValidEmail: Bool {
        let emailRegex = #"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"#
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: viewModel.email)
    }
    
    private var isFormValid: Bool {
        isValidFullName &&
        isValidPhone &&
        isValidEmail
    }
    
    // MARK: - Actions
    private func savePersonnel() {
        guard let userId = viewModel.currentUserId else {
            print("User not authenticated")
            return
        }
        
        let newPersonnel = PersonnelModel(
            id: personnel?.id ?? UUID(),
            fullName: viewModel.fullName,
            phoneNumber: viewModel.phoneNumber,
            email: viewModel.email,
            personnelNumber: personnel?.personnelNumber ?? PersonnelModel.generatePersonnelNumber(),
            createdBy: userId,
            propertyIds: personnel?.propertyIds ?? [],
            startDate: viewModel.startDate,
            endDate: nil,
            status: .active
        )
        
        Task {
            let success = personnel == nil ?
                await viewModel.createPersonnel(newPersonnel) :
                await viewModel.updatePersonnel(newPersonnel)
            onSave(success)
            if success {
                dismiss()
            }
        }
    }
}
