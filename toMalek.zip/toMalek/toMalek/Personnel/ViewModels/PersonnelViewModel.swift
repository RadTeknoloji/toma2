//
//  PersonnelViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import SwiftUI



@MainActor
final class PersonnelViewModel: ObservableObject {
    // MARK: - Services
    private let db = Firestore.firestore()
    private let propertyService: PropertyService
    let currentUserId: String? = Auth.auth().currentUser?.uid
    let authState: AuthenticationState
    
    // MARK: - Published Properties
    @Published var personnel: [PersonnelModel] = []
    @Published var properties: [PropertyModel] = []
    @Published var selectedPersonnel: PersonnelModel?
    @Published var showDeleteConfirmation = false
    @Published var personnelToDelete: PersonnelModel?
    @Published var showEndDatePicker = false
    
    @Published var fullName = ""
    @Published var phoneNumber = ""
    @Published var email = ""
    @Published var startDate = Date()
    @Published var endDate: Date?
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    // Private init
    private init(
        authState: AuthenticationState,
        propertyService: PropertyService
    ) {
        self.authState = authState
        self.propertyService = propertyService
        Task {
            await fetchPersonnel()
        }
    }
    
    // Public factory method
    @MainActor
    static func create() -> PersonnelViewModel {
        return PersonnelViewModel(
            authState: AuthenticationState.shared,
            propertyService: ServiceContainer.shared.propertyService
        )
    }
    
    // MARK: - Form Validation
    var isValidFullName: Bool {
        !fullName.isEmpty && fullName.count >= 3
    }
    
    var isValidPhoneNumber: Bool {
        let phoneRegex = "^\\+?\\d{1,3}?[-. ]?\\(?\\d{3}\\)?[-. ]?\\d{3}[-. ]?\\d{4,6}$"
        let phonePredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phonePredicate.evaluate(with: phoneNumber)
    }
    
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    var isValidForm: Bool {
        isValidFullName &&
        isValidPhoneNumber &&
        isValidEmail
    }
    
    // MARK: - Form Methods
    func loadPersonnelData(_ personnel: PersonnelModel) {
        fullName = personnel.fullName
        phoneNumber = personnel.phoneNumber
        email = personnel.email
        startDate = personnel.startDate
        endDate = personnel.endDate
    }
    
    func clearForm() {
        fullName = ""
        phoneNumber = ""
        email = ""
        startDate = Date()
        endDate = nil
        selectedPersonnel = nil
    }
    
    // MARK: - CRUD Operations
    func fetchPersonnel() async {
        guard let userId = currentUserId else { return }
        
        do {
            let snapshot = try await db.collection("personnel")
                .whereField("createdBy", isEqualTo: userId)
                .getDocuments()
            
            var fetchedPersonnel: [PersonnelModel] = []
            
            for document in snapshot.documents {
                let data = document.data()
                
                var modifiedData = data  // direkt olarak data'yı kullan
                modifiedData["id"] = document.documentID
                                    
                if let personnel = try? Firestore.Decoder().decode(PersonnelModel.self, from: modifiedData) {
                    fetchedPersonnel.append(personnel)
                }
            }
            
            await MainActor.run {
                self.personnel = fetchedPersonnel
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }
    
    func fetchProperties() async {
        guard let currentUserId = currentUserId else { return }
        
        do {
            let fetchedProperties = try await propertyService.fetchProperties()
            
            let filteredProperties = fetchedProperties.filter { property in
                // 1. Kullanıcının kendi oluşturduğu mülk VE aktif rolüyle oluşturmuş
                if property.createdBy == currentUserId && property.createdByUserType.rawValue == authState.userType {
                    return true
                }
                
                // 2. Match durumuna göre görüntüleme
                if let matchStatus = property.matchStatus {
                    switch matchStatus {
                    case .tenantOwner:
                        // Kiracı-Mal Sahibi eşleşmesi
                        if property.createdByUserType == .owner && authState.userType == "tenant" {
                            return true
                        }
                        if property.createdByUserType == .tenant && authState.userType == "owner" {
                            return true
                        }
                    case .tenantAgent:
                        // Kiracı-Emlakçı eşleşmesi
                        if property.createdByUserType == .tenant && authState.userType == "agency" {
                            return true
                        }
                        if property.createdByUserType == .agency && authState.userType == "tenant" {
                            return true
                        }
                    case .ownerAgent:
                        // Mal Sahibi-Emlakçı eşleşmesi
                        if property.createdByUserType == .owner && authState.userType == "agency" {
                            return true
                        }
                        if property.createdByUserType == .agency && authState.userType == "owner" {
                            return true
                        }
                    case .ownerAgentTenant:
                        // Mal Sahibi-Emlakçı-Kiracı eşleşmesi (3'lü match)
                        if property.createdByUserType == .owner && (authState.userType == "agency" || authState.userType == "tenant") {
                            return true
                        }
                        if property.createdByUserType == .tenant && (authState.userType == "agency" || authState.userType == "owner") {
                            return true
                        }
                        if property.createdByUserType == .agency && (authState.userType == "owner" || authState.userType == "tenant") {
                            return true
                        }
                    }
                }
                
                return false
            }
            
            await MainActor.run {
                self.properties = filteredProperties
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }
    
    // MARK: - Property Assignment Methods
    func assignPropertiesToPersonnel(_ properties: [PropertyModel], personnel: PersonnelModel) async {
        do {
            var updatedPersonnel = personnel
            let currentTime = Date()
            
            // Yeni property'leri ekle
            for property in properties {
                if !updatedPersonnel.propertyIds.contains(property.id.uuidString) {
                    updatedPersonnel.propertyIds.append(property.id.uuidString)
                    updatedPersonnel.propertyAssignmentDates[property.id.uuidString] = Timestamp(date: currentTime)
                }
            }
            
            try db.collection("personnel").document(personnel.id.uuidString).setData(from: updatedPersonnel)
            await fetchPersonnel()
        } catch {
            errorMessage = String(localized: "error_assigning_property")
        }
    }
    
    func removePropertiesFromPersonnel(_ properties: [PropertyModel], personnel: PersonnelModel) async {
        do {
            var updatedPersonnel = personnel
            
            // Property'leri kaldır
            for property in properties {
                updatedPersonnel.propertyIds.removeAll { $0 == property.id.uuidString }
                updatedPersonnel.propertyAssignmentDates.removeValue(forKey: property.id.uuidString)
            }
            
            try db.collection("personnel").document(personnel.id.uuidString).setData(from: updatedPersonnel)
            await fetchPersonnel()
        } catch {
            errorMessage = String(localized: "error_removing_property")
        }
    }
    
    // Eski fonksiyonları da tutalım geriye dönük uyumluluk için
    func assignPropertyToPersonnel(_ property: PropertyModel, personnel: PersonnelModel) async {
        await assignPropertiesToPersonnel([property], personnel: personnel)
    }
    
    func removePropertyFromPersonnel(_ property: PropertyModel, personnel: PersonnelModel) async {
        await removePropertiesFromPersonnel([property], personnel: personnel)
    }
    
    // MARK: - Personnel Operations
    func createPersonnel(_ personnel: PersonnelModel) async -> Bool {
        guard isValidForm else {
            errorMessage = String(localized: "fill_all_fields")
            return false
        }
        
        var newPersonnel = personnel
        newPersonnel.createdBy = currentUserId ?? ""
        newPersonnel.personnelNumber = PersonnelModel.generatePersonnelNumber()
        newPersonnel.status = .active
        
        do {
            let personnelRef = db.collection("personnel").document(newPersonnel.id.uuidString)
            try personnelRef.setData(from: newPersonnel)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_creating_personnel"), localizeError(error))
            return false
        }
    }
    
    func updatePersonnel(_ personnel: PersonnelModel) async -> Bool {
        guard isValidForm else {
            errorMessage = String(localized: "fill_all_fields")
            return false
        }
        
        var updatedPersonnel = personnel
        updatedPersonnel.fullName = fullName
        updatedPersonnel.phoneNumber = phoneNumber
        updatedPersonnel.email = email
        updatedPersonnel.startDate = startDate
        updatedPersonnel.endDate = endDate
        
        do {
            let personnelRef = db.collection("personnel").document(personnel.id.uuidString)
            try personnelRef.setData(from: updatedPersonnel)
            return true
        } catch {
            errorMessage = String(format: String(localized: "error_updating_personnel"), localizeError(error))
            return false
        }
    }
    
    func deletePersonnel(_ personnel: PersonnelModel) async {
        do {
            try await db.collection("personnel").document(personnel.id.uuidString).delete()
            await fetchPersonnel()
        } catch {
            errorMessage = String(format: String(localized: "error_deleting_personnel"), localizeError(error))
        }
    }
    
    // MARK: - Helper Methods
    private func localizeError(_ error: Error) -> String {
        // Firebase hatalarını localize et
        return error.localizedDescription
    }
    
    private func formatPhoneNumber(_ number: String) -> String {
        // Telefon numarasını formatla
        return number.filter { $0.isNumber }
    }
}
