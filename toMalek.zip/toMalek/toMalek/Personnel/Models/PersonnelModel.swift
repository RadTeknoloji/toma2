//
//  PersonnelModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseFirestore

// MARK: - Personnel Status
enum PersonnelStatus: String, Codable, CaseIterable {
    case active = "active"
    case inactive = "inactive"
    
    var localizedKey: String {
        switch self {
        case .active:
            return String(localized: "personnel_status_active")
        case .inactive:
            return String(localized: "personnel_status_inactive")
        }
    }
}

struct PersonnelModel: Codable, Identifiable, Hashable {
    let id: UUID
    var fullName: String
    var phoneNumber: String
    var email: String
    var personnelNumber: String
    var createdBy: String
    var propertyIds: [String] // İlgilendiği mülk ID'leri
    var propertyAssignmentDates: [String: Timestamp] // Property ID -> Atanma tarihi
    
    // Yeni alanlar
    var startDate: Date
    var endDate: Date?
    var status: PersonnelStatus
    
    var formattedPhoneNumber: String {
        phoneNumber.formatPhoneNumber()
    }
    
    var formattedStartDate: String {
        startDate.formatted(date: .long, time: .omitted)
    }
    
    var formattedEndDate: String? {
        endDate?.formatted(date: .long, time: .omitted)
    }
    
    static func generatePersonnelNumber() -> String {
        // 5 haneli personel numarası üret
        let number = Int.random(in: 10000..<99999)
        return String(number)
    }
    
    init(id: UUID = UUID(),
         fullName: String,
         phoneNumber: String,
         email: String,
         personnelNumber: String = PersonnelModel.generatePersonnelNumber(),
         createdBy: String,
         propertyIds: [String] = [],
         propertyAssignmentDates: [String: Timestamp] = [:],
         startDate: Date = Date(),
         endDate: Date? = nil,
         status: PersonnelStatus = .active) {
        self.id = id
        self.fullName = fullName
        self.phoneNumber = phoneNumber
        self.email = email
        self.personnelNumber = personnelNumber
        self.createdBy = createdBy
        self.propertyIds = propertyIds
        self.propertyAssignmentDates = propertyAssignmentDates
        self.startDate = startDate
        self.endDate = endDate
        self.status = status
    }
    
    // MARK: - Hashable
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: PersonnelModel, rhs: PersonnelModel) -> Bool {
        lhs.id == rhs.id
    }
}
