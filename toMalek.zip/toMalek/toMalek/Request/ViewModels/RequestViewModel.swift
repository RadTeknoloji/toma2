//
//  RequestViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import SwiftUI




@MainActor
final class RequestViewModel: ObservableObject {
    // MARK: - Properties
    private let db = Firestore.firestore()
    private let propertyService: PropertyService
    private let currentUserId = Auth.auth().currentUser?.uid
    
    // MARK: - Published Properties
    @Published var selectedTab = 0 // 0: Incoming, 1: Outgoing
    @Published var incomingRequests: [RequestModel] = []
    @Published var outgoingRequests: [RequestModel] = []
    @Published var selectedRequest: RequestModel?
    
    // Form fields
    @Published var title = ""
    @Published var requestDescription = ""
    @Published var selectedCategory: RequestCategory = .expense
    @Published var selectedPropertyID = "" {
        didSet {
            if selectedPropertyID != oldValue {
                Task {
                    await updateAvailableTargetTypes()
                }
            }
        }
    }
    @Published var selectedTargetType = ""
    @Published var availableTargetTypes: [String] = []
    
    // State Management
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    // Properties list
    @Published var properties: [(id: String, title: String)] = []
    
    var userType: String = ""
    
    // MARK: - Computed Properties
    var isValidForm: Bool {
        !title.isEmpty &&
        !requestDescription.isEmpty &&
        !selectedPropertyID.isEmpty &&
        !selectedTargetType.isEmpty
    }
    
    // Form'da gösterilecek kategoriler
    var availableCategories: [RequestCategory] {
        [.expense, .eviction, .cleaning, .document]
    }
    
    // MARK: - Initialization
    init(propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.propertyService = propertyService
        setupRequestListeners()
    }
    
    // MARK: - Private Methods
    private func setupRequestListeners() {
        guard let userId = currentUserId else { return }
        
        // Gelen talepleri dinle
        db.collection("requests")
            .whereField("toUserID", isEqualTo: userId)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.errorMessage = String(localized: "request_error_fetch_data \(error.localizedDescription)")
                    return
                }
                
                self.incomingRequests = querySnapshot?.documents.compactMap { doc in
                    try? doc.data(as: RequestModel.self)
                } ?? []
            }
        
        // Giden talepleri dinle
        db.collection("requests")
            .whereField("fromUserID", isEqualTo: userId)
            .addSnapshotListener { [weak self] querySnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    self.errorMessage = String(localized: "request_error_fetch_data \(error.localizedDescription)")
                    return
                }
                
                self.outgoingRequests = querySnapshot?.documents.compactMap { doc in
                    try? doc.data(as: RequestModel.self)
                } ?? []
            }
    }
    
    private func determineTargetUser(property: PropertyModel) throws -> String {
        guard !selectedTargetType.isEmpty else {
            throw RequestError.invalidTargetUser
        }
        
        switch selectedTargetType {
        case "owner":
            guard !property.ownerPhone.isEmpty else { throw RequestError.invalidTargetUser }
            return property.ownerPhone
            
        case "tenant":
            guard let tenantPhone = property.tenantPhone, !tenantPhone.isEmpty else {
                throw RequestError.invalidTargetUser
            }
            return tenantPhone
            
        case "agency":
            guard let agentPhone = property.agentPhone, !agentPhone.isEmpty else {
                throw RequestError.invalidTargetUser
            }
            return agentPhone
            
        default:
            throw RequestError.invalidTargetUser
        }
    }
    
    private func clearForm() {
        title = ""
        requestDescription = ""
        selectedCategory = .expense
        selectedPropertyID = ""
        selectedTargetType = ""
        availableTargetTypes = []
    }
    
    // MARK: - Public Methods
    
    // Eşleşmeli mülkleri getir
    func fetchProperties() async {
        guard let userId = currentUserId else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let properties = try await propertyService.fetchProperties()
            
            // Sadece eşleşmesi olan mülkleri filtrele
            self.properties = properties.compactMap { property in
                // Eşleşmesi olmayan mülkleri gösterme
                guard property.matchedToPropertyId != nil else { return nil }
                
                // Kullanıcının erişimi olan mülkleri kontrol et
                if property.createdBy == userId ||
                   property.tenantId == userId ||
                   property.agentName == userId {
                    return (id: property.id.uuidString, title: property.title)
                }
                return nil
            }
        } catch {
            self.errorMessage = String(localized: "request_error_fetch_data \(error.localizedDescription)")
        }
    }
    
    // Hedef kullanıcı tiplerini güncelle
    private func updateAvailableTargetTypes() async {
        guard !selectedPropertyID.isEmpty else {
            availableTargetTypes = []
            return
        }
        
        do {
            guard let property = try await propertyService.fetchProperty(id: selectedPropertyID) else {
                throw RequestError.propertyNotFound
            }
            
            var types: [String] = []
            
            // Emlakçı kontrolü
            if let _ = property.agentPhone {
                types.append("agency")
            }
            
            // Kiracı kontrolü
            if let _ = property.tenantPhone {
                types.append("tenant")
            }
            
            // Mal sahibi kontrolü
            if !property.ownerPhone.isEmpty {
                types.append("owner")
            }
            
            // Mevcut kullanıcı tipini çıkar
            types.removeAll { $0 == userType }
            
            await MainActor.run {
                self.availableTargetTypes = types
                // İlk tipi otomatik seç
                if let firstType = types.first {
                    self.selectedTargetType = firstType
                }
            }
            
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func createRequest() async -> Bool {
        guard let userId = currentUserId, isValidForm else {
            errorMessage = String(localized: "request_error_fill_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            guard let property = try await propertyService.fetchProperty(id: selectedPropertyID) else {
                throw RequestError.propertyNotFound
            }
            
            let targetUserId = try determineTargetUser(property: property)
            
            let newRequest = RequestModel(
                title: title,
                requestDescription: requestDescription,
                category: selectedCategory,
                propertyID: selectedPropertyID,
                propertyTitle: property.title,
                fromUserID: userId,
                fromUserType: userType,
                toUserID: targetUserId,
                toUserType: selectedTargetType,
                canBeModified: true
            )
            
            let ref = db.collection("requests").document(newRequest.id.uuidString)
            try ref.setData(from: newRequest)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "request_error_create"), error.localizedDescription)
            return false
        }
    }
    
    func updateRequestStatus(_ request: RequestModel, newStatus: RequestStatus) async {
        guard request.canBeModified else {
            errorMessage = String(localized: "request_error_cannot_modify")
            return
        }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("requests").document(request.id.uuidString)
            
            let updateData: [String: Any] = [
                "status": newStatus.rawValue,
                "updatedAt": FieldValue.serverTimestamp()
            ]
            
            try await ref.updateData(updateData)
        } catch {
            errorMessage = String(format: String(localized: "request_error_update_status"), error.localizedDescription)        }
    }

    func forwardRequest(_ request: RequestModel, toOwner: Bool) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("requests").document(request.id.uuidString)
            
            let updateData: [String: Any] = [
                "forwardedToOwner": toOwner,
                "forwardedToTenant": !toOwner,
                "canBeModified": false,
                "updatedAt": FieldValue.serverTimestamp()
            ]
            
            try await ref.updateData(updateData)
        } catch {
            errorMessage = String(format: String(localized: "request_error_forward"), error.localizedDescription)        }
    }
    
    // MARK: - Helper Methods
    func canModifyRequest(_ request: RequestModel) -> Bool {
        guard !request.isForwarded else { return false }
        return request.canBeModified
    }
    
    func canForwardToOwner(_ request: RequestModel) -> Bool {
        userType == String(localized: "user_type_agent") &&
        request.toUserType == String(localized: "user_type_agent") &&
        request.fromUserType == String(localized: "user_type_tenant") &&
        !request.isForwarded
    }
    
    func canForwardToTenant(_ request: RequestModel) -> Bool {
        userType == String(localized: "user_type_agent") &&
        request.toUserType == String(localized: "user_type_agent") &&
        request.fromUserType == String(localized: "user_type_owner") &&
        !request.isForwarded
    }
}

extension String? {
    var isNilOrEmpty: Bool {
        self == nil || self?.isEmpty == true
    }
}
