//
//  RequestRowView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct RequestRowView: View {
    let request: RequestModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            // Üst satır: Başlık ve Durum
            HStack(alignment: .center) {
                Text(request.title)
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                    .lineLimit(1)
                
                Spacer()
                
                StatusBadge(status: request.status)
            }
            
            // Orta satır: Mülk başlığı ve Kategori
            HStack(alignment: .center) {
                Text(request.propertyTitle)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
                    .lineLimit(1)
                
                Spacer()
                
                Text(request.category.displayName)
                    .font(TFont.caption)
                    .foregroundColor(TColor.areapolPrimary)
                    .padding(.horizontal, TLayout.spacingXS)
                    .padding(.vertical, 2)
                    .background(TColor.areapolPrimary.opacity(0.1))
                    .cornerRadius(TLayout.cornerRadiusS)
            }
            
            // Alt satır: Yönlendirme durumu ve Tarih
            HStack(alignment: .center) {
                if request.isForwarded {
                    HStack(spacing: TLayout.spacingXXS) {
                        Image(systemName: "arrow.forward")
                            .font(.system(size: 12))
                        Text(request.forwardedToOwner! ?
                            String(localized: "request_forwarded_to_owner") :
                            String(localized: "request_forwarded_to_tenant"))
                            .font(TFont.caption)
                    }
                    .foregroundColor(TColor.warning)
                }
                
                Spacer()
                
                Text(request.createdAt, style: .date)
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
            }
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}

struct StatusBadge: View {
    let status: RequestStatus
    
    var body: some View {
        Text(status.displayName)
            .font(TFont.caption)
            .padding(.horizontal, TLayout.spacingXS)
            .padding(.vertical, 2)
            .background(Color(status.color).opacity(0.1))
            .foregroundColor(Color(status.color))
            .cornerRadius(TLayout.cornerRadiusS)
    }
}
