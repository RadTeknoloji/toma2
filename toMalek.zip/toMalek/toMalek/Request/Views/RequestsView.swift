//
//  RequestsView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct RequestsView: View {
    @StateObject private var viewModel = RequestViewModel()
    @State private var showingCreateForm = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Segment Control
            Picker("", selection: $viewModel.selectedTab) {
                Text(String(localized: "requests_tab_incoming"))
                    .tag(0)
                Text(String(localized: "requests_tab_outgoing"))
                    .tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, TLayout.padding)
            .padding(.vertical, TLayout.spacingS)
            .background(TColor.surface)
            
            // Ana içerik
            if viewModel.isLoading {
                Spacer()
                ProgressView()
                Spacer()
            } else if viewModel.selectedTab == 0 && viewModel.incomingRequests.isEmpty {
                RequestEmptyStateView(isIncoming: true)
            } else if viewModel.selectedTab == 1 && viewModel.outgoingRequests.isEmpty {
                RequestEmptyStateView(isIncoming: false)
            } else {
                ScrollView {
                    LazyVStack(spacing: TLayout.spacingS) {
                        ForEach(viewModel.selectedTab == 0 ? viewModel.incomingRequests : viewModel.outgoingRequests) { request in
                            NavigationLink(destination: RequestDetailView(viewModel: viewModel, request: request)) {
                                RequestRowView(request: request)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, TLayout.padding)
                    .padding(.vertical, TLayout.spacingM)
                }
            }
        }
        .navigationTitle(String(localized: "requests_title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    showingCreateForm = true
                } label: {
                    Image(systemName: "plus")
                        .foregroundColor(TColor.areapolPrimary)
                }
            }
        }
        .sheet(isPresented: $showingCreateForm) {
            NavigationView {
                RequestFormView(viewModel: viewModel) { success in
                    if success {
                        showingCreateForm = false
                    }
                }
            }
        }
        .alert(
            String(localized: "error_title"),
            isPresented: .constant(viewModel.errorMessage != nil),
            actions: {
                Button(String(localized: "error_ok"), role: .cancel) {
                    viewModel.errorMessage = nil
                }
            },
            message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        )
    }
}

// MARK: - Helper Views
private struct RequestEmptyStateView: View {
    let isIncoming: Bool
    
    var body: some View {
        VStack(spacing: TLayout.spacingM) {
            Image(systemName: "tray")
                .font(.system(size: 48))
                .foregroundColor(TColor.textSecondary)
            
            Text(isIncoming ? 
                String(localized: "requests_empty_incoming_title") :
                String(localized: "requests_empty_outgoing_title"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            Text(isIncoming ?
                String(localized: "requests_empty_incoming_message") :
                String(localized: "requests_empty_outgoing_message"))
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, TLayout.paddingL)
        }
        .padding(.vertical, TLayout.paddingL)
    }
}
