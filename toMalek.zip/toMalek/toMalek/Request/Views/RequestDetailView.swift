//
//  RequestDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct RequestDetailView: View {
    @ObservedObject var viewModel: RequestViewModel
    let request: RequestModel
    
    var body: some View {
        List {
            statusSection
            infoSection
            listingSection
            descriptionSection
            statusUpdateSection
            forwardOptionsSection
            forwardingInfoSection
        }
        .scrollContentBackground(.hidden)
        .background(TColor.background)
        .navigationTitle(String(localized: "request_detail_navigation_title"))
        .navigationBarTitleDisplayMode(.inline)
    }
    
    // MARK: - List Sections
    private var statusSection: some View {
        Section {
            HStack {
                Spacer()
                StatusBadge(status: request.status)
                Spacer()
            }
            .listRowBackground(Color.clear)
        }
    }
    
    private var infoSection: some View {
        Section(String(localized: "request_detail_section_info")) {
            DetailRow(
                title: String(localized: "request_detail_title"),
                value: request.title
            )
            DetailRow(
                title: String(localized: "request_detail_category"),
                value: request.category.displayName,
                icon: request.category.icon
            )
            DetailRow(
                title: String(localized: "request_detail_property"),
                value: request.propertyTitle
            )
            DetailRow(
                title: String(localized: "request_detail_created"),
                value: request.createdAt.formatted()
            )
            DetailRow(
                title: String(localized: "request_detail_updated"),
                value: request.updatedAt.formatted()
            )
        }
        .listRowBackground(TColor.surface)
    }
    
    @ViewBuilder
    private var listingSection: some View {
        if request.listingID != nil {
            Section(String(localized: "request_detail_section_listing")) {
                DetailRow(
                    title: String(localized: "request_detail_listing"),
                    value: request.listingTitle ?? "-"
                )
                
                if let price = request.listingPrice,
                   let currency = request.listingCurrency {
                    DetailRow(
                        title: String(localized: "request_detail_price"),
                        value: "\(price.formatted()) \(currency.symbol)"
                    )
                }
                
                if let type = request.listingType {
                    DetailRow(
                        title: String(localized: "request_detail_listing_type"),
                        value: type.displayName
                    )
                }
            }
            .listRowBackground(TColor.surface)
        }
    }
    
    private var descriptionSection: some View {
        Section(String(localized: "request_detail_section_description")) {
            Text(request.requestDescription)
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, TLayout.paddingXS)
        }
        .listRowBackground(TColor.surface)
    }
    
    @ViewBuilder
    private var statusUpdateSection: some View {
        if viewModel.canModifyRequest(request) {
            Section(String(localized: "request_detail_section_update_status")) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: TLayout.spacingM) {
                        ForEach(RequestStatus.allCases, id: \.self) { status in
                            Button {
                                Task {
                                    await viewModel.updateRequestStatus(request, newStatus: status)
                                }
                            } label: {
                                VStack(spacing: TLayout.spacingXS) {
                                    Image(systemName: status.icon)
                                        .font(.system(size: 20))
                                        .foregroundColor(status == request.status ? .white : status.color)
                                    
                                    Text(status.displayName)
                                        .font(TFont.footnote)
                                        .foregroundColor(status == request.status ? .white : status.color)
                                }
                                .frame(width: 80)
                                .padding(.vertical, TLayout.spacingS)
                                .background(status == request.status ? status.color : status.color.opacity(0.1))
                                .cornerRadius(TLayout.cornerRadius)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal, TLayout.spacingXS)
                }
            }
            .listRowBackground(TColor.surface)
        }
    }
    
    @ViewBuilder
    private var forwardOptionsSection: some View {
        Group {
            if viewModel.canForwardToOwner(request) {
                forwardSection(
                    label: String(localized: "request_detail_forward_to_owner"),
                    warning: String(localized: "request_detail_forward_to_owner_warning"),
                    action: { await viewModel.forwardRequest(request, toOwner: true) }
                )
            }
            
            if viewModel.canForwardToTenant(request) {
                forwardSection(
                    label: String(localized: "request_detail_forward_to_tenant"),
                    warning: String(localized: "request_detail_forward_to_tenant_warning"),
                    action: { await viewModel.forwardRequest(request, toOwner: false) }
                )
            }
        }
    }
    
    @ViewBuilder
    private var forwardingInfoSection: some View {
        if request.isForwarded {
            Section {
                HStack(spacing: TLayout.spacingS) {
                    Image(systemName: "info.circle.fill")
                        .foregroundColor(TColor.warning)
                    
                    Text(request.forwardedToOwner! ?
                        String(localized: "request_detail_forwarded_to_owner_info") :
                        String(localized: "request_detail_forwarded_to_tenant_info"))
                        .font(TFont.subheadline)
                        .foregroundColor(TColor.textSecondary)
                }
            }
            .listRowBackground(TColor.surface)
        }
    }
    
    // MARK: - Helper Methods
    private func forwardSection(label: String, warning: String, action: @escaping () async -> Void) -> some View {
        Section {
            Button {
                Task { await action() }
            } label: {
                Label(label, systemImage: "arrow.forward")
                    .foregroundColor(TColor.info)
            }
        } footer: {
            Text(warning)
                .font(TFont.caption)
                .foregroundColor(TColor.textSecondary)
        }
    }
}

// MARK: - Helper Views
private struct DetailRow: View {
    let title: String
    let value: String
    var icon: String? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            Text(title)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
            
            HStack(spacing: TLayout.spacingXS) {
                if let icon = icon {
                    Image(systemName: icon)
                        .foregroundColor(TColor.info)
                        .font(TFont.body)
                }
                
                Text(value)
                    .font(TFont.body)
                    .foregroundColor(TColor.textPrimary)
            }
        }
        .padding(.vertical, TLayout.paddingXXS)
    }
}
