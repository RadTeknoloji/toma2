//
//  RequestFormView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct RequestFormView: View {
    @ObservedObject var viewModel: RequestViewModel
    let onComplete: (Bool) -> Void
    
    var body: some View {
        Form {
            infoSection
            descriptionSection
            submitSection
        }
        .scrollContentBackground(.hidden)
        .background(TColor.background)
        .task {
            await viewModel.fetchProperties()
        }
    }
    
    // MARK: - Form Sections
    private var infoSection: some View {
        Section {
            titleField
            categoryPicker
            propertyPicker
            targetPicker
        } header: {
            Text(String(localized: "request_form_section_info"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
        .listRowBackground(TColor.surface)
    }
    
    private var descriptionSection: some View {
        Section {
            descriptionEditor
        } header: {
            Text(String(localized: "request_form_section_description"))
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
        }
        .listRowBackground(TColor.surface)
    }
    
    private var submitSection: some View {
        Section {
            submitButton
        }
        .listRowBackground(TColor.surface)
    }
    
    // MARK: - Form Components
    private var titleField: some View {
        TextField(String(localized: "request_form_title_placeholder"), text: $viewModel.title)
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
    }
    
    private var categoryPicker: some View {
        Picker(String(localized: "request_form_category"), selection: $viewModel.selectedCategory) {
            ForEach(RequestCategory.formCategories, id: \.self) { category in
                Text(category.displayName)
                    .tag(category)
                    .font(TFont.body)
            }
        }
        .tint(TColor.areapolPrimary)
        .foregroundColor(TColor.textPrimary)
    }
    
    private var propertyPicker: some View {
        Picker(String(localized: "request_form_property"), selection: $viewModel.selectedPropertyID) {
            Text(String(localized: "request_form_select_property"))
                .tag("")
                .font(TFont.body)
            
            ForEach(viewModel.properties, id: \.id) { property in
                Text(property.title)
                    .tag(property.id)
                    .font(TFont.body)
            }
        }
        .tint(TColor.areapolPrimary)
        .foregroundColor(TColor.textPrimary)
    }
    
    @ViewBuilder
    private var targetPicker: some View {
        if viewModel.userType == String(localized: "user_type_agent") {
            Picker(String(localized: "request_form_target"), selection: $viewModel.selectedTargetType) {
                Text(String(localized: "user_type_owner"))
                    .tag(String(localized: "user_type_owner"))
                    .font(TFont.body)
                
                Text(String(localized: "user_type_tenant"))
                    .tag(String(localized: "user_type_tenant"))
                    .font(TFont.body)
            }
            .tint(TColor.areapolPrimary)
            .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var descriptionEditor: some View {
        TextEditor(text: $viewModel.requestDescription)
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            .frame(height: 100)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
    }
    
    private var submitButton: some View {
        Button {
            Task {
                let success = await viewModel.createRequest()
                onComplete(success)
            }
        } label: {
            Text(String(localized: "request_form_submit"))
                .font(TFont.bodyBold)
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(TButton.Primary())
        .disabled(!viewModel.isValidForm)
        .foregroundColor(viewModel.isValidForm ? TColor.onPrimary : TColor.textSecondary)
        .background(
            RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                .fill(viewModel.isValidForm ? TColor.areapolPrimary : TColor.surface)
        )
    }
}

struct RequestFormView_Previews: PreviewProvider {
    static var previews: some View {
        RequestFormView(viewModel: RequestViewModel(), onComplete: { _ in })
            .background(TColor.background)
    }
}
