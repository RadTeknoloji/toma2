//
//  RequestModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation
import FirebaseFirestore

// MARK: - Enums
enum RequestCategory: String, Codable, CaseIterable {
    case expense = "expense"
    case eviction = "eviction"
    case cleaning = "cleaning"
    case document = "document"
    case reservation = "reservation"
    case matching = "matching"
    case contractRenewal = "contract_renewal"     // Sözleşme Yenileme
    case priceIncrease = "price_increase"        // Zam talebi
    case assignment = "assignment"               // Atama talebi
    
    var displayName: String {
        switch self {
        case .expense: return String(localized: "request_category_expense")
        case .eviction: return String(localized: "request_category_eviction")
        case .cleaning: return String(localized: "request_category_cleaning")
        case .document: return String(localized: "request_category_document")
        case .reservation: return String(localized: "request_category_reservation")
        case .matching: return String(localized: "request_category_matching")
        case .contractRenewal: return String(localized: "request_category_contract_renewal")
        case .priceIncrease: return String(localized: "request_category_price_increase")
        case .assignment: return String(localized: "request_category_assignment")
        }
    }
    
    var icon: String {
        switch self {
        case .expense: return "banknote"
        case .eviction: return "door.right.hand.open"
        case .cleaning: return "spray.sparkle"
        case .document: return "doc.text"
        case .reservation: return "calendar.badge.clock"
        case .matching: return "person.2.circle"
        case .contractRenewal: return "doc.badge.clock" // Sözleşme yenileme için zamanlı döküman ikonu
        case .priceIncrease: return "chart.line.uptrend.xyaxis.circle" // Fiyat artışı için yukarı trend ikonu
        case .assignment: return "person.badge.shield.checkmark" // Görevlendirme için kişi ve onay işareti
        }
    }
    
}

extension RequestCategory {
    // Formda gösterilecek kategoriler
    static var formCategories: [RequestCategory] {
        [.expense, .eviction, .cleaning, .document]
    }
}

// MARK: - Models
struct RequestModel: Identifiable, Codable, Sendable {
    let id: UUID
    var title: String
    var requestDescription: String
    var category: RequestCategory
    var status: RequestStatus
    var propertyID: String
    var propertyTitle: String
    var fromUserID: String
    var fromUserType: String
    var toUserID: String
    var toUserType: String
    var createdAt: Date
    var updatedAt: Date
    var forwardedToOwner: Bool?
    var forwardedToTenant: Bool?
    var canBeModified: Bool = true
    
    // Listing Information
    var listingID: String?
    var listingTitle: String?
    var listingType: ListingType?
    var listingPrice: Double?
    var listingCurrency: CurrencyType?
    
    var isForwarded: Bool {
        forwardedToOwner == true || forwardedToTenant == true
    }
    
    // MARK: - Coding Keys
    enum CodingKeys: String, CodingKey {
        case id, title, requestDescription, category, status
        case propertyID, propertyTitle, fromUserID, fromUserType
        case toUserID, toUserType, createdAt, updatedAt
        case forwardedToOwner, forwardedToTenant, canBeModified
        case listingID, listingTitle, listingType, listingPrice, listingCurrency
    }
    
    // MARK: - Encodable
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        // Main information
        try container.encode(id, forKey: .id)
        try container.encode(title, forKey: .title)
        try container.encode(requestDescription, forKey: .requestDescription)
        try container.encode(category.rawValue, forKey: .category)
        try container.encode(status.rawValue, forKey: .status)
        try container.encode(propertyID, forKey: .propertyID)
        try container.encode(propertyTitle, forKey: .propertyTitle)
        try container.encode(fromUserID, forKey: .fromUserID)
        try container.encode(fromUserType, forKey: .fromUserType)
        try container.encode(toUserID, forKey: .toUserID)
        try container.encode(toUserType, forKey: .toUserType)
        try container.encode(Timestamp(date: createdAt), forKey: .createdAt)
        try container.encode(Timestamp(date: updatedAt), forKey: .updatedAt)
        try container.encodeIfPresent(forwardedToOwner, forKey: .forwardedToOwner)
        try container.encodeIfPresent(forwardedToTenant, forKey: .forwardedToTenant)
        try container.encode(canBeModified, forKey: .canBeModified)
        
        // Listing information
        try container.encodeIfPresent(listingID, forKey: .listingID)
        try container.encodeIfPresent(listingTitle, forKey: .listingTitle)
        try container.encodeIfPresent(listingType?.rawValue, forKey: .listingType)
        try container.encodeIfPresent(listingPrice, forKey: .listingPrice)
        try container.encodeIfPresent(listingCurrency?.rawValue, forKey: .listingCurrency)
    }
    
    // MARK: - Decodable
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Main information
        id = try container.decode(UUID.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        requestDescription = try container.decode(String.self, forKey: .requestDescription)
        
        let categoryString = try container.decode(String.self, forKey: .category)
        category = RequestCategory(rawValue: categoryString) ?? .expense
        
        let statusString = try container.decode(String.self, forKey: .status)
        status = RequestStatus(rawValue: statusString) ?? .pending
        
        propertyID = try container.decode(String.self, forKey: .propertyID)
        propertyTitle = try container.decode(String.self, forKey: .propertyTitle)
        fromUserID = try container.decode(String.self, forKey: .fromUserID)
        fromUserType = try container.decode(String.self, forKey: .fromUserType)
        toUserID = try container.decode(String.self, forKey: .toUserID)
        toUserType = try container.decode(String.self, forKey: .toUserType)
        
        let createdTimestamp = try container.decode(Timestamp.self, forKey: .createdAt)
        createdAt = createdTimestamp.dateValue()
        
        let updatedTimestamp = try container.decode(Timestamp.self, forKey: .updatedAt)
        updatedAt = updatedTimestamp.dateValue()
        
        forwardedToOwner = try container.decodeIfPresent(Bool.self, forKey: .forwardedToOwner)
        forwardedToTenant = try container.decodeIfPresent(Bool.self, forKey: .forwardedToTenant)
        canBeModified = try container.decode(Bool.self, forKey: .canBeModified)
        
        // Listing information
        listingID = try container.decodeIfPresent(String.self, forKey: .listingID)
        listingTitle = try container.decodeIfPresent(String.self, forKey: .listingTitle)
        
        if let typeString = try container.decodeIfPresent(String.self, forKey: .listingType) {
            listingType = ListingType(rawValue: typeString)
        }
        
        listingPrice = try container.decodeIfPresent(Double.self, forKey: .listingPrice)
        
        if let currencyString = try container.decodeIfPresent(String.self, forKey: .listingCurrency) {
            listingCurrency = CurrencyType(rawValue: currencyString)
        }
    }
    
    // MARK: - Custom Initializer
    init(id: UUID = UUID(),
         title: String,
         requestDescription: String,
         category: RequestCategory,
         status: RequestStatus = .pending,
         propertyID: String,
         propertyTitle: String,
         fromUserID: String,
         fromUserType: String,
         toUserID: String,
         toUserType: String,
         createdAt: Date = Date(),
         updatedAt: Date = Date(),
         forwardedToOwner: Bool? = nil,
         forwardedToTenant: Bool? = nil,
         canBeModified: Bool = true,
         listingID: String? = nil,
         listingTitle: String? = nil,
         listingType: ListingType? = nil,
         listingPrice: Double? = nil,
         listingCurrency: CurrencyType? = nil) {
        self.id = id
        self.title = title
        self.requestDescription = requestDescription
        self.category = category
        self.status = status
        self.propertyID = propertyID
        self.propertyTitle = propertyTitle
        self.fromUserID = fromUserID
        self.fromUserType = fromUserType
        self.toUserID = toUserID
        self.toUserType = toUserType
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.forwardedToOwner = forwardedToOwner
        self.forwardedToTenant = forwardedToTenant
        self.canBeModified = canBeModified
        self.listingID = listingID
        self.listingTitle = listingTitle
        self.listingType = listingType
        self.listingPrice = listingPrice
        self.listingCurrency = listingCurrency
    }
}
