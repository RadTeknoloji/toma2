import Foundation
import SwiftUI

enum RequestStatus: String, Codable, CaseIterable, Sendable {
    case pending = "pending"
    case inProgress = "inProgress"
    case approved = "approved"
    case rejected = "rejected"
    
    var displayName: String {
        switch self {
        case .pending:
            return String(localized: "request_status_pending")
        case .inProgress:
            return String(localized: "request_status_in_progress")
        case .approved:
            return String(localized: "request_status_approved")
        case .rejected:
            return String(localized: "request_status_rejected")
        }
    }
    
    var color: Color {
        switch self {
        case .pending: return .orange
        case .inProgress: return .blue
        case .approved: return .green
        case .rejected: return .red
        }
    }
    
    var icon: String {
        switch self {
        case .pending: return "clock"
        case .inProgress: return "arrow.triangle.2.circlepath"
        case .approved: return "checkmark.circle"
        case .rejected: return "xmark.circle"
        }
    }
}
