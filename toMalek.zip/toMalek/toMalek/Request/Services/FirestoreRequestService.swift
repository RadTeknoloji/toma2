//
//  FirestoreRequestService.swift
//  toMalek
//
//  Created by Selman Erbay on 6.02.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

final class FirestoreRequestService: RequestService {
    private let db = Firestore.firestore()
    private let collection = "requests"
    
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // MARK: - Create
    func createRequest(_ request: RequestModel) async throws {
        guard currentUserId != nil else {
            throw RequestError.unauthorized
        }
        
        let documentRef = db.collection(collection).document(request.id.uuidString)
        try documentRef.setData(from: request)
    }
    
    // MARK: - Read
    func fetchRequests() async throws -> [RequestModel] {
        guard let userId = currentUserId else {
            throw RequestError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("fromUserID", isEqualTo: userId)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try document.data(as: RequestModel.self)
        }
    }
    
    func fetchRequest(id: String) async throws -> RequestModel? {
        let documentRef = db.collection(collection).document(id)
        let document = try await documentRef.getDocument()
        return try document.data(as: RequestModel.self)
    }
    
    func fetchIncomingRequests(forUserID userId: String) async throws -> [RequestModel] {
        let snapshot = try await db.collection(collection)
            .whereField("toUserID", isEqualTo: userId)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try document.data(as: RequestModel.self)
        }
    }
    
    func fetchOutgoingRequests(forUserID userId: String) async throws -> [RequestModel] {
        let snapshot = try await db.collection(collection)
            .whereField("fromUserID", isEqualTo: userId)
            .order(by: "createdAt", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try document.data(as: RequestModel.self)
        }
    }
    
    // MARK: - Update
    func updateRequest(_ request: RequestModel) async throws {
        let documentRef = db.collection(collection).document(request.id.uuidString)
        try documentRef.setData(from: request)
    }
    
    func updateRequestStatus(_ requestId: String, newStatus: RequestStatus) async throws {
        let documentRef = db.collection(collection).document(requestId)
        try await documentRef.updateData([
            "status": newStatus.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ])
    }
    
    // MARK: - Delete
    func deleteRequest(id: String) async throws {
        try await db.collection(collection).document(id).delete()
    }
    
    // MARK: - Match Specific
    func createMatchRequest(fromProperty: PropertyModel, targetUserType: UserType, targetPhone: String) async throws {
        // Kullanıcıyı telefon numarasına göre bul
        let userSnapshot = try await db.collection("users")
            .whereField("phoneNumber", isEqualTo: targetPhone)
            .getDocuments()
        
        guard let userDoc = userSnapshot.documents.first,
              let targetUserId = userDoc.documentID as String? else {
            throw RequestError.userNotFound
        }
        
        // Kullanıcının hedef role sahip olup olmadığını kontrol et
        let userTypeSnapshot = try await db.collection("userTypes")
            .whereField("userId", isEqualTo: targetUserId)
            .whereField("type", isEqualTo: targetUserType.rawValue)
            .getDocuments()
        
        guard !userTypeSnapshot.documents.isEmpty else {
            throw RequestError.invalidTargetUser
        }
        
        // Eşleşme talebi oluştur
        let request = await RequestModel(
            title: String(format: String(localized: "match_request_title"), fromProperty.title),
            requestDescription: String(format: String(localized: "match_request_description"),
                                     fromProperty.title,
                                     fromProperty.propertyCode,
                                     ServiceContainer.shared.authenticationState.userType),
            category: .matching,
            propertyID: fromProperty.id.uuidString,
            propertyTitle: fromProperty.title,
            fromUserID: currentUserId ?? "",
            fromUserType: ServiceContainer.shared.authenticationState.userType,
            toUserID: targetUserId,
            toUserType: targetUserType.rawValue,
            canBeModified: true,
            listingID: nil,
            listingTitle: nil,
            listingType: nil,
            listingPrice: nil,
            listingCurrency: nil
        )
        
        try await createRequest(request)
    }
    func acceptMatchRequest(requestId: String, selectedPropertyId: String) async throws {
        guard let request = try await fetchRequest(id: requestId) else {
            throw RequestError.notFound
        }
        
        // Eşleşme durumunu güncelle
        try await updateRequestStatus(requestId, newStatus: .approved)
        
        // Mülkleri eşleştir
        try await matchProperties(request.propertyID, with: selectedPropertyId)
    }
    
    func rejectMatchRequest(requestId: String) async throws {
        try await updateRequestStatus(requestId, newStatus: .rejected)
    }
    
    // MARK: - Helper Methods
    private func matchProperties(_ propertyId1: String, with propertyId2: String) async throws {
        let batch = db.batch()
        
        let prop1Ref = db.collection("properties").document(propertyId1)
        let prop2Ref = db.collection("properties").document(propertyId2)
        
        // İlk mülkü güncelle
        batch.updateData([
            "matchedToPropertyId": propertyId2,
            "updatedAt": FieldValue.serverTimestamp()
        ], forDocument: prop1Ref)
        
        // İkinci mülkü güncelle
        batch.updateData([
            "matchedToPropertyId": propertyId1,
            "updatedAt": FieldValue.serverTimestamp()
        ], forDocument: prop2Ref)
        
        try await batch.commit()
    }
}
