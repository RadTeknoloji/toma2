//
//  RequestService.swift
//  toMalek
//
//  Created by Selman Erbay on 6.02.2025.
//

import Foundation

protocol RequestService {
    // MARK: - Create
    func createRequest(_ request: RequestModel) async throws
    
    // MARK: - Read
    func fetchRequests() async throws -> [RequestModel]
    func fetchRequest(id: String) async throws -> RequestModel?
    func fetchIncomingRequests(forUserID: String) async throws -> [RequestModel]
    func fetchOutgoingRequests(forUserID: String) async throws -> [RequestModel]
    
    // MARK: - Update
    func updateRequest(_ request: RequestModel) async throws
    func updateRequestStatus(_ requestId: String, newStatus: RequestStatus) async throws
    
    // MARK: - Delete
    func deleteRequest(id: String) async throws
    
    // MARK: - Match Specific
    func createMatchRequest(fromProperty: PropertyModel, targetUserType: UserType, targetPhone: String) async throws
    func acceptMatchRequest(requestId: String, selectedPropertyId: String) async throws
    func rejectMatchRequest(requestId: String) async throws
}
