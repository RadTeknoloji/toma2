//
//  RequestError.swift
//  toMalek
//
//  Created by Selman Erbay on 6.02.2025.
//

import SwiftUI
import Foundation


enum RequestError: LocalizedError {
    case invalidData
    case notFound
    case alreadyExists
    case unauthorized
    case invalidMatchRequest
    case userNotFound
    case propertyNotFound
    case invalidTargetUser // Bunu ekledik
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "request_error_invalid_data")
        case .notFound:
            return String(localized: "request_error_not_found")
        case .alreadyExists:
            return String(localized: "request_error_already_exists")
        case .unauthorized:
            return String(localized: "request_error_unauthorized")
        case .invalidMatchRequest:
            return String(localized: "request_error_invalid_match")
        case .userNotFound:
            return String(localized: "request_error_user_not_found")
        case .propertyNotFound:
            return String(localized: "request_error_property_not_found")
        case .invalidTargetUser:
            return String(localized: "request_error_invalid_target_user")
        case .unknown:
            return String(localized: "request_error_unknown")
        }
    }
}
