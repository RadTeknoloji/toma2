import Foundation

enum ExpenseCategory: String, Codable, CaseIterable {
    case dues = "expense_category_dues"
    case bill = "expense_category_bill"
    case maintenance = "expense_category_maintenance"
    case renovation = "expense_category_renovation"
    case tax = "expense_category_tax"
    case penalty = "expense_category_penalty"
    case insurance = "expense_category_insurance"
    case other = "expense_category_other"
    
    var localized: String {
        NSLocalizedString(self.rawValue, comment: "")
    }
}

enum ExpenseStatus: String, Codable, CaseIterable {
    case unpaid = "expense_status_unpaid"
    case paid = "expense_status_paid"
    
    var localized: String {
        NSLocalizedString(self.rawValue, comment: "")
    }
}
