//
//  CurrencyEnums.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation

enum CurrencyType: String, CaseIterable, Codable {
    case usd = "USD"
    case eur = "EUR"
    case gbp = "GBP"
    case `try` = "TRY"
    case rub = "RUB"
    case cny = "CNY"
    
    var symbol: String {        switch self {
        case .usd: return "$"
        case .eur: return "€"
        case .gbp: return "£"
        case .try: return "₺"
        case .rub: return "₽"
        case .cny: return "¥"
        }
    }
    
    var name: String {
        switch self {
        case .usd: return NSLocalizedString("currency_usd", comment: "")
        case .eur: return NSLocalizedString("currency_eur", comment: "")
        case .gbp: return NSLocalizedString("currency_gbp", comment: "")
        case .try: return NSLocalizedString("currency_try", comment: "")
        case .rub: return NSLocalizedString("currency_rub", comment: "")
        case .cny: return NSLocalizedString("currency_cny", comment: "")
        }
    }
}
