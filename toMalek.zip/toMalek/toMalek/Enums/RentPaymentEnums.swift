//
//  PropertyEnums.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation

enum PaymentDay: Int, Codable, CaseIterable {
    case first = 1
    case fifth = 5
    case tenth = 10
    case fifteenth = 15
    case twentieth = 20
    case twentyFifth = 25
    case last = 31
    
    var displayName: String {
        switch self {
        case .first:
            return String(localized: "payment_day_first")
        case .fifth:
            return String(localized: "payment_day_fifth")
        case .tenth:
            return String(localized: "payment_day_tenth")
        case .fifteenth:
            return String(localized: "payment_day_fifteenth")
        case .twentieth:
            return String(localized: "payment_day_twentieth")
        case .twentyFifth:
            return String(localized: "payment_day_twenty_fifth")
        case .last:
            return String(localized: "payment_day_last")
        }
    }
}

enum RentPaymentStatus: String, Codable, CaseIterable {
    case paid = "rent_payment_status_paid"
    case unpaid = "rent_payment_status_unpaid"
    case partiallyPaid = "rent_payment_status_partially_paid"
}
