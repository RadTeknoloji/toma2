//
//  PropertyEnums.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI


// MARK: - Eşleşme Durumları
enum MatchStatus: String, Codable, CaseIterable {
    case tenantOwner = "match_status_tenant_owner"
    case tenantAgent = "match_status_tenant_agent"
    case ownerAgent = "match_status_owner_agent"
    case ownerAgentTenant = "match_status_owner_agent_tenant"
    
    var localizedDescription: String {
        switch self {
        case .tenantOwner:
            return String(localized: "match_status_tenant_owner")
        case .tenantAgent:
            return String(localized: "match_status_tenant_agent")
        case .ownerAgent:
            return String(localized: "match_status_owner_agent")
        case .ownerAgentTenant:
            return String(localized: "match_status_owner_agent_tenant")
        }
    }
}

// MARK: - Rezerve Durumları
enum ReserveStatus: String, Codable, CaseIterable {
    case reserved = "reserve_status_reserved"
    case available = "reserve_status_available"
    
    var localizedDescription: String {
        switch self {
        case .reserved:
            return String(localized: "reserve_status_reserved")
        case .available:
            return String(localized: "reserve_status_available")
        }
    }
}

// MARK: - Ana Mülk Tipleri
enum PropertyType: String, Codable, CaseIterable {
    case residential = "property_type_residential"
    case commercial = "property_type_commercial"
    case land = "property_type_land"
    case machine = "property_type_machine"
    case timeshareProperty = "property_type_timeshare"
    
    var icon: String {
        switch self {
        case .residential:
            return "house.fill"
        case .commercial:
            return "building.2.fill"
        case .land:
            return "leaf.fill"
        case .machine:
            return "gearshape.fill"
        case .timeshareProperty:
            return "clock.fill"
        }
    }
}

extension PropertyType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Kontrat Tipleri
enum ContractType: String, Codable, CaseIterable {
    case individual = "contract_type_individual"
    case corporate = "contract_type_corporate"
    
    var localizedText: String {
        String(localized: String.LocalizationValue(self.rawValue))
    }
}

enum ContractTime: Int, Codable, CaseIterable {
    case month1 = 1
    case month2 = 2
    case month3 = 3
    case month4 = 4
    case month5 = 5
    case month6 = 6
    case month12 = 12
    case month18 = 18
    case month24 = 24
    case month30 = 30
    case month36 = 36
    case month42 = 42
    case month48 = 48
    case month54 = 54
    case month60 = 60
    case month120 = 120
    
    var description: String {
        let years = self.rawValue / 12
        let months = self.rawValue % 12
        
        if months == 0 {
            return "\(years) " + (years == 1 ? String(localized: "year") : String(localized: "years"))
        } else if years == 0 {
            return "\(months) " + (months == 1 ? String(localized: "month") : String(localized: "months"))
        } else {
            return "\(years) " + (years == 1 ? String(localized: "year") : String(localized: "years")) + " " +
                   "\(months) " + (months == 1 ? String(localized: "month") : String(localized: "months"))
        }
    }
}

// MARK: - Konut Tipleri
enum ResidentialType: String, Codable, CaseIterable {
    case apartment = "residential_type_apartment"
    case residence = "residential_type_residence"
    case villa = "residential_type_villa"
    case detachedHouse = "residential_type_detached_house"
    case building = "residential_type_building"
    case waterfrontMansion = "residential_type_waterfront_mansion"
    case mansion = "residential_type_mansion"
    case farmhouse = "residential_type_farmhouse"
}

extension ResidentialType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}


// MARK: - Property Advantages Enums
enum ResidentialAdvantage: String, Codable, CaseIterable {
    case elevator = "elevator"
    case masterBathroom = "master_bathroom"
    case disabledFriendly = "disabled_friendly"
    case duplex = "duplex"
    case triplex = "triplex"
    case seaView = "sea_view"
    case security = "security"
    case site = "site"
    case fireEscape = "fire_escape"
    case pool = "pool"
    case hobbyGarden = "hobby_garden"
    case privateParking = "private_parking"
    case gym = "gym"
    case sauna = "sauna"
    case hammam = "hammam"
    case thermalSprings = "thermal_springs"
    case jacuzzi = "jacuzzi"
    case storage = "storage"
    case lessThanSixPumps = "less_than_six_pumps"
    case moreThanSixPumps = "more_than_six_pumps"
    case smartBoard = "smart_board"
    case conferenceHall = "conference_hall"
    case library = "library"
    case playground = "playground"
}

enum CommercialAdvantage: String, Codable, CaseIterable {
    case hood = "hood"
    case elevator = "elevator"
    case freightElevator = "freight_elevator"
    case security = "security"
    case site = "site"
    case doubleToilet = "double_toilet"
    case walkingPath = "walking_path"
    case inMall = "in_mall"
    case organizedIndustrial = "organized_industrial"
    case generator = "generator"
}

enum LandAdvantage: String, Codable, CaseIterable {
    case roadside = "roadside"
    case readyForLicense = "ready_for_license"
    case cornerParcel = "corner_parcel"
    case readyInfrastructure = "ready_infrastructure"
}

enum MachineAdvantage: String, Codable, CaseIterable {
    case renewed = "renewed"
    case withOperator = "with_operator"
    case suitableForLeasing = "suitable_for_leasing"
    case invoiced = "invoiced"
}

enum TimeshareAdvantage: String, Codable, CaseIterable {
    case playground = "playground"
    case gym = "gym"
    case duplex = "duplex"
    case triplex = "triplex"
    case seaView = "sea_view"
    case thermal = "thermal"
    case airConditioning = "air_conditioning"
    case familyFriendly = "family_friendly"
}

// MARK: - Ortak Sayısal Değerler
enum BuildingAge: Int, Codable, CaseIterable {
    case age0 = 0, age1, age2, age3, age4, age5, age6, age7, age8, age9, age10
    case age11, age12, age13, age14, age15, age16, age17, age18, age19, age20
    case age21, age22, age23, age24, age25, age26, age27, age28, age29, age30
    case age31, age32, age33, age34, age35, age36, age37, age38, age39, age40
    case age41, age42, age43, age44, age45, age46, age47, age48, age49, age50
    case age51, age52, age53, age54, age55, age56, age57, age58, age59, age60
}

extension BuildingAge {
    var localizedText: String {
        String(format: String(localized: "building_age"), self.rawValue)
    }
}

enum BuildingFloorCount: Int, Codable, CaseIterable {
    case f0 = 0, f1 = 1, f2, f3, f4, f5, f6, f7, f8, f9, f10
    case f11, f12, f13, f14, f15, f16, f17, f18, f19, f20
    case f21, f22, f23, f24, f25, f26, f27, f28, f29, f30
    case f31, f32, f33, f34, f35, f36, f37, f38, f39, f40
    case f41, f42, f43, f44, f45, f46, f47, f48, f49, f50
    case f51, f52, f53, f54, f55, f56, f57, f58, f59, f60
}

extension BuildingFloorCount {
    var localizedText: String {
        String(format: String(localized: "floor_count"), self.rawValue)
    }
}

enum FloorLocation: Int, Codable, CaseIterable {
    case basement3 = -3, basement2 = -2, basement1 = -1
    case ground = 0
    case f1 = 1, f2, f3, f4, f5, f6, f7, f8, f9, f10
    case f11, f12, f13, f14, f15, f16, f17, f18, f19, f20
    case f21, f22, f23, f24, f25, f26, f27, f28, f29, f30
    case f31, f32, f33, f34, f35, f36, f37, f38, f39, f40
    case f41, f42, f43, f44, f45, f46, f47, f48, f49, f50
    case f51, f52, f53, f54, f55, f56, f57, f58, f59, f60
}

extension FloorLocation {
    var localizedText: String {
        switch self {
        case .basement3:
            return String(localized: "floor_basement3")
        case .basement2:
            return String(localized: "floor_basement2")
        case .basement1:
            return String(localized: "floor_basement1")
        case .ground:
            return String(localized: "floor_ground")
        default:
            return String(format: String(localized: "floor_number"), self.rawValue)
        }
    }
}

// MARK: - Oda ve Bölümler
enum RoomCount: String, Codable, CaseIterable {
    case openOffice = "room_count_open_office"
    case studio = "room_count_studio"
    case room1_0 = "room_count_1_0"
    case room1_1 = "room_count_1_1"
    case room2_0 = "room_count_2_0"
    case room2_1 = "room_count_2_1"
    case room3_1 = "room_count_3_1"
    case room4_1 = "room_count_4_1"
    case room5_1 = "room_count_5_1"
    case room6_1 = "room_count_6_1"
    case room7_1 = "room_count_7_1"
    case room8_1 = "room_count_8_1"
    case other = "room_count_other"
}

extension RoomCount {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

enum BathroomCount: Int, Codable, CaseIterable {
    case one = 1, two, three, four, five
}

extension BathroomCount {
    var localizedText: String {
        String(format: String(localized: "bathroom_count"), self.rawValue)
    }
}

// MARK: - Mutfak ve Isıtma
enum KitchenCount: Int, Codable, CaseIterable {
    case none = 0
    case one = 1, two, three, four, five
}

extension KitchenCount {
    var localizedText: String {
        self == .none ?
        String(localized: "kitchen_none") :
        String(format: String(localized: "kitchen_count"), self.rawValue)
    }
}

enum HeatingType: String, Codable, CaseIterable {
    case none = "heating_type_none"
    case combi = "heating_type_combi"
    case underfloor = "heating_type_underfloor"
    case central = "heating_type_central"
    case stove = "heating_type_stove"
    case fullSolar = "heating_type_full_solar"
    case partialSolar = "heating_type_partial_solar"
    case airCondition = "heating_type_air_condition"
    case other = "heating_type_other"
}

extension HeatingType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Yapı Detayları
enum ConstructionMaterial: String, Codable, CaseIterable {
    case steel = "construction_material_steel"
    case reinforcedConcrete = "construction_material_reinforced_concrete"
    case prefab = "construction_material_prefab"
    case naturalStone = "construction_material_natural_stone"
}

extension ConstructionMaterial {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

enum DirectionFacade: String, Codable, CaseIterable {
    case north = "direction_facade_north"
    case south = "direction_facade_south"
    case east = "direction_facade_east"
    case west = "direction_facade_west"
}

extension DirectionFacade {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Rental/Sale Status
enum RentalStatus: String, Codable, CaseIterable {
    case rented = "rented"
    case reserved = "reserved"
    case available = "available"
    case notRent = "not_rent"
    
    var localizedDescription: String {
        switch self {
        case .rented:
            return String(localized: "rental_status_rented")
        case .reserved:
            return String(localized: "rental_status_reserved")
        case .available:
            return String(localized: "rental_status_available")
        case .notRent:
            return String(localized: "rental_status_not_for_rent")
        }
    }
}

enum SaleStatus: String, Codable, CaseIterable {
    case forSale = "forSale"
    case sold = "sold"
    case reserved = "reserved"
    case available = "available"
    
    var localizedDescription: String {
        switch self {
        case .forSale:
            return String(localized: "sale_status_for_sale")
        case .sold:
            return String(localized: "sale_status_sold")
        case .reserved:
            return String(localized: "sale_status_reserved")
        case .available:
            return String(localized: "sale_status_available")
        }
    }
}

var rentalStatus: RentalStatus = .available
var saleStatus: SaleStatus = .available
// MARK: - İşyeri Tipleri
enum CommercialType: String, Codable, CaseIterable {
    case office = "commercial_type_office"
    case store = "commercial_type_store"
    case factory = "commercial_type_factory"
    case school = "commercial_type_school"
    case gasStation = "commercial_type_gas_station"
    case workshop = "commercial_type_workshop"
    case kiosk = "commercial_type_kiosk"
    case cafeBar = "commercial_type_cafe_bar"
    case animalFarm = "commercial_type_animal_farm"
    case warehouse = "commercial_type_warehouse"
    case weddingVenue = "commercial_type_wedding_venue"
    case garage = "commercial_type_garage"
    case parkingLot = "commercial_type_parking_lot"
    case canteen = "commercial_type_canteen"
    case garden = "commercial_type_garden"
    case carWash = "commercial_type_car_wash"
    case bakery = "commercial_type_bakery"
    case dessertShop = "commercial_type_dessert_shop"
    case restaurant = "commercial_type_restaurant"
    case marketplace = "commercial_type_marketplace"
    case sportsFacility = "commercial_type_sports_facility"
    case dormitory = "commercial_type_dormitory"
    case other = "commercial_type_other"
}

extension CommercialType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Arsa Tipleri
enum LandType: String, Codable, CaseIterable {
    case zoned = "land_type_zoned"
    case unzoned = "land_type_unzoned"
    case floorEquivalent = "land_type_floor_equivalent"
    case field = "land_type_field"
    case other = "land_type_other"
}

extension LandType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Makine Detayları
enum MachineType: String, Codable, CaseIterable {
    case workVehicle = "machine_type_work_vehicle"
    case industrialMachine = "machine_type_industrial_machine"
    case other = "machine_type_other"
}

extension MachineType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

enum WarrantyStatus: String, Codable, CaseIterable {
    case ongoing = "warranty_ongoing"
    case expired = "warranty_expired"
}

extension WarrantyStatus {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

enum ServiceSupport: String, Codable, CaseIterable {
    case yes = "service_support_yes"
    case no = "service_support_no"
}

extension ServiceSupport {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Devre Mülk
enum TimeshareType: String, Codable, CaseIterable {
    case hotel = "timeshare_type_hotel"
    case thermalResort = "timeshare_type_thermal_resort"
    case summerHouse = "timeshare_type_summer_house"
    case villa = "timeshare_type_villa"
    case apartment = "timeshare_type_apartment"
    case residence = "timeshare_type_residence"
}

extension TimeshareType {
    var localizedKey: LocalizedStringKey {
        LocalizedStringKey(self.rawValue)
    }
}

// MARK: - Quick Actions
enum QuickAction: String, CaseIterable {
    // Mevcut case'ler
    case rentTracking = "quick_action_rent_tracking"
    case expenseTracking = "quick_action_expense_tracking"
    case raiseRent = "quick_action_raise_rent"
    case renewContract = "quick_action_renew_contract"
    case archive = "quick_action_archive"
    case match = "quick_action_match"
    
    // Yeni case'ler
    case rentOut = "quick_action_rent_out"
    case listing = "quick_action_listing"
    case createRequest = "quick_action_create_request"
    case assignAgent = "quick_action_assign_agent"
    
    var title: String {
        switch self {
        // Mevcut title'lar
        case .rentTracking: return String(localized: "rent_tracking")
        case .expenseTracking: return String(localized: "expense_tracking")
        case .raiseRent: return String(localized: "raise_rent")
        case .renewContract: return String(localized: "renew_contract")
        case .archive: return String(localized: "archive")
        case .match: return String(localized: "match")
        
        // Yeni title'lar
        case .rentOut: return String(localized: "rent_out")
        case .listing: return String(localized: "to_listing")
        case .createRequest: return String(localized: "create_request")
        case .assignAgent: return String(localized: "assign_agent")
        }
    }
    
    var icon: String {
        switch self {
        // Mevcut iconlar
        case .rentTracking: return "creditcard.fill"
        case .expenseTracking: return "banknote.fill"
        case .raiseRent: return "percent"
        case .renewContract: return "doc.fill"
        case .archive: return "archivebox.fill"
        case .match: return "person.2.fill"
        
        // Yeni iconlar
        case .rentOut: return "key.fill"
        case .listing: return "megaphone.fill"
        case .createRequest: return "paperplane.fill"
        case .assignAgent: return "person.badge.key.fill"
        }
    }
    
    // Aksiyonların aktif/pasif durumunu kontrol eden computed property
    var isEnabled: (PropertyModel) -> Bool {
        switch self {
        case .rentTracking:
            return { property in
                property.rentalStatus == .rented &&
                (property.tenantPhone != nil || property.matchStatus != nil)
            }
        case .raiseRent, .renewContract:
            return { property in
                property.rentalStatus == .rented
            }
        case .rentOut:
            return { property in
                property.rentalStatus != .rented &&
                property.createdByUserType != .tenant
            }
        case .listing:
            return { property in
                property.createdByUserType != .tenant
            }
        case .createRequest:
            return { property in
                property.matchStatus != nil
            }
        case .assignAgent:
            return { property in
                property.agentPhone == nil &&
                property.createdByUserType == .owner
            }
        case .expenseTracking, .archive, .match:
            return { _ in true }
        }
    }
}
