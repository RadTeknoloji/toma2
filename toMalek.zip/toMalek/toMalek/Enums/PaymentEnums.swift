//
//  PaymentEnums.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation

enum PaymentMethod: String, Codable, CaseIterable {
    case cash = "payment_method_cash"
    case bankTransfer = "payment_method_bank_transfer"
    case creditCard = "payment_method_credit_card"
    case other = "payment_method_other"
    
    var localized: String {
        NSLocalizedString(self.rawValue, comment: "")
    }
}
