//
//  HomeView.swift
//  toMalek
//

import SwiftUI
import FirebaseAuth

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @StateObject private var listingViewModel = ListingViewModel()
    @State private var showingPersonnelView = false
    @State private var showingPortfolioView = false
    @State private var showingMyAgenciesView = false
    @State private var showingRequestsView = false
    @State private var showingListingsView = false
    @State private var showingDocumentsView = false
    @State private var showingFindAgencyView = false
    @State private var showingStatisticsView = false
    @EnvironmentObject var authState: AuthenticationState
    
    private let buttonHeight: CGFloat = 80
    private let gridSpacing: CGFloat = TLayout.spacingS
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Üst Kısım - Sabit Menu Grid
                ScrollView(showsIndicators: false) {
                    VStack(spacing: TLayout.spacingL) {
                        // Menu Grid
                        LazyVGrid(
                            columns: [
                                GridItem(.flexible(), spacing: gridSpacing),
                                GridItem(.flexible(), spacing: gridSpacing),
                                GridItem(.flexible(), spacing: gridSpacing)
                            ],
                            spacing: gridSpacing
                        ) {
                            if viewModel.isAgencyUser {
                                MenuButton(
                                    title: "home_menu_staff".localized(),
                                    systemImage: "person.2.fill",
                                    color: TColor.areapolPrimary,
                                    height: buttonHeight
                                ) {
                                    showingPersonnelView = true
                                }
                                
                                MenuButton(
                                    title: String(localized: "home_menu_portfolio"),
                                    systemImage: "briefcase.fill",
                                    color: TColor.areapolPrimary,
                                    height: buttonHeight
                                ) {
                                    showingPortfolioView = true
                                }
                            }
                            
                            if viewModel.isOwnerUser {
                                MenuButton(
                                    title: String(localized: "home_menu_agencies"),
                                    systemImage: "building.2.fill",
                                    color: TColor.areapolPrimary,
                                    height: buttonHeight
                                ) {
                                    showingMyAgenciesView = true
                                }
                            }
                            
                            MenuButton(
                                title: "home_menu_listings".localized(),
                                systemImage: "doc.text.fill",
                                color: TColor.areapolPrimary,
                                height: buttonHeight
                            ) {
                                showingListingsView = true
                            }
                            
                            MenuButton(
                                title: String(localized: "home_menu_requests"),
                                systemImage: "envelope.fill",
                                color: TColor.areapolPrimary,
                                height: buttonHeight
                            ) {
                                showingRequestsView = true
                            }
                            
                            // Tenant kullanıcıları için FindAgency butonu
                            if viewModel.activeUserType == .tenant {
                                MenuButton(
                                    title: String(localized: "home_menu_find_agency"),
                                    systemImage: "building.2.crop.circle",
                                    color: TColor.areapolPrimary,
                                    height: buttonHeight
                                ) {
                                    showingFindAgencyView = true
                                }
                            }
                            
                            MenuButton(
                                title: String(localized: "home_menu_statistics"),
                                systemImage: "chart.bar.fill",
                                color: TColor.areapolPrimary,
                                height: buttonHeight
                            ) {
                                showingStatisticsView = true
                            }
                            
                            MenuButton(
                                title: String(localized: "home_menu_documents"),
                                systemImage: "folder.fill",
                                color: TColor.areapolPrimary,
                                height: buttonHeight
                            ) {
                                showingDocumentsView = true
                            }
                        }
                        .padding(.horizontal, TLayout.spacingM)
                        .padding(.top, TLayout.spacingM)
                        
                        // Featured Listings Section
                        VStack(alignment: .leading, spacing: TLayout.spacingM) {
                            Text(String(localized: "home_featured_listings"))
                                .font(TFont.h3)
                                .foregroundColor(TColor.textPrimary)
                                .padding(.horizontal, TLayout.spacingM)
                            
                            LazyVGrid(
                                columns: Array(repeating:
                                    GridItem(.flexible(), spacing: TLayout.spacingS),
                                    count: 3
                                ),
                                spacing: TLayout.spacingS
                            ) {
                                ForEach(listingViewModel.listings.prefix(15)) { listing in
                                    FeaturedListingCard(listing: listing, listingViewModel: listingViewModel)
                                        .frame(height: 180)
                                }
                            }
                            .padding(.horizontal, TLayout.spacingM)
                        }
                        .padding(.vertical, TLayout.spacingM)
                    }
                }
            }
            .background(TColor.background)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    NavigationLink(destination: ProfileView()) {
                        HStack(spacing: TLayout.spacingS) {
                            Text(viewModel.userFullName)
                                .font(TFont.h3)
                                .foregroundColor(.white)
                            
                            Text("•")
                                .foregroundColor(.white.opacity(0.7))
                            
                            Text(viewModel.activeUserType.localizedText) // ✅ `localizedKey` yerine `localizedText` kullan
                                .font(TFont.bodyBold)
                                .foregroundColor(.white.opacity(0.9))
                        }
                    }
                }
            }
        }
        .loadingOverlay(isLoading: viewModel.isLoading)
        .alert(String(localized: "home_error_title"), isPresented: .constant(viewModel.errorMessage != nil)) {
            Button(String(localized: "home_error_ok"), role: .cancel) {
                viewModel.errorMessage = nil
            }
        } message: {
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
        .sheet(isPresented: $showingPersonnelView) {
            NavigationView {
                PersonnelView(authState: AuthenticationState.shared)
                    .environmentObject(authState)
            }
        }
        .sheet(isPresented: $showingPortfolioView) {
            NavigationView {
                PortfolioView(viewModel: PortfolioViewModel())
            }
        }
        .sheet(isPresented: $showingMyAgenciesView) {
            NavigationView {
                MyAgenciesView()
            }
        }
        .sheet(isPresented: $showingRequestsView) {
            NavigationView {
                RequestsView()
            }
        }
        .sheet(isPresented: $showingListingsView) {
            NavigationView {
                ListingsView()
            }
        }
        .sheet(isPresented: $showingDocumentsView) {
            NavigationView {
                Text(String(localized: "documents_view_placeholder"))
            }
        }
        .sheet(isPresented: $showingFindAgencyView) {
            FindAgencyView()
        }
        .sheet(isPresented: $showingStatisticsView) {
            NavigationView {
                StatisticsView()
            }
        }
    }
}

// MARK: - Menu Button
private struct MenuButton: View {
    let title: String
    let systemImage: String
    let color: Color
    let height: CGFloat
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: TLayout.spacingXS) {
                Image(systemName: systemImage)
                    .font(.system(size: 24))
                    .foregroundColor(color)
                
                Text(title)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textPrimary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(maxWidth: .infinity)
            .frame(height: height)
            .padding(TLayout.spacingXS)
            .background(
                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                    .fill(TColor.surface)
            )
            .shadow(
                color: TElevation.low.color,
                radius: TElevation.low.radius,
                x: TElevation.low.x,
                y: TElevation.low.y
            )
        }
    }
}

// MARK: - Featured Listing Card
private struct FeaturedListingCard: View {
    let listing: ListingModel
    @ObservedObject var listingViewModel: ListingViewModel
    
    var body: some View {
        NavigationLink {
            ListingDetailView(
                viewModel: listingViewModel,
                listing: listing,
                currentUserId: Auth.auth().currentUser?.uid ?? ""
            )
        } label: {
            VStack(alignment: .leading, spacing: TLayout.spacingXXS) {
                // Image with Type Badge
                ZStack(alignment: .top) {
                    if let firstImageUrl = listing.mediaUrls.first {
                        AsyncImage(url: URL(string: firstImageUrl)) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                                    .frame(height: 100)
                                    .frame(maxWidth: .infinity)
                            case .success(let image):
                                image
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 100)
                                    .frame(maxWidth: .infinity)
                            case .failure:
                                Image(systemName: "photo")
                                    .font(.system(size: 40))
                                    .foregroundColor(TColor.textSecondary)
                                    .frame(height: 100)
                                    .frame(maxWidth: .infinity)
                            @unknown default:
                                EmptyView()
                            }
                        }
                    } else {
                        Image(systemName: "photo")
                            .font(.system(size: 40))
                            .foregroundColor(TColor.textSecondary)
                            .frame(height: 100)
                            .frame(maxWidth: .infinity)
                    }
                    
                    // Type Badge
                    Text(listing.type.displayName)
                        .font(TFont.caption2)
                        .foregroundColor(TColor.onPrimary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(TColor.areapolPrimary)
                        .cornerRadius(TLayout.cornerRadiusS)
                        .padding(.top, 4)
                        .zIndex(1)
                }
                .clipShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                
                // Title
                Text(listing.title)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textPrimary)
                    .lineLimit(1)
                    .padding(.horizontal, 4)
                
                // Price
                Text("\(listing.price.formatted()) \(listing.currency.symbol)")
                    .font(TFont.caption)
                    .foregroundColor(TColor.textSecondary)
                    .padding(.horizontal, 4)
                
                // Location Tags
                HStack(spacing: 4) {
                    if let country = listing.property.country {
                        LocationTag(text: country)
                    }
                    if let state = listing.property.state {
                        LocationTag(text: state)
                    }
                    if let district = listing.property.district {
                        LocationTag(text: district)
                    }
                }
                .lineLimit(1)
                .padding(.horizontal, 4)
            }
            .padding(TLayout.spacingXXS)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            .frame(width: UIScreen.main.bounds.width / 3.5)
        }
    }
}

// MARK: - Location Tag
private struct LocationTag: View {
    let text: String
    
    var body: some View {
        Text(text)
            .font(TFont.caption2)
            .foregroundColor(TColor.textSecondary)
            .padding(.horizontal, 4)
            .padding(.vertical, 2)
            .background(TColor.background)
            .cornerRadius(TLayout.cornerRadiusXS)
    }
}

#Preview {
    HomeView()
}
