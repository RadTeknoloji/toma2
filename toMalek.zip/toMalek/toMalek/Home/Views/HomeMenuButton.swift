//
//  HomeMenuButton.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct HomeMenuButton: View {
    let title: String
    let systemImage: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 12) {
                Image(systemName: systemImage)
                    .font(.system(size: 32))
                    .foregroundColor(color)
                
                Text(title)
                    .font(.headline)
                    .foregroundColor(.areapolPrimary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.systemGray6))
            )
        }
    }
}

#Preview {
    HStack {
        HomeMenuButton(
            title: String(localized: "home_menu_staff"),
            systemImage: "person.2.fill",
            color: .blue
        ) {
            // Test action
        }
        
        HomeMenuButton(
            title: String(localized: "home_menu_statistics"),
            systemImage: "chart.bar.fill",
            color: .orange
        ) {
            // Test action
        }
    }
    .padding()
}
