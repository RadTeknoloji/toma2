//
//  HomeViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore
import SwiftUI

@MainActor
final class HomeViewModel: ObservableObject {
    @Published private(set) var userRole: String = ""
    @Published private(set) var userFullName: String = ""
    @Published private(set) var activeUserType: UserType = .tenant
    @Published var userTypes: Set<UserType> = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var isAgencyUser: Bool {
        activeUserType == .agency
    }

    var isOwnerUser: Bool {
        activeUserType == .owner
    }
    
    init() {
        print("DEBUG: HomeViewModel init")
        fetchUserProfile()
    }
    
    private func fetchUserProfile() {
        guard let userId = Auth.auth().currentUser?.uid else {
            print("DEBUG: No current user found")
            return
        }
        
        print("DEBUG: Fetching user profile for userId: \(userId)")
        isLoading = true
        let db = Firestore.firestore()
        
        db.collection("profiles")
            .document(userId)
            .addSnapshotListener { [weak self] documentSnapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("DEBUG: Error fetching user profile: \(error.localizedDescription)")
                    self.errorMessage = String(localized: "home_error_fetch_profile")
                    self.isLoading = false
                    return
                }
                
                guard let data = documentSnapshot?.data() else {
                    print("DEBUG: No profile data found")
                    self.isLoading = false
                    return
                }
                
                self.userFullName = data["fullName"] as? String ?? String(localized: "home_default_user_name")
                
                // Kullanıcı tiplerini al
                if let typeStrings = data["userTypes"] as? [String] {
                    self.userTypes = Set(typeStrings.compactMap { UserType(rawValue: $0) })
                }
                
                // Aktif kullanıcı tipini al
                if let activeTypeString = data["activeUserType"] as? String,
                   let activeType = UserType(rawValue: activeTypeString) {
                    self.activeUserType = activeType
                }
                
                self.isLoading = false
                print("DEBUG: User profile fetched successfully")
            }
    }
    
    func hasUserType(_ type: String) -> Bool {
        return userRole == type
    }
}
