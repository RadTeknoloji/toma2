//
//  StatisticsView.swift
//  toMalek
//
//  Created by Selman Erbay on 11.02.2025.
//

import SwiftUI
import Charts

struct StatisticsView: View {
    @StateObject private var viewModel = StatisticsViewModel()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Fixed Header
            VStack(spacing: TLayout.spacingS) {
                timeRangePicker
                    .padding(.horizontal, TLayout.padding)
                
                if viewModel.isLoading {
                    loadingView
                } else if viewModel.errorMessage != nil {
                    errorView
                }
            }
            .padding(.top, TLayout.paddingXS)
            .background(TColor.background)
            
            Divider()
                .background(TColor.background)
            
            // Scrollable Content
            ScrollView {
                VStack(spacing: TLayout.spacingL) {
                    if let statistics = viewModel.statistics {
                        if !viewModel.summaries.isEmpty {
                            summaryCardsGrid
                        }
                        
                        if !statistics.monthlyStats.isEmpty {
                            monthlyStatsSection(statistics)
                                .padding(.horizontal, TLayout.padding)
                        }
                    } else if !viewModel.isLoading && viewModel.errorMessage == nil {
                        emptyStateView
                    }
                }
                .padding(.vertical, TLayout.padding)
            }
            .background(TColor.background)
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationTitle(String(localized: "statistics_title"))
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(String(localized: "statistics_close")) {
                    dismiss()
                }
            }
        }
        .task {
            // İlk yükleme
            await viewModel.fetchStatisticsForRange()
        
        }
    }
    
    private var timeRangePicker: some View {
        Picker("", selection: $viewModel.selectedTimeRange.animation()) {
            ForEach(StatisticsViewModel.TimeRange.allCases, id: \.self) { range in
                Text(range.localizedName)
                    .tag(range as StatisticsViewModel.TimeRange?)
            }
        }
        .pickerStyle(.segmented)
    }
    
    private var summaryCardsGrid: some View {
        LazyVGrid(
            columns: [
                GridItem(.flexible(), spacing: TLayout.spacingM),
                GridItem(.flexible(), spacing: TLayout.spacingM)
            ],
            spacing: TLayout.spacingM
        ) {
            ForEach(viewModel.summaries, id: \.title) { summary in
                StatisticsSummaryCard(summary: summary)
            }
        }
        .padding(.horizontal, TLayout.padding)
    }
    
    private func monthlyStatsSection(_ statistics: StatisticsModel) -> some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Text(String(localized: "statistics_monthly_overview"))
                .font(TFont.h2)
                .foregroundColor(TColor.textPrimary)
            
            // Income/Expense Chart
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text(String(localized: "statistics_income_expenses"))
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                Chart {
                    ForEach(statistics.monthlyStats, id: \.month) { stat in
                        LineMark(
                            x: .value("Month", stat.month),
                            y: .value("Income", stat.income)
                        )
                        .foregroundStyle(TColor.success)
                        
                        LineMark(
                            x: .value("Month", stat.month),
                            y: .value("Expenses", stat.expenses)
                        )
                        .foregroundStyle(TColor.error)
                    }
                }
                .frame(height: 200)
                .chartLegend(position: .top)
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
            
            // Occupancy Rate Chart
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text(String(localized: "statistics_occupancy_rate"))
                    .font(TFont.bodyBold)
                    .foregroundColor(TColor.textPrimary)
                
                Chart {
                    ForEach(statistics.monthlyStats, id: \.month) { stat in
                        BarMark(
                            x: .value("Month", stat.month),
                            y: .value("Occupancy", stat.occupancyRate)
                        )
                        .foregroundStyle(TColor.areapolPrimary)
                    }
                }
                .frame(height: 200)
            }
            .padding(TLayout.padding)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    private var loadingView: some View {
        VStack {
            ProgressView()
                .scaleEffect(1.5)
            Text(String(localized: "statistics_loading"))
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
                .padding(.top, TLayout.spacingS)
        }
        .frame(height: 100)
    }
    
    private var errorView: some View {
        VStack(spacing: TLayout.spacingXS) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 24))
                .foregroundColor(TColor.error)
            
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.error)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: 300)
        .padding(.vertical, TLayout.spacingS)
        .padding(.horizontal, TLayout.padding)
        .background(TColor.error.opacity(0.1))
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: TLayout.spacingM) {
            Image(systemName: "chart.bar.xaxis")
                .font(.system(size: 48))
                .foregroundColor(TColor.textSecondary)
            
            Text(String(localized: "statistics_no_data"))
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
        }
        .padding(TLayout.padding)
    }
}

// MARK: - Summary Card Component
struct StatisticsSummaryCard: View {
    let summary: StatisticsSummary
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingS) {
            Text(summary.title)
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            
            Text(summary.value)
                .font(TFont.h3)
                .foregroundColor(TColor.textPrimary)
            
            HStack(spacing: TLayout.spacingXS) {
                Image(systemName: summary.trend.icon)
                Text("\(summary.percentage, specifier: "%.1f")%")
            }
            .font(TFont.caption)
            .foregroundColor(summary.trend.color)
        }
        .padding(TLayout.padding)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
        .shadow(
            color: TElevation.low.color,
            radius: TElevation.low.radius,
            x: TElevation.low.x,
            y: TElevation.low.y
        )
    }
}
