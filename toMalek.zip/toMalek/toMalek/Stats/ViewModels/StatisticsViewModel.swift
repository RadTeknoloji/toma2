//  StatisticsViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 11.02.2025.
//

import SwiftUI

@MainActor
final class StatisticsViewModel: ObservableObject {
    @Published private(set) var statistics: StatisticsModel?
    @Published private(set) var summaries: [StatisticsSummary] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var selectedTimeRange: TimeRange = .month {
        didSet {
            Task {
                await fetchStatisticsForRange()
            }
        }
    }
    
    private let propertyService: PropertyService
    private let rentPaymentService: RentPaymentService
    private let expenseService: ExpenseService
    
    enum TimeRange: String, CaseIterable {
        case week
        case month
        case quarter
        case year
        
        var localizedName: LocalizedStringKey {
            switch self {
            case .week: return "statistics_range_week"
            case .month: return "statistics_range_month"
            case .quarter: return "statistics_range_quarter"
            case .year: return "statistics_range_year"
            }
        }
    }
    
    init(
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
        expenseService: ExpenseService = ServiceContainer.shared.expenseService
    ) {
        self.propertyService = propertyService
        self.rentPaymentService = rentPaymentService
        self.expenseService = expenseService
    }
    
    func fetchStatisticsForRange() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let startDate = calculateStartDate(for: selectedTimeRange)
            let userType = ServiceContainer.shared.authenticationState.userType
            print("Debug: Active user type - \(userType)")
            print("Debug: Fetching statistics from \(startDate)")
            
            let properties = try await propertyService.fetchProperties()
            let rentPayments = try await rentPaymentService.fetchRentPayments()
            let expenses = try await expenseService.fetchExpenses()
            
            // Filter by date range
            let filteredRentPayments = rentPayments.filter { $0.whichMonth >= startDate }
            let filteredExpenses = expenses.filter { $0.createdDate >= startDate }
            
            switch userType {
            case "owner":
                try await calculateOwnerStatistics(
                    properties: properties,
                    rentPayments: filteredRentPayments,
                    expenses: filteredExpenses
                )
            case "tenant":
                try await calculateTenantStatistics(
                    properties: properties,
                    rentPayments: filteredRentPayments,
                    expenses: filteredExpenses
                )
            case "agency":
                try await calculateAgencyStatistics(
                    properties: properties,
                    rentPayments: filteredRentPayments,
                    expenses: filteredExpenses
                )
            default:
                errorMessage = String(localized: "statistics_error_unsupported_user_type")
            }
        } catch {
            errorMessage = error.localizedDescription
            print("Debug: Error fetching statistics - \(error)")
        }
    }
    
    private func calculateStartDate(for range: TimeRange) -> Date {
        let calendar = Calendar.current
        let now = Date()
        
        switch range {
        case .week:
            return calendar.date(byAdding: .day, value: -7, to: now) ?? now
        case .month:
            return calendar.date(byAdding: .month, value: -1, to: now) ?? now
        case .quarter:
            return calendar.date(byAdding: .month, value: -3, to: now) ?? now
        case .year:
            return calendar.date(byAdding: .year, value: -1, to: now) ?? now
        }
    }
    
    private func calculateOwnerStatistics(
        properties: [PropertyModel],
        rentPayments: [RentPaymentModel],
        expenses: [ExpenseModel]
    ) async throws {
        let totalProperties = properties.count
        let rentedProperties = properties.filter { $0.rentalStatus == .rented }.count
        let availableProperties = properties.filter { $0.rentalStatus == .available }.count
        
        // Toplam aylık kira geliri
        let monthlyRentIncome = properties
            .compactMap { $0.rentPrice }
            .reduce(0, +)
        
        // Bu ayki giderler
        let currentMonthExpenses = try await expenseService.calculateMonthlyExpenses(forMonth: Date())
        
        let monthlyStats = createMonthlyStats(rentPayments: rentPayments, expenses: expenses)
        
        let statistics = StatisticsModel(
            totalProperties: totalProperties,
            totalRentedProperties: rentedProperties,
            totalAvailableProperties: availableProperties,
            monthlyRentIncome: monthlyRentIncome,
            monthlyExpenses: currentMonthExpenses,
            currency: .try,
            totalMonthlyIncome: monthlyRentIncome - currentMonthExpenses,
            monthlyStats: monthlyStats
        )
        
        await MainActor.run {
            self.statistics = statistics
            self.summaries = createSummaries(from: statistics)
        }
    }
    
    private func calculateTenantStatistics(
        properties: [PropertyModel],
        rentPayments: [RentPaymentModel],
        expenses: [ExpenseModel]
    ) async throws {
        let totalProperties = properties.count
        let currentMonthExpenses = try await expenseService.calculateMonthlyExpenses(forMonth: Date())
        
        // Toplam ödenen kira
        let totalPaidRent = rentPayments
            .filter { $0.rentPaymentStatus == .paid }
            .reduce(0) { $0 + $1.rentAmountPaid }
        
        // Toplam ödenen giderler
        let totalPaidExpenses = expenses
            .filter { $0.expenseStatus == .paid }
            .reduce(0) { $0 + $1.expenseAmount }
        
        let monthlyStats = createMonthlyStats(rentPayments: rentPayments, expenses: expenses)
        
        let statistics = StatisticsModel(
            totalProperties: totalProperties,
            totalRentedProperties: totalProperties,
            totalAvailableProperties: 0,
            monthlyRentIncome: 0,
            monthlyExpenses: currentMonthExpenses,
            currency: .try,
            totalPaidRent: totalPaidRent,
            totalPaidExpenses: totalPaidExpenses,
            monthlyStats: monthlyStats
        )
        
        await MainActor.run {
            self.statistics = statistics
            self.summaries = createSummaries(from: statistics)
        }
    }
    
    private func calculateAgencyStatistics(
        properties: [PropertyModel],
        rentPayments: [RentPaymentModel],
        expenses: [ExpenseModel]
    ) async throws {
        let totalPortfolio = properties.count
        let totalListings = properties.filter { $0.listingStatus == .published }.count
        let rentedProperties = properties.filter { $0.rentalStatus == .rented }.count
        
        let monthlyStats = createMonthlyStats(rentPayments: rentPayments, expenses: expenses)
        
        let statistics = StatisticsModel(
            totalProperties: totalPortfolio,
            totalRentedProperties: rentedProperties,
            totalAvailableProperties: totalPortfolio - rentedProperties,
            monthlyRentIncome: 0,
            monthlyExpenses: 0,
            currency: .try,
            totalPortfolio: totalPortfolio,
            totalListings: totalListings,
            monthlyStats: monthlyStats
        )
        
        await MainActor.run {
            self.statistics = statistics
            self.summaries = createSummaries(from: statistics)
        }
    }
    
    private func createMonthlyStats(
        rentPayments: [RentPaymentModel],
        expenses: [ExpenseModel]
    ) -> [StatisticsModel.MonthlyStatistics] {
        // Son 6 ay için aylık istatistikler
        let calendar = Calendar.current
        var stats: [StatisticsModel.MonthlyStatistics] = []
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM yyyy"
        
        for monthOffset in (0...5).reversed() {
            guard let date = calendar.date(byAdding: .month, value: -monthOffset, to: Date()) else {
                continue
            }
            
            let monthRentPayments = rentPayments.filter {
                calendar.isDate($0.whichMonth, equalTo: date, toGranularity: .month)
            }
            
            let monthExpenses = expenses.filter {
                calendar.isDate($0.createdDate, equalTo: date, toGranularity: .month)
            }
            
            let income = monthRentPayments.reduce(0) { $0 + $1.rentAmountPaid }
            let expenses = monthExpenses.reduce(0) { $0 + $1.expenseAmount }
            let occupancyRate = Double(monthRentPayments.filter { $0.rentPaymentStatus == .paid }.count) /
            Double(monthRentPayments.count) * 100
            
            stats.append(StatisticsModel.MonthlyStatistics(
                month: dateFormatter.string(from: date),
                income: income,
                expenses: expenses,
                occupancyRate: occupancyRate
            ))
        }
        
        return stats
    }
    
    private func createSummaries(from statistics: StatisticsModel) -> [StatisticsSummary] {
        var summaries: [StatisticsSummary] = []
        
        // Property summaries
        summaries.append(StatisticsSummary(
            title: "Total Properties",
            value: "\(statistics.totalProperties)",
            trend: .neutral,
            percentage: 0
        ))
        
        // Financial summaries
        if statistics.monthlyRentIncome > 0 {
            summaries.append(StatisticsSummary(
                title: "Monthly Income",
                value: "\(statistics.monthlyRentIncome.formatted()) \(statistics.currency.symbol)",
                trend: .up,
                percentage: 100
            ))
        }
        
        // Occupancy rate
        let occupancyRate = Double(statistics.totalRentedProperties) /
        Double(statistics.totalProperties) * 100
        summaries.append(StatisticsSummary(
            title: "Occupancy Rate",
            value: "\(Int(occupancyRate))%",
            trend: occupancyRate > 80 ? .up : .down,
            percentage: occupancyRate
        ))
        
        return summaries
    }
}
