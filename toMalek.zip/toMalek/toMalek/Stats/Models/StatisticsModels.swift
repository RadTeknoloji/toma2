//  StatisticsModel.swift
//  toMalek
//
//  Created by Selman Erbay on 11.02.2025.
//

import Foundation
import SwiftUI

struct StatisticsModel: Codable {
    let totalProperties: Int
    let totalRentedProperties: Int
    let totalAvailableProperties: Int
    let monthlyRentIncome: Double
    let monthlyExpenses: Double
    let currency: CurrencyType
    
    // Agency specific
    var totalPortfolio: Int?
    var totalListings: Int?
    var totalPersonnel: Int?
    
    // Owner specific
    var totalMonthlyIncome: Double?
    var propertyValueEstimate: Double?
    
    // Tenant specific
    var totalPaidRent: Double?
    var totalPaidExpenses: Double?
    var averageMonthlyExpenses: Double?
    
    // Monthly statistics for charts
    var monthlyStats: [MonthlyStatistics]
    
    struct MonthlyStatistics: Codable {
        let month: String
        let income: Double
        let expenses: Double
        let occupancyRate: Double
    }
}

struct StatisticsSummary: Codable {
    let title: String
    let value: String
    let trend: StatisticsTrend
    let percentage: Double
    
    enum StatisticsTrend: String, Codable {
        case up, down, neutral
        
        var color: Color {
            switch self {
            case .up: return TColor.success
            case .down: return TColor.error
            case .neutral: return TColor.textSecondary
            }
        }
        
        var icon: String {
            switch self {
            case .up: return "arrow.up.right.circle.fill"
            case .down: return "arrow.down.right.circle.fill"
            case .neutral: return "arrow.right.circle.fill"
            }
        }
    }
}
