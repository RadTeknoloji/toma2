//
//  ListingViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import UIKit

@MainActor
final class ListingViewModel: ObservableObject {
    // MARK: - Services
    private let db = Firestore.firestore()
    private let currentUserId: String?
    
    // MARK: - Published Properties
    @Published var listings: [ListingModel] = []
    @Published var selectedListing: ListingModel?
    @Published var userProperties: [PropertyModel] = []
    @Published var selectedProperty: PropertyModel?
    @Published var listingType: ListingType = .rent
    @Published var title = ""
    @Published var description = ""
    @Published var price = ""
    @Published var currency: CurrencyType = .try
    @Published var mediaUrls: [String] = []  // ModulMedia URL'leri için yeni property
    @Published var selectedTab = 0
    @Published var errorMessage: String?
    @Published var isLoading = false
    @Published var userType: UserType = .tenant
    @Published var userProfiles: [String: ProfilModel] = [:]
    
    // MARK: - Computed Properties
    var filteredListings: [ListingModel] {
         selectedTab == 0 ? listings : listings.filter { $0.isFavorited }
     }
     
     var isValidForm: Bool {
         guard let selectedProperty = selectedProperty,
               !title.isEmpty,
               !description.isEmpty,
               !price.isEmpty,
               let priceValue = Double(price.replacingOccurrences(of: ",", with: ".")),
               priceValue > 0,
               isPropertyAvailableForListing(selectedProperty) else {
             return false
         }
         return true
     }
    
    // MARK: - Initialization
    init() {
        self.currentUserId = Auth.auth().currentUser?.uid
        
        Task { @MainActor in
            await self.fetchUserType()
            await self.fetchUserProperties()
            self.fetchListings()
        }
    }
    
    // MARK: - User Type Management
    private func fetchUserType() async {
        guard let userId = currentUserId else {
            print("No current user ID")
            return
        }
        
        do {
            let docRef = db.collection("profiles").document(userId)
            let snapshot = try await docRef.getDocument()
            
            if let data = snapshot.data(),
               let activeTypeString = data["activeUserType"] as? String,
               let activeType = UserType(rawValue: activeTypeString) {
                self.userType = activeType
            } else {
                self.userType = .tenant
            }
        } catch {
            print("Error fetching user type:", error)
            self.errorMessage = "Kullanıcı tipi alınamadı: \(error.localizedDescription)"
            self.userType = .tenant
        }
    }
    
    // MARK: - Listing Management
    func createListing() async -> Bool {
        guard let userId = currentUserId,
              let property = selectedProperty,
              isValidForm,
              let priceValue = Double(price.replacingOccurrences(of: ",", with: ".")) else {
            errorMessage = String(localized: "listing_error_fill_all_fields")
            return false
        }
        
        isLoading = true
        defer { isLoading = false }
        
        if !isPropertyAvailableForListing(property) {
            errorMessage = String(localized: "listing_error_property_already_listed")
            return false
        }
        
        do {
            let newListing = ListingModel(
                property: property,
                status: .active,
                type: listingType,
                price: priceValue,
                currency: currency,
                createdBy: userId,
                title: title.uppercased(),
                description: description,
                mediaUrls: []
            )
            
            let ref = db.collection("listings").document(newListing.id.uuidString)
            try await ref.setData(newListing.toUpdateData())
            try await updatePropertyListingStatus(property.id.uuidString, type: listingType)
            clearForm()
            return true
        } catch {
            errorMessage = String(format: String(localized: "listing_error_create"), error.localizedDescription)
            return false
        }
    }
    
    // MARK: - Listing Creation Methods
        func createListing(property: PropertyModel, type: ListingType, price: Double, title: String, description: String) async {
            guard let userId = currentUserId else { return }
            
            isLoading = true
            defer { isLoading = false }
            
            do {
                let listing = ListingModel(
                    property: property,
                    status: .active,
                    type: type,
                    price: price,
                    currency: .try,
                    createdBy: userId,
                    createdAt: Date(),
                    updatedAt: Date(),
                    title: title,
                    description: description,
                    mediaUrls: mediaUrls,
                    interestedUsers: [],
                    reservationRequests: [],
                    currentReservation: nil
                )
                
                let docRef = db.collection("listings").document(listing.id.uuidString)
                try await docRef.setData(listing.toUpdateData())
                
                await MainActor.run {
                    listings.append(listing)
                    resetListingForm()
                }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    
    func fetchListings() {
        guard Auth.auth().currentUser != nil else {
            errorMessage = String(localized: "listing_error_user_not_logged_in")
            return
        }
        
        isLoading = true
        db.collection("listings").addSnapshotListener { [weak self] querySnapshot, error in
            guard let self = self else { return }
            
            if let error = error {
                self.errorMessage = String(format: String(localized: "listing_error_fetch_data"), error.localizedDescription)
                return
            }
            
            self.listings = querySnapshot?.documents.compactMap { doc in
                try? doc.data(as: ListingModel.self)
            } ?? []
            
            self.isLoading = false
        }
    }
    
    // MARK: - Listing Actions
    func toggleFavorite(_ listing: ListingModel) async {
        guard let userId = currentUserId else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("listings").document(listing.id.uuidString)
            let updateData = [
                "favoritedUsers": listing.isFavorited ?
                FieldValue.arrayRemove([userId]) :
                    FieldValue.arrayUnion([userId])
            ] as [String: Any]
            
            try await updateDocument(ref, data: updateData)
        } catch {
            errorMessage = String(format: String(localized: "listing_error_favorite_update"), error.localizedDescription)
        }
    }
    
    func showInterest(_ listing: ListingModel) async {
        guard let userId = currentUserId else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("listings").document(listing.id.uuidString)
            let updateData = [
                "interestedUsers": FieldValue.arrayUnion([userId])
            ] as [String: Any]
            
            try await updateDocument(ref, data: updateData)
        } catch {
            errorMessage = String(format: String(localized: "listing_error_interest_update"), error.localizedDescription)
        }
    }
    
    func requestReservation(_ listing: ListingModel) async {
        guard let userId = currentUserId else { return }
        let listingOwnerId = listing.createdBy
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let request = ReservationRequest(
                userId: userId,
                userName: String(localized: "listing_default_user_name")
            )
            
            var updatedListing = listing
            updatedListing.reservationRequests.append(request)
            
            let docRef = db.collection("listings").document(listing.id.uuidString)
            try await docRef.updateData(updatedListing.toUpdateData())
            
            if let index = listings.firstIndex(where: { $0.id == listing.id }) {
                listings[index] = updatedListing
            }
            
            try await createReservationRequest(for: listing, from: userId, to: listingOwnerId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func handleReservationRequest(_ listing: ListingModel, request: ReservationRequest, approved: Bool) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let docRef = db.collection("listings").document(listing.id.uuidString)
            
            var updatedRequests = listing.reservationRequests
            if let index = updatedRequests.firstIndex(where: { $0.id == request.id }) {
                var updatedRequest = updatedRequests[index]
                updatedRequest.status = approved ? .approved : .rejected
                updatedRequests[index] = updatedRequest
            }
            
            let data: [String: Any] = [
                "reservationRequests": updatedRequests.map { [
                    "id": $0.id,
                    "userId": $0.userId,
                    "requestDate": $0.requestDate,
                    "status": $0.status.rawValue
                ] }
            ]
            
            try await docRef.updateData(data)
            
            if let index = listings.firstIndex(where: { $0.id == listing.id }) {
                listings[index].reservationRequests = updatedRequests
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    func cancelReservation(_ listing: ListingModel) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let ref = db.collection("listings").document(listing.id.uuidString)
            let updateData: [String: Any] = [
                "status": listing.type == .sale ? ListingStatus.closed.rawValue : ListingStatus.active.rawValue,
                "currentReservation": NSNull(),
                "updatedAt": FieldValue.serverTimestamp()
            ]
            
            try await updateDocument(ref, data: updateData)
        } catch {
            errorMessage = String(format: String(localized: "listing_error_reservation_cancel"), error.localizedDescription)
        }
    }
    
    func deleteListing(_ listing: ListingModel) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let docRef = db.collection("listings").document(listing.id.uuidString)
            try await docRef.delete()
            
            listings.removeAll { $0.id == listing.id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    // MARK: - Property Management
    func fetchUserProperties() async {
        guard let userId = currentUserId else { return }
        
        isLoading = true
        defer { isLoading = false }
        
        do {
            let properties = try await ServiceContainer.shared.propertyService.fetchProperties()
            userProperties = properties.filter { property in
                property.createdBy == userId ||
                (userType == .agency && property.agentName != nil)
            }
        } catch {
            errorMessage = String(format: String(localized: "listing_error_property_fetch"), error.localizedDescription)
        }
    }
    
    private func isPropertyAvailableForListing(_ property: PropertyModel) -> Bool {
        switch listingType {
        case .sale:
            return property.saleStatus == .available
        case .rent:
            return property.rentalStatus == .available
        }
    }
    
    private func updatePropertyListingStatus(_ propertyId: String, type: ListingType) async throws {
        let ref = db.collection("properties").document(propertyId)
        let updateData: [String: Any] = type == .sale ?
        [
            "saleStatus": SaleStatus.forSale.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ] :
        [
            "rentalStatus": RentalStatus.rented.rawValue,
            "updatedAt": FieldValue.serverTimestamp()
        ]
        
        try await updateDocument(ref, data: updateData)
    }
    
    // MARK: - Profile Management
    private func fetchUserProfile(userId: String) async -> ProfilModel? {
        do {
            let docRef = db.collection("profiles").document(userId)
            let document = try await docRef.getDocument()
            
            if let profile = try? document.data(as: ProfilModel.self) {
                userProfiles[userId] = profile
                return profile
            }
        } catch {
            print("Error fetching user profile: \(error)")
        }
        return nil
    }
    
    func getListingUserProfile(_ listing: ListingModel) async -> ProfilModel? {
        if let profile = userProfiles[listing.createdBy] {
            return profile
        }
        return await fetchUserProfile(userId: listing.createdBy)
    }
    
    // MARK: - Helper Methods
    private func createReservationRequest(for listing: ListingModel, from userId: String, to ownerId: String) async throws {
        let request = RequestModel(
            id: UUID(),
            title: String(localized: "listing_reservation_request_title"),
            requestDescription: String(format: String(localized: "listing_reservation_request_description"), listing.title),
            category: .reservation,
            status: .pending,
            propertyID: listing.property.id.uuidString,
            propertyTitle: listing.property.title,
            fromUserID: userId,
            fromUserType: "tenant",
            toUserID: ownerId,
            toUserType: "owner",
            createdAt: Date(),
            updatedAt: Date()
        )
        
        let ref = db.collection("requests").document(request.id.uuidString)
        try await ref.setData(request.toUpdateData())
    }
    
    @MainActor
    private func updateDocument(_ ref: DocumentReference, data: [String: Any]) async throws {
        try await ref.updateData(data)
    }
    
    private func clearForm() {
        selectedProperty = nil
        listingType = .rent
        title = ""
        description = ""
        price = ""
        currency = .try
    }
    
    func resetListingForm() {
            selectedProperty = nil
            listingType = .rent
            title = ""
            description = ""
            price = ""
            currency = .try
            mediaUrls = []  // Media URL'lerini temizle
        }
}

// MARK: - Extensions
extension RequestModel: FirestoreUpdateData {
    func toUpdateData() -> [String: Any] {
        return [
            "id": id.uuidString,
            "title": title,
            "requestDescription": requestDescription,
            "category": category.rawValue,
            "propertyID": propertyID,
            "propertyTitle": propertyTitle,
            "fromUserID": fromUserID,
            "fromUserType": fromUserType,
            "toUserID": toUserID,
            "toUserType": toUserType,
            "canBeModified": canBeModified,
            "createdAt": createdAt,
            "updatedAt": updatedAt,
            "status": status.rawValue
                    ]
                }
            }

            // MARK: - Protocol Conformance
            protocol FirestoreUpdateData {
                func toUpdateData() -> [String: Any]
            }

            struct ReservationRequestData: Sendable, FirestoreUpdateData {
                let id: String
                let userId: String
                let userName: String
                let requestDate: Date
                let status: String
                
                func toUpdateData() -> [String: Any] {
                    return [
                        "id": id,
                        "userId": userId,
                        "userName": userName,
                        "requestDate": requestDate,
                        "status": status
                    ]
                }
            }
