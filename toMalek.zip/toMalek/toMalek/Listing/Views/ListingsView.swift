//
//  ListingsView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct ListingsView: View {
    @StateObject private var viewModel = ListingViewModel()
    @EnvironmentObject var authState: AuthenticationState
    @State private var showingCreateForm = false
    @State private var showingTenantAlert = false
    @Environment(\.presentationMode) var presentationMode
    
    // Search and Filter States
    @State private var searchText = ""
    @State private var showFilters = false
    @State private var selectedListingType: ListingType?
    @State private var selectedPropertyType: PropertyType?
    @State private var selectedPropertySubType: String?
    @State private var selectedCountry: String?
    @State private var selectedState: String?
    @State private var selectedDistrict: String?
    @State private var selectedNeighborhood: String?
    @State private var minPrice: String = ""
    @State private var maxPrice: String = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Search and Filter Header
                searchAndFilterHeader
                    .padding(.top, 8)
                
                // Filter Sheet
                if showFilters {
                    filterSection
                }
                
                // Fixed Tabs Header
                segmentedTabs
                    .padding(.vertical, 8)
                
                // Listings Content
                listingsContent
                    .refreshable {
                        Task {
                             viewModel.fetchListings()
                        }
                    }
            }
            .navigationTitle(String(localized: "listings_title"))
            .navigationBarTitleDisplayMode(.inline)
            .applyNavigationBarStyle()
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    createButton
                }
            }
            .sheet(isPresented: $showingCreateForm) {
                NavigationStack {
                    CreateListingView(
                        viewModel: viewModel,
                        isPresented: $showingCreateForm,
                        onComplete: { success in
                            if success {
                                showingCreateForm = false
                            }
                        }
                    )
                }
            }
            .alert(String(localized: "listings_create_alert_title"),
                   isPresented: $showingTenantAlert) {
                Button(String(localized: "listings_create_alert_go_profile")) {
                    presentationMode.wrappedValue.dismiss()
                }
                Button(String(localized: "common_cancel"), role: .cancel) { }
            } message: {
                Text(String(localized: "listings_create_alert_message"))
                    .font(TFont.body)
            }
        }
    } 
    private var createButton: some View {
        Button {
            handleCreateButtonTap()
        } label: {
            Image(systemName: "plus")
                .font(.system(size: TLayout.iconSize))
                .foregroundColor(TColor.areapolPrimary)
        }
    }
    
    private func handleCreateButtonTap() {
        if viewModel.userType == .owner || viewModel.userType == .agency {
            showingCreateForm = true
        } else {
            showingTenantAlert = true
        }
    }
    
    
    private var createFormSheet: some View {
        NavigationView {
            CreateListingView(
                viewModel: viewModel,
                isPresented: $showingCreateForm,
                onComplete: { success in
                    if success {
                        showingCreateForm = false
                    }
                }
            )
        }
    }
    // MARK: - Search and Filter Header
    private var searchAndFilterHeader: some View {
        VStack(spacing: TLayout.spacingXS) {
            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(TColor.textSecondary)
                TextField(String(localized: "search_placeholder"), text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                
                if !searchText.isEmpty {
                    Button(action: { searchText = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(TColor.textSecondary)
                    }
                }
            }
            .padding(.horizontal, TLayout.spacingS)
            
            // Filter Toggle Button
            Button(action: { withAnimation { showFilters.toggle() } }) {
                HStack {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                    Text(String(localized: showFilters ? "hide_filters" : "show_filters"))
                }
                .foregroundColor(TColor.areapolPrimary)
            }
            
            if hasActiveFilters {
                Button(action: clearFilters) {
                    HStack(spacing: 4) {
                        Image(systemName: "xmark.circle.fill")
                        Text(String(localized: "clear_filters"))
                    }
                    .foregroundColor(TColor.error)
                }
            }
        }
        .padding(.top, 1)
        .background(TColor.background)
    }
    
    // MARK: - Filter Section
    private var filterSection: some View {
        VStack(spacing: TLayout.spacingM) {
            ScrollView {
                VStack(spacing: TLayout.spacingL) {
                    // İlan Tipi ve Mülk Tipi Filtreleri
                    HStack(spacing: TLayout.spacingL) {
                        // İlan Tipi Filtresi
                        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                            Text(String(localized: "listing_type"))
                                .font(TFont.footnoteBold)
                                .foregroundColor(TColor.textPrimary)
                            
                            ForEach(ListingType.allCases, id: \.self) { type in
                                FilterChip(
                                    title: LocalizedStringKey(type.displayName),
                                    isSelected: Binding(
                                        get: { selectedListingType == type },
                                        set: { if $0 { selectedListingType = type } else { selectedListingType = nil } }
                                    )
                                )
                            }
                        }
                        .frame(maxWidth: .infinity)
                        
                        // Mülk Tipi Filtresi
                        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                            Text(String(localized: "property_type"))
                                .font(TFont.footnoteBold)
                                .foregroundColor(TColor.textPrimary)
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(PropertyType.allCases, id: \.self) { type in
                                        FilterChip(
                                            title: LocalizedStringKey(type.rawValue.localized()),
                                            isSelected: Binding(
                                                get: { selectedPropertyType == type },
                                                set: { if $0 { selectedPropertyType = type } else { selectedPropertyType = nil } }
                                            )
                                        )
                                    }
                                }
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                    
                    Divider()
                        .background(TColor.border.opacity(0.3))
                    
                    // Konum Filtreleri
                    VStack(alignment: .leading, spacing: TLayout.spacingM) {
                        Text(String(localized: "location"))
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                        
                        VStack(spacing: TLayout.spacingS) {
                            // Ülke Seçimi
                            HStack {
                                Image(systemName: "globe")
                                    .foregroundColor(TColor.textSecondary)
                                Picker(String(localized: "country"), selection: $selectedCountry) {
                                    Text(String(localized: "select_country"))
                                        .tag(Optional<String>.none)
                                    ForEach(getAvailableCountries(), id: \.self) { country in
                                        Text(country).tag(Optional(country))
                                    }
                                }
                                .tint(TColor.textPrimary)
                            }
                            .padding(.horizontal, TLayout.spacingS)
                            .padding(.vertical, TLayout.spacingXS)
                            .background(TColor.surface)
                            .cornerRadius(TLayout.cornerRadius)
                            
                            if selectedCountry != nil {
                                HStack {
                                    Image(systemName: "mappin")
                                        .foregroundColor(TColor.textSecondary)
                                    Picker(String(localized: "state"), selection: $selectedState) {
                                        Text(String(localized: "select_state"))
                                            .tag(Optional<String>.none)
                                        ForEach(getAvailableStates(), id: \.self) { state in
                                            Text(state).tag(Optional(state))
                                        }
                                    }
                                    .tint(TColor.textPrimary)
                                }
                                .padding(.horizontal, TLayout.spacingS)
                                .padding(.vertical, TLayout.spacingXS)
                                .background(TColor.surface)
                                .cornerRadius(TLayout.cornerRadius)
                                
                                if selectedState != nil {
                                    HStack {
                                        Image(systemName: "mappin.circle")
                                            .foregroundColor(TColor.textSecondary)
                                        Picker(String(localized: "district"), selection: $selectedDistrict) {
                                            Text(String(localized: "select_district"))
                                                .tag(Optional<String>.none)
                                            ForEach(getAvailableDistricts(), id: \.self) { district in
                                                Text(district).tag(Optional(district))
                                            }
                                        }
                                        .tint(TColor.textPrimary)
                                    }
                                    .padding(.horizontal, TLayout.spacingS)
                                    .padding(.vertical, TLayout.spacingXS)
                                    .background(TColor.surface)
                                    .cornerRadius(TLayout.cornerRadius)
                                }
                            }
                        }
                    }
                    
                    Divider()
                        .background(TColor.border.opacity(0.3))
                    
                    // Fiyat Aralığı Filtresi
                    VStack(alignment: .leading, spacing: TLayout.spacingS) {
                        Text(String(localized: "price_range"))
                            .font(TFont.footnoteBold)
                            .foregroundColor(TColor.textPrimary)
                        
                        HStack(spacing: TLayout.spacingM) {
                            // Minimum Fiyat
                            HStack {
                                Image(systemName: "turkishlirasign")
                                    .foregroundColor(TColor.textSecondary)
                                TextField(String(localized: "min_price"), text: $minPrice)
                                    .keyboardType(.numberPad)
                                    .foregroundColor(TColor.textPrimary)
                            }
                            .padding(.horizontal, TLayout.spacingS)
                            .padding(.vertical, TLayout.spacingXS)
                            .background(TColor.surface)
                            .cornerRadius(TLayout.cornerRadius)
                            
                            Text("-")
                                .foregroundColor(TColor.textSecondary)
                            
                            // Maksimum Fiyat
                            HStack {
                                Image(systemName: "turkishlirasign")
                                    .foregroundColor(TColor.textSecondary)
                                TextField(String(localized: "max_price"), text: $maxPrice)
                                    .keyboardType(.numberPad)
                                    .foregroundColor(TColor.textPrimary)
                            }
                            .padding(.horizontal, TLayout.spacingS)
                            .padding(.vertical, TLayout.spacingXS)
                            .background(TColor.surface)
                            .cornerRadius(TLayout.cornerRadius)
                        }
                    }
                }
                .padding()
            }
            
            // Butonlar
            VStack(spacing: TLayout.spacingS) {
                Button(action: applyFilters) {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                        Text(String(localized: "apply_filters"))
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(TColor.areapolPrimary)
                    .foregroundColor(TColor.onPrimary)
                    .cornerRadius(TLayout.cornerRadius)
                }
                
                Button(action: clearFilters) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text(String(localized: "clear_filters"))
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(TColor.surface)
                    .foregroundColor(TColor.textPrimary)
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, TLayout.spacingS)
        }
        .background(TColor.background)
    }

    private struct FilterChip: View {
        let title: LocalizedStringKey
        @Binding var isSelected: Bool
        
        var body: some View {
            Button(action: { isSelected.toggle() }) {
                Text(title)
                    .font(TFont.caption)
                    .padding(.horizontal, TLayout.spacingS)
                    .padding(.vertical, TLayout.spacingXXS)
                    .background(isSelected ? TColor.areapolPrimary : TColor.surface)
                    .foregroundColor(isSelected ? TColor.onPrimary : TColor.textPrimary)
                    .cornerRadius(TLayout.cornerRadius)
                    .overlay(
                        RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                            .stroke(isSelected ? TColor.areapolPrimary : TColor.border.opacity(0.3), lineWidth: 1)
                    )
            }
        }
    }

private var hasActiveFilters: Bool {
    selectedListingType != nil ||
    selectedPropertyType != nil ||
    selectedPropertySubType != nil ||
    selectedCountry != nil ||
    selectedState != nil ||
    selectedDistrict != nil ||
    selectedNeighborhood != nil ||
    !minPrice.isEmpty ||
    !maxPrice.isEmpty ||
    !searchText.isEmpty
}
    
    private var emptyContentView: some View {
        ContentUnavailableView(
            viewModel.selectedTab == 0 ?
            String(localized: "listings_empty_all") :
            String(localized: "listings_empty_favorites"),
            systemImage: "doc.text.fill",
            description: Text(viewModel.selectedTab == 0 ?
                            String(localized: "listings_empty_all_description") :
                            String(localized: "listings_empty_favorites_description"))
        )
        .padding(.top, TLayout.padding)
    }
    
    // MARK: - Segmented Tabs
    private var segmentedTabs: some View {
        Picker("", selection: $viewModel.selectedTab) {
            Text(String(localized: "listings_tab_all")).tag(0)
            Text(String(localized: "listings_tab_favorites")).tag(1)
        }
        .pickerStyle(.segmented)
        .padding()
    }
    
    // MARK: - Listings Content
    private var listingsContent: some View {
        Group {
            if viewModel.filteredListings.isEmpty {
                emptyContentView
            } else {
                ScrollView {
                    LazyVStack(spacing: TLayout.spacingS) {
                        ForEach(getFilteredListings()) { listing in
                            NavigationLink {
                                ListingDetailView(
                                    viewModel: viewModel,
                                    listing: listing,
                                    currentUserId: authState.currentUser?.uid ?? ""
                                )
                            } label: {
                                ListingRowView(listing: listing)
                                    .padding(.horizontal)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical)
                }
            }
        }
    }
    
    // MARK: - Helper Functions
    private func getFilteredListings() -> [ListingModel] {
        viewModel.filteredListings.filter { listing in
            var matches = true
            
            // Search Text Filter
            if !searchText.isEmpty {
                matches = matches && (
                    listing.title.localizedCaseInsensitiveContains(searchText) ||
                    listing.property.formattedAddress?.localizedCaseInsensitiveContains(searchText) ?? false ||
                    listing.description.localizedCaseInsensitiveContains(searchText)
                )
            }
            
            // Listing Type Filter
            if let listingType = selectedListingType {
                matches = matches && listing.type == listingType
            }
            
            // Property Type Filter
            if let propertyType = selectedPropertyType {
                matches = matches && listing.property.propertyType == propertyType
            }
            
            // Location Filters
            if let country = selectedCountry {
                matches = matches && listing.property.country == country
            }
            if let state = selectedState {
                matches = matches && listing.property.state == state
            }
            if let district = selectedDistrict {
                matches = matches && listing.property.district == district
            }
            if let neighborhood = selectedNeighborhood {
                matches = matches && listing.property.neighborhood == neighborhood
            }
            
            // Price Range Filter
            if let minPriceValue = Double(minPrice) {
                matches = matches && listing.price >= minPriceValue
            }
            if let maxPriceValue = Double(maxPrice) {
                matches = matches && listing.price <= maxPriceValue
            }
            
            return matches
        }
    }
    
    private func getAvailableCountries() -> [String] {
        let countries = Set(viewModel.listings.compactMap { $0.property.country })
        return Array(countries).sorted()
    }
    
    private func getAvailableStates() -> [String] {
        let states = Set(viewModel.listings.filter { $0.property.country == selectedCountry }
            .compactMap { $0.property.state })
        return Array(states).sorted()
    }
    
    private func getAvailableDistricts() -> [String] {
        let districts = Set(viewModel.listings
            .filter { $0.property.country == selectedCountry && $0.property.state == selectedState }
            .compactMap { $0.property.district })
        return Array(districts).sorted()
    }
    
    private func getAvailableNeighborhoods() -> [String] {
        let neighborhoods = Set(viewModel.listings
            .filter { $0.property.country == selectedCountry &&
                     $0.property.state == selectedState &&
                     $0.property.district == selectedDistrict }
            .compactMap { $0.property.neighborhood })
        return Array(neighborhoods).sorted()
    }
    
    private func applyFilters() {
        withAnimation {
            showFilters = false
        }
    }
    
    private func clearFilters() {
        selectedListingType = nil
        selectedPropertyType = nil
        selectedPropertySubType = nil
        selectedCountry = nil
        selectedState = nil
        selectedDistrict = nil
        selectedNeighborhood = nil
        minPrice = ""
        maxPrice = ""
        searchText = ""
    }
}

// MARK: - Supporting Views
struct ListingFilterChip: View {
    let title: String
    @Binding var isSelected: Bool
    
    var body: some View {
        Button(action: { isSelected.toggle() }) {
            Text(title)
                .font(TFont.footnote)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? TColor.areapolPrimary : TColor.surface)
                .foregroundColor(isSelected ? TColor.onPrimary : TColor.textPrimary)
                .cornerRadius(TLayout.cornerRadius)
        }
    }
}

struct ListingRowView: View {
    let listing: ListingModel
    
    var body: some View {
        HStack(spacing: TLayout.spacingM) {
            // Thumbnail Image
            if let firstImageUrl = listing.mediaUrls.first {
                ModulMediaGridItemView(
                    media: ModulMediaModel(
                        propertyId: listing.property.id,
                        modulMediaType: .image,
                        url: firstImageUrl,
                        fileExtension: "jpg"
                    ),
                    onDelete: { /* Gerekirse implement edilebilir */ },
                    onRename: { _ in /* Gerekirse implement edilebilir */ },
                    onTap: nil
                )
                .frame(width: 80, height: 80)
                .cornerRadius(TLayout.cornerRadius)
            } else {
                Rectangle()
                    .fill(TColor.surface)
                    .frame(width: 80, height: 80)
                    .cornerRadius(TLayout.cornerRadius)
                    .overlay(
                        Image(systemName: "photo")
                            .font(.system(size: 24))
                            .foregroundColor(TColor.textSecondary)
                    )
        }

            
            // Listing Details
            VStack(alignment: .leading, spacing: TLayout.spacingS) {
                // Price and Type
                HStack {
                    Text("\(listing.price.formatted()) \(listing.currency.symbol)")
                        .font(TFont.title3)
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Spacer()
                    
                    Label(listing.type.displayName, systemImage: listing.type == .sale ? "tag.fill" : "key.fill")
                        .font(TFont.caption)
                        .foregroundColor(TColor.onPrimary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(TColor.areapolPrimary)
                        .cornerRadius(8)
                }
                
                // Title
                Text(listing.title)
                    .font(TFont.headline)
                    .foregroundColor(TColor.textPrimary)
                    .lineLimit(1)
                
                // Location
                if let location = listing.property.formattedAddress {
                    HStack(spacing: TLayout.spacingXXS) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.caption2)
                        Text(location)
                            .font(TFont.caption)
                    }
                    .foregroundColor(TColor.textSecondary)
                }
                
                // Property Details
                if let roomCount = listing.property.roomCount?.rawValue {
                    HStack(spacing: TLayout.spacingXXS) {
                        Image(systemName: "bed.double.fill")
                            .font(.caption2)
                        Text(roomCount)
                            .font(TFont.caption)
                    }
                    .foregroundColor(TColor.textSecondary)
                }
                
                // Status Badge
                Text(listing.status.displayName)
                    .font(TFont.caption)
                    .foregroundColor(TColor.onPrimary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color(listing.status.color))
                    .cornerRadius(4)
            }
            .padding(.vertical, TLayout.spacingS)
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadius)
    }
}
