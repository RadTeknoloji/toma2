//
//  CreateListingView.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import SwiftUI

struct CreateListingView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject var viewModel: ListingViewModel
    @Binding var isPresented: Bool
    let onComplete: (Bool) -> Void
    
    @State private var showMediaPicker = false
    @State private var isUploading = false
    @State private var listingCreated = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(String(localized: "create_listing_section_property")) {
                    if viewModel.userProperties.isEmpty {
                        Text(String(localized: "create_listing_no_properties"))
                            .font(TFont.body)
                            .foregroundColor(TColor.border)
                    } else {
                        Picker(String(localized: "create_listing_property_picker"), selection: $viewModel.selectedProperty) {
                            Text(String(localized: "create_listing_select_property")).tag(Optional<PropertyModel>.none)
                            ForEach(viewModel.userProperties) { property in
                                Text(property.title).tag(Optional(property))
                            }
                        }
                    }
                }
                
                if viewModel.selectedProperty != nil {
                    Section(String(localized: "create_listing_section_type")) {
                        Picker(String(localized: "create_listing_type_picker"), selection: $viewModel.listingType) {
                            ForEach(ListingType.allCases, id: \.self) { type in
                                Text(type.displayName).tag(type)
                            }
                        }
                    }
                    
                    Section(String(localized: "create_listing_section_price")) {
                        HStack {
                            TextField(String(localized: "create_listing_price"), text: $viewModel.price)
                                .keyboardType(.decimalPad)
                            
                            Picker(String(localized: "create_listing_currency"), selection: $viewModel.currency) {
                                ForEach(CurrencyType.allCases, id: \.self) { currency in
                                    Text(currency.symbol).tag(currency)
                                }
                            }
                            .pickerStyle(.menu)
                        }
                    }
                    
                    Section(String(localized: "create_listing_section_details")) {
                        TextField(String(localized: "create_listing_title"), text: $viewModel.title)
                            .textInputAutocapitalization(.characters)
                            .font(TFont.body)
                            .foregroundColor(TColor.textPrimary)
                            .onChange(of: viewModel.title) { _, newValue in
                                viewModel.title = newValue.uppercased()
                            }
                        
                        TextEditor(text: $viewModel.description)
                            .frame(minHeight: 150)
                            .font(TFont.body)
                            .foregroundColor(TColor.textPrimary)
                            .overlay(
                                RoundedRectangle(cornerRadius: TLayout.cornerRadius)
                                    .stroke(TColor.border.opacity(0.2), lineWidth: 1)
                            )
                    }
                    
                    Section(String(localized: "create_listing_section_photos")) {
                        Button(action: {
                            showMediaPicker = true
                        }) {
                            HStack {
                                Image(systemName: "photo.on.rectangle.angled")
                                Text(String(localized: "create_listing_add_photos"))
                            }
                        }
                        .buttonStyle(TButton.Bordered())
                        
                        // Seçilen medyaların önizlemesi
                        if !viewModel.mediaUrls.isEmpty {
                            mediaPreviewGrid
                        }
                    }
                }
            }
            .navigationTitle(String(localized: "create_listing_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "cancel")) {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(String(localized: "publish")) {
                        Task {
                            isUploading = true
                            if let property = viewModel.selectedProperty,
                               let price = Double(viewModel.price.replacingOccurrences(of: ",", with: ".")) {
                                await viewModel.createListing(
                                    property: property,
                                    type: viewModel.listingType,
                                    price: price,
                                    title: viewModel.title,
                                    description: viewModel.description
                                )
                                listingCreated = true
                                isPresented = false
                                onComplete(true)
                            }
                            isUploading = false
                        }
                    }
                    .disabled(!viewModel.isValidForm || isUploading)
                }
            }
            .sheet(isPresented: $showMediaPicker) {
                ModulMediaPickerView(
                    propertyId: viewModel.selectedProperty?.id ?? UUID(),
                    onComplete: { urls in
                        viewModel.mediaUrls = urls
                        // showMediaPicker = false satırını kaldırıyoruz
                    }
                )
            }
        }
    }
    
    private var mediaPreviewGrid: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHGrid(rows: [GridItem(.fixed(100))], spacing: TLayout.spacing) {
                ForEach(viewModel.mediaUrls, id: \.self) { url in
                    ModulMediaGridItemView(
                        media: ModulMediaModel(
                            propertyId: viewModel.selectedProperty?.id ?? UUID(),
                            modulMediaType: .image,
                            url: url,
                            fileExtension: "jpg"
                        ),
                        mode: .edit,
                        onDelete: {
                            if let index = viewModel.mediaUrls.firstIndex(of: url) {
                                viewModel.mediaUrls.remove(at: index)
                            }
                        }
                    )
                    .frame(width: 100, height: 100)
                }
            }
            .padding(.vertical, TLayout.spacing)
        }
    }
}
