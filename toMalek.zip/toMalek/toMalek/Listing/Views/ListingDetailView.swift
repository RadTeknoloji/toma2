import SwiftUI

struct ListingDetailView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: ListingViewModel
    @StateObject private var requestViewModel = RequestViewModel()
    
    let listing: ListingModel
    
    @State private var showReservationSheet = false
    @State private var showDeleteAlert = false
    @State private var userProfile: ProfilModel?
    @State private var currentUserId: String
    
    // ModulMedia için state'ler
    @State private var selectedMediaIndex: Int?
    @State private var showMediaPreview = false
    
    init(viewModel: ListingViewModel, listing: ListingModel, currentUserId: String) {
        _viewModel = StateObject(wrappedValue: viewModel)
        self.listing = listing
        self.currentUserId = currentUserId
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: TLayout.spacingL) {
                // 1. Media Section
                mediaGridSection
                
                VStack(spacing: TLayout.spacingM) {
                    // 2. Header Section
                    headerSection
                    
                    // 3. Type, SubType and Price Section
                    typeAndPriceSection
                    
                    // 4. Address Tags
                    addressSection
                    
                    // 5. Description
                    descriptionSection
                    
                    // 6. Property Details
                    propertyDetailsSection
                    
                    // 7. Action Buttons
                    if currentUserId == listing.createdBy {
                        ownerActionSection
                    } else {
                        userActionSection
                    }
                }
                .padding(.horizontal)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .alert(String(localized: "listing_delete_alert_title"), isPresented: $showDeleteAlert) {
            Button("listing_delete_alert_confirm", role: .destructive) {
                Task {
                    await viewModel.deleteListing(listing)
                    dismiss()
                }
            }
            Button("listing_delete_alert_cancel", role: .cancel) {}
        }
        .task {
            if userProfile == nil {
                userProfile = await viewModel.getListingUserProfile(listing)
            }
        }
        .sheet(isPresented: $showMediaPreview) {
            if let index = selectedMediaIndex,
               index < listing.mediaUrls.count {
                ModulMediaPreviewView(
                    media: ModulMediaModel(
                        propertyId: listing.property.id,
                        modulMediaType: .image,
                        url: listing.mediaUrls[index],
                        fileExtension: "jpg"
                    ),
                    mediaService: ModulMediaFirebaseService()
                )
            }
        }
    }
    
    // MARK: - Sections
    private var mediaGridSection: some View {
        TabView {
            if listing.mediaUrls.isEmpty {
                emptyMediaPlaceholder
            } else {
                ForEach(Array(listing.mediaUrls.enumerated()), id: \.element) { index, url in
                    ModulMediaGridItemView(
                        media: ModulMediaModel(
                            propertyId: listing.property.id,
                            modulMediaType: .image,
                            url: url,
                            fileExtension: "jpg"
                        ),
                        mode: .readonly,
                        onTap: {
                            selectedMediaIndex = index
                            showMediaPreview = true
                        }
                    )
                    .frame(height: 280)
                    .clipped()
                }
            }
        }
        .tabViewStyle(PageTabViewStyle())
        .frame(height: 280)
    }
    
    private var emptyMediaPlaceholder: some View {
        Color.gray.opacity(0.2)
            .overlay {
                Image(systemName: "photo")
                    .font(.system(size: 48))
                    .foregroundColor(.gray)
            }
    }
    
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(listing.title)
                    .font(TFont.h2)
                    .foregroundColor(TColor.textPrimary)
                
                Spacer()
                
                statusBadge
            }
        }
    }
    
    private var statusBadge: some View {
        Text(listing.status.displayName)
            .font(TFont.footnote)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(getStatusColor().opacity(0.15))
            .foregroundColor(getStatusColor())
            .cornerRadius(8)
    }
    
    private var typeAndPriceSection: some View {
        VStack(spacing: 12) {
            HStack {
                Text(listing.type.displayName)
                    .font(TFont.footnoteBold)
                    .foregroundColor(TColor.areapolPrimary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(TColor.areapolPrimary.opacity(0.15))
                    .cornerRadius(8)
                
                Spacer()
                
                Text("\(listing.price.formatted()) \(listing.currency.symbol)")
                    .font(TFont.h3)
                    .foregroundColor(TColor.areapolPrimary)
            }
            
            HStack(spacing: 16) {
                PropertyTypeTag(title: listing.propertyType.rawValue.localized())
                
                if !listing.propertySubType.isEmpty {
                    PropertyTypeTag(title: listing.propertySubType.localized())
                }
                
                Spacer()
            }
        }
    }
    
    private var addressSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            if listing.property.formattedAddress != nil {
                Text(String(localized: "property_location"))
                    .font(TFont.footnoteBold)
                    .foregroundColor(TColor.textPrimary)
                
                AddressTagsView(property: listing.property)
            }
        }
    }
    
    private var descriptionSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(String(localized: "listing_description_title"))
                .font(TFont.footnoteBold)
                .foregroundColor(TColor.textPrimary)
            
            Text(listing.description)
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
        }
    }
    
    private var propertyDetailsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(String(localized: "property_details"))
                .font(TFont.footnoteBold)
                .foregroundColor(TColor.textPrimary)
            
            // Advantages
            if let advantages = getPropertyAdvantages() {
                PropertyAdvantagesView(advantages: advantages)
            }
            
            // Primary Details
            VStack(spacing: 8) {
                if let roomCount = listing.property.roomCount?.rawValue {
                    ListsDetailRow(title: "room_count", value: roomCount.localized())
                }
                
                if let buildingAge = listing.property.buildingAge?.rawValue {
                    ListsDetailRow(title: "building_age", value: "\(buildingAge)")
                }
                
                if let floorLocation = listing.property.floorLocation?.rawValue {
                    ListsDetailRow(title: "floor", value: "\(floorLocation)")
                }
                
                if let netSquareMeters = listing.property.netSquareMeters {
                    ListsDetailRow(title: "net_square_meters", value: "\(netSquareMeters) m²")
                }
            }
            
            // Additional Details
            VStack(spacing: 8) {
                if let heatingType = listing.property.heatingType?.rawValue {
                    ListsDetailRow(title: "heating_type", value: heatingType.localized())
                }
                
                if let constructionMaterial = listing.property.constructionMaterial?.rawValue {
                    ListsDetailRow(title: "construction_material", value: constructionMaterial.localized())
                }
                
                if let directionFacade = listing.property.directionFacade?.rawValue {
                    ListsDetailRow(title: "direction_facade", value: directionFacade.localized())
                }
            }
        }
    }
    
    private var ownerActionSection: some View {
        Button(action: {
            showDeleteAlert = true
        }) {
            Text("listing_action_delete")
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(.red)
        .padding(.top, 8)
    }
    
    private var userActionSection: some View {
        VStack(spacing: 12) {
            if let userPhone = userProfile?.phoneNumber {
                CallButton(phoneNumber: userPhone)
            }
            
            FavoriteButton(
                isFavorited: listing.isFavorited,
                action: {
                    Task {
                        await viewModel.toggleFavorite(listing)
                    }
                }
            )
            
            ReservationButton(
                status: listing.status,
                action: {
                    Task {
                        await viewModel.requestReservation(listing)
                    }
                }
            )
        }
        .padding(.top, 8)
    }
    
    // MARK: - Helper Functions
    
    private func getStatusColor() -> Color {
        switch listing.status.color {
        case "green": return TColor.success
        case "orange": return TColor.warning
        case "red": return TColor.error
        default: return TColor.textSecondary
        }
    }

    private func getPropertyAdvantages() -> [String]? {
        switch listing.property.propertyType {
        case .residential:
            return listing.property.residentialAdvantages?.map { $0.rawValue.localized() }
        case .commercial:
            return listing.property.commercialAdvantages?.map { $0.rawValue.localized() }
        case .land:
            return listing.property.landAdvantages?.map { $0.rawValue.localized() }
        case .machine:
            return listing.property.machineAdvantages?.map { $0.rawValue.localized() }
        case .timeshareProperty:
            return listing.property.timeshareAdvantages?.map { $0.rawValue.localized() }
        }
    }
}

// MARK: - Supporting Views
struct PropertyTypeTag: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(TFont.footnote)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(TColor.areapolPrimary.opacity(0.15))
            .foregroundColor(TColor.areapolPrimary)
            .cornerRadius(8)
    }
}

struct AddressTagsView: View {
    let property: PropertyModel
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                if let country = property.country {
                    switch country {
                    case "Turkey", "Türkiye":
                        if let neighborhood = property.neighborhood {
                            AddressTag(title: neighborhood)
                        }
                        if let district = property.district {
                            AddressTag(title: district)
                        }
                        if let state = property.state {
                            AddressTag(title: state)
                        }
                    default:
                        if let city = property.city {
                            AddressTag(title: city)
                        }
                        if let state = property.state {
                            AddressTag(title: state)
                        }
                    }
                    AddressTag(title: country)
                }
            }
        }
    }
}

struct AddressTag: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(TFont.caption)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(TColor.surface)
            .foregroundColor(TColor.textSecondary)
            .cornerRadius(8)
    }
}

struct ListsDetailRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(LocalizedStringKey(title))
                .font(TFont.footnote)
                .foregroundColor(TColor.textSecondary)
            Spacer()
            Text(value)
                .font(TFont.footnote)
                .foregroundColor(TColor.textPrimary)
        }
    }
}

struct PropertyAdvantagesView: View {
    let advantages: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(String(localized: "property_advantages"))
                .font(TFont.footnoteBold)
                .foregroundColor(TColor.textPrimary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(advantages, id: \.self) { advantage in
                        PropertyAdvantageTag(title: advantage)
                    }
                }
            }
        }
    }
}

struct PropertyAdvantageTag: View {
    let title: String
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(TColor.success)
            Text(title)
                .font(TFont.caption)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(TColor.surface)
        .foregroundColor(TColor.textSecondary)
        .cornerRadius(8)
    }
}

// MARK: - Action Buttons
struct CallButton: View {
    let phoneNumber: String
    
    var body: some View {
        Button {
            if let url = URL(string: "tel://\(phoneNumber)") {
                UIApplication.shared.open(url)
            }
        } label: {
            Label(String(localized: "call"), systemImage: "phone.fill")
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(TColor.success)
    }
}

struct FavoriteButton: View {
    let isFavorited: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Label(
                isFavorited ? String(localized: "listing_button_remove_favorite") : String(localized: "listing_button_add_favorite"),
                systemImage: isFavorited ? "star.fill" : "star"
            )
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(isFavorited ? TColor.warning : TColor.areapolPrimary)
    }
}

struct ReservationButton: View {
    let status: ListingStatus
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Label(String(localized: "listing_action_request_reservation"),
                  systemImage: "calendar.badge.clock")
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(TColor.areapolPrimary)
        .disabled(status != .active)
    }
}
