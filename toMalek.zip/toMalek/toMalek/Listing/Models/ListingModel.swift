//
//  ListingModel.swift
//  toMalek
//
//  Created by Selman Erbay on 25.01.2025.
//

import Foundation
import FirebaseFirestore

enum ListingType: String, Codable, CaseIterable {
    case sale = "sale"
    case rent = "rent"
    
    var displayName: String {
        switch self {
        case .sale: return String(localized: "listing_type_sale")
        case .rent: return String(localized: "listing_type_rent")
        }
    }
}

enum ListingStatus: String, Codable, CaseIterable {
    case active = "active"
    case reserved = "reserved"
    case closed = "closed"
    
    var displayName: String {
        switch self {
        case .active: return String(localized: "listing_status_active")
        case .reserved: return String(localized: "listing_status_reserved")
        case .closed: return String(localized: "listing_status_closed")
        }
    }
    
    var color: String {
        switch self {
        case .active: return "green"
        case .reserved: return "orange"
        case .closed: return "red"
        }
    }
}

enum ReservationStatus: String, Codable, CaseIterable {
    case pending = "pending"
    case approved = "approved"
    case rejected = "rejected"
    case cancelled = "cancelled"
    
    var displayName: String {
        switch self {
        case .pending: return String(localized: "reservation_status_pending")
        case .approved: return String(localized: "reservation_status_approved")
        case .rejected: return String(localized: "reservation_status_rejected")
        case .cancelled: return String(localized: "reservation_status_cancelled")
        }
    }
}

struct ListingModel: Identifiable, Codable, FirestoreUpdateData {
    // MARK: - Properties
    let id: UUID
    let property: PropertyModel
    var status: ListingStatus
    let type: ListingType
    var isFavorited: Bool
    let price: Double
    let currency: CurrencyType
    let createdBy: String
    let createdAt: Date
    var updatedAt: Date
    let title: String
    let description: String
    var mediaUrls: [String]
    var interestedUsers: [String]
    var reservationRequests: [ReservationRequest]
    var currentReservation: ReservationRequest?
    
    // MARK: - Computed Properties
    var propertyType: PropertyType { property.propertyType }
    
    var propertySubType: String {
        switch property.propertyType {
        case .residential: return property.residentialType?.rawValue ?? ""
        case .commercial: return property.commercialType?.rawValue ?? ""
        case .land: return property.landType?.rawValue ?? ""
        case .machine: return property.machineType?.rawValue ?? ""
        case .timeshareProperty: return property.timeshareType?.rawValue ?? ""
        }
    }
    
    var propertyLocation: String? { property.formattedAddress }
    var propertyRoomCount: String? { property.roomCount?.rawValue }
    var propertyBuildingAge: Int? { property.buildingAge?.rawValue }
    var propertyFloorLocation: Int? { property.floorLocation?.rawValue }
    
    var propertyAdvantages: [String] {
        var advantages: [String] = []
        switch property.propertyType {
        case .residential:
            if let type = property.residentialType {
                advantages.append(type.rawValue)
            }
        case .commercial:
            if let type = property.commercialType {
                advantages.append(type.rawValue)
            }
        case .land:
            if let type = property.landType {
                advantages.append(type.rawValue)
            }
        case .machine:
            if let type = property.machineType {
                advantages.append(type.rawValue)
            }
        case .timeshareProperty:
            if let type = property.timeshareType {
                advantages.append(type.rawValue)
            }
        }
        return advantages
    }
    
    // MARK: - Initialization
    init(
        id: UUID = UUID(),
        property: PropertyModel,
        status: ListingStatus,
        type: ListingType,
        isFavorited: Bool = false,
        price: Double,
        currency: CurrencyType,
        createdBy: String,
        createdAt: Date = Date(),
        updatedAt: Date = Date(),
        title: String,
        description: String,
        mediaUrls: [String] = [],
        interestedUsers: [String] = [],
        reservationRequests: [ReservationRequest] = [],
        currentReservation: ReservationRequest? = nil
    ) {
        self.id = id
        self.property = property
        self.status = status
        self.type = type
        self.isFavorited = isFavorited
        self.price = price
        self.currency = currency
        self.createdBy = createdBy
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.title = title
        self.description = description
        self.mediaUrls = mediaUrls
        self.interestedUsers = interestedUsers
        self.reservationRequests = reservationRequests
        self.currentReservation = currentReservation
    }
    
    // MARK: - Codable
    enum CodingKeys: String, CodingKey {
        case id, property, status, type, isFavorited, price, currency, createdBy,
             createdAt, updatedAt, title, description, mediaUrls,
             interestedUsers, reservationRequests, currentReservation
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(UUID.self, forKey: .id)
        property = try container.decode(PropertyModel.self, forKey: .property)
        status = try container.decode(ListingStatus.self, forKey: .status)
        type = try container.decode(ListingType.self, forKey: .type)
        isFavorited = try container.decode(Bool.self, forKey: .isFavorited)
        price = try container.decode(Double.self, forKey: .price)
        currency = try container.decode(CurrencyType.self, forKey: .currency)
        createdBy = try container.decode(String.self, forKey: .createdBy)
        createdAt = try container.decode(Date.self, forKey: .createdAt)
        updatedAt = try container.decode(Date.self, forKey: .updatedAt)
        title = try container.decode(String.self, forKey: .title)
        description = try container.decode(String.self, forKey: .description)
        mediaUrls = try container.decode([String].self, forKey: .mediaUrls)
        interestedUsers = try container.decode([String].self, forKey: .interestedUsers)
        reservationRequests = try container.decode([ReservationRequest].self, forKey: .reservationRequests)
        currentReservation = try container.decodeIfPresent(ReservationRequest.self, forKey: .currentReservation)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(id, forKey: .id)
        try container.encode(property, forKey: .property)
        try container.encode(status, forKey: .status)
        try container.encode(type, forKey: .type)
        try container.encode(isFavorited, forKey: .isFavorited)
        try container.encode(price, forKey: .price)
        try container.encode(currency, forKey: .currency)
        try container.encode(createdBy, forKey: .createdBy)
        try container.encode(createdAt, forKey: .createdAt)
        try container.encode(updatedAt, forKey: .updatedAt)
        try container.encode(title, forKey: .title)
        try container.encode(description, forKey: .description)
        try container.encode(mediaUrls, forKey: .mediaUrls)
        try container.encode(interestedUsers, forKey: .interestedUsers)
        try container.encode(reservationRequests, forKey: .reservationRequests)
        try container.encodeIfPresent(currentReservation, forKey: .currentReservation)
    }
    
    // MARK: - FirestoreUpdateData
    func toUpdateData() -> [String: Any] {
        let encoder = Firestore.Encoder()
        guard let data = try? encoder.encode(self) else { return [:] }
        return data
    }
}

// MARK: - ReservationRequest
struct ReservationRequest: Codable, Identifiable, Equatable {
    let id: String
    let userId: String
    let userName: String
    let userPhone: String?
    let userEmail: String?
    let requestDate: Date
    var status: ReservationStatus
    var responseDate: Date?
    
    init(
        id: String = UUID().uuidString,
        userId: String,
        userName: String,
        userPhone: String? = nil,
        userEmail: String? = nil,
        requestDate: Date = Date(),
        status: ReservationStatus = .pending,
        responseDate: Date? = nil
    ) {
        self.id = id
        self.userId = userId
        self.userName = userName
        self.userPhone = userPhone
        self.userEmail = userEmail
        self.requestDate = requestDate
        self.status = status
        self.responseDate = responseDate
    }
}
