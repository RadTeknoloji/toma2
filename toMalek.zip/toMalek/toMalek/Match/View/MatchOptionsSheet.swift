//
//  MatchOptionsSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct MatchOptionsSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: MatchOptionsViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: MatchOptionsViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: TLayout.spacingL) {
                Text("match_explanation_text")
                    .font(TFont.body)
                    .foregroundColor(TColor.textSecondary)
                    .padding()
                    .multilineTextAlignment(.center)
                
                matchOptionsList
            }
            .navigationTitle("match_options_title")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel_button") { dismiss() }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
    
    private var matchOptionsList: some View {
        List(viewModel.availableMatchOptions, id: \.self) { userType in
            MatchOptionRow(
                userType: userType,
                phone: viewModel.getPhoneForUserType(userType)
            ) {
                Task {
                    await viewModel.initiateMatch(withUserType: userType)
                    dismiss()
                                    }
                                }
                            }
                            .listStyle(.insetGrouped)
                        }
                    }

                    struct MatchOptionRow: View {
                        let userType: UserType
                        let phone: String
                        let action: () -> Void
                        
                        var body: some View {
                            Button(action: action) {
                                VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                                    HStack {
                                        Image(systemName: userTypeIcon)
                                            .foregroundColor(TColor.areapolPrimary)
                                        Text(userTypeTitle)
                                            .font(TFont.bodyBold)
                                            .foregroundColor(TColor.textPrimary)
                                    }
                                    
                                    if !phone.isEmpty {
                                        Text("match_with_phone \(phone)")
                                            .font(TFont.caption)
                                            .foregroundColor(TColor.textSecondary)
                                    }
                                }
                                .padding(.vertical, TLayout.spacingXS)
                            }
                            .disabled(phone.isEmpty)
                        }
                        
                        private var userTypeIcon: String {
                            switch userType {
                            case .owner: return "person.fill"
                            case .tenant: return "person.2.fill"
                            case .agency: return "building.columns.fill"
                            }
                        }
                        
                        private var userTypeTitle: String {
                            switch userType {
                            case .owner: return String(localized: "match_option_owner")
                            case .tenant: return String(localized: "match_option_tenant")
                            case .agency: return String(localized: "match_option_agency")
                            }
                        }
                    }
