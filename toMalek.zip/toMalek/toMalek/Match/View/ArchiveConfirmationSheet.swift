//
//  ArchiveConfirmationSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct ArchiveConfirmationSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: ArchiveConfirmationViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: ArchiveConfirmationViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: TLayout.spacingXL) {
                // Uyarı İkonu
                Image(systemName: "archivebox.fill")
                    .font(.system(size: 48))
                    .foregroundColor(TColor.warning)
                
                // Açıklama Metinleri
                VStack(spacing: TLayout.spacingL) {
                    Text("archive_confirmation_title")
                        .font(TFont.h2)
                        .multilineTextAlignment(.center)
                    
                    VStack(spacing: TLayout.spacingM) {
                        Text("archive_effects_title")
                            .font(TFont.bodyBold)
                        
                        // Kullanıcı tipine göre etkileri açıkla
                        switch viewModel.userType {
                        case "owner":
                            Text("archive_effects_owner")
                        case "tenant":
                            Text("archive_effects_tenant")
                        case "agency":
                            Text("archive_effects_agency")
                        default:
                            EmptyView()
                        }
                    }
                    .font(TFont.body)
                    .multilineTextAlignment(.center)
                    .foregroundColor(TColor.textSecondary)
                }
                
                Spacer()
                
                // Butonlar
                VStack(spacing: TLayout.spacingM) {
                    Button {
                        Task {
                            await viewModel.archiveProperty()
                            dismiss()
                        }
                    } label: {
                        HStack {
                            if viewModel.isLoading {
                                ProgressView()
                                    .tint(TColor.error)
                            }
                            Text("archive_confirm")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(TButton.Primary())
                        .disabled(viewModel.isLoading)
                    }
                    
                    Button("cancel") {
                        dismiss()
                    }
                    .buttonStyle(TButton.Primary())
                }
            }
            .padding(TLayout.padding)
            .navigationTitle("archive_property")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel") {
                        dismiss()
                    }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
}
