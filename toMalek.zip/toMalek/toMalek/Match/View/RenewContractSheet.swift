//
//  RenewContractSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct RenewContractSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: RenewContractViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: RenewContractViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            Form {
                // Sözleşme Süresi
                Section("contract_duration") {
                    Picker("select_duration", selection: $viewModel.selectedContractTime) {
                        ForEach(ContractTime.allCases, id: \.self) { time in
                            Text(time.description).tag(time)
                        }
                    }
                    .pickerStyle(.wheel)
                }
                
                // Yeni Kira Tutarı
                Section("new_rent_amount") {
                    // Mevcut Kira
                    HStack {
                        Text("current_rent")
                        Spacer()
                        Text("\(viewModel.currentRent, specifier: "%.2f") \(viewModel.property.rentCurrency.symbol)")
                            .foregroundColor(TColor.textSecondary)
                    }
                    
                    // Yeni Kira Girişi
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text("new_rent")
                        HStack {
                            TextField("enter_amount", value: $viewModel.newRentAmount, format: .number)
                                .keyboardType(.decimalPad)
                            Text(viewModel.property.rentCurrency.symbol)
                                .foregroundColor(TColor.textSecondary)
                        }
                    }
                    
                    // Artış Oranı Gösterimi
                    if let percentage = viewModel.increasePercentage {
                        HStack {
                            Text("increase_percentage")
                            Spacer()
                            Text("%\(Int(percentage))")
                                .foregroundColor(TColor.success)
                                .bold()
                        }
                    }
                }
                
                // Açıklama ve Bilgilendirme
                Section {
                    VStack(alignment: .leading, spacing: TLayout.spacingS) {
                        if viewModel.property.matchStatus != nil {
                            Text("contract_renewal_request_explanation")
                                .font(TFont.caption)
                                .foregroundColor(TColor.textSecondary)
                        }
                        
                        Text("renewal_terms_explanation")
                            .font(TFont.caption)
                            .foregroundColor(TColor.textSecondary)
                    }
                }
                
                // Onay Butonu
                Section {
                    Button {
                        Task {
                            await viewModel.applyContractRenewal()
                            dismiss()
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if viewModel.isLoading {
                                ProgressView()
                            } else {
                                Text("renew_contract")
                            }
                            Spacer()
                        }
                    }
                    .buttonStyle(TButton.Primary())
                    .disabled(viewModel.newRentAmount <= 0 || viewModel.isLoading)
                }
            }
            .navigationTitle("contract_renewal")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel") {
                        dismiss()
                    }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
}
