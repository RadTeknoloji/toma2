//
//  RaiseRentSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct RaiseRentSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: RaiseRentViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: RaiseRentViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            Form {
                // Kira Artış Bilgileri
                Section("rent_raise_info") {
                    // Mevcut Kira
                    HStack {
                        Text("current_rent")
                        Spacer()
                        Text("\(viewModel.currentRent, specifier: "%.2f") \(viewModel.property.rentCurrency.symbol)")
                            .foregroundColor(TColor.textSecondary)
                    }
                    
                    // Zam Oranı
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text("raise_percentage")
                        HStack {
                            Slider(value: $viewModel.raisePercentage, in: 0...100, step: 1)
                            Text("%\(Int(viewModel.raisePercentage))")
                                .frame(width: 50)
                        }
                    }
                    
                    // Yeni Kira
                    HStack {
                        Text("new_rent")
                        Spacer()
                        Text("\(viewModel.newRent, specifier: "%.2f") \(viewModel.property.rentCurrency.symbol)")
                            .foregroundColor(TColor.success)
                            .bold()
                    }
                }
                
                // Kalan Aylara Uygulama
                Section {
                    Toggle("apply_to_remaining_months", isOn: $viewModel.applyToRemainingMonths)
                } footer: {
                    Text("apply_to_remaining_months_explanation")
                        .font(TFont.caption)
                        .foregroundColor(TColor.textSecondary)
                }
                
                // Onay Butonu
                Section {
                    Button {
                        Task {
                            await viewModel.applyRentRaise()
                            dismiss()
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if viewModel.isLoading {
                                ProgressView()
                            } else {
                                Text("apply_raise")
                            }
                            Spacer()
                        }
                    }
                    .buttonStyle(TButton.Primary())
                    .disabled(viewModel.raisePercentage == 0 || viewModel.isLoading)
                }
            }
            .navigationTitle("rent_raise")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel") {
                        dismiss()
                    }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
}
