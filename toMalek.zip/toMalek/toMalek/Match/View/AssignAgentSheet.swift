//
//  AssignAgentSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct AssignAgentSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: AssignAgentViewModel
    @State private var showAgencyPicker = false
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: AssignAgentViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            VStack {  // Group yerine VStack kullanıyoruz
                if viewModel.hasExistingAgent {
                    existingAgentView
                } else {
                    FindAgencyView { agency in
                        Task {
                            await viewModel.assignAgent(agency: agency)
                            dismiss()
                        }
                    }
                    .environment(\.assignMode, true)
                }
            }
            .navigationTitle("assign_agent")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel") {
                        dismiss()
                    }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
            .sheet(isPresented: $showAgencyPicker) {
                FindAgencyView { agency in
                    Task {
                        await viewModel.assignAgent(agency: agency)
                        dismiss()
                    }
                }
                .environment(\.assignMode, true)
            }
        }
    }
    
    private var existingAgentView: some View {
        VStack(spacing: TLayout.spacingL) {
            // Mevcut emlakçı bilgileri
            VStack(alignment: .leading, spacing: TLayout.spacingM) {
                Text("current_agent")
                    .font(TFont.h2)
                
                VStack(alignment: .leading, spacing: TLayout.spacingS) {
                    if let agencyName = viewModel.property.agencyName {
                        Text(agencyName)
                            .font(TFont.bodyBold)
                    }
                    
                    if let agentName = viewModel.property.agentName {
                        Text(agentName)
                            .font(TFont.body)
                    }
                    
                    if let agentPhone = viewModel.property.agentPhone {
                        Text(agentPhone)
                            .font(TFont.body)
                    }
                }
                .padding()
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
            }
            
            // Emlakçı değiştirme butonu
            Button {
                Task {
                    await viewModel.clearExistingAgent()
                    showAgencyPicker = true
                }
            } label: {
                Text("change_agent")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(Theme.ButtonStyles.Bordered())
            .disabled(viewModel.isLoading)
            
            Spacer()
        }
        .padding()
    }
}
