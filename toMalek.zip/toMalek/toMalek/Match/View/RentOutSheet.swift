//
//  RentOutSheet.swift
//  toMalek
//
//  Created by Selman Erbay on 9.02.2025.
//

import SwiftUI

struct RentOutSheet: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: RentOutViewModel
    
    init(property: PropertyModel) {
        _viewModel = StateObject(wrappedValue: RentOutViewModel(property: property))
    }
    
    var body: some View {
        NavigationView {
            Form {
                // Kiracı Bilgileri Section
                Section("tenant_info") {
                    TextField("tenant_name", text: $viewModel.tenantName)
                        .textContentType(.name)
                    
                    TextField("tenant_phone", text: $viewModel.tenantPhone)
                        .textContentType(.telephoneNumber)
                        .keyboardType(.phonePad)
                    
                    TextField("tenant_email", text: $viewModel.tenantEmail)
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                }
                
                // Kontrat Bilgileri Section
                Section("contract_info") {
                    DatePicker(
                        "rent_start_date",
                        selection: $viewModel.rentStartDate,
                        displayedComponents: .date
                    )
                    
                    Picker("contract_duration", selection: $viewModel.selectedContractTime) {
                        ForEach(ContractTime.allCases, id: \.self) { time in
                            Text(time.description).tag(time)
                        }
                    }
                    
                    Picker("contract_type", selection: $viewModel.selectedContractType) {
                        ForEach(ContractType.allCases, id: \.self) { type in
                            Text(type.rawValue.localized()).tag(type)
                        }
                    }
                }
                
                // Finansal Bilgiler Section
                Section("financial_info") {
                    HStack {
                        Text("rent_amount")
                        Spacer()
                        TextField("amount", value: $viewModel.rentAmount, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                        Text(viewModel.property.rentCurrency.symbol)
                    }
                    
                    HStack {
                        Text("deposit_amount")
                        Spacer()
                        TextField("amount", value: $viewModel.depositAmount, format: .number)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                        Text(viewModel.property.depositCurrency.symbol)
                    }
                }
                
                // Onay Butonu
                Section {
                    Button {
                        Task {
                            await viewModel.rentOut()
                            dismiss()
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if viewModel.isLoading {
                                ProgressView()
                            } else {
                                Text("rent_out_property")
                            }
                            Spacer()
                        }
                    }
                    .buttonStyle(TButton.Primary())
                    .disabled(!viewModel.isFormValid || viewModel.isLoading)
                }
            }
            .navigationTitle("rent_out")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("cancel") {
                        dismiss()
                    }
                }
            }
            .alert("error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("ok", role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
}
