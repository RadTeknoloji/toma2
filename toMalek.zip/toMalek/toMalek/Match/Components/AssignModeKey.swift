//
//  AssignModeKey.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI

private struct AssignModeKey: EnvironmentKey {
    static let defaultValue: Bool = false
}

extension EnvironmentValues {
    var assignMode: Bool {
        get { self[AssignModeKey.self] }
        set { self[AssignModeKey.self] = newValue }
    }
}
