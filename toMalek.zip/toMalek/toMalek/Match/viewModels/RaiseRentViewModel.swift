//
//  RaiseRentViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI
import Foundation

@MainActor
final class RaiseRentViewModel: ObservableObject {
    private let propertyService: PropertyService
    private let rentPaymentService: RentPaymentService
    private let requestService: RequestService
    
    @Published var property: PropertyModel
    @Published var raisePercentage: Double = 0
    @Published var applyToRemainingMonths = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var currentRent: Double {
        property.rentPrice ?? 0
    }
    
    var newRent: Double {
        currentRent * (1 + (raisePercentage / 100))
    }
    
    init(
        property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
        requestService: RequestService = ServiceContainer.shared.requestService
    ) {
        self.property = property
        self.propertyService = propertyService
        self.rentPaymentService = rentPaymentService
        self.requestService = requestService
    }
    
    func applyRentRaise() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            if property.matchStatus != nil {
                try await createRentRaiseRequest()
            } else {
                try await applyRentRaiseDirectly()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func createRentRaiseRequest() async throws {
        let request = RequestModel(
            title: String(localized: "rent_raise_request_title"),
            requestDescription: String(format: String(localized: "rent_raise_request_description"),
                                    raisePercentage,
                                    currentRent,
                                    newRent),
            category: .priceIncrease,
            propertyID: property.id.uuidString,
            propertyTitle: property.title,
            fromUserID: ServiceContainer.shared.authService.currentUser?.uid ?? "",
            fromUserType: ServiceContainer.shared.authenticationState.userType,
            toUserID: property.tenantId ?? "",
            toUserType: "tenant",
            canBeModified: true
        )
        
        // try? kaldırılıp yerine try kullanıldı
        try await requestService.createRequest(request)
    }
    
    private func applyRentRaiseDirectly() async throws {
        var updatedProperty = property
        updatedProperty.rentPrice = newRent
        try await propertyService.updateProperty(updatedProperty)
        
        if applyToRemainingMonths {
            try await updateRemainingMonths(newRent: newRent)
        }
        
        property = updatedProperty
    }
    
    private func updateRemainingMonths(newRent: Double) async throws {
        let payments = try await rentPaymentService.fetchRentPayments()
        let unpaidFuturePayments = payments.filter { payment in
            payment.propertyId == property.id &&
            payment.rentPaymentStatus == .unpaid &&
            payment.whichMonth > Date()
        }
        
        for var payment in unpaidFuturePayments {
            payment.rentPrice = newRent
            payment.rentBalance = newRent - payment.rentAmountPaid
            try await rentPaymentService.updateRentPayment(payment)
        }
    }
}
