//
//  RenewContractViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI
import Foundation

@MainActor
final class RenewContractViewModel: ObservableObject {
    private let propertyService: PropertyService
    private let rentPaymentService: RentPaymentService
    private let requestService: RequestService
    
    @Published var property: PropertyModel
    @Published var selectedContractTime: ContractTime = .month12
    @Published var newRentAmount: Double
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var currentRent: Double {
        property.rentPrice ?? 0
    }
    
    var increasePercentage: Double? {
        guard newRentAmount > currentRent else { return nil }
        return ((newRentAmount - currentRent) / currentRent) * 100
    }
    
    init(
        property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
        requestService: RequestService = ServiceContainer.shared.requestService
    ) {
        self.property = property
        self.propertyService = propertyService
        self.rentPaymentService = rentPaymentService
        self.requestService = requestService
        self.newRentAmount = property.rentPrice ?? 0
    }
    
    func applyContractRenewal() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            if property.matchStatus != nil {
                try await createRenewalRequest()
            } else {
                try await applyRenewalDirectly()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func createRenewalRequest() async throws {
        let request = RequestModel(
            title: String(localized: "contract_renewal_request_title"),
            requestDescription: String(format: String(localized: "contract_renewal_request_description"),
                                    selectedContractTime.description,
                                    newRentAmount),
            category: .contractRenewal,
            propertyID: property.id.uuidString,
            propertyTitle: property.title,
            fromUserID: ServiceContainer.shared.authService.currentUser?.uid ?? "",
            fromUserType: ServiceContainer.shared.authenticationState.userType,
            toUserID: property.tenantId ?? "",
            toUserType: "tenant",
            canBeModified: true
        )
        
        try await requestService.createRequest(request)  // try? kaldırıldı
        }
    
    private func applyRenewalDirectly() async throws {
        var updatedProperty = property
        updatedProperty.rentPrice = newRentAmount
        updatedProperty.contractTime = selectedContractTime
        try await propertyService.updateProperty(updatedProperty)  // try? kaldırıldı
        
        // Yeni sözleşme süresi için kira ödemeleri oluştur
        try await rentPaymentService.ensureRentPaymentsExist(property: updatedProperty)  // try? kaldırıldı
        
        property = updatedProperty
    }
}
