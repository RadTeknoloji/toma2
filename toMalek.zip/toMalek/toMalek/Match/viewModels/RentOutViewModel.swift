//
//  RentOutViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI
import Foundation

@MainActor
final class RentOutViewModel: ObservableObject {
    private let propertyService: PropertyService
    private let rentPaymentService: RentPaymentService
    
    @Published var property: PropertyModel
    @Published var tenantName = ""
    @Published var tenantPhone = ""
    @Published var tenantEmail = ""
    @Published var rentStartDate = Date()
    @Published var selectedContractTime: ContractTime = .month12
    @Published var selectedContractType: ContractType = .individual
    @Published var rentAmount: Double = 0
    @Published var depositAmount: Double = 0
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var isFormValid: Bool {
        !tenantName.isEmpty &&
        !tenantPhone.isEmpty &&
        isValidEmail(tenantEmail) &&
        rentAmount > 0 &&
        depositAmount > 0
    }
    
    init(
        property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService
    ) {
        self.property = property
        self.propertyService = propertyService
        self.rentPaymentService = rentPaymentService
    }
    
    func rentOut() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            var updatedProperty = property
            
            // Kiracı bilgilerini güncelle
            updatedProperty.tenantName = tenantName
            updatedProperty.tenantPhone = tenantPhone
            updatedProperty.tenantEmail = tenantEmail
            
            // Kontrat bilgilerini güncelle
            updatedProperty.rentStartDate = rentStartDate
            updatedProperty.contractTime = selectedContractTime
            updatedProperty.contractType = selectedContractType
            
            // Finansal bilgileri güncelle
            updatedProperty.rentPrice = rentAmount
            updatedProperty.depositAmount = depositAmount
            updatedProperty.rentalStatus = .rented
            
            try await propertyService.updateProperty(updatedProperty)
            
            // Kira ödemelerini oluştur
            try await rentPaymentService.ensureRentPaymentsExist(property: updatedProperty)
            
            property = updatedProperty
        } catch {
            errorMessage = error.localizedDescription
        }
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
}
