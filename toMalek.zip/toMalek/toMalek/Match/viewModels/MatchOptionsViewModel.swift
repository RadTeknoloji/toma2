//
//  MatchOptionsViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI
import Foundation

@MainActor
final class MatchOptionsViewModel: ObservableObject {
    private let propertyService: PropertyService
    private let matchService: PropertyMatchService
    
    @Published var property: PropertyModel
    @Published var availableMatchOptions: [UserType] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var userType: String {
        ServiceContainer.shared.authenticationState.userType
    }
    
    init(
        property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService,
        matchService: PropertyMatchService = ServiceContainer.shared.propertyService as! PropertyMatchService
    ) {
        self.property = property
        self.propertyService = propertyService
        self.matchService = matchService
        calculateAvailableMatchOptions()
    }
    
    private func calculateAvailableMatchOptions() {
        switch userType {
        case "tenant":
            if !property.ownerPhone.isEmpty {
                availableMatchOptions.append(.owner)
            }
            if !property.agentPhone.isNilOrEmpty {
                availableMatchOptions.append(.agency)
            }
        case "owner":
            if !property.tenantPhone.isNilOrEmpty {
                availableMatchOptions.append(.tenant)
            }
            if !property.agentPhone.isNilOrEmpty {
                availableMatchOptions.append(.agency)
            }
        case "agency":
            if !property.ownerPhone.isEmpty {
                availableMatchOptions.append(.owner)
            }
            if !property.tenantPhone.isNilOrEmpty {
                availableMatchOptions.append(.tenant)
            }
        default:
            break
        }
    }
    
    func getPhoneForUserType(_ userType: UserType) -> String {
        switch userType {
        case .owner: return property.ownerPhone
        case .tenant: return property.tenantPhone ?? ""
        case .agency: return property.agentPhone ?? ""
        }
    }
    
    func initiateMatch(withUserType userType: UserType) async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            let phoneNumber = getPhoneForUserType(userType)
            guard !phoneNumber.isEmpty else {
                errorMessage = "phone_number_required"
                return
            }
            
            try await matchService.initiateMatch(
                fromProperty: property,
                targetUserType: userType,
                targetPhone: phoneNumber
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
