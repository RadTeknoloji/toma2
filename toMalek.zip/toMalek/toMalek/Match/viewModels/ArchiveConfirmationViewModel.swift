//
//  ArchiveConfirmationViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import SwiftUI
import Foundation

@MainActor
final class ArchiveConfirmationViewModel: ObservableObject {
    private let propertyService: PropertyService
    
    @Published var property: PropertyModel
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    var userType: String {
        ServiceContainer.shared.authenticationState.userType
    }
    
    init(
        property: PropertyModel,
        propertyService: PropertyService = ServiceContainer.shared.propertyService
    ) {
        self.property = property
        self.propertyService = propertyService
    }
    
    func archiveProperty() async {
        isLoading = true
        defer { isLoading = false }
        
        do {
            var updatedProperty = property
            updatedProperty.isArchived = true
            try await propertyService.updateProperty(updatedProperty)
            property = updatedProperty
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
