//
//  DocumentViewer.swift
//  toMalek
//
//  Created by Selman Erbay on 24.01.2025.
//

import SwiftUI
import PDFKit

struct DocumentViewer: View {
    let document: PortfolioDocument
    @Environment(\.dismiss) private var dismiss
    @State private var pdfDocument: PDFDocument?
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationView {
            Group {
                if isLoading {
                    ProgressView()
                } else if let error = errorMessage {
                    VStack {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.largeTitle)
                            .foregroundColor(.red)
                        Text(error)
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                } else if let pdfDoc = pdfDocument {
                    PDFKitView(document: pdfDoc)
                } else {
                    AsyncImage(url: URL(string: document.url)) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        case .failure:
                            VStack {
                                Image(systemName: "exclamationmark.triangle")
                                    .font(.largeTitle)
                                    .foregroundColor(.red)
                                Text(String(localized: "error_loading_document"))
                            }
                        @unknown default:
                            EmptyView()
                        }
                    }
                }
            }
            .navigationTitle(document.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.border)
                    }
                }
            }
        }
        .task {
            await loadDocument()
        }
    }
    
    private func loadDocument() async {
        isLoading = true
        defer { isLoading = false }
        
        guard let url = URL(string: document.url) else {
            errorMessage = String(localized: "invalid_document_url")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            
            if let pdf = PDFDocument(data: data) {
                pdfDocument = pdf
            }
        } catch {
            errorMessage = String(format: String(localized: "error_loading_document_message"), error.localizedDescription)
        }
    }
}

