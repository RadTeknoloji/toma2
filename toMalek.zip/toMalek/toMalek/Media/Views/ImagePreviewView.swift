//
//  ImagePreviewView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct ImagePreviewView: View {
    // MARK: - Properties
    private let imageContent: ImageContent
    @Environment(\.dismiss) var dismiss
    @GestureState private var dragOffset = CGSize.zero
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset = CGSize.zero
    @State private var lastOffset = CGSize.zero
    
    // MARK: - Initialization
    init(image: UIImage) {
        self.imageContent = .uiImage(image)
    }
    
    init(imageURL: URL) {
        self.imageContent = .url(imageURL)
    }
    
    // MARK: - Body
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.edgesIgnoringSafeArea(.all)
                
                Group {
                    switch imageContent {
                    case .uiImage(let image):
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .modifier(ImageModifier(
                                geometry: geometry,
                                scale: scale,
                                offset: offset,
                                dragOffset: dragOffset
                            ))
                            
                    case .url(let url):
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                                    .tint(.white)
                            case .success(let image):
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .modifier(ImageModifier(
                                        geometry: geometry,
                                        scale: scale,
                                        offset: offset,
                                        dragOffset: dragOffset
                                    ))
                            case .failure:
                                Image(systemName: "photo")
                                    .foregroundColor(.gray)
                            @unknown default:
                                EmptyView()
                            }
                        }
                    }
                }
                .gesture(magnificationGesture)
                .gesture(dragGesture)
                .onTapGesture(count: 2, perform: handleDoubleTap)
            }
        }
        .overlay(alignment: .topTrailing) {
            closeButton
        }
        .edgesIgnoringSafeArea(.all)
        .statusBarHidden(true)
    }
    
    // MARK: - Gestures
    private var magnificationGesture: some Gesture {
        MagnificationGesture()
            .onChanged { value in
                let delta = value / lastScale
                lastScale = value
                scale = min(max(scale * delta, 1), 4)
            }
            .onEnded { _ in
                lastScale = 1.0
            }
    }
    
    private var dragGesture: some Gesture {
        DragGesture()
            .updating($dragOffset) { value, state, _ in
                state = value.translation
            }
            .onEnded { value in
                if scale > 1 {
                    offset.width += value.translation.width
                    offset.height += value.translation.height
                    lastOffset = offset
                } else if abs(value.translation.height) > 100 {
                    dismiss()
                } else {
                    withAnimation {
                        offset = .zero
                    }
                }
            }
    }
    
    // MARK: - Actions
    private func handleDoubleTap() {
        withAnimation {
            if scale > 1 {
                scale = 1
                offset = .zero
                lastOffset = .zero
            } else {
                scale = 2
            }
        }
    }
    
    // MARK: - Components
    private var closeButton: some View {
        Button {
            dismiss()
        } label: {
            Image(systemName: "xmark.circle.fill")
                .font(.title)
                .foregroundColor(.white)
                .padding()
                .shadow(radius: 2)
        }
    }
}

// MARK: - Helper Types
private enum ImageContent {
    case uiImage(UIImage)
    case url(URL)
}

private struct ImageModifier: ViewModifier {
    let geometry: GeometryProxy
    let scale: CGFloat
    let offset: CGSize
    let dragOffset: CGSize
    
    func body(content: Content) -> some View {
        content
            .frame(width: geometry.size.width)
            .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            .offset(x: offset.width + dragOffset.width, y: offset.height + dragOffset.height)
            .scaleEffect(scale)
    }
}

// MARK: - Preview Provider
struct ImagePreviewView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // UIImage Preview
            ImagePreviewView(image: UIImage(systemName: "photo")!)
            
            // URL Preview
            ImagePreviewView(imageURL: URL(string: "https://example.com/image.jpg")!)
        }
    }
}
