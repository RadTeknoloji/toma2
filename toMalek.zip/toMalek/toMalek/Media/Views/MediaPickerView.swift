//
//  MediaPickerView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct MediaPickerView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: MediaPickerViewModel
    var onComplete: (([String]) -> Void)?
    
    init(propertyId: UUID, onComplete: (([String]) -> Void)? = nil) {
        _viewModel = StateObject(wrappedValue: MediaPickerViewModel(propertyId: propertyId))
        self.onComplete = onComplete
    }
    
    var body: some View {
        NavigationView {
            VStack {
                // Media Selection Button
                PhotosPicker(
                    selection: $viewModel.imageSelections,
                    maxSelectionCount: 5,
                    matching: .images
                ) {
                    Label(String(localized: "select_photos"), systemImage: "photo.on.rectangle.angled")
                        .font(TFont.headline)
                        .foregroundColor(TColor.areapolPrimary)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(TColor.surface)
                        .cornerRadius(TLayout.cornerRadius)
                }
                .onChange(of: viewModel.imageSelections) { oldValue, newValue in
                    Task {
                        await viewModel.loadImages(from: newValue)
                    }
                }
                .padding()
                
                // Selected Images Preview
                ScrollView {
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: TLayout.spacingM) {
                        ForEach(viewModel.selectedImages, id: \.self) { image in
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 120)
                                .clipShape(RoundedRectangle(cornerRadius: TLayout.cornerRadius))
                        }
                    }
                    .padding()
                }
                
                Spacer()
                
                // Upload Button
                Button {
                    Task {
                        await viewModel.uploadImages()
                        if viewModel.isSuccessful {
                            onComplete?(viewModel.mediaUrls)
                            dismiss()
                        }
                    }
                } label: {
                    HStack {
                        if viewModel.isLoading {
                            ProgressView()
                                .tint(TColor.onPrimary)
                        } else {
                            Text(String(localized: "upload"))
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(TColor.areapolPrimary)
                    .foregroundColor(TColor.onPrimary)
                    .cornerRadius(TLayout.cornerRadius)
                }
                .disabled(viewModel.selectedImages.isEmpty || viewModel.isLoading)
                .padding()
            }
            .navigationTitle(String(localized: "add_photos"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(String(localized: "cancel")) {
                        dismiss()
                    }
                    .foregroundColor(TColor.textPrimary)
                }
            }
            .alert(String(localized: "error"), isPresented: .constant(viewModel.errorMessage != nil)) {
                Button(String(localized: "ok"), role: .cancel) {
                    viewModel.errorMessage = nil
                }
            } message: {
                if let error = viewModel.errorMessage {
                    Text(error)
                }
            }
        }
    }
}

// MARK: - Preview Provider
struct MediaPickerView_Previews: PreviewProvider {
    static var previews: some View {
        MediaPickerView(propertyId: UUID())
    }
}
