//
//  FirebaseMediaService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore
import UIKit

final class FirebaseMediaService: MediaService {
    private let storage = Storage.storage()
    private let db = Firestore.firestore()
    private let collection = "medias"
    
    // MARK: - Helper Properties
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    // MARK: - Image Optimization
    private func optimizeImage(_ data: Data) -> Data? {
        guard let image = UIImage(data: data) else { return nil }
        
        // Maksimum boyut 1920x1920
        let maxDimension: CGFloat = 1920
        var newWidth: CGFloat
        var newHeight: CGFloat
        
        if image.size.width > image.size.height {
            newWidth = min(image.size.width, maxDimension)
            newHeight = image.size.height * (newWidth / image.size.width)
        } else {
            newHeight = min(image.size.height, maxDimension)
            newWidth = image.size.width * (newHeight / image.size.height)
        }
        
        let newSize = CGSize(width: newWidth, height: newHeight)
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: CGRect(origin: .zero, size: newSize))
        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        // %60 kalite ile JPEG sıkıştırma
        return resizedImage?.jpegData(compressionQuality: 0.6)
    }
    
    
    // MARK: - Image Uploads

    func uploadImages(_ images: [UIImage]) async throws -> [String] {
        var uploadedUrls: [String] = []
        
        for image in images {
            guard let imageData = image.jpegData(compressionQuality: 0.7) else { continue }
            
            let media = MediaModel(
                id: UUID(),
                propertyId: UUID(),  // Geçici bir UUID oluştur, gerçek propertyId ViewModel'den gelecek
                mediaType: .image,
                url: "",
                createdDate: Date(),
                fileSize: imageData.count,
                fileExtension: "jpg"
            )
            
            try await uploadMedia(media, data: imageData)
            
            if let uploadedMedia = try await fetchMedia(id: media.id.uuidString) {
                uploadedUrls.append(uploadedMedia.url)
            }
        }
        
        return uploadedUrls
    }
    
    // MARK: - Upload
    func uploadMedia(_ media: MediaModel, data: Data) async throws {
        guard let userId = currentUserId else {
            throw MediaError.unauthorized
        }
        
        // Önbellekte daha önceden yüklenmiş resim var mı kontrol et
        if MediaCacheManager.shared.getImage(forKey: media.id.uuidString) != nil {
            print("Resim zaten önbellekte mevcut")
            return
        }
        
        // Fotoğrafı optimize et
        let optimizedData = optimizeImage(data) ?? data
        
        // Depolama referansını oluştur
        let storageRef = storage.reference()
            .child("users")
            .child(userId)
            .child("properties")
            .child(media.propertyId.uuidString)
            .child("media")
            .child("\(media.id.uuidString).\(media.fileExtension ?? "jpg")")
        
        // Yükleme metadatasını hazırla
        let metadata = StorageMetadata()
        metadata.contentType = "image/jpeg"
        
        // Resmi Firebase Storage'a yükle
        try await storageRef.putDataAsync(optimizedData, metadata: metadata)
        let url = try await storageRef.downloadURL()
        
        // Firestore referansını oluştur
        let mediaRef = db.collection(collection).document(media.id.uuidString)
        
        // Media bilgilerini hazırla
        let mediaData: [String: Any] = [
            "id": media.id.uuidString,
            "propertyId": media.propertyId.uuidString,
            "title": media.title as Any,
            "mediaType": media.mediaType.rawValue,
            "url": url.absoluteString,
            "createdDate": FieldValue.serverTimestamp(),
            "fileSize": optimizedData.count,
            "fileExtension": "jpg",
            "userId": userId
        ]
        
        // Firestore'a kaydet
        try await mediaRef.setData(mediaData)
        
        // Başarılı yükleme sonrası önbelleğe ekle
        if let uploadedImage = UIImage(data: optimizedData) {
            MediaCacheManager.shared.cacheImage(uploadedImage, forKey: media.id.uuidString)
            print("Resim önbelleğe eklendi")
        }
    }
    
    // MARK: - Read
    func fetchMedias(propertyId: String) async throws -> [MediaModel] {
        guard let userId = currentUserId else {
            throw MediaError.unauthorized
        }
        
        do {
            let snapshot = try await db.collection(collection)
                .whereField("userId", isEqualTo: userId)
                .whereField("propertyId", isEqualTo: propertyId)
                .order(by: "createdDate", descending: true)
                .getDocuments()
            
            return try snapshot.documents.compactMap { document in
                try decodeMedia(from: document)
            }
        } catch {
            print("Fetch error: \(error)")
            throw MediaError.invalidData
        }
    }
    
    func fetchMedia(id: String) async throws -> MediaModel? {
        do {
            let document = try await db.collection(collection).document(id).getDocument()
            guard document.exists else { return nil }
            return try decodeMedia(from: document)
        } catch {
            print("Fetch media error: \(error)")
            throw MediaError.invalidData
        }
    }
    
    func downloadMedia(url: String) async throws -> Data {
        guard let url = URL(string: url) else {
            print("Invalid URL: \(url)")
            throw MediaError.invalidData
        }
        
        do {
            let storageRef = storage.reference(forURL: url.absoluteString)
            print("Downloading from URL: \(url)")
            
            let maxSize: Int64 = 10 * 1024 * 1024 // 10MB
            let data = try await storageRef.data(maxSize: maxSize)
            print("Download successful, data size: \(data.count) bytes")
            return data
        } catch {
            print("Download error: \(error)")
            throw MediaError.downloadFailed
        }
    }
    
    // MARK: - Delete
    func deleteMedia(_ media: MediaModel) async throws {
        guard let userId = currentUserId else {
            throw MediaError.unauthorized
        }
        
        do {
            // Check if media belongs to current user
            let document = try await db.collection(collection).document(media.id.uuidString).getDocument()
            guard let documentUserId = document.data()?["userId"] as? String,
                  documentUserId == userId else {
                throw MediaError.unauthorized
            }
            
            // Delete from storage
            let storageRef = storage.reference(forURL: media.url)
            try await storageRef.delete()
            
            // Delete from Firestore
            try await db.collection(collection).document(media.id.uuidString).delete()
        } catch {
            print("Delete error: \(error)")
            throw MediaError.deleteFailed
        }
    }
    
    // MARK: - Helper Methods
    private func decodeMedia(from document: DocumentSnapshot) throws -> MediaModel {
        guard let data = document.data() else {
            print("Invalid document data")
            throw MediaError.invalidData
        }
        
        let id = UUID(uuidString: data["id"] as? String ?? "") ?? UUID()
        let propertyId = UUID(uuidString: data["propertyId"] as? String ?? "") ?? UUID()
        let url = data["url"] as? String ?? ""
        
        print("Decoded media - ID: \(id), PropertyID: \(propertyId), URL: \(url)")
        
        return MediaModel(
            id: id,
            propertyId: propertyId,
            title: data["title"] as? String,
            mediaType: MediaType(rawValue: data["mediaType"] as? String ?? "") ?? .image,
            url: url,
            createdDate: (data["createdDate"] as? Timestamp)?.dateValue() ?? Date(),
            fileSize: data["fileSize"] as? Int,
            fileExtension: data["fileExtension"] as? String
        )
    }
}
