//
//  MediaService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import UIKit

enum MediaError: LocalizedError {
    case invalidData
    case uploadFailed
    case downloadFailed
    case deleteFailed
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "invalid_media_data")
        case .uploadFailed:
            return String(localized: "upload_failed")
        case .downloadFailed:
            return String(localized: "download_failed")
        case .deleteFailed:
            return String(localized: "delete_failed")
        case .unauthorized:
            return String(localized: "unauthorized")
        }
    }
}

enum MediaServiceError: LocalizedError {
    case mediaIsNil

    var errorDescription: String? {
        switch self {
        case .mediaIsNil:
            return String(localized: "media_not_found")
        }
    }
}

protocol MediaService {
    // Upload
    func uploadMedia(_ media: MediaModel, data: Data) async throws
    func uploadImages(_ images: [UIImage]) async throws -> [String]

    
    
    // Read
    func fetchMedias(propertyId: String) async throws -> [MediaModel]
    func fetchMedia(id: String) async throws -> MediaModel?
    func downloadMedia(url: String) async throws -> Data
    
    // Delete
    func deleteMedia(_ media: MediaModel) async throws
}
