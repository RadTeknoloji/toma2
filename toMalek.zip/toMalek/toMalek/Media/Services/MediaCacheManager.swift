//
//  MediaCacheManager.swift
//  toMalek
//
//  Created by Selman Erbay on 10.02.2025.
//

import Foundation
import UIKit

class MediaCacheManager {
    static let shared = MediaCacheManager()
    private let imageCache = NSCache<NSString, UIImage>()
    private let imageCacheSizeLimit: Int = 100 // Toplam önbellek boyutu
    
    init() {
        imageCache.countLimit = imageCacheSizeLimit
    }
    
    func cacheImage(_ image: UIImage, forKey key: String) {
        imageCache.setObject(image, forKey: key as NSString)
    }
    
    func getImage(forKey key: String) -> UIImage? {
        return imageCache.object(forKey: key as NSString)
    }
    
    func removeImage(forKey key: String) {
        imageCache.removeObject(forKey: key as NSString)
    }
    
    func clearCache() {
        imageCache.removeAllObjects()
    }
}
