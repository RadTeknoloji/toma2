//
//  MediaModel.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation

enum MediaType: String, Codable {
    case image
    case document
}

struct MediaModel: Codable, Identifiable {
    let id: UUID
    let propertyId: UUID
    
    var title: String?
    var mediaType: MediaType
    var url: String  // Storage'daki dosya yolu
    var createdDate: Date
    
    // Dosya boyutu (bytes)
    var fileSize: Int?
    
    // Dosya uzantısı (.pdf, .jpg vs)
    var fileExtension: String?
}
