//
//  MediaPickerViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI
import PhotosUI

@MainActor
final class MediaPickerViewModel: ObservableObject {
    // MARK: - Services
    private let mediaService: MediaService
    
    // MARK: - Properties
    private let propertyId: UUID
    
    // MARK: - Published Properties
    @Published var imageSelections: [PhotosPickerItem] = []
    @Published var selectedImages: [UIImage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    @Published var mediaUrls: [String] = []
    
    // MARK: - Initialization
    init(propertyId: UUID,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.propertyId = propertyId
        self.mediaService = mediaService
    }
    
    // MARK: - Methods
    func loadImages(from selections: [PhotosPickerItem]) async {
        selectedImages.removeAll()
        
        for selection in selections {
            do {
                guard let data = try await selection.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else { continue }
                
                if !selectedImages.contains(where: { $0.pngData() == image.pngData() }) {
                    selectedImages.append(image)
                }
            } catch {
                print(String(format: String(localized: "error_loading_image"), error.localizedDescription))
            }
        }
    }
    
    func uploadImages() async {
        guard !selectedImages.isEmpty else { return }
        
        isLoading = true
        errorMessage = nil
        mediaUrls = []
        
        do {
            let imageDataArray = selectedImages.compactMap { image -> Data? in
                image.jpegData(compressionQuality: 0.7)
            }
            
            for imageData in imageDataArray {
                let media = MediaModel(
                    id: UUID(),
                    propertyId: propertyId,
                    mediaType: .image,
                    url: "",
                    createdDate: Date(),
                    fileSize: imageData.count,
                    fileExtension: "jpg"
                )
                
                try await mediaService.uploadMedia(media, data: imageData)
                
                if let uploadedMedia = try await mediaService.fetchMedia(id: media.id.uuidString) {
                    mediaUrls.append(uploadedMedia.url)
                } else {
                    throw MediaServiceError.mediaIsNil
                }
            }
            
            isSuccessful = true
            
        } catch {
            errorMessage = String(localized: "error_uploading_images")
            print(String(format: String(localized: "error_uploading_images_detail"), error.localizedDescription))
        }
        
        isLoading = false
    }
}
