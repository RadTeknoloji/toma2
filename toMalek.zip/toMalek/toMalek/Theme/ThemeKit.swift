// ThemeKit.swift
import SwiftUI

// Shadow yapısını ekliyoruz
struct Shadow {
    let color: Color
    let radius: CGFloat
    let x: CGFloat
    let y: CGFloat
}

enum Theme {
    // MARK: - Renk Sistemi
    enum ColorPalette {
        // Ana Renkler
        static let accent = Color("accent")
        static let action = Color("action")
        static let onPrimary = Color ("onPrimary")
        static let areapolPrimary = Color ("areapolPrimary")
        static let areapolSecondary = Color ("areapolSecondary")
        
        // Arka Plan Renkleri
        static let background = Color("background")
        static let backgroundDark = Color("backgroundDark")
        static let surface = Color("surface")
        static let surfaceDark = Color("surfaceDark")
        static let card = Color("card")
        static let cardDark = Color("cardDark")
        
        // Metin Renkleri
        static let textPrimary = Color("textPrimary")
        static let textSecondary = Color("textSecondary")
        static let textTertiary = Color("textTertiary")
        static let textPrimaryDark = Color("textPrimaryDark")
        static let textSecondaryDark = Color("textSecondaryDark")
        static let textTertiaryDark = Color("textTertiaryDark")
        
        // Durum Renkleri
        static let success = Color("success")
        static let error = Color("error")
        static let warning = Color("warning")
        static let info = Color("info")
        
        // Özel Durum Renkleri
        static let available = Color("available")
        static let rented = Color("rented")
        static let sold = Color("sold")
        static let verified = Color("verified")
        static let premium = Color("premium")
        
        // Fiyat Renkleri
        static let price = Color("price")
        static let priceUp = Color("priceUp")
        static let priceDown = Color("priceDown")
        
        // Diğer
        static let border = Color("border")
        static let ColorRenksiz = Color("ColorRenksiz")
    }
    
    
    // MARK: - Tipografi (iOS 17+ Uyumlu)
    enum Typography {
        static let h1 = Font.system(size: 28, weight: .bold, design: .rounded)
        static let h2 = Font.system(size: 22, weight: .semibold, design: .rounded)
        static let h3 = Font.system(size: 18, weight: .semibold, design: .rounded)
        static let body = Font.system(size: 14, design: .rounded)
        static let bodyBold = Font.system(size: 14, weight: .semibold, design: .rounded)
        static let caption = Font.system(size: 10, design: .rounded)
        static let caption2 = Font.system(size: 8, design: .rounded)
        static let footnote = Font.system(size: 11, design: .rounded)
        static let footnoteBold = Font.system(size: 11, weight: .semibold, design: .rounded)
        static let title2 = Font.system(size: 17, weight: .semibold, design: .rounded)
        static let subheadline = Font.system(size: 12, design: .rounded)
        static let title3: Font = .system(
            size: 16,
            weight: .semibold,
            design: .rounded
        )
        static let headline: Font = .system(
            size: 14,
            weight: .semibold,
            design: .default
        )
    }
    
    // MARK: - Buton Stilleri
    enum ButtonStyles {
        struct Primary: SwiftUI.ButtonStyle {
            func makeBody(configuration: Configuration) -> some View {
                configuration.label
                    .font(Typography.bodyBold)
                    .foregroundColor(ColorPalette.onPrimary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Layout.padding)
                    .background(ColorPalette.areapolPrimary)
                    .cornerRadius(Layout.cornerRadius)
                    .opacity(configuration.isPressed ? 0.8 : 1.0)
            }
        }
        
        struct Secondary: SwiftUI.ButtonStyle {
            func makeBody(configuration: Configuration) -> some View {
                configuration.label
                    .font(Typography.bodyBold)
                    .foregroundColor(ColorPalette.areapolPrimary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Layout.padding)
                    .background(ColorPalette.background)
                    .cornerRadius(Layout.cornerRadius)
                    .opacity(configuration.isPressed ? 0.8 : 1.0)
            }
        }
        
        struct Bordered: SwiftUI.ButtonStyle {
            func makeBody(configuration: Configuration) -> some View {
                configuration.label
                    .font(Typography.bodyBold)
                    .foregroundColor(ColorPalette.areapolPrimary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Layout.padding)
                    .background(ColorPalette.background)
                    .cornerRadius(Layout.cornerRadius)
                    .overlay(
                        RoundedRectangle(cornerRadius: Layout.cornerRadius)
                            .stroke(ColorPalette.areapolPrimary, lineWidth: 1.25)
                    )
                    .opacity(configuration.isPressed ? 0.8 : 1.0)
            }
        }
        
        struct Destructive: SwiftUI.ButtonStyle {
            func makeBody(configuration: Configuration) -> some View {
                configuration.label
                    .font(Typography.bodyBold)
                    .foregroundColor(ColorPalette.onPrimary)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Layout.padding)
                    .background(ColorPalette.error)
                    .cornerRadius(Layout.cornerRadius)
                    .opacity(configuration.isPressed ? 0.8 : 1.0)
            }
        }
    }
    
    struct Destructive: SwiftUI.ButtonStyle {
        func makeBody(configuration: Configuration) -> some View {
            configuration.label
                .font(Typography.bodyBold)
                .foregroundColor(ColorPalette.onPrimary)
                .frame(height: 52)
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: Layout.cornerRadius)
                        .fill(configuration.isPressed ?
                              ColorPalette.error.opacity(0.9) :
                                ColorPalette.error
                             )
                )
        }
    }
    
    // MARK: - Layout
    enum Layout {
        static let cornerRadiusXS: CGFloat = 8
        static let cornerRadiusS: CGFloat = 9
        static let cornerRadius: CGFloat = 10
        static let cornerRadiusM: CGFloat = 12
        static let cornerRadiusL: CGFloat = 16
        static let paddingXXS: CGFloat = 10
        static let paddingXS: CGFloat = 12
        static let paddingS: CGFloat = 14
        static let padding: CGFloat = 16
        static let paddingL: CGFloat = 24
        static let paddingXL: CGFloat = 32
        static let spacing: CGFloat = 8
        static let spacingXXS: CGFloat = 3
        static let spacingXS: CGFloat = 4
        static let spacingS: CGFloat = 8
        static let spacingM: CGFloat = 16
        static let spacingL: CGFloat = 24
        static let spacingXL: CGFloat = 32
        static let iconSize: CGFloat = 24
        static let logoSize: CGFloat = 80
    }
    
    // MARK: - Elevation
    enum Elevation {
        static let low = Shadow(
            color: .black.opacity(0.1),
            radius: 2,
            x: 0,
            y: 1
        )
        static let medium = Shadow(
            color: .black.opacity(0.2),
            radius: 4,
            x: 0,
            y: 2
        )
        static let high = Shadow(
            color: .black.opacity(0.3),
            radius: 6,
            x: 0,
            y: 4
        )
        static let divider = Shadow(
            color: ColorPalette.textSecondary.opacity(0.2),
            radius: 0.5,
            x: 0,
            y: 0
        )
    }
}

// MARK: - View Styles
extension Theme {
    enum ViewStyles {
        struct ListRow: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .padding(TLayout.padding)
                    .background(TColor.surface)
                    .cornerRadius(TLayout.cornerRadius)
                    .shadow(
                        color: TElevation.low.color,
                        radius: TElevation.low.radius,
                        x: TElevation.low.x,
                        y: TElevation.low.y
                    )
            }
        }
        
        struct Card: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .padding(TLayout.padding)
                    .background(TColor.card)
                    .cornerRadius(TLayout.cornerRadius)
                    .shadow(
                        color: TElevation.medium.color,
                        radius: TElevation.medium.radius,
                        x: TElevation.medium.x,
                        y: TElevation.medium.y
                    )
            }
        }
        
        struct NavigationBarStyle: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .toolbarBackground(TColor.areapolSecondary, for: .navigationBar)
                    .toolbarBackground(.visible, for: .navigationBar)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbarColorScheme(.dark, for: .navigationBar)
            }
        }
    }
}

// MARK: - View Extensions
extension View {
    func applyListRowStyle() -> some View {
        self.modifier(TViewStyle.ListRow())
    }
    
    func applyCardStyle() -> some View {
        self.modifier(TViewStyle.Card())
    }
    
    func applyNavigationBarStyle() -> some View {
        self.modifier(TViewStyle.NavigationBarStyle())
    }
}

// Hızlı Erişim
typealias TColor = Theme.ColorPalette
typealias TFont = Theme.Typography
typealias TButton = Theme.ButtonStyles
typealias TLayout = Theme.Layout
typealias TElevation = Theme.Elevation
typealias TViewStyle = Theme.ViewStyles
