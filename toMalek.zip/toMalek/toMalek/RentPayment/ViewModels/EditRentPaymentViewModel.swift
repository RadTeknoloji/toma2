//
//  EditRentPaymentViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class EditRentPaymentViewModel: ObservableObject {
    // MARK: - Services
    private let rentPaymentService: RentPaymentService
    private let propertyService: PropertyService
    
    @Published var mediaUrls: [String] = []
    @Published var showMediaPicker = false
    private let mediaService: MediaService
    
    // MARK: - Private Properties
    let payment: RentPaymentModel

    // MARK: - Published Properties
    @Published var selectedProperty: PropertyModel?
    @Published var selectedMonth: Date
    @Published var rentPaymentStatus: RentPaymentStatus
    @Published var paymentDay: PaymentDay
    @Published var rentPrice: String
    @Published var rentAmountPaid: String
    @Published var paymentDescription: String
    
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isSuccessful = false
    @Published var properties: [PropertyModel] = []

    // MARK: - Computed Properties
    var rentBalance: Double {
        let price = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0
        let paid = Double(rentAmountPaid.replacingOccurrences(of: ",", with: ".")) ?? 0
        return max(0, price - paid)
    }
    
    var isValidForm: Bool {
        selectedProperty != nil &&
        isValidAmount &&
        isValidPaidAmount
    }
    
    private var isValidAmount: Bool {
        if let amount = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) {
            return amount > 0
        }
        return false
    }
    
    private var isValidPaidAmount: Bool {
        if let paid = Double(rentAmountPaid.replacingOccurrences(of: ",", with: ".")) {
            let price = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0
            return paid >= 0 && paid <= price
        }
        return false
    }
    
    // MARK: - Initialization
    init(payment: RentPaymentModel,
         rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService,
         mediaService: MediaService = ServiceContainer.shared.mediaService) {
        self.mediaService = mediaService
        self.payment = payment
        self.rentPaymentService = rentPaymentService
        self.propertyService = propertyService
        
        // Initialize published properties with payment data
        self.selectedMonth = payment.whichMonth
        self.rentPaymentStatus = payment.rentPaymentStatus
        self.paymentDay = payment.paymentDay
        self.rentPrice = "\(payment.rentPrice)"
        self.rentAmountPaid = "\(payment.rentAmountPaid)"
        self.paymentDescription = payment.paymentDescription ?? ""
        self.mediaUrls = payment.mediaUrls
        
        // Fetch properties
        Task { await fetchProperties() }
    }

    func saveWithMedia(urls: [String]) async {
        self.mediaUrls = urls
        await save() // Mevcut save fonksiyonu çağrılır
    }
    
    // MARK: - Methods
    func save() async {
        guard isValidForm else {
            errorMessage = String(localized: "error_fill_required_fields")
            return
        }
        isLoading = true
        errorMessage = nil
        do {
            guard let userId = Auth.auth().currentUser?.uid else {
                throw RentPaymentError.unauthorized
            }
            let price = Double(rentPrice.replacingOccurrences(of: ",", with: ".")) ?? 0
            let paid = Double(rentAmountPaid.replacingOccurrences(of: ",", with: ".")) ?? 0
            let status: RentPaymentStatus
            if paid >= price {
                status = .paid
            } else if paid > 0 {
                status = .partiallyPaid
            } else {
                status = .unpaid
            }
            let updatedPayment = RentPaymentModel(
                id: payment.id,
                userId: userId,
                propertyId: payment.propertyId,
                rentPrice: price,
                rentAmountPaid: paid,
                rentBalance: price - paid,
                whichMonth: payment.whichMonth,
                rentPaymentStatus: status,
                paymentDay: payment.paymentDay,
                paymentDescription: paymentDescription,
                paidDate: paid > 0 ? Date() : nil
            )
            try await rentPaymentService.updateRentPayment(updatedPayment)
            isSuccessful = true
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
    
    // MARK: - Private Methods
    private func fetchProperties() async {
        isLoading = true
        do {
            properties = try await propertyService.fetchProperties()
            // Find and set the selected property
            self.selectedProperty = properties.first { $0.id == payment.propertyId }
        } catch {
            errorMessage = String(localized: "error_loading_properties")
        }
        isLoading = false
    }
}
