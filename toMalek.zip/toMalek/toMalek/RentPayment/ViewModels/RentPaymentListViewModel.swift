//
//  RentPaymentListViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

@MainActor
final class RentPaymentListViewModel: ObservableObject {
    // MARK: - Services
    private let rentPaymentService: RentPaymentService
    private let propertyService: PropertyService

    // MARK: - Published Properties
    @Published var rentPayments: [RentPaymentModel] = []
    @Published var properties: [PropertyModel] = []
    @Published var selectedProperty: PropertyModel?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showPaymentDetail = false
    @Published var selectedPayment: RentPaymentModel?

    // MARK: - Computed Properties
    var paymentsForSelectedProperty: [RentPaymentModel] {
        let payments = selectedProperty == nil ?
            rentPayments : // Tümü seçili ise
            rentPayments.filter { $0.propertyId == selectedProperty?.id } // Belirli bir mülk seçili ise
        
        // Tarihe göre sıralama (eskiden yeniye)
        return payments.sorted { $0.whichMonth < $1.whichMonth }
    }
    
    var paymentsExistForSelectedProperty: Bool {
        guard let selectedProperty = selectedProperty else { return false }
        return rentPayments.contains { $0.propertyId == selectedProperty.id }
    }
        
    var totalDueAmount: Double {
        let relevantPayments = paymentsForSelectedProperty
        return relevantPayments.reduce(0) { $0 + $1.rentPrice }
    }
    
    var totalPaidAmount: Double {
        let relevantPayments = paymentsForSelectedProperty
        return relevantPayments.reduce(0) { $0 + $1.rentAmountPaid }
    }
    
    var totalRemainingAmount: Double {
        totalDueAmount - totalPaidAmount
    }
    
    // Kira planı oluştur butonunun görünürlüğünü kontrol eden property
    var shouldShowCreateScheduleButton: Bool {
        guard let selectedProperty = selectedProperty else { return false }
        let existingPayments = rentPayments.filter { $0.propertyId == selectedProperty.id }
        return existingPayments.isEmpty
    }
    
    // MARK: - Initialization
    init(rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.rentPaymentService = rentPaymentService
        self.propertyService = propertyService
        self.selectedProperty = nil  // Başlangıçta "Tümü" seçili
    }
    
    // MARK: - Public Methods
    func fetchPropertiesAndPayments() async {
        isLoading = true
        errorMessage = nil
        
        do {
            // Fetch properties and existing payments
            let fetchedProperties = try await propertyService.fetchProperties()
            self.properties = fetchedProperties
            
            let payments = try await rentPaymentService.fetchRentPayments()
            self.rentPayments = payments
            
            print("Debug: \(String(localized: "debug_fetched_properties_count")) \(fetchedProperties.count)")
            print("Debug: \(String(localized: "debug_fetched_payments_count")) \(payments.count)")
            
            // Eğer hiç property yoksa selectedProperty nil kalacak ("Tümü" seçili)
            
        } catch {
            errorMessage = String(localized: "error_loading_data")
            print("Debug: \(String(localized: "debug_error")) \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    func createRentPaymentsForProperty(_ property: PropertyModel) async {
        guard property.rentStartDate != nil else {
            errorMessage = String(localized: "error_no_rent_start_date")
            return
        }
            
        isLoading = true
        errorMessage = nil
            
        do {
            print("Debug: \(String(localized: "debug_creating_payments_for_property")) \(property.title)")
            try await rentPaymentService.ensureRentPaymentsExist(property: property)
                
            // Refresh payments after creation
            let payments = try await rentPaymentService.fetchRentPayments()
            self.rentPayments = payments
                
            print("Debug: \(String(localized: "debug_payments_created_successfully"))")
            print("Debug: \(String(localized: "debug_total_payments_after_creation")) \(payments.count)")
                
        } catch {
            errorMessage = String(localized: "error_creating_rent_schedule")
            print("Debug: \(String(localized: "debug_error_creating_payments")) \(error.localizedDescription)")
        }
            
        isLoading = false
    }
    
    func setSelectedProperty(_ property: PropertyModel?) {
        // nil değeri "Tümü" seçeneğini temsil eder
        selectedProperty = property
    }
    
    func selectPayment(_ payment: RentPaymentModel) {
        selectedPayment = payment
        showPaymentDetail = true
    }
    
    func refreshList() async {
        await fetchPropertiesAndPayments()
    }
}
