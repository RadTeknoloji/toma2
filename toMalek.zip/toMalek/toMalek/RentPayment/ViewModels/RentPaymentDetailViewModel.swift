//
//  RentPaymentDetailViewModel.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import SwiftUI

@MainActor
final class RentPaymentDetailViewModel: ObservableObject {
    // MARK: - Services
    private let rentPaymentService: RentPaymentService
    private let propertyService: PropertyService
    private let authState = AuthenticationState.shared

    // MARK: - Published Properties
    @Published var payment: RentPaymentModel
    @Published var property: PropertyModel?
    @Published var showEditPayment = false
    @Published var showDeleteAlert = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var isDeleted = false
    @Published var canMakePayment: Bool = false
    @Published var showImagePreview = false
    @Published var selectedImageUrl: String?
    
    // MARK: - Computed Properties
    var propertyText: String {
        property?.title ?? String(localized: "property_not_found")
    }
    
    var statusColor: Color {
        switch payment.rentPaymentStatus {
        case .paid: return TColor.success
        case .unpaid: return TColor.error
        case .partiallyPaid: return TColor.warning
        }
    }
    
    var dueText: String {
        String(format: String(localized: "payment_due_day"), payment.paymentDay.rawValue)
    }
    
    var monthText: String {
        payment.whichMonth.formatted(.dateTime.month(.wide).year())
    }
    
    var paidDateText: String? {
        payment.paidDate?.formatted(date: .long, time: .shortened)
    }
    
    var isLate: Bool {
        payment.isLate
    }
    
    var hasPhotos: Bool {
        !payment.mediaUrls.isEmpty
    }
    
    // MARK: - Initialization
    init(payment: RentPaymentModel,
         rentPaymentService: RentPaymentService = ServiceContainer.shared.rentPaymentService,
         propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.payment = payment
        self.rentPaymentService = rentPaymentService
        self.propertyService = propertyService
        
        // Fetch property and check permissions
        Task {
            await fetchProperty()
            await checkPaymentPermission()
        }
    }
    
    // MARK: - Methods
    func deletePayment() async {
        isLoading = true
        errorMessage = nil
        
        do {
            try await rentPaymentService.deleteRentPayment(id: payment.id.uuidString)
            isDeleted = true
        } catch {
            errorMessage = String(localized: "error_deleting_payment")
        }
        
        isLoading = false
    }
    
    func updatePaymentStatus() async {
        isLoading = true
        errorMessage = nil
        
        do {
            var updatedPayment = payment
            updatedPayment.rentAmountPaid = payment.rentPrice
            updatedPayment.rentBalance = 0
            updatedPayment.rentPaymentStatus = .paid
            updatedPayment.paidDate = Date()
            
            try await rentPaymentService.updateRentPayment(updatedPayment)
            payment = updatedPayment
            
        } catch {
            errorMessage = String(localized: "error_updating_payment_status")
        }
        
        isLoading = false
    }
    
    func selectImage(_ url: String) {
        selectedImageUrl = url
        showImagePreview = true
    }
    
    // MARK: - Private Methods
    private func fetchProperty() async {
        isLoading = true
        do {
            if let property = try await propertyService.fetchProperty(id: payment.propertyId.uuidString) {
                self.property = property
            } else {
                errorMessage = String(localized: "error_property_not_found")
            }
        } catch {
            errorMessage = String(localized: "error_loading_property")
            print("Debug: \(String(localized: "debug_error_fetching_property")) \(error)")
        }
        isLoading = false
    }
    
    private func checkPaymentPermission() async {
        // Eğer mülkte tenant eşleşmesi varsa
        if let property = property, property.tenantId != nil {
            // Sadece tenant ödeme yapabilir
            canMakePayment = authState.userType == UserType.tenant.rawValue
        } else {
            // Tenant eşleşmesi yoksa owner ve agency ödeme yapabilir
            canMakePayment = authState.userType != UserType.tenant.rawValue
        }
    }
    
    func refreshPayment() async {
        do {
            if let updatedPayment = try await rentPaymentService.fetchRentPayment(id: payment.id.uuidString) {
                self.payment = updatedPayment
            }
        } catch {
            errorMessage = String(localized: "error_refreshing_payment")
        }
    }
}
