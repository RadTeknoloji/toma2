//
//  RentPaymentListView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct RentPaymentListView: View {
    @StateObject private var viewModel = RentPaymentListViewModel()
    
    var body: some View {
        VStack(spacing: TLayout.spacing) {
            propertyPickerSection
                .padding(TLayout.padding)
            
            selectedPropertyContent
            Spacer()
        }
        .navigationTitle(String(localized: "rent_tracking"))
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $viewModel.showPaymentDetail) {
            if let payment = viewModel.selectedPayment {
                RentPaymentDetailView(payment: payment)
            }
        }
        .task {
            await viewModel.fetchPropertiesAndPayments()
        }
        .refreshable {
            await viewModel.fetchPropertiesAndPayments()
        }
        .overlay {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
        .alert(String(localized: "error"), isPresented: .constant(viewModel.errorMessage != nil)) {
            Button(String(localized: "ok"), role: .cancel) {
                viewModel.errorMessage = nil
            }
        } message: {
            if let error = viewModel.errorMessage {
                Text(error)
                    .font(TFont.body)
            }
        }
        .background(TColor.background)
    }

    // MARK: - Property Picker Section
    private var propertyPickerSection: some View {
        VStack(spacing: TLayout.spacingS) {
            Menu {
                Button {
                    viewModel.selectedProperty = nil
                } label: {
                    HStack {
                        Text(String(localized: "all_properties"))
                            .font(TFont.body)
                        if viewModel.selectedProperty == nil {
                            Image(systemName: "checkmark")
                                .foregroundColor(TColor.areapolPrimary)
                        }
                    }
                }
                
                ForEach(viewModel.properties) { property in
                    Button {
                        viewModel.setSelectedProperty(property)
                    } label: {
                        HStack {
                            Text(property.title)
                                .font(TFont.body)
                            if viewModel.selectedProperty?.id == property.id {
                                Image(systemName: "checkmark")
                                    .foregroundColor(TColor.areapolPrimary)
                            }
                        }
                    }
                }
            } label: {
                HStack {
                    Image(systemName: "building.2.fill")
                        .foregroundColor(TColor.areapolPrimary)
                    
                    Text(viewModel.selectedProperty?.title ?? String(localized: "all_properties"))
                        .font(TFont.bodyBold)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.down")
                        .foregroundColor(TColor.areapolPrimary)
                }
                .padding(TLayout.padding)
                .frame(maxWidth: .infinity)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
            }

            if viewModel.shouldShowCreateScheduleButton {
                Button {
                    Task {
                        if let property = viewModel.selectedProperty {
                            await viewModel.createRentPaymentsForProperty(property)
                        }
                    }
                } label: {
                    HStack {
                        Image(systemName: "table.badge.plus")
                        Text(String(localized: "create_rent_schedule"))
                    }
                    .font(TFont.body)
                    .frame(maxWidth: .infinity)
                    .padding(TLayout.spacing)
                    .background(TColor.areapolPrimary)
                    .foregroundColor(TColor.onPrimary)
                    .cornerRadius(TLayout.cornerRadius)
                }
            }
        }
    }

    // MARK: - Selected Property Content
    private var selectedPropertyContent: some View {
        VStack(spacing: 0) {
            // Summary Cards artık property parametresi almayacak
            summaryCards
                .padding(.horizontal, TLayout.padding)
                .padding(.bottom, TLayout.padding)
            
            if viewModel.paymentsForSelectedProperty.isEmpty {
                ContentUnavailableView(
                    String(localized: "no_rent_records"),
                    systemImage: "doc.text.magnifyingglass",
                    description: Text(String(localized: "create_schedule_instruction"))
                        .font(TFont.body)
                )
                .padding()
            } else {
                paymentsTable
            }
        }
    }

    // Summary Cards'ı güncelliyoruz
    private var summaryCards: some View {
        HStack(spacing: TLayout.spacingM) {
            SummaryCard(
                title: String(localized: "total"),
                value: "\(viewModel.totalDueAmount.formatted()) ₺",
                icon: "banknote.fill",
                color: TColor.areapolPrimary
            )
            
            SummaryCard(
                title: String(localized: "paid"),
                value: "\(viewModel.totalPaidAmount.formatted()) ₺",
                icon: "checkmark.circle.fill",
                color: TColor.success
            )
            
            SummaryCard(
                title: String(localized: "remaining"),
                value: "\(viewModel.totalRemainingAmount.formatted()) ₺",
                icon: "exclamationmark.circle.fill",
                color: TColor.error
            )
        }
    }

    private var paymentsTable: some View {
        VStack(spacing: 0) {
            tableHeader
            
            if viewModel.paymentsForSelectedProperty.isEmpty {
                ContentUnavailableView(
                    String(localized: "no_rent_records"),
                    systemImage: "doc.text.magnifyingglass",
                    description: Text(String(localized: "create_schedule_instruction"))
                        .font(TFont.body)
                )
                .padding()
            } else {
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(viewModel.paymentsForSelectedProperty) { payment in
                            PaymentRow(payment: payment) {
                                viewModel.selectPayment(payment)
                            }
                            Divider()
                                .background(TColor.border.opacity(0.2))
                        }
                    }
                }
            }
        }
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
        .padding(.horizontal, TLayout.padding)
    }
    
    // MARK: - Helper Views
    private var tableHeader: some View {
        HStack {
            Text(String(localized: "period"))
                .frame(width: 80, alignment: .leading)
            Text(String(localized: "due_date"))
                .frame(width: 80)
            Text(String(localized: "amount"))
                .frame(width: 80)
            Text(String(localized: "status"))
                .frame(width: 100)
        }
        .font(TFont.footnote)
        .foregroundColor(TColor.textSecondary)
        .padding(.horizontal, TLayout.padding)
        .padding(.vertical, TLayout.spacing)
        .background(TColor.background)
    }
    
    private func summaryCards(for property: PropertyModel) -> some View {
        HStack(spacing: TLayout.spacingM) {
            SummaryCard(
                title: String(localized: "total"),
                value: "\(viewModel.totalDueAmount.formatted()) ₺",
                icon: "banknote.fill",
                color: TColor.areapolPrimary
            )
            
            SummaryCard(
                title: String(localized: "paid"),
                value: "\(viewModel.totalPaidAmount.formatted()) ₺",
                icon: "checkmark.circle.fill",
                color: TColor.success
            )
            
            SummaryCard(
                title: String(localized: "remaining"),
                value: "\(viewModel.totalRemainingAmount.formatted()) ₺",
                icon: "exclamationmark.circle.fill",
                color: TColor.error
            )
        }
    }
}

// MARK: - Payment Row
struct PaymentRow: View {
    let payment: RentPaymentModel
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack {
                // Period
                Text(payment.whichMonth.formatted(.dateTime.month().year()))
                    .frame(width: 80, alignment: .leading)
                    .font(TFont.subheadline)
                    .foregroundColor(TColor.textPrimary)
                
                // Due Date
                Text(payment.paymentDay.displayName)
                    .frame(width: 80)
                    .font(TFont.subheadline)
                    .foregroundColor(TColor.textSecondary)
                
                // Amount
                VStack(alignment: .trailing, spacing: TLayout.spacingXS) {
                    Text("\(payment.rentPrice.formatted()) ₺")
                        .font(TFont.subheadline)
                    if payment.rentAmountPaid > 0 {
                        Text(String(format: String(localized: "paid_amount_label"), payment.rentAmountPaid.formatted()))
                            .font(TFont.caption)
                            .foregroundColor(TColor.success)
                    }
                }
                .frame(width: 80)
                
                // Status
                PaymentStatusBadge(status: payment.rentPaymentStatus)
                    .frame(width: 100)
            }
            .padding(.horizontal, TLayout.padding)
            .padding(.vertical, TLayout.spacing)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Summary Card
struct SummaryCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXS) {
            HStack(spacing: TLayout.spacingXS) {
                Image(systemName: icon)
                    .foregroundColor(color)
                Text(title)
                    .font(TFont.footnote)
                    .foregroundColor(TColor.textSecondary)
            }
            
            Text(value)
                .font(TFont.bodyBold)
                .foregroundColor(color)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(TLayout.spacing)
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
    }
}

// MARK: - Payment Status Badge
struct PaymentStatusBadge: View {
        let status: RentPaymentStatus
        
        var body: some View {
            Text(statusText)
                .font(TFont.caption)
                .foregroundColor(statusColor)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(
                    Capsule()
                        .fill(statusColor.opacity(0.15))
                )
        }
        
        private var statusColor: Color {
            switch status {
            case .paid: return TColor.success
            case .unpaid: return TColor.error
            case .partiallyPaid: return TColor.warning
            }
        }
        
        private var statusText: String {
            switch status {
            case .paid: return String(localized: "status_paid")
            case .unpaid: return String(localized: "status_unpaid")
            case .partiallyPaid: return String(localized: "status_partially_paid")
            }
        }
    }
