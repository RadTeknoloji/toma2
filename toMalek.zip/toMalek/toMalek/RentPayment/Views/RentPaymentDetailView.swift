//
//  RentPaymentDetailView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI

struct RentPaymentDetailView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: RentPaymentDetailViewModel
    @State private var showEditSheet = false
    @State private var showImageViewer = false
    @State private var selectedImageURL: URL?
    
    init(payment: RentPaymentModel) {
        _viewModel = StateObject(wrappedValue: RentPaymentDetailViewModel(payment: payment))
    }
    
    var body: some View {
        ZStack {
            TColor.background.ignoresSafeArea()
            
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: TLayout.spacingXL) {
                    statusCard
                    
                    if viewModel.canMakePayment {
                        paymentActionButton
                    }
                    
                    propertyCard
                    paymentDetailsSection
                    
                    if viewModel.hasPhotos {
                        mediaSection
                    }
                }
                .padding(TLayout.padding)
            }
        }
        .navigationTitle(String(localized: "payment_detail"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                editButton
            }
        }
        .sheet(isPresented: $showEditSheet) {
            EditRentPaymentView(payment: viewModel.payment, onSave: {
                Task {
                    await viewModel.refreshPayment()
                }
                showEditSheet = false
            })
            .background(TColor.background)
        }
        .overlay {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
        .fullScreenCover(isPresented: $showImageViewer) {
            if let url = selectedImageURL {
                ImagePreviewView(imageURL: url)
            }
        
        }
    }
    
    // MARK: - Components
    private var statusCard: some View {
        VStack(spacing: TLayout.spacingM) {
            VStack(spacing: TLayout.spacingXS) {
                Text(viewModel.payment.rentPaymentStatus.rawValue)
                    .font(TFont.title3)
                    .foregroundColor(viewModel.statusColor)
                
                Text(viewModel.monthText)
                    .font(TFont.headline)
                    .foregroundColor(TColor.textSecondary)
            }
        }
        .padding(TLayout.spacingM)
        .frame(maxWidth: .infinity)
        .background(viewModel.statusColor.opacity(0.1))
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var paymentActionButton: some View {
        Button {
            showEditSheet = true
        } label: {
            HStack {
                Image(systemName: "banknote")
                Text(String(localized: "make_payment"))
            }
            .frame(maxWidth: .infinity)
            .padding(TLayout.spacingM)
            .background(TColor.areapolPrimary)
            .foregroundColor(TColor.onPrimary)
            .cornerRadius(TLayout.cornerRadius)
        }
    }
    
    private var propertyCard: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingM) {
            Label(String(localized: "property_info"), systemImage: "house.fill")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            Text(viewModel.propertyText)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textPrimary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(TLayout.spacingM)
                .background(TColor.surface)
                .cornerRadius(TLayout.cornerRadius)
        }
        .padding(TLayout.spacingM)
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var paymentDetailsSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingXL) {
            Label(String(localized: "payment_details"), systemImage: "creditcard.fill")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            VStack(spacing: TLayout.spacingM) {
                Group {
                    DetailRow(
                        title: String(localized: "rent_amount"),
                        value: "\(viewModel.payment.rentPrice.formatted()) ₺",
                        icon: "banknote"
                    )
                    
                    if viewModel.payment.rentAmountPaid > 0 {
                        DetailRow(
                            title: String(localized: "paid_amount"),
                            value: "\(viewModel.payment.rentAmountPaid.formatted()) ₺",
                            icon: "checkmark.circle.fill",
                            valueColor: TColor.success
                        )
                    }
                    
                    if viewModel.payment.rentBalance > 0 {
                        DetailRow(
                            title: String(localized: "remaining_amount"),
                            value: "\(viewModel.payment.rentBalance.formatted()) ₺",
                            icon: "exclamationmark.circle.fill",
                            valueColor: TColor.error
                        )
                    }
                }
                
                Divider()
                    .background(TColor.textSecondary.opacity(0.2))
                
                Group {
                    DetailRow(
                        title: String(localized: "due_date"),
                        value: viewModel.dueText,
                        icon: "calendar"
                    )
                    
                    if let paidDate = viewModel.paidDateText {
                        DetailRow(
                            title: String(localized: "payment_date"),
                            value: paidDate,
                            icon: "clock.fill",
                            valueColor: viewModel.isLate ? TColor.warning : TColor.success
                        )
                    }
                }
                
                if let description = viewModel.payment.paymentDescription {
                    Divider()
                        .background(TColor.textSecondary.opacity(0.2))
                    
                    VStack(alignment: .leading, spacing: TLayout.spacingXS) {
                        Text(String(localized: "description"))
                            .font(TFont.subheadline)
                            .foregroundColor(TColor.textSecondary)
                        
                        Text(description)
                            .font(TFont.subheadline)
                            .foregroundColor(TColor.textPrimary)
                    }
                }
            }
            .padding(TLayout.spacingM)
            .background(TColor.surface)
            .cornerRadius(TLayout.cornerRadius)
        }
        .padding(TLayout.spacingM)
        .background(TColor.background)
        .cornerRadius(TLayout.cornerRadius)
    }
    
    private var mediaSection: some View {
        VStack(alignment: .leading, spacing: TLayout.spacingL) {
            Label(String(localized: "payment_photos"), systemImage: "photo.stack")
                .font(TFont.headline)
                .foregroundColor(TColor.textPrimary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: TLayout.spacingS) {
                    ForEach(viewModel.payment.mediaUrls, id: \.self) { urlString in
                        if let url = URL(string: urlString) {
                            AsyncImage(url: url) { phase in
                                switch phase {
                                case .empty:
                                    ProgressView()
                                        .frame(width: 200, height: 200)
                                case .success(let image):
                                    Button {
                                        selectedImageURL = url
                                        showImageViewer = true
                                    } label: {
                                        image
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 200, height: 200)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                    }
                                case .failure:
                                    Image(systemName: "photo")
                                        .foregroundColor(TColor.textSecondary)
                                        .frame(width: 200, height: 200)
                                @unknown default:
                                    EmptyView()
                                }
                            }
                        }
                    }
                }
                .padding(.vertical, TLayout.paddingXXS)
            }
        }
        .padding(TLayout.padding)
        .background(TColor.surface)
        .cornerRadius(TLayout.cornerRadiusL)
    }
    
    private var editButton: some View {
        Button {
            showEditSheet = true
        } label: {
            Image(systemName: "pencil")
                .foregroundColor(TColor.textPrimary)
        }
        .disabled(!viewModel.canMakePayment)
    }
}

// MARK: - Helper Views
private struct DetailRow: View {
    let title: String
    let value: String
    let icon: String
    var valueColor: Color = TColor.textPrimary
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(TColor.textSecondary)
                .frame(width: 24)
            
            Text(title)
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
            
            Spacer()
            
            Text(value)
                .font(TFont.subheadline)
                .foregroundColor(valueColor)
        }
    }
}


// MARK: - Preview Provider
struct RentPaymentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            RentPaymentDetailView(payment: RentPaymentModel(
                id: UUID(),
                userId: "preview-user-id",
                propertyId: UUID(),
                rentPrice: 5000,
                rentAmountPaid: 0,
                rentBalance: 5000,
                whichMonth: Date(),
                rentPaymentStatus: .unpaid,
                paymentDay: .fifth,
                paymentDescription: nil,
                paidDate: nil,
                mediaUrls: []
            ))
        }
    }
}
