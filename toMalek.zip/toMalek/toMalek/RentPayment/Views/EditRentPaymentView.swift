//
//  EditRentPaymentView.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import SwiftUI
import PhotosUI

struct EditRentPaymentView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel: EditRentPaymentViewModel
    var onSave: (() -> Void)?
    
    init(payment: RentPaymentModel, onSave: (() -> Void)? = nil) {
        _viewModel = StateObject(wrappedValue: EditRentPaymentViewModel(payment: payment))
        self.onSave = onSave
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                TColor.background.ignoresSafeArea()
                
                Form {
                    // Payment Details Section
                    Section {
                        rentAmountRow
                        paidAmountField
                        remainingAmountRow
                    } header: {
                        Text(String(localized: "payment_details"))
                            .font(TFont.headline)
                            .foregroundColor(TColor.textPrimary)
                    }
                    .listRowBackground(TColor.surface)
                    
                    // Description Section
                    Section {
                        descriptionField
                    } header: {
                        Text(String(localized: "payment_description"))
                            .font(TFont.headline)
                            .foregroundColor(TColor.textPrimary)
                    }
                    .listRowBackground(TColor.surface)
                    
                    // Media Section
                    Section {
                        addMediaButton
                        mediaPreview
                    } header: {
                        Text(String(localized: "payment_media"))
                            .font(TFont.headline)
                            .foregroundColor(TColor.textPrimary)
                    }
                    .listRowBackground(TColor.surface)
                }
                .scrollContentBackground(.hidden)
                .background(TColor.background)
                .formStyle(.grouped)
            }
            .navigationTitle(String(localized: "make_payment"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                cancelToolbarItem
                saveToolbarItem
            }
            .sheet(isPresented: $viewModel.showMediaPicker) {
                MediaPickerView(propertyId: viewModel.payment.propertyId) { urls in
                    Task {
                        await viewModel.saveWithMedia(urls: urls)
                    }
                }
            }
            .overlay(loadingOverlay)
            .alert(
                        String(localized: "error"),
                        isPresented: .constant(viewModel.errorMessage != nil),
                        presenting: viewModel.errorMessage,
                        actions: { _ in
                            Button(String(localized: "ok"), role: .cancel) {
                                viewModel.errorMessage = nil
                            }
                        },
                        message: { message in
                            Text(message)
                                .font(TFont.body)
                        }
                    )
                }
            }
    
    
    
    // MARK: - Components
    private var rentAmountRow: some View {
        HStack {
            Text("rent_amount")
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            Spacer()
            
            Text("\(viewModel.payment.rentPrice.formatted()) ₺")
                .font(TFont.subheadline)
                .foregroundColor(TColor.textSecondary)
        }
    }
    
    private var paidAmountField: some View {
        HStack {
            Text("paid_amount")
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            Spacer()
            
            TextField("0.00", text: $viewModel.rentAmountPaid)
                .font(TFont.body)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .foregroundColor(TColor.textPrimary)
            
            Text("₺")
                .font(TFont.body)
                .foregroundColor(TColor.textSecondary)
        }
    }
    
    private var remainingAmountRow: some View {
        HStack {
            Text("remaining_amount")
                .font(TFont.body)
                .foregroundColor(TColor.textPrimary)
            
            Spacer()
            
            Text("\(viewModel.rentBalance.formatted()) ₺")
                .font(TFont.subheadline)
                .foregroundColor(TColor.error)
        }
    }
    
    private var descriptionField: some View {
        TextField(String(localized: "add_description"), text: $viewModel.paymentDescription, axis: .vertical)
            .font(TFont.body)
            .foregroundColor(TColor.textPrimary)
            .lineLimit(3...5)
    }
    
    private var addMediaButton: some View {
        Button {
            viewModel.showMediaPicker = true
        } label: {
            HStack {
                Image(systemName: "photo.on.rectangle.angled")
                Text(String(localized: "add_payment_photos"))
            }
        }
    }
    
    private var mediaPreview: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: TLayout.spacingS) {
                ForEach(viewModel.mediaUrls, id: \.self) { url in
                    AsyncImage(url: URL(string: url)) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .frame(width: 80, height: 80)
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                        case .failure:
                            Image(systemName: "photo")
                                .foregroundColor(TColor.textSecondary)
                                .frame(width: 80, height: 80)
                        @unknown default:
                            EmptyView()
                        }
                    }
                }
            }
        }
    }
    
    private var cancelToolbarItem: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button(String(localized: "cancel")) {
                dismiss()
            }
            .foregroundColor(TColor.textPrimary)
        }
    }
    
    private var saveToolbarItem: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(String(localized: "save")) {
                Task {
                    await viewModel.save()
                    if viewModel.isSuccessful {
                        onSave?()
                    }
                }
            }
            .foregroundColor(TColor.textPrimary)
            .disabled(!viewModel.isValidForm || viewModel.isLoading)
        }
    }
    
    private var loadingOverlay: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
                    .tint(TColor.areapolPrimary)
            }
        }
    }
}

// MARK: - Preview Provider
struct EditRentPaymentView_Previews: PreviewProvider {
    static var previews: some View {
        EditRentPaymentView(payment: RentPaymentModel(
            id: UUID(),
            userId: "preview-user-id",
            propertyId: UUID(),
            rentPrice: 5000,
            rentAmountPaid: 0,
            rentBalance: 5000,
            whichMonth: Date(),
            rentPaymentStatus: .unpaid,
            paymentDay: .fifth,
            paymentDescription: nil,
            paidDate: nil,
            mediaUrls: []
        ))
        .background(TColor.background)
    }
}

