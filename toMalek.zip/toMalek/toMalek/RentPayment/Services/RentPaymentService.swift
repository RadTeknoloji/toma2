//
//  RentPaymentService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

// MARK: - RentPayment Service Protocol
protocol RentPaymentService {
    // MARK: - Create
    func createRentPayment(_ payment: RentPaymentModel) async throws
    
    // MARK: - Read
    func fetchRentPayments() async throws -> [RentPaymentModel]
    func fetchRentPayment(id: String) async throws -> RentPaymentModel?
    func fetchRentPayments(forProperty propertyId: String) async throws -> [RentPaymentModel]
    func fetchRentPayments(forMonth date: Date) async throws -> [RentPaymentModel]
    
    // MARK: - Update
    func updateRentPayment(_ payment: RentPaymentModel) async throws
    func markAsPaid(_ payment: RentPaymentModel, paidDate: Date) async throws
    
    // MARK: - Delete
    func deleteRentPayment(id: String) async throws
    
    // MARK: - Stats & Summary
    func calculateTotalPaidRent(forMonth date: Date) async throws -> Double
    func calculateTotalUnpaidRent() async throws -> Double
    func getLatePayments() async throws -> [RentPaymentModel]
    func getUpcomingPayments(withinDays days: Int) async throws -> [RentPaymentModel]
    
    // MARK: - Auto Payment Creation
    func ensureRentPaymentsExist(property: PropertyModel) async throws
    func ensureRentPaymentsExistForMonth(date: Date) async throws
    func fetchOrCreateRentPaymentsForMonth(date: Date) async throws -> [RentPaymentModel]
}

// MARK: - Helper Extensions
extension RentPaymentService {
    func createRentPaymentsForProperty(_ property: PropertyModel) async throws {
        guard let rentStartDate = property.rentStartDate else {
            print("Debug: \(String(localized: "debug_no_rent_start_date"))")
            return
        }
        let contractMonths = property.contractTime.rawValue
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month], from: rentStartDate)
        guard let startOfMonth = calendar.date(from: components) else {
            print("Debug: \(String(localized: "debug_failed_start_month"))")
            return
        }
        var currentDate = startOfMonth
        for _ in 0..<contractMonths {
            let existingPayments = try await fetchRentPayments(forMonth: currentDate)
            if existingPayments.isEmpty {
                let payment = RentPaymentModel(
                    id: UUID(),
                    userId: property.tenantId ?? "",
                    propertyId: property.id,
                    rentPrice: property.rentPrice ?? 0,
                    rentAmountPaid: 0,
                    rentBalance: property.rentPrice ?? 0,
                    whichMonth: currentDate,
                    rentPaymentStatus: .unpaid,
                    paymentDay: .first,
                    paymentDescription: nil,
                    paidDate: nil
                )
                try await createRentPayment(payment)
            }
            currentDate = calendar.date(byAdding: .month, value: 1, to: currentDate)!
        }
    }
}

// MARK: - RentPayment Errors
enum RentPaymentError: LocalizedError {
    case invalidData
    case notFound
    case invalidProperty
    case invalidAmount
    case unauthorized
    case alreadyPaid
    case unknown
    
    var errorDescription: String? {
        switch self {
        case .invalidData:
            return String(localized: "rent_payment_error_invalid_data")
        case .notFound:
            return String(localized: "rent_payment_error_not_found")
        case .invalidProperty:
            return String(localized: "rent_payment_error_invalid_property")
        case .invalidAmount:
            return String(localized: "rent_payment_error_invalid_amount")
        case .unauthorized:
            return String(localized: "rent_payment_error_unauthorized")
        case .alreadyPaid:
            return String(localized: "rent_payment_error_already_paid")
        case .unknown:
            return String(localized: "rent_payment_error_unknown")
        }
    }
}
