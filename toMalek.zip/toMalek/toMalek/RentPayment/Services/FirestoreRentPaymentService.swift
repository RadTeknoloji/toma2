//
//  FirestoreRentPaymentService.swift
//  toMalek
//
//  Created by Selman Erbay on 19.01.2025.
//

import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

final class FirestoreRentPaymentService: RentPaymentService {
    private let db = Firestore.firestore()
    private let collection = "rentPayments"
    private let propertyService: PropertyService
    
    private var currentUserId: String? {
        Auth.auth().currentUser?.uid
    }
    
    init(propertyService: PropertyService = ServiceContainer.shared.propertyService) {
        self.propertyService = propertyService
    }
    
    func createRentPayment(_ payment: RentPaymentModel) async throws {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        let propertyExists = try await propertyService.fetchProperty(id: payment.propertyId.uuidString) != nil
        guard propertyExists else {
            throw RentPaymentError.invalidProperty
        }
        
        let paymentRef = db.collection(collection).document(payment.id.uuidString)
        
        let data: [String: Any] = [
            "id": payment.id.uuidString,
            "userId": userId,
            "propertyId": payment.propertyId.uuidString,
            "rentPrice": payment.rentPrice,
            "rentAmountPaid": payment.rentAmountPaid,
            "rentBalance": payment.rentBalance,
            "whichMonth": Timestamp(date: payment.whichMonth),
            "rentPaymentStatus": payment.rentPaymentStatus.rawValue,
            "paymentDay": payment.paymentDay.rawValue,
            "paymentDescription": payment.paymentDescription as Any,
            "paidDate": payment.paidDate.map { Timestamp(date: $0) } as Any,
            "createdAt": FieldValue.serverTimestamp()
        ]
        
        print("Debug: \(String(localized: "debug_creating_payment_for_month")) \(payment.whichMonth)")
        try await paymentRef.setData(data)
    }
    
    func fetchRentPayments() async throws -> [RentPaymentModel] {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        print("Debug: \(String(localized: "debug_fetching_payments_for_user")) \(userId)")
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .order(by: "whichMonth", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeRentPayment(from: document)
        }
    }
    
    func fetchRentPayment(id: String) async throws -> RentPaymentModel? {
        let document = try await db.collection(collection).document(id).getDocument()
        guard document.exists else { return nil }
        return try decodeRentPayment(from: document)
    }
    
    func fetchRentPayments(forProperty propertyId: String) async throws -> [RentPaymentModel] {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("propertyId", isEqualTo: propertyId)
            .order(by: "whichMonth", descending: true)
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeRentPayment(from: document)
        }
    }
    
    func fetchRentPayments(forMonth date: Date) async throws -> [RentPaymentModel] {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        let calendar = Calendar.current
        let startOfMonth = calendar.startOfMonth(for: date)
        let endOfMonth = calendar.endOfMonth(for: date)
        
        let snapshot = try await db.collection(collection)
            .whereField("userId", isEqualTo: userId)
            .whereField("whichMonth", isGreaterThanOrEqualTo: Timestamp(date: startOfMonth))
            .whereField("whichMonth", isLessThanOrEqualTo: Timestamp(date: endOfMonth))
            .getDocuments()
        
        return try snapshot.documents.compactMap { document in
            try decodeRentPayment(from: document)
        }
    }
    
    func ensureRentPaymentsExist(property: PropertyModel) async throws {
        guard let rentStartDate = property.rentStartDate else {
            throw RentPaymentError.invalidData
        }
        
        let rentPrice = property.rentPrice ?? 0
        if rentPrice <= 0 {
            throw RentPaymentError.invalidAmount
        }
        
        let contractMonths = property.contractTime.rawValue
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month], from: rentStartDate)
        guard let startOfMonth = calendar.date(from: components) else {
            throw RentPaymentError.invalidData
        }
        
        // Check existing payments
        let existingPayments = try await fetchRentPayments(forProperty: property.id.uuidString)
        if !existingPayments.isEmpty {
            print("Debug: \(String(localized: "debug_payments_exist"))")
            return
        }
        
        var currentDate = startOfMonth
        for _ in 0..<contractMonths {
            let payment = RentPaymentModel(
                id: UUID(),
                userId: currentUserId ?? "",
                propertyId: property.id,
                rentPrice: rentPrice,
                rentAmountPaid: 0,
                rentBalance: rentPrice,
                whichMonth: currentDate,
                rentPaymentStatus: .unpaid,
                paymentDay: .first,
                paymentDescription: nil,
                paidDate: nil
            )
            
            print("Debug: \(String(localized: "debug_creating_payment_for_month")) \(currentDate)")
            try await createRentPayment(payment)
            currentDate = calendar.date(byAdding: .month, value: 1, to: currentDate)!
        }
        print("Debug: \(String(localized: "debug_successfully_created_payments")) \(contractMonths)")
    }
    
    func ensureRentPaymentsExistForMonth(date: Date) async throws {
        let properties = try await propertyService.fetchProperties()
        for property in properties {
            try await ensureRentPaymentsExist(property: property)
        }
    }
    
    func fetchOrCreateRentPaymentsForMonth(date: Date) async throws -> [RentPaymentModel] {
        try await ensureRentPaymentsExistForMonth(date: date)
        return try await fetchRentPayments(forMonth: date)
    }
    
    func markAsPaid(_ payment: RentPaymentModel, paidDate: Date) async throws {
        var updatedPayment = payment
        updatedPayment.rentPaymentStatus = .paid
        updatedPayment.rentAmountPaid = payment.rentPrice
        updatedPayment.rentBalance = 0
        updatedPayment.paidDate = paidDate
        
        try await updateRentPayment(updatedPayment)
    }
    
    func calculateTotalPaidRent(forMonth date: Date) async throws -> Double {
        let payments = try await fetchRentPayments(forMonth: date)
        return payments.reduce(0) { $0 + $1.rentAmountPaid }
    }
    
    func calculateTotalUnpaidRent() async throws -> Double {
        let payments = try await fetchRentPayments()
        return payments.reduce(0) { $0 + $1.rentBalance }
    }
    
    func getLatePayments() async throws -> [RentPaymentModel] {
        let payments = try await fetchRentPayments()
        let today = Date()
        
        return payments.filter { payment in
            guard payment.rentPaymentStatus != .paid else { return false }
            guard let dueDate = Calendar.current.date(
                bySetting: .day,
                value: payment.paymentDay.rawValue,
                of: payment.whichMonth
            ) else { return false }
            
            return dueDate < today
        }
    }
    
    func getUpcomingPayments(withinDays days: Int) async throws -> [RentPaymentModel] {
        let payments = try await fetchRentPayments()
        let today = Date()
        let futureDate = Calendar.current.date(byAdding: .day, value: days, to: today) ?? today
        
        return payments.filter { payment in
            guard payment.rentPaymentStatus != .paid else { return false }
            guard let dueDate = Calendar.current.date(
                bySetting: .day,
                value: payment.paymentDay.rawValue,
                of: payment.whichMonth
            ) else { return false }
            
            return dueDate > today && dueDate <= futureDate
        }
    }
    
    func updateRentPayment(_ payment: RentPaymentModel) async throws {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        let document = try await db.collection(collection).document(payment.id.uuidString).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw RentPaymentError.unauthorized
        }
        
        let paymentRef = db.collection(collection).document(payment.id.uuidString)
        
        let data: [String: Any] = [
            "rentPrice": payment.rentPrice,
            "rentAmountPaid": payment.rentAmountPaid,
            "rentBalance": payment.rentBalance,
            "whichMonth": Timestamp(date: payment.whichMonth),
            "rentPaymentStatus": payment.rentPaymentStatus.rawValue,
            "paymentDay": payment.paymentDay.rawValue,
            "paymentDescription": payment.paymentDescription as Any,
            "paidDate": payment.paidDate.map { Timestamp(date: $0) } as Any,
            "updatedAt": FieldValue.serverTimestamp()
        ]
        
        try await paymentRef.updateData(data)
    }
    
    func deleteRentPayment(id: String) async throws {
        guard let userId = currentUserId else {
            throw RentPaymentError.unauthorized
        }
        
        let document = try await db.collection(collection).document(id).getDocument()
        guard let documentUserId = document.data()?["userId"] as? String,
              documentUserId == userId else {
            throw RentPaymentError.unauthorized
        }
        
        try await db.collection(collection).document(id).delete()
    }
    
    private func decodeRentPayment(from document: DocumentSnapshot) throws -> RentPaymentModel {
        guard let data = document.data() else {
            throw RentPaymentError.invalidData
        }
        
        return RentPaymentModel(
            id: UUID(uuidString: data["id"] as? String ?? "") ?? UUID(),
            userId: data["userId"] as? String ?? "",
            propertyId: UUID(uuidString: data["propertyId"] as? String ?? "") ?? UUID(),
            rentPrice: data["rentPrice"] as? Double ?? 0,
            rentAmountPaid: data["rentAmountPaid"] as? Double ?? 0,
            rentBalance: data["rentBalance"] as? Double ?? 0,
            whichMonth: (data["whichMonth"] as? Timestamp)?.dateValue() ?? Date(),
            rentPaymentStatus: RentPaymentStatus(rawValue: data["rentPaymentStatus"] as? String ?? "") ?? .unpaid,
            paymentDay: PaymentDay(rawValue: data["paymentDay"] as? Int ?? 1) ?? .first,
            paymentDescription: data["paymentDescription"] as? String,
            paidDate: (data["paidDate"] as? Timestamp)?.dateValue()
        )
    }
}

private extension Calendar {
    func startOfMonth(for date: Date) -> Date {
        let components = dateComponents([.year, .month], from: date)
        return self.date(from: components) ?? date
    }
    
    func endOfMonth(for date: Date) -> Date {
        var components = DateComponents()
        components.month = 1
        components.second = -1
        return self.date(byAdding: components, to: startOfMonth(for: date)) ?? date
    }
}
