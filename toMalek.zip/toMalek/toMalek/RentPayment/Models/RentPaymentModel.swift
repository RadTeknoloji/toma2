//
//  RentPaymentModel.swift
//  toMalek
//
//  Created by Selman Erbay on 18.01.2025.
//

import Foundation

struct RentPaymentModel: Codable, Identifiable {
    let id: UUID
    let userId: String
    let propertyId: UUID
    
    // Rent amount information
    var rentPrice: Double
    var rentAmountPaid: Double
    var rentBalance: Double
    
    // Payment details
    var whichMonth: Date
    var rentPaymentStatus: RentPaymentStatus
    var paymentDay: PaymentDay
    var paymentDescription: String?
    var paidDate: Date?
    var mediaUrls: [String]
    
    // Computed property
    var isLate: Bool {
        guard let paid = paidDate else { return false }
        let calendar = Calendar.current
        let paymentDayInt = paymentDay.rawValue
        let paidDayInt = calendar.component(.day, from: paid)
        return paidDayInt > paymentDayInt
    }
    
    // MARK: - Custom Initializer
    init(
        id: UUID = UUID(),
        userId: String,
        propertyId: UUID,
        rentPrice: Double,
        rentAmountPaid: Double = 0,
        rentBalance: Double? = nil,
        whichMonth: Date,
        rentPaymentStatus: RentPaymentStatus = .unpaid,
        paymentDay: PaymentDay,
        paymentDescription: String? = nil,
        paidDate: Date? = nil,
        mediaUrls: [String] = []
    ) {
        self.id = id
        self.userId = userId
        self.propertyId = propertyId
        self.rentPrice = rentPrice
        self.rentAmountPaid = rentAmountPaid
        self.rentBalance = rentBalance ?? (rentPrice - rentAmountPaid)
        self.whichMonth = whichMonth
        self.rentPaymentStatus = rentPaymentStatus
        self.paymentDay = paymentDay
        self.paymentDescription = paymentDescription
        self.paidDate = paidDate
        self.mediaUrls = mediaUrls
    }
    
    // MARK: - Helper Methods
    func formattedMonth() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM yyyy"
        dateFormatter.locale = Locale.current
        return dateFormatter.string(from: whichMonth)
    }
    
    func formattedPaidDate() -> String {
        guard let paid = paidDate else {
            return String(localized: "rent_payment_not_paid")
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .short
        dateFormatter.locale = Locale.current
        return dateFormatter.string(from: paid)
    }
    
    func formattedRentPrice() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(from: NSNumber(value: rentPrice)) ?? String(format: "%.2f", rentPrice)
    }
    
    func formattedRentBalance() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(from: NSNumber(value: rentBalance)) ?? String(format: "%.2f", rentBalance)
    }
    
    func formattedPaymentDay() -> String {
        return String(localized: "rent_payment_day_\(paymentDay.rawValue)")
    }
    
    func paymentStatusColor() -> String {
        switch rentPaymentStatus {
        case .unpaid:
            return isLate ? "red" : "orange"
        case .partiallyPaid:
            return "blue"
        case .paid:
            return "green"
        }
    }

    func paymentStatusText() -> String {
        switch rentPaymentStatus {
        case .unpaid:
            return isLate ?
                String(localized: "rent_payment_status_late") :
                String(localized: "rent_payment_status_unpaid")
        case .partiallyPaid:
            return String(localized: "rent_payment_status_partially_paid")
        case .paid:
            return String(localized: "rent_payment_status_paid")
        }
    }
}
