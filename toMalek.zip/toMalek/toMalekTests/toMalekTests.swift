//
//  toMalekTests.swift
//  toMalekTests
//
//  Created by Selman Erbay on 19.01.2025.
//

import XCTest
@testable import toMalek

final class toMalekTests: XCTestCase {
    override func setUpWithError() throws {
        // Test başlamadan önce çağrılır
        // Gerekli setup işlemleri burada yapılır
    }

    override func tearDownWithError() throws {
        // Her test sonrası çağrılır
        // Temizlik işlemleri burada yapılır
    }

    func testExample() async throws {
        // Test case'leri buraya yazılır
        XCTAssert(true)
    }

    func testPerformanceExample() throws {
        measure {
            // Performance test'leri buraya yazılır
        }
    }
}
